import React from "react";
import ModuleCardProduct1 from "../detail/modules/DealOfDay/ModuleDealOfDayCardProduct1";

const ProductDealOfDaySlider1 = ({ product }) => {
  return (
    <div className="" style={{ margin: "5px" }}>
      <ModuleCardProduct1 product={product} />
    </div>
  );
};

export default ProductDealOfDaySlider1;
