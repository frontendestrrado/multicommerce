webpackHotUpdate_N_E("pages/_app",{

/***/ "./repositories/AccountRepository.js":
/*!*******************************************!*\
  !*** ./repositories/AccountRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");





const modalOpen = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message,
    description
  });
};

class AccountRepository {
  async getUserPurchaseYears(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/year`, payload).then(response => {
      return response.data;
    }).catch(err => {
      modalOpen("error", "Error", "Error Fetching Years from Server");
    });
    return response;
  }

  async changePassword(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/password/change`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async registerNewUser(payload) {
    alert("d");
    console.log("....555...", payload);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async editCustomerProfile(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(function (response) {
      return response.data;
    }).catch(function (response) {
      console.log(response);
      return response.data;
    });
    return response;
  }

  async getCountry() {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/country`).then(response => {
      if (response.data.httpcode == 200) {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getChatList(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/list`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getChatMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/message`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/send`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getState(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/state`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getCity(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/city`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getMyOrders(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/mypurchase`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async cancelOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/response/cancel/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getOrderDetails(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getCustomerProfileDetail({ access_token }) {


  async getCustomerProfileDetail() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/profile`, {
      access_token,
      lang_id: 1
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateCustomerProfileDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerRecentViews(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/recent/views`, {
      access_token,
      lang_id: 1
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerAddresses() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/address`, {
      access_token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async makeDefaultAddresses(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    userUpdateFormData.append("is_default", payload.default);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/default/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteAddress(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/remove/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/return/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnShipmentDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/return/shipment`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => response.error);
    return response;
  }

  async listSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/list-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async supportMessageByID(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/support-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async addTicketMessage(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-ticket-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getWalletDetails(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/wallet/amount`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionCartData(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getUserNotification(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/view/notifications`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionOrderList(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/order/list`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/send/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/verify/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyForgotOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/login/forgot/verify-otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new AccountRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/CartRepository.js":
/*!****************************************!*\
  !*** ./repositories/CartRepository.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");




class CartRepository {
  async addProductToCart({
    access_token,
    product,
    quantity,
    cart_type
  }) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/add-cart`, {
      access_token,
      product_id: product.product_id,
      quantity,
      cart_type
    }).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      }

      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCartItem(payload) {
    // alert("d")
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__["getDeviceId"]);
    console.log("....bbbbb...bbb...", payload);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }); // alert("3333")

    console.log("....bbbbb...bbb..444444444444.", response).then(response => {
      //   alert("44444444")
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async fetchPlatformVoucher() {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/platform`, {
      lang_id: ""
    }).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async checkPlatformVoucher(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/platform`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async checkSellerVoucher(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/seller`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new CartRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Homeapi.js":
/*!*********************************!*\
  !*** ./repositories/Homeapi.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");




class Homeapi {
  async getHomedata(pathName) {
    let payload = {
      access_token: "",
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["getDeviceId"],
      page_url: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["makePageUrl"])("/"),
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["osType"])()
    };
    const CancelToken = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken;
    let source = CancelToken.source();
    source && source.cancel("Operation canceled due to new request."); // save the new request for cancellation

    source = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken.source();
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/home`, payload, {
      cancelToken: source.token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    })); // cancel the request (the message parameter is optional)

    source.cancel("Operation canceled by the user.");
    return reponse;
  }

  async submitReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-product-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async submitSellerReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-seller-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getHomedata() {
  //   const response = await axios
  //     .get(`https://estrradoweb.com/kangtao/api/customer/home`, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     })
  //     .then((response) => response.data)
  //     .catch((error) => error);
  //   return response;
  // }


}

/* harmony default export */ __webpack_exports__["default"] = (new Homeapi());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/ProductRepository.js":
/*!*******************************************!*\
  !*** ./repositories/ProductRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");



class ProductRepository {
  async getRecords(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(params)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getSearchedProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-search`, {
      lang_id: "",
      category_id: params.category_id,
      keyword: params.title_contains
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.no_of_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list?page=` + params.page, {
      lang_id: 1,
      access_token: "",
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: "https://abc.com/products/us/img",
      os_type: "WEB"
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list-filter?page=` + payload.page, payload).then(response => {
      console.log("############", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getBrands() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/brand`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductCategories() {
    // const reponse = await Repository.get(`${baseUrl}/product-categories`)
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cat-subcat`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getTotalRecords() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products/count`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsById(id) {
    console.log("....dddddd..1..", id);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("....dddddd..1.userdata.", userdata);
    console.log("....dddddd..1..parsedata", parsedata);
    console.log("....dddddd..1.access_token.", access_token);
    console.log("....dddddd..1.getDeviceId.", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"]);
    console.log("....dddddd..1.access_token.", access_token);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-detail`, {
      access_token,
      id,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["basePathUrl"]}/product/${id}`,
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["osType"])()
    }).then(response => {
      console.log("....dddddd....", response);
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getShockSaleByid(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getProductsByCategory(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/product-categories?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrand(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByPriceRange(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(payload)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addProductToCart(payload) {
    console.log(".....56565656565656...", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async changeQty(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart/change-qty`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeOrder(payload) {
    console.log("......3333333333.......", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/placeorder`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCart(payload) {
    console.log("....aaaa....", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteCart(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/delete-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getAuctionProductByAuctionId(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createBid(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-bid`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShopDetailById(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shop-detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCheckoutInfo(payload) {
    console.log("...getCheckoutInfo... apyload..", payload);
    console.log("...getCheckoutInfo... apibaseurl..", _Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/checkout-info`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeAuctionOrder(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/checkout`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new ProductRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Repository.js":
/*!************************************!*\
  !*** ./repositories/Repository.js ***!
  \************************************/
/*! exports provided: basePostUrl, baseStoreURL, apibaseurl, basePathUrl, customHeaders, baseUrl, default, serializeQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePostUrl", function() { return basePostUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseStoreURL", function() { return baseStoreURL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "apibaseurl", function() { return apibaseurl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePathUrl", function() { return basePathUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customHeaders", function() { return customHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "serializeQuery", function() { return serializeQuery; });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseDomain = "https://beta.apinouthemes.com"; // API for products

const basePostUrl = "https://beta.apinouthemes.com"; // API for post

const baseStoreURL = "https://beta.apinouthemes.com"; // API for vendor(store)

let apibaseurlCustom = "https://dev-bigbasket.estrradoweb.com";
let basePath = "https://dev-kangtao.vercel.app";

if (true) {
  if (window.location.hostname == "uat-kangtao.vercel.app") {
    apibaseurlCustom = "https://uat-kt.estrradoweb.com";
    basePath = "https://uat-kangtao.vercel.app";
  }

  if (window.location.hostname == "qa-kangtao.vercel.app") {
    apibaseurlCustom = "https://qa-kt.estrradoweb.com";
    basePath = "https://qa-kangtao.vercel.app";
  }
}

const apibaseurl = apibaseurlCustom;
const basePathUrl = basePath;
const customHeaders = {
  Accept: "application/json"
};
const baseUrl = `${baseDomain}`;
/* harmony default export */ __webpack_exports__["default"] = (axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseUrl,
  headers: customHeaders
}));
const serializeQuery = query => {
  return Object.keys(query).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`).join("&");
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/account/saga.js":
/*!*******************************!*\
  !*** ./store/account/saga.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/repositories/AccountRepository */ "./repositories/AccountRepository.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./action */ "./store/account/action.js");
/* harmony import */ var _auth_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth/action */ "./store/auth/action.js");








const modalSuccess = type => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message: "Wellcome",
    description: "You are logged in successfully!"
  });
};

const modalOpen = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message,
    description
  });
};

function* getMyOrdersSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getMyOrders, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(response.httpcode == 200 && Object(_action__WEBPACK_IMPORTED_MODULE_5__["getMyOrdersSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerProfile({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerProfileDetail, payload);

    if (response.httpcode == 401) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Invalid Access Token! Login Again");
      next_router__WEBPACK_IMPORTED_MODULE_4___default.a.push("/account/login");
      yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_auth_action__WEBPACK_IMPORTED_MODULE_6__["logOut"])());
    }

    if (response.httpcode == 200) {
      yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerProfileSuccess"])(response.data));
    }
  } catch (err) {
    console.log(err);
  }
}

function* updateCustomerProfile({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].updateCustomerProfileDetail, payload);

    if (response.httpcode == 401) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Invalid Access Token! Login Again");
    }

    if (response.httpcode == 200 && response.data.success) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success("Profile updated successfully!");
    }

    if (response.error) {
      response.error.map(error => {
        antd__WEBPACK_IMPORTED_MODULE_3__["notification"]["error"]({
          message: error
        });
      });
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(getCustomerProfile());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["updateCustomerProfileSuccess"])(response));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerRecentViewsSlug({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerRecentViews, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerRecentViewsSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerAddressSlug() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerAddresses);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddressSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* makeDefaultAddressSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].makeDefaultAddresses, payload);

    if (response.httpcode == "200") {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success(response.data.message);
    } else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error Updating Default Address!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* deleteAddressSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].deleteAddress, payload);

    if (response.httpcode == "200") {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success(response.data.message);
    } else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error Deleting Address!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* addAddressSaga({
  payload
}) {
  try {
    // const response = yield call(AccountRepository.addAddress, payload);
    // if (response.httpcode == "200") {
    //   message.success(response.data.message);
    // } else {
    //   message.error("Error Updating Address!");
    // }
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* getChatListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getChatList, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Fetching Chats!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerChatListSuccess"])(response.data.list));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerChatMessageSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getChatMessage, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Fetching Chats!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerChatMessageSuccess"])(response.data.messages));
  } catch (err) {
    console.log(err);
  }
}

function* sendMessageToSellerSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].sendMessage, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Sending Message!");
    } // yield put(getCustomerChatMessageSuccess(response.data.messages));

  } catch (err) {
    console.log(err);
  }
}

function* getOrderDetailsSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getOrderDetails, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error(response.message);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getOrderDetailsSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* cancelOrderRequestSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].cancelOrderRequest, payload);
    let data_payload = {
      access_token: payload.access_token,
      lang_id: "1"
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getMyOrders"])(data_payload));
  } catch (err) {
    console.log(err);
  }
}

function* getTokenListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].listSupportToken, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getTokenListSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getSupportMessageSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].supportMessageByID, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getSupportMessagefromSupportIdSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getUserWalletDetails({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getWalletDetails, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getWalletDetailsSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Wallet Data");
    console.log(err);
  }
}

function* getAuctionDataSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getAuctionCartData, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getAuctionCartDataSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Auction Data");
    console.log(err);
  }
}

function* getAuctionOrderListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getAuctionOrderList, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getAuctionOrderListSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Auction Data");
    console.log(err);
  }
}

function* getCountryDataSaga() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCountry);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCountryDataSuccess"])(response));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Country Data");
    console.log(err);
  }
}

function* getUserNotificationSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getUserNotification, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getUserNotificationsSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Notifications");
  }
}

function* getPurchaseYear({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getUserPurchaseYears, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(response.httpcode == 200 && Object(_action__WEBPACK_IMPORTED_MODULE_5__["getUserPurchaseYearSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Years!");
  }
}

function* rootSaga() {
  // yield all([
  //   takeEvery(actionTypes.GET_NEW_SELLER_CHATS, getNewSellerChatsSaga),
  // ]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_CHAT_MESSAGE, getCustomerChatMessageSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].SEND_MESSAGE_TO_SELLER, sendMessageToSellerSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_CHAT_LIST, getChatListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_MY_ORDERS, getMyOrdersSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_PROFILE, getCustomerProfile)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].UPDATE_CUSTOMER_PROFILE, updateCustomerProfile)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_RECENT_VIEWS, getCustomerRecentViewsSlug)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_ADDRESS, getCustomerAddressSlug)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].MAKE_DEFAULT_ADDRESS, makeDefaultAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].ADD_ADDRESS, addAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].DELETE_ADDRESS, deleteAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_ORDER_DETAILS, getOrderDetailsSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].MAKE_CANCEL_ORDER_REQUEST, cancelOrderRequestSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_TOKEN_LIST, getTokenListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_SUPPORT_MESSAGE_BY_SUPPORT_ID, getSupportMessageSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_WALLET_DETAILS, getUserWalletDetails)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_AUCTION_CART_DATA, getAuctionDataSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_AUCTION_ORDER_LIST, getAuctionOrderListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_COUNTRY_DATA, getCountryDataSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_USER_NOTIFICATION, getUserNotificationSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_USER_PURCHASE_YEARS, getPurchaseYear)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/action.js":
/*!******************************!*\
  !*** ./store/cart/action.js ***!
  \******************************/
/*! exports provided: actionTypes, removeProductFromCartNew, selectedPaymentOption, sellerWiseMessage, usedWalletAmount, sellerWiseDiscount, grandTotalWithDiscountValue, appliedSellerVoucher, appliedPlatformVoucher, totalDiscount, fetchPlatformVoucherAction, fetchPlatformVoucherActionSuccess, getCart, getCartSuccess, getCartError, updateSelectedAddress, addItem, removeItem, increaseItemQty, decreaseItemQty, updateCartSuccess, updateCartError, clearCart, clearCartSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "actionTypes", function() { return actionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeProductFromCartNew", function() { return removeProductFromCartNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedPaymentOption", function() { return selectedPaymentOption; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseMessage", function() { return sellerWiseMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "usedWalletAmount", function() { return usedWalletAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseDiscount", function() { return sellerWiseDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "grandTotalWithDiscountValue", function() { return grandTotalWithDiscountValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedSellerVoucher", function() { return appliedSellerVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedPlatformVoucher", function() { return appliedPlatformVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalDiscount", function() { return totalDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherAction", function() { return fetchPlatformVoucherAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherActionSuccess", function() { return fetchPlatformVoucherActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCart", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartSuccess", function() { return getCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartError", function() { return getCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSelectedAddress", function() { return updateSelectedAddress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addItem", function() { return addItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeItem", function() { return removeItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "increaseItemQty", function() { return increaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decreaseItemQty", function() { return decreaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartSuccess", function() { return updateCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartError", function() { return updateCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCart", function() { return clearCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCartSuccess", function() { return clearCartSuccess; });
const actionTypes = {
  GET_CART: "GET_CART",
  GET_CART_SUCCESS: "GET_CART_SUCCESS",
  GET_CART_ERROR: "GET_CART_ERROR",
  GET_CART_TOTAL_QUANTITY: "GET_CART_TOTAL_QUANTITY",
  GET_CART_TOTAL_QUANTITY_SUCCESS: "GET_CART_TOTAL_QUANTITY_SUCCESS",
  ADD_ITEM: "ADD_ITEM",
  REMOVE_ITEM: "REMOVE_ITEM",
  REMOVE_PRODUCT_FROM_CART_NEW: "REMOVE_PRODUCT_FROM_CART_NEW",
  CLEAR_CART: "CLEAR_CART",
  CLEAR_CART_SUCCESS: "CLEAR_CART_SUCCESS",
  CLEAR_CART_ERROR: "CLEAR_CART_ERROR",
  INCREASE_QTY: "INCREASE_QTY",
  INCREASE_QTY_SUCCESS: "INCREASE_QTY_SUCCESS",
  INCREASE_QTY_ERROR: "INCREASE_QTY_ERROR",
  DECREASE_QTY: "DECREASE_QTY",
  UPDATE_CART: "UPDATE_CART",
  UPDATE_CART_SUCCESS: "UPDATE_CART_SUCCESS",
  UPDATE_CART_ERROR: "UPDATE_CART_ERROR",
  UPDATE_SELECTED_ADDRESS: "UPDATE_SELECTED_ADDRESS",
  FETCH_PLATFORM_VOUCHER: "FETCH_PLATFORM_VOUCHER",
  FETCH_PLATFORM_VOUCHER_SUCCESS: "FETCH_PLATFORM_VOUCHER_SUCCESS",
  TOTAL_DISCOUNT: "TOTAL_DISCOUNT",
  APPLIED_SELLER_VOUCHER: "APPLIED_SELLER_VOUCHER",
  APPLIED_PLATFORM_VOUCHER: "APPLIED_PLATFORM_VOUCHER",
  GRAND_TOTAL_WITH_DISCOUNT_VALUE: "GRAND_TOTAL_WITH_DISCOUNT_VALUE",
  SELLER_WISE_DISCOUNT: "SELLER_WISE_DISCOUNT",
  SELLER_WISE_MESSAGES: "SELLER_WISEMESSAGES",
  USED_WALLET_AMOUNT: "USED_WALLET_AMOUNT",
  SELECTED_PAYMENT_OPTION_BY_USER: "SELECTED_PAYMENT_OPTION_BY_USER"
};
function removeProductFromCartNew(payload) {
  return {
    type: actionTypes.REMOVE_PRODUCT_FROM_CART_NEW,
    payload
  };
}
function selectedPaymentOption(payload) {
  return {
    type: actionTypes.SELECTED_PAYMENT_OPTION_BY_USER,
    payload
  };
}
function sellerWiseMessage(payload) {
  return {
    type: actionTypes.SELLER_WISE_MESSAGES,
    payload
  };
}
function usedWalletAmount(payload) {
  return {
    type: actionTypes.USED_WALLET_AMOUNT,
    payload
  };
}
function sellerWiseDiscount(payload) {
  return {
    type: actionTypes.SELLER_WISE_DISCOUNT,
    payload
  };
}
function grandTotalWithDiscountValue(payload) {
  return {
    type: actionTypes.GRAND_TOTAL_WITH_DISCOUNT_VALUE,
    payload
  };
}
function appliedSellerVoucher(payload) {
  return {
    type: actionTypes.APPLIED_SELLER_VOUCHER,
    payload
  };
}
function appliedPlatformVoucher(payload) {
  return {
    type: actionTypes.APPLIED_PLATFORM_VOUCHER,
    payload
  };
}
function totalDiscount(payload) {
  return {
    type: actionTypes.TOTAL_DISCOUNT,
    payload
  };
}
function fetchPlatformVoucherAction() {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER
  };
}
function fetchPlatformVoucherActionSuccess(payload) {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER_SUCCESS,
    payload
  };
}
function getCart() {
  alert("getCart");
  return {
    type: actionTypes.GET_CART
  };
}
function getCartSuccess(payload) {
  return {
    type: actionTypes.GET_CART_SUCCESS,
    payload
  };
}
function getCartError(error) {
  return {
    type: actionTypes.GET_CART_ERROR,
    error
  };
}
function updateSelectedAddress(payload) {
  alert("call");
  console.log("..555555....", payload);
  return {
    type: actionTypes.UPDATE_SELECTED_ADDRESS,
    payload
  };
}
function addItem(payload) {
  return {
    type: actionTypes.ADD_ITEM,
    payload
  };
}
function removeItem(product) {
  return {
    type: actionTypes.REMOVE_ITEM,
    product
  };
}
function increaseItemQty(product) {
  return {
    type: actionTypes.INCREASE_QTY,
    product
  };
}
function decreaseItemQty(product) {
  return {
    type: actionTypes.DECREASE_QTY,
    product
  };
}
function updateCartSuccess(payload) {
  return {
    type: actionTypes.UPDATE_CART_SUCCESS,
    payload
  };
}
function updateCartError(payload) {
  return {
    type: actionTypes.UPDATE_CART_ERROR,
    payload
  };
}
function clearCart() {
  return {
    type: actionTypes.CLEAR_CART
  };
}
function clearCartSuccess() {
  return {
    type: actionTypes.CLEAR_CART_SUCCESS
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/saga.js":
/*!****************************!*\
  !*** ./store/cart/saga.js ***!
  \****************************/
/*! exports provided: calculateAmount, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateAmount", function() { return calculateAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./action */ "./store/cart/action.js");
/* harmony import */ var _repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/CartRepository */ "./repositories/CartRepository.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");







const modalSuccess = (type, message) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description: "This product has been added to your cart!",
    duration: 1
  });
};

const modalWarning = type => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Remove A Item",
    description: "This product has been removed from your cart!",
    duration: 1
  });
};

const calculateAmount = obj => Object.values(obj).reduce((acc, {
  quantity,
  price
}) => acc + quantity * price, 0).toFixed(2);

function* getCartSaga() {
  alert("bbbbb");

  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let lang_id = 1;
    let payload = {
      access_token,
      lang_id
    };
    console.log("...getCartSaga..payload...", payload);
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].getCartItem, payload);
    console.log("...getCartSaga..payload...", payload);
    console.log("......abcd.....", response);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartSuccess"])(response.data));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* addItemSaga({
  payload
}) {
  alert("aaaaaaaaaaa");

  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].addProductToCart, payload);
    modalSuccess(response.status, response.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCart"])(payload.access_token));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* removeItemSaga(payload) {
  try {
    const {
      product
    } = payload;
    let localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let index = localCart.cartItems.findIndex(item => item.id === product.id);
    localCart.cartTotal = localCart.cartTotal - product.quantity;
    localCart.cartItems.splice(index, 1);
    localCart.amount = calculateAmount(localCart.cartItems);

    if (localCart.cartItems.length === 0) {
      localCart.cartItems = [];
      localCart.amount = 0;
      localCart.cartTotal = 0;
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
    modalWarning("warning");
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* increaseQtySaga(payload) {
  try {
    const {
      product
    } = payload;
    let localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let selectedItem = localCart.cartItems.find(item => item.id === product.id);

    if (selectedItem) {
      selectedItem.quantity++;
      localCart.cartTotal++;
      localCart.amount = calculateAmount(localCart.cartItems);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* decreaseItemQtySaga(payload) {
  try {
    const {
      product
    } = payload;
    const localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let selectedItem = localCart.cartItems.find(item => item.id === product.id);

    if (selectedItem) {
      selectedItem.quantity--;
      localCart.cartTotal--;
      localCart.amount = calculateAmount(localCart.cartItems);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* clearCartSaga() {
  try {
    const emptyCart = {
      cartItems: [],
      amount: 0,
      cartTotal: 0,
      cart: []
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["clearCartSuccess"])(emptyCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartError"])(err));
  }
}

function* fetchPlatformVoucherSaga() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].fetchPlatformVoucher);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["fetchPlatformVoucherActionSuccess"])(response.data.coupon));
  } catch (err) {}
}

function* removeFromCartNewSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_4__["default"].deleteCart, payload);

    if (response && response.httpcode == 200) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__["displayNotification"])("success", "Success", "Product Removed");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCart"])());
  } catch (err) {
    Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__["displayNotification"])("error", "Error", "Error in removing Item");
  }
}

function* rootSaga() {
  // alert("cccc")
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].GET_CART, getCartSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_ITEM, addItemSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_ITEM, removeItemSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].INCREASE_QTY, increaseQtySaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].DECREASE_QTY, decreaseItemQtySaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].CLEAR_CART, clearCartSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].FETCH_PLATFORM_VOUCHER, fetchPlatformVoucherSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_PRODUCT_FROM_CART_NEW, removeFromCartNewSaga)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/wishlist/saga.js":
/*!********************************!*\
  !*** ./store/wishlist/saga.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./action */ "./store/wishlist/action.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/repositories/WishlistRepository */ "./repositories/WishlistRepository.js");
/* harmony import */ var _product_action__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../product/action */ "./store/product/action.js");









const modalSuccess = type => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Added to wishlisht!",
    description: "This product has been added to wishlist!"
  });
};

const modalWarning = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Removed from wishlist",
    description: "This product has been removed from wishlist!"
  });
};

const modalRemoveWarning = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description
  });
};

const modalShow = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description
  });
};

function* getWishlistListSaga() {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let lang_id = 1;
    let payload = {
      access_token,
      lang_id
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].getProductToWishlist, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])((responseData === null || responseData === void 0 ? void 0 : responseData.httpcode) == "200" && Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistListSuccess"])(responseData.data));
  } catch (err) {
    console.log(err);
  }
}

function* addItemToWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product,
      type: "web"
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToWishList, payload);
    modalShow(responseData.status, responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["getProductsById"])(product));
  } catch (err) {
    console.log(err);
  }
}

function* removeItemWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].removeProductFromWishList, payload);
    modalRemoveWarning("warning", responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["getProductsById"])(product));
  } catch (err) {
    console.log(err);
  }
}

function* clearWishlistListSaga() {
  try {
    const emptyCart = {
      wishlistItems: [],
      wishlistTotal: 0
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateWishlistListSuccess"])(emptyCart));
  } catch (err) {
    console.log(err);
  }
}

function* addShockingSaleItemToWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product,
      type: "web"
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToWishList, payload);
    modalShow(responseData.status, responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["updateShockingsaleWishlist"])(true));
  } catch (err) {
    console.log(err);
  }
}

function* removeShockingSaleItemFromWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].removeProductFromWishList, payload);
    modalRemoveWarning("warning", responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["updateShockingsaleWishlist"])(false));
  } catch (err) {
    console.log(err);
  }
}

function* rootSaga() {
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].GET_WISHLIST_LIST, getWishlistListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_ITEM_WISHLISH, addItemToWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_ITEM_WISHLISH, removeItemWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_SHOCKING_SALE_ITEM_TO_WISHLIST, addShockingSaleItemToWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_SHOCKING_SALE_ITEM_FROM_WISHLIST, removeShockingSaleItemFromWishlistSaga)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./utilities/product-helper.js":
/*!*************************************!*\
  !*** ./utilities/product-helper.js ***!
  \*************************************/
/*! exports provided: routeWithoutRefresh, homePageProductPriceHelper, returnTotalOfCartValue, returnTotalCommission, returnTotalOfCartTaxValue, priceHelper, currencyHelperConvertToRinggit, mathFormula, divCurrency, mulCurrency, addCurrency, subCurrency, formatCurrency, getColletionBySlug, getItemBySlug, convertSlugsQueryString, StrapiProductBadge, StrapiProductPrice, StrapiProductPrice_New, featureproductprice, StrapiProductPriceExpanded, StrapiProductPriceExpandedOther, StrapiProductPriceExpandedOther1, StrapiProductThumbnail, StrapiProductThumbnailOther, StrapiProductThumbnailDetail, Shockingproductthumbnail, colorHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routeWithoutRefresh", function() { return routeWithoutRefresh; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "homePageProductPriceHelper", function() { return homePageProductPriceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartValue", function() { return returnTotalOfCartValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalCommission", function() { return returnTotalCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartTaxValue", function() { return returnTotalOfCartTaxValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "priceHelper", function() { return priceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currencyHelperConvertToRinggit", function() { return currencyHelperConvertToRinggit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mathFormula", function() { return mathFormula; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "divCurrency", function() { return divCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mulCurrency", function() { return mulCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addCurrency", function() { return addCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subCurrency", function() { return subCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatCurrency", function() { return formatCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColletionBySlug", function() { return getColletionBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getItemBySlug", function() { return getItemBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertSlugsQueryString", function() { return convertSlugsQueryString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductBadge", function() { return StrapiProductBadge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice", function() { return StrapiProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice_New", function() { return StrapiProductPrice_New; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "featureproductprice", function() { return featureproductprice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpanded", function() { return StrapiProductPriceExpanded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther", function() { return StrapiProductPriceExpandedOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther1", function() { return StrapiProductPriceExpandedOther1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnail", function() { return StrapiProductThumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailOther", function() { return StrapiProductThumbnailOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailDetail", function() { return StrapiProductThumbnailDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Shockingproductthumbnail", function() { return Shockingproductthumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorHelper", function() { return colorHelper; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "E:\\bigBasket\\utilities\\product-helper.js";

/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */






const exactMath = __webpack_require__(/*! exact-math */ "./node_modules/exact-math/dist/exact-math.node.js");

function routeWithoutRefresh(routeLink) {
  next_router__WEBPACK_IMPORTED_MODULE_5___default.a.replace(routeLink, undefined, {
    shallow: true
  });
}
function homePageProductPriceHelper(product) {
  if (product.offer_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this);
  }

  if (product.shock_sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.shock_sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this);
  }

  if (product.sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", product.actual_price ? product.actual_price : 0]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
function returnTotalOfCartValue(products) {
  let cart_total_price = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_discount_price == 0 ? next.total_actual_price : next.total_discount_price));
  }, 0);
  return cart_total_price;
}
function returnTotalCommission(products) {
  let cart_total_commission = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.commission));
  }, 0);
  return cart_total_commission;
}
function returnTotalOfCartTaxValue(products) {
  let cart_total_tax = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_tax_value));
  }, 0);
  return cart_total_tax;
}
function priceHelper(num) {
  let numberArray = num === null || num === void 0 ? void 0 : num.toString().split(",");

  if (numberArray && (numberArray === null || numberArray === void 0 ? void 0 : numberArray.length) > 0) {
    return numberArray.reduce((prev, next) => prev + next);
  } else {
    return 0;
  }
}
function currencyHelperConvertToRinggit(currencyVal) {
  return new Intl.NumberFormat("ms-MY", {
    style: "currency",
    currency: "MYR"
  }).format(priceHelper(currencyVal));
}
function mathFormula(formulaText) {
  let result = exactMath.formula(formulaText);
}
function divCurrency(firstVal, secondVal) {
  let divData = exactMath.div(priceHelper(firstVal || 0), priceHelper(secondVal || 1));
  return divData;
}
function mulCurrency(firstVal, secondVal) {
  let mulData = exactMath.mul(priceHelper(firstVal || 1), priceHelper(secondVal || 1));
  return mulData;
}
function addCurrency(currencyValFirst, currencyValSecond) {
  let addData = exactMath.add(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return addData;
}
function subCurrency(currencyValFirst, currencyValSecond) {
  let subData = exactMath.sub(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return subData;
}
function formatCurrency(num) {
  if (num !== undefined) {
    return parseFloat(num).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
  } else {}
}
function getColletionBySlug(collections, slug) {
  if (collections.length > 0) {
    const result = collections.find(item => item.slug === slug.toString());

    if (result !== undefined) {
      return result.products;
    } else {
      return [];
    }
  } else {
    return [];
  }
}
function getItemBySlug(banners, slug) {
  if (banners.length > 0) {
    const banner = banners.find(item => item.slug === slug.toString());

    if (banner !== undefined) {
      return banner;
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function convertSlugsQueryString(payload) {
  let query = "";

  if (payload.length > 0) {
    payload.forEach(item => {
      if (query === "") {
        query = `slug_in=${item}`;
      } else {
        query = query + `&slug_in=${item}`;
      }
    });
  }

  return query;
}
function StrapiProductBadge(product) {
  let view;

  if (product.badge && product.badge !== null) {
    view = product.badge.map(badge => {
      if (badge.type === "sale") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 16
        }, this);
      } else if (badge.type === "outStock") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge out-stock",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 16
        }, this);
      } else {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge hot",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 16
        }, this);
      }
    });
  }

  return view;
}
_c = StrapiProductBadge;
function StrapiProductPrice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 216,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 223,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c2 = StrapiProductPrice;
function StrapiProductPrice_New(product) {
  let view;

  if (product.sale_price !== false) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 235,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", product.actual_price]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 239,
      columnNumber: 12
    }, this);
  }

  return view;
}
_c3 = StrapiProductPrice_New;
function featureproductprice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 259,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 7
    }, this);
  }

  return view;
}
function StrapiProductPriceExpanded(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 274,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
        children: "18% off"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 275,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 272,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 280,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c4 = StrapiProductPriceExpanded;
function StrapiProductPriceExpandedOther(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.offer_price ? product.offer_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.actual_price ? product.actual_price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 292,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 295,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 290,
    columnNumber: 5
  }, this);
  return view;
}
_c5 = StrapiProductPriceExpandedOther;
function StrapiProductPriceExpandedOther1(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.sale_price ? product.sale_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.price ? product.price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 307,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 310,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 305,
    columnNumber: 5
  }, this);
  return view;
}
_c6 = StrapiProductPriceExpandedOther1;
function StrapiProductThumbnail(product) {
  let view;

  if (product.thumbnail) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: `${_repositories_Repository__WEBPACK_IMPORTED_MODULE_3__["baseUrl"]}${product.thumbnail.url}`,
            alt: product.title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 323,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 322,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 338,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 337,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 336,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 335,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c7 = StrapiProductThumbnail;
function StrapiProductThumbnailOther(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 356,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 355,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 353,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 371,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 370,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 368,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c8 = StrapiProductThumbnailOther;
function StrapiProductThumbnailDetail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$2;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
            alt: product.product_name,
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 393,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 392,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 391,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 409,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 408,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 407,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 406,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c9 = StrapiProductThumbnailDetail;
function Shockingproductthumbnail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$3;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$3 = product.image[0]) === null || _product$image$3 === void 0 ? void 0 : _product$image$3.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 432,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 431,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 430,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 429,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 447,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 446,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 445,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 444,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c10 = Shockingproductthumbnail;
function colorHelper() {
  console.log("hello");
}

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;

$RefreshReg$(_c, "StrapiProductBadge");
$RefreshReg$(_c2, "StrapiProductPrice");
$RefreshReg$(_c3, "StrapiProductPrice_New");
$RefreshReg$(_c4, "StrapiProductPriceExpanded");
$RefreshReg$(_c5, "StrapiProductPriceExpandedOther");
$RefreshReg$(_c6, "StrapiProductPriceExpandedOther1");
$RefreshReg$(_c7, "StrapiProductThumbnail");
$RefreshReg$(_c8, "StrapiProductThumbnailOther");
$RefreshReg$(_c9, "StrapiProductThumbnailDetail");
$RefreshReg$(_c10, "Shockingproductthumbnail");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVwb3NpdG9yaWVzL0FjY291bnRSZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvQ2FydFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9Ib21lYXBpLmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9zdG9yZS9hY2NvdW50L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3N0b3JlL2NhcnQvYWN0aW9uLmpzIiwid2VicGFjazovL19OX0UvLi9zdG9yZS9jYXJ0L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3N0b3JlL3dpc2hsaXN0L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlci5qcyJdLCJuYW1lcyI6WyJtb2RhbE9wZW4iLCJ0eXBlIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwibm90aWZpY2F0aW9uIiwiQWNjb3VudFJlcG9zaXRvcnkiLCJnZXRVc2VyUHVyY2hhc2VZZWFycyIsInBheWxvYWQiLCJyZXNwb25zZSIsIlJlcG9zaXRvcnkiLCJwb3N0IiwiYXBpYmFzZXVybCIsInRoZW4iLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJjaGFuZ2VQYXNzd29yZCIsImh0dHBjb2RlIiwiY29uc29sZSIsImxvZyIsInJlZ2lzdGVyTmV3VXNlciIsImFsZXJ0IiwiZWRpdEN1c3RvbWVyUHJvZmlsZSIsImdldENvdW50cnkiLCJnZXRDaGF0TGlzdCIsIkF4aW9zIiwibWV0aG9kIiwidXJsIiwiaGVhZGVycyIsImVycm9yIiwiSlNPTiIsInN0cmluZ2lmeSIsImdldENoYXRNZXNzYWdlIiwic2VuZE1lc3NhZ2UiLCJnZXRTdGF0ZSIsImdldENpdHkiLCJnZXRNeU9yZGVycyIsInJlcG9uc2UiLCJjYW5jZWxPcmRlclJlcXVlc3QiLCJnZXRPcmRlckRldGFpbHMiLCJnZXRDdXN0b21lclByb2ZpbGVEZXRhaWwiLCJ1c2VyZGF0YSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJwYXJzZWRhdGEiLCJwYXJzZSIsImFjY2Vzc190b2tlbiIsImxhbmdfaWQiLCJ1cGRhdGVDdXN0b21lclByb2ZpbGVEZXRhaWwiLCJnZXRDdXN0b21lclJlY2VudFZpZXdzIiwiZ2V0Q3VzdG9tZXJBZGRyZXNzZXMiLCJtYWtlRGVmYXVsdEFkZHJlc3NlcyIsInVzZXJVcGRhdGVGb3JtRGF0YSIsIkZvcm1EYXRhIiwiYXBwZW5kIiwiYWRkcmVzc19pZCIsImRlZmF1bHQiLCJkZWxldGVBZGRyZXNzIiwiYWRkQWRkcmVzcyIsInVwZGF0ZUFkZHJlc3MiLCJyZXR1cm5PcmRlclJlcXVlc3QiLCJyZXR1cm5TaGlwbWVudERldGFpbCIsImNyZWF0ZVN1cHBvcnRUb2tlbiIsImxpc3RTdXBwb3J0VG9rZW4iLCJzdXBwb3J0TWVzc2FnZUJ5SUQiLCJhZGRUaWNrZXRNZXNzYWdlIiwiZ2V0V2FsbGV0RGV0YWlscyIsImdldEF1Y3Rpb25DYXJ0RGF0YSIsImdldFVzZXJOb3RpZmljYXRpb24iLCJnZXRBdWN0aW9uT3JkZXJMaXN0Iiwic2VuZFJlZ2lzdGVyTW9iaWxlT1RQIiwidmVyaWZ5UmVnaXN0ZXJNb2JpbGVPVFAiLCJ2ZXJpZnlGb3Jnb3RPVFAiLCJDYXJ0UmVwb3NpdG9yeSIsImFkZFByb2R1Y3RUb0NhcnQiLCJwcm9kdWN0IiwicXVhbnRpdHkiLCJjYXJ0X3R5cGUiLCJwcm9kdWN0X2lkIiwiZ2V0Q2FydEl0ZW0iLCJnZXREZXZpY2VJZCIsInVzZXJfdG9rZW4iLCJkZXZpY2VfaWQiLCJwYWdlX3VybCIsIm9zX3R5cGUiLCJmZXRjaFBsYXRmb3JtVm91Y2hlciIsImNoZWNrUGxhdGZvcm1Wb3VjaGVyIiwiY2hlY2tTZWxsZXJWb3VjaGVyIiwiSG9tZWFwaSIsImdldEhvbWVkYXRhIiwicGF0aE5hbWUiLCJtYWtlUGFnZVVybCIsIm9zVHlwZSIsIkNhbmNlbFRva2VuIiwiYXhpb3MiLCJzb3VyY2UiLCJjYW5jZWwiLCJjYW5jZWxUb2tlbiIsInRva2VuIiwic3VibWl0UmV2aWV3Iiwic3VibWl0U2VsbGVyUmV2aWV3IiwiUHJvZHVjdFJlcG9zaXRvcnkiLCJnZXRSZWNvcmRzIiwicGFyYW1zIiwiZ2V0IiwiYmFzZVVybCIsInNlcmlhbGl6ZVF1ZXJ5IiwiZ2V0U2VhcmNoZWRQcm9kdWN0cyIsImNhdGVnb3J5X2lkIiwia2V5d29yZCIsInRpdGxlX2NvbnRhaW5zIiwiaXRlbXMiLCJwcm9kdWN0cyIsInRvdGFsSXRlbXMiLCJub19vZl9wcm9kdWN0cyIsImdldFByb2R1Y3RzIiwicGFnZSIsInRvdGFsX3Byb2R1Y3RzIiwiZ2V0TmV3RGVhbHNQcm9kdWN0cyIsImdldFNob2NraW5nU2FsZVByb2R1Y3RzIiwic2hvY2tfc2FsZSIsImdldEZlYXR1cmVkUHJvZHVjdHMiLCJnZXRQcm9kdWN0c2J5RmlsdGVyIiwiZ2V0TmV3RGVhbHNQcm9kdWN0c2J5RmlsdGVyIiwiZ2V0U2hvY2tpbmdTYWxlUHJvZHVjdHNieUZpbHRlciIsImdldEZlYXR1cmVkUHJvZHVjdHNieUZpbHRlciIsImdldFNob2NraW5nUHJvZHVjdHMiLCJnZXRCcmFuZHMiLCJnZXRQcm9kdWN0Q2F0ZWdvcmllcyIsImdldFRvdGFsUmVjb3JkcyIsImdldFByb2R1Y3RzQnlJZCIsImlkIiwiYmFzZVBhdGhVcmwiLCJnZXRTaG9ja1NhbGVCeWlkIiwiZ2V0UHJvZHVjdHNCeUNhdGVnb3J5IiwibGVuZ3RoIiwiZ2V0UHJvZHVjdHNCeUJyYW5kIiwiZ2V0UHJvZHVjdHNCeUJyYW5kcyIsInF1ZXJ5IiwiZm9yRWFjaCIsIml0ZW0iLCJnZXRQcm9kdWN0c0J5UHJpY2VSYW5nZSIsImNoYW5nZVF0eSIsInBsYWNlT3JkZXIiLCJnZXRDYXJ0IiwiZGVsZXRlQ2FydCIsImdldEF1Y3Rpb25Qcm9kdWN0QnlBdWN0aW9uSWQiLCJjcmVhdGVCaWQiLCJnZXRTaG9wRGV0YWlsQnlJZCIsImdldENoZWNrb3V0SW5mbyIsInBsYWNlQXVjdGlvbk9yZGVyIiwiYmFzZURvbWFpbiIsImJhc2VQb3N0VXJsIiwiYmFzZVN0b3JlVVJMIiwiYXBpYmFzZXVybEN1c3RvbSIsImJhc2VQYXRoIiwid2luZG93IiwibG9jYXRpb24iLCJob3N0bmFtZSIsImN1c3RvbUhlYWRlcnMiLCJBY2NlcHQiLCJjcmVhdGUiLCJPYmplY3QiLCJrZXlzIiwibWFwIiwia2V5IiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwiam9pbiIsIm1vZGFsU3VjY2VzcyIsImdldE15T3JkZXJzU2FnYSIsImNhbGwiLCJwdXQiLCJnZXRNeU9yZGVyc1N1Y2Nlc3MiLCJnZXRDdXN0b21lclByb2ZpbGUiLCJyb3V0ZXIiLCJwdXNoIiwibG9nT3V0IiwiZ2V0Q3VzdG9tZXJQcm9maWxlU3VjY2VzcyIsInVwZGF0ZUN1c3RvbWVyUHJvZmlsZSIsInN1Y2Nlc3MiLCJ1cGRhdGVDdXN0b21lclByb2ZpbGVTdWNjZXNzIiwiZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3c1NsdWciLCJnZXRDdXN0b21lclJlY2VudFZpZXdzU3VjY2VzcyIsImdldEN1c3RvbWVyQWRkcmVzc1NsdWciLCJnZXRDdXN0b21lckFkZHJlc3NTdWNjZXNzIiwibWFrZURlZmF1bHRBZGRyZXNzU2FnYSIsImdldEN1c3RvbWVyQWRkcmVzcyIsImRlbGV0ZUFkZHJlc3NTYWdhIiwiYWRkQWRkcmVzc1NhZ2EiLCJnZXRDaGF0TGlzdFNhZ2EiLCJnZXRDdXN0b21lckNoYXRMaXN0U3VjY2VzcyIsImxpc3QiLCJnZXRDdXN0b21lckNoYXRNZXNzYWdlU2FnYSIsImdldEN1c3RvbWVyQ2hhdE1lc3NhZ2VTdWNjZXNzIiwibWVzc2FnZXMiLCJzZW5kTWVzc2FnZVRvU2VsbGVyU2FnYSIsImdldE9yZGVyRGV0YWlsc1NhZ2EiLCJnZXRPcmRlckRldGFpbHNTdWNjZXNzIiwiY2FuY2VsT3JkZXJSZXF1ZXN0U2FnYSIsImRhdGFfcGF5bG9hZCIsImdldFRva2VuTGlzdFNhZ2EiLCJnZXRUb2tlbkxpc3RTdWNjZXNzIiwiZ2V0U3VwcG9ydE1lc3NhZ2VTYWdhIiwiZ2V0U3VwcG9ydE1lc3NhZ2Vmcm9tU3VwcG9ydElkU3VjY2VzcyIsImdldFVzZXJXYWxsZXREZXRhaWxzIiwiZ2V0V2FsbGV0RGV0YWlsc1N1Y2Nlc3MiLCJnZXRBdWN0aW9uRGF0YVNhZ2EiLCJnZXRBdWN0aW9uQ2FydERhdGFTdWNjZXNzIiwiZ2V0QXVjdGlvbk9yZGVyTGlzdFNhZ2EiLCJnZXRBdWN0aW9uT3JkZXJMaXN0U3VjY2VzcyIsImdldENvdW50cnlEYXRhU2FnYSIsImdldENvdW50cnlEYXRhU3VjY2VzcyIsImdldFVzZXJOb3RpZmljYXRpb25TYWdhIiwiZ2V0VXNlck5vdGlmaWNhdGlvbnNTdWNjZXNzIiwiZ2V0UHVyY2hhc2VZZWFyIiwiZ2V0VXNlclB1cmNoYXNlWWVhclN1Y2Nlc3MiLCJyb290U2FnYSIsImFsbCIsInRha2VFdmVyeSIsImFjdGlvblR5cGVzIiwiR0VUX0NVU1RPTUVSX0NIQVRfTUVTU0FHRSIsIlNFTkRfTUVTU0FHRV9UT19TRUxMRVIiLCJHRVRfQ1VTVE9NRVJfQ0hBVF9MSVNUIiwiR0VUX01ZX09SREVSUyIsIkdFVF9DVVNUT01FUl9QUk9GSUxFIiwiVVBEQVRFX0NVU1RPTUVSX1BST0ZJTEUiLCJHRVRfQ1VTVE9NRVJfUkVDRU5UX1ZJRVdTIiwiR0VUX0NVU1RPTUVSX0FERFJFU1MiLCJNQUtFX0RFRkFVTFRfQUREUkVTUyIsIkFERF9BRERSRVNTIiwiREVMRVRFX0FERFJFU1MiLCJHRVRfT1JERVJfREVUQUlMUyIsIk1BS0VfQ0FOQ0VMX09SREVSX1JFUVVFU1QiLCJHRVRfVE9LRU5fTElTVCIsIkdFVF9TVVBQT1JUX01FU1NBR0VfQllfU1VQUE9SVF9JRCIsIkdFVF9XQUxMRVRfREVUQUlMUyIsIkdFVF9BVUNUSU9OX0NBUlRfREFUQSIsIkdFVF9BVUNUSU9OX09SREVSX0xJU1QiLCJHRVRfQ09VTlRSWV9EQVRBIiwiR0VUX1VTRVJfTk9USUZJQ0FUSU9OIiwiR0VUX1VTRVJfUFVSQ0hBU0VfWUVBUlMiLCJHRVRfQ0FSVCIsIkdFVF9DQVJUX1NVQ0NFU1MiLCJHRVRfQ0FSVF9FUlJPUiIsIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZIiwiR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlfU1VDQ0VTUyIsIkFERF9JVEVNIiwiUkVNT1ZFX0lURU0iLCJSRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXIiwiQ0xFQVJfQ0FSVCIsIkNMRUFSX0NBUlRfU1VDQ0VTUyIsIkNMRUFSX0NBUlRfRVJST1IiLCJJTkNSRUFTRV9RVFkiLCJJTkNSRUFTRV9RVFlfU1VDQ0VTUyIsIklOQ1JFQVNFX1FUWV9FUlJPUiIsIkRFQ1JFQVNFX1FUWSIsIlVQREFURV9DQVJUIiwiVVBEQVRFX0NBUlRfU1VDQ0VTUyIsIlVQREFURV9DQVJUX0VSUk9SIiwiVVBEQVRFX1NFTEVDVEVEX0FERFJFU1MiLCJGRVRDSF9QTEFURk9STV9WT1VDSEVSIiwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTIiwiVE9UQUxfRElTQ09VTlQiLCJBUFBMSUVEX1NFTExFUl9WT1VDSEVSIiwiQVBQTElFRF9QTEFURk9STV9WT1VDSEVSIiwiR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRSIsIlNFTExFUl9XSVNFX0RJU0NPVU5UIiwiU0VMTEVSX1dJU0VfTUVTU0FHRVMiLCJVU0VEX1dBTExFVF9BTU9VTlQiLCJTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSIiwicmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3Iiwic2VsZWN0ZWRQYXltZW50T3B0aW9uIiwic2VsbGVyV2lzZU1lc3NhZ2UiLCJ1c2VkV2FsbGV0QW1vdW50Iiwic2VsbGVyV2lzZURpc2NvdW50IiwiZ3JhbmRUb3RhbFdpdGhEaXNjb3VudFZhbHVlIiwiYXBwbGllZFNlbGxlclZvdWNoZXIiLCJhcHBsaWVkUGxhdGZvcm1Wb3VjaGVyIiwidG90YWxEaXNjb3VudCIsImZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uIiwiZmV0Y2hQbGF0Zm9ybVZvdWNoZXJBY3Rpb25TdWNjZXNzIiwiZ2V0Q2FydFN1Y2Nlc3MiLCJnZXRDYXJ0RXJyb3IiLCJ1cGRhdGVTZWxlY3RlZEFkZHJlc3MiLCJhZGRJdGVtIiwicmVtb3ZlSXRlbSIsImluY3JlYXNlSXRlbVF0eSIsImRlY3JlYXNlSXRlbVF0eSIsInVwZGF0ZUNhcnRTdWNjZXNzIiwidXBkYXRlQ2FydEVycm9yIiwiY2xlYXJDYXJ0IiwiY2xlYXJDYXJ0U3VjY2VzcyIsImR1cmF0aW9uIiwibW9kYWxXYXJuaW5nIiwiY2FsY3VsYXRlQW1vdW50Iiwib2JqIiwidmFsdWVzIiwicmVkdWNlIiwiYWNjIiwicHJpY2UiLCJ0b0ZpeGVkIiwiZ2V0Q2FydFNhZ2EiLCJhZGRJdGVtU2FnYSIsInN0YXR1cyIsInJlbW92ZUl0ZW1TYWdhIiwibG9jYWxDYXJ0IiwiY2FydCIsImluZGV4IiwiY2FydEl0ZW1zIiwiZmluZEluZGV4IiwiY2FydFRvdGFsIiwic3BsaWNlIiwiYW1vdW50IiwiaW5jcmVhc2VRdHlTYWdhIiwic2VsZWN0ZWRJdGVtIiwiZmluZCIsImRlY3JlYXNlSXRlbVF0eVNhZ2EiLCJjbGVhckNhcnRTYWdhIiwiZW1wdHlDYXJ0IiwiZmV0Y2hQbGF0Zm9ybVZvdWNoZXJTYWdhIiwiY291cG9uIiwicmVtb3ZlRnJvbUNhcnROZXdTYWdhIiwiZGlzcGxheU5vdGlmaWNhdGlvbiIsIm1vZGFsUmVtb3ZlV2FybmluZyIsIm1vZGFsU2hvdyIsImdldFdpc2hsaXN0TGlzdFNhZ2EiLCJyZXNwb25zZURhdGEiLCJXaXNobGlzdFJlcG9zaXRvcnkiLCJnZXRQcm9kdWN0VG9XaXNobGlzdCIsImdldFdpc2hsaXN0TGlzdFN1Y2Nlc3MiLCJhZGRJdGVtVG9XaXNobGlzdFNhZ2EiLCJhZGRQcm9kdWN0VG9XaXNoTGlzdCIsImdldFdpc2hsaXN0TGlzdCIsInJlbW92ZUl0ZW1XaXNobGlzdFNhZ2EiLCJyZW1vdmVQcm9kdWN0RnJvbVdpc2hMaXN0IiwiY2xlYXJXaXNobGlzdExpc3RTYWdhIiwid2lzaGxpc3RJdGVtcyIsIndpc2hsaXN0VG90YWwiLCJ1cGRhdGVXaXNobGlzdExpc3RTdWNjZXNzIiwiYWRkU2hvY2tpbmdTYWxlSXRlbVRvV2lzaGxpc3RTYWdhIiwidXBkYXRlU2hvY2tpbmdzYWxlV2lzaGxpc3QiLCJyZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0U2FnYSIsIkdFVF9XSVNITElTVF9MSVNUIiwiQUREX0lURU1fV0lTSExJU0giLCJSRU1PVkVfSVRFTV9XSVNITElTSCIsIkFERF9TSE9DS0lOR19TQUxFX0lURU1fVE9fV0lTSExJU1QiLCJSRU1PVkVfU0hPQ0tJTkdfU0FMRV9JVEVNX0ZST01fV0lTSExJU1QiLCJleGFjdE1hdGgiLCJyZXF1aXJlIiwicm91dGVXaXRob3V0UmVmcmVzaCIsInJvdXRlTGluayIsIlJvdXRlciIsInJlcGxhY2UiLCJ1bmRlZmluZWQiLCJzaGFsbG93IiwiaG9tZVBhZ2VQcm9kdWN0UHJpY2VIZWxwZXIiLCJvZmZlcl9wcmljZSIsImFjdHVhbF9wcmljZSIsInNob2NrX3NhbGVfcHJpY2UiLCJzYWxlX3ByaWNlIiwicmV0dXJuVG90YWxPZkNhcnRWYWx1ZSIsImNhcnRfdG90YWxfcHJpY2UiLCJwcmV2IiwibmV4dCIsIk51bWJlciIsInByaWNlSGVscGVyIiwidG90YWxfZGlzY291bnRfcHJpY2UiLCJ0b3RhbF9hY3R1YWxfcHJpY2UiLCJyZXR1cm5Ub3RhbENvbW1pc3Npb24iLCJjYXJ0X3RvdGFsX2NvbW1pc3Npb24iLCJjb21taXNzaW9uIiwicmV0dXJuVG90YWxPZkNhcnRUYXhWYWx1ZSIsImNhcnRfdG90YWxfdGF4IiwidG90YWxfdGF4X3ZhbHVlIiwibnVtIiwibnVtYmVyQXJyYXkiLCJ0b1N0cmluZyIsInNwbGl0IiwiY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IiwiY3VycmVuY3lWYWwiLCJJbnRsIiwiTnVtYmVyRm9ybWF0Iiwic3R5bGUiLCJjdXJyZW5jeSIsImZvcm1hdCIsIm1hdGhGb3JtdWxhIiwiZm9ybXVsYVRleHQiLCJyZXN1bHQiLCJmb3JtdWxhIiwiZGl2Q3VycmVuY3kiLCJmaXJzdFZhbCIsInNlY29uZFZhbCIsImRpdkRhdGEiLCJkaXYiLCJtdWxDdXJyZW5jeSIsIm11bERhdGEiLCJtdWwiLCJhZGRDdXJyZW5jeSIsImN1cnJlbmN5VmFsRmlyc3QiLCJjdXJyZW5jeVZhbFNlY29uZCIsImFkZERhdGEiLCJhZGQiLCJzdWJDdXJyZW5jeSIsInN1YkRhdGEiLCJzdWIiLCJmb3JtYXRDdXJyZW5jeSIsInBhcnNlRmxvYXQiLCJnZXRDb2xsZXRpb25CeVNsdWciLCJjb2xsZWN0aW9ucyIsInNsdWciLCJnZXRJdGVtQnlTbHVnIiwiYmFubmVycyIsImJhbm5lciIsImNvbnZlcnRTbHVnc1F1ZXJ5U3RyaW5nIiwiU3RyYXBpUHJvZHVjdEJhZGdlIiwidmlldyIsImJhZGdlIiwidmFsdWUiLCJTdHJhcGlQcm9kdWN0UHJpY2UiLCJpc19zYWxlIiwiU3RyYXBpUHJvZHVjdFByaWNlX05ldyIsImZlYXR1cmVwcm9kdWN0cHJpY2UiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZCIsIlN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIiLCJvZmZlciIsIlN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIxIiwiU3RyYXBpUHJvZHVjdFRodW1ibmFpbCIsInRodW1ibmFpbCIsInRpdGxlIiwiU3RyYXBpUHJvZHVjdFRodW1ibmFpbE90aGVyIiwiaW1hZ2UiLCJwcm9kdWN0X25hbWUiLCJTdHJhcGlQcm9kdWN0VGh1bWJuYWlsRGV0YWlsIiwiU2hvY2tpbmdwcm9kdWN0dGh1bWJuYWlsIiwiY29sb3JIZWxwZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQSxTQUFTLEdBQUcsQ0FBQ0MsSUFBRCxFQUFPQyxPQUFQLEVBQWdCQyxXQUFoQixLQUFnQztBQUNoREMsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLE1BQU1FLGlCQUFOLENBQXdCO0FBQ3RCLFFBQU1DLG9CQUFOLENBQTJCQyxPQUEzQixFQUFvQztBQUNsQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVywwQkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JDLEdBQUQsSUFBUztBQUNkZixlQUFTLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsa0NBQW5CLENBQVQ7QUFDRCxLQVRvQixDQUF2QjtBQVVBLFdBQU9RLFFBQVA7QUFDRDs7QUFHRCxRQUFNUSxjQUFOLENBQXFCVCxPQUFyQixFQUE4QjtBQUM1QixVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVywrQkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixHQUE5QixFQUFtQztBQUNqQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7O0FBQ0QsYUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBVG9CLEVBVXBCQyxLQVZvQixDQVViQyxHQUFELElBQVNHLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaLENBVkssQ0FBdkI7QUFXQSxXQUFPUCxRQUFQO0FBQ0Q7O0FBRUQsUUFBTVksZUFBTixDQUFzQmIsT0FBdEIsRUFBK0I7QUFDN0JjLFNBQUssQ0FBQyxHQUFELENBQUw7QUFDQUgsV0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWixFQUF5QlosT0FBekI7QUFDQSxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyx3QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixHQUE5QixFQUFtQztBQUNqQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7O0FBQ0QsYUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBVG9CLEVBVXBCQyxLQVZvQixDQVViQyxHQUFELElBQVNHLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaLENBVkssQ0FBdkI7QUFXQSxXQUFPUCxRQUFQO0FBQ0Q7O0FBRUQsUUFBTWMsbUJBQU4sQ0FBMEJmLE9BQTFCLEVBQW1DO0FBQ2pDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDRCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZixVQUFVSixRQUFWLEVBQW9CO0FBQ3hCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPZCxVQUFVTixRQUFWLEVBQW9CO0FBQ3pCVSxhQUFPLENBQUNDLEdBQVIsQ0FBWVgsUUFBWjtBQUNBLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVZvQixDQUF2QjtBQVdBLFdBQU9MLFFBQVA7QUFDRDs7QUFFRCxRQUFNZSxVQUFOLEdBQW1CO0FBQ2pCLFVBQU1mLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQWlCLEdBQUVDLHNEQUFXLHVCQUE5QixFQUNwQkMsSUFEb0IsQ0FDZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEdBQTlCLEVBQW1DO0FBQ2pDLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVBLLENBQXZCO0FBUUEsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU1nQixXQUFOLENBQWtCakIsT0FBbEIsRUFBMkI7QUFDekIsVUFBTUMsUUFBUSxHQUFHLE1BQU1pQiw0Q0FBSyxDQUFDO0FBQzNCQyxZQUFNLEVBQUUsTUFEbUI7QUFFM0JDLFNBQUcsRUFBRyxHQUFFaEIsc0RBQVcseUJBRlE7QUFHM0JFLFVBQUksRUFBRU4sT0FIcUI7QUFJM0JxQixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBRCxDQUFMLENBTXBCaEIsSUFOb0IsQ0FNZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJvQixFQVNwQkMsS0FUb0IsQ0FTYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGMsQ0FBdkI7QUFXQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU13QixjQUFOLENBQXFCekIsT0FBckIsRUFBOEI7QUFDNUIsVUFBTUMsUUFBUSxHQUFHLE1BQU1pQiw0Q0FBSyxDQUFDO0FBQzNCQyxZQUFNLEVBQUUsTUFEbUI7QUFFM0JDLFNBQUcsRUFBRyxHQUFFaEIsc0RBQVcsNEJBRlE7QUFHM0JFLFVBQUksRUFBRU4sT0FIcUI7QUFJM0JxQixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBRCxDQUFMLENBTXBCaEIsSUFOb0IsQ0FNZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJvQixFQVNwQkMsS0FUb0IsQ0FTYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGMsQ0FBdkI7QUFXQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU15QixXQUFOLENBQWtCMUIsT0FBbEIsRUFBMkI7QUFDekIsVUFBTUMsUUFBUSxHQUFHLE1BQU1pQiw0Q0FBSyxDQUFDO0FBQzNCQyxZQUFNLEVBQUUsTUFEbUI7QUFFM0JDLFNBQUcsRUFBRyxHQUFFaEIsc0RBQVcseUJBRlE7QUFHM0JFLFVBQUksRUFBRU4sT0FIcUI7QUFJM0JxQixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBRCxDQUFMLENBTXBCaEIsSUFOb0IsQ0FNZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJvQixFQVNwQkMsS0FUb0IsQ0FTYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGMsQ0FBdkI7QUFXQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU0wQixRQUFOLENBQWUzQixPQUFmLEVBQXdCO0FBQ3RCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLHFCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU0yQixPQUFOLENBQWM1QixPQUFkLEVBQXVCO0FBQ3JCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLG9CQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU00QixXQUFOLENBQWtCN0IsT0FBbEIsRUFBMkI7QUFDekIsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywwQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1DLGtCQUFOLENBQXlCL0IsT0FBekIsRUFBa0M7QUFDaEMsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1Q0FETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1FLGVBQU4sQ0FBc0JoQyxPQUF0QixFQUErQjtBQUM3QixVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDRCQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0QsR0F4THFCLENBMEx0Qjs7O0FBQ0EsUUFBTUcsd0JBQU4sR0FBaUM7QUFDL0IsUUFBSUMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFVBQU1ULE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQjtBQUFFbUMsa0JBQUY7QUFBZ0JDLGFBQU8sRUFBRTtBQUF6QixLQUZvQixFQUluQm5DLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1XLDJCQUFOLENBQWtDekMsT0FBbEMsRUFBMkM7QUFDekMsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyw0QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1ZLHNCQUFOLENBQTZCMUMsT0FBN0IsRUFBc0M7QUFDcEMsUUFBSWtDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFFQSxVQUFNVCxPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsNEJBRE0sRUFFcEI7QUFBRW1DLGtCQUFGO0FBQWdCQyxhQUFPLEVBQUU7QUFBekIsS0FGb0IsRUFJbkJuQyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNYSxvQkFBTixHQUE2QjtBQUMzQixRQUFJVCxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBRUEsVUFBTVQsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHVCQURNLEVBRXBCO0FBQUVtQztBQUFGLEtBRm9CLEVBSW5CbEMsSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBQ0QsUUFBTWMsb0JBQU4sQ0FBMkI1QyxPQUEzQixFQUFvQztBQUNsQyxRQUFJa0MsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFFBQUlNLGtCQUFrQixHQUFHLElBQUlDLFFBQUosRUFBekI7QUFFQUQsc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLGNBQTFCLEVBQTBDUixZQUExQztBQUNBTSxzQkFBa0IsQ0FBQ0UsTUFBbkIsQ0FBMEIsWUFBMUIsRUFBd0MvQyxPQUFPLENBQUNnRCxVQUFoRDtBQUNBSCxzQkFBa0IsQ0FBQ0UsTUFBbkIsQ0FBMEIsWUFBMUIsRUFBd0MvQyxPQUFPLENBQUNpRCxPQUFoRDtBQUVBLFVBQU1uQixPQUFPLEdBQUcsTUFBTVosNENBQUssQ0FBQztBQUMxQkMsWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWhCLHNEQUFXLCtCQUZPO0FBRzFCRSxVQUFJLEVBQUV1QyxrQkFIb0I7QUFJMUJ4QixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKaUIsS0FBRCxDQUFMLENBTW5CaEIsSUFObUIsQ0FNYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJtQixFQVNuQkMsS0FUbUIsQ0FTWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9CLGFBQU4sQ0FBb0JsRCxPQUFwQixFQUE2QjtBQUMzQixRQUFJa0MsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFFBQUlNLGtCQUFrQixHQUFHLElBQUlDLFFBQUosRUFBekI7QUFFQUQsc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLGNBQTFCLEVBQTBDUixZQUExQztBQUNBTSxzQkFBa0IsQ0FBQ0UsTUFBbkIsQ0FBMEIsWUFBMUIsRUFBd0MvQyxPQUFPLENBQUNnRCxVQUFoRDtBQUVBLFVBQU1sQixPQUFPLEdBQUcsTUFBTVosNENBQUssQ0FBQztBQUMxQkMsWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWhCLHNEQUFXLDhCQUZPO0FBRzFCRSxVQUFJLEVBQUV1QyxrQkFIb0I7QUFJMUJ4QixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKaUIsS0FBRCxDQUFMLENBTW5CaEIsSUFObUIsQ0FNYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJtQixFQVNuQkMsS0FUbUIsQ0FTWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXFCLFVBQU4sQ0FBaUJuRCxPQUFqQixFQUEwQjtBQUN4QixVQUFNOEIsT0FBTyxHQUFHLE1BQU1aLDRDQUFLLENBQUM7QUFDMUJDLFlBQU0sRUFBRSxNQURrQjtBQUUxQkMsU0FBRyxFQUFHLEdBQUVoQixzREFBVywyQkFGTztBQUcxQkUsVUFBSSxFQUFFTixPQUhvQjtBQUkxQnFCLGFBQU8sRUFBRTtBQUFFLHdCQUFnQjtBQUFsQjtBQUppQixLQUFELENBQUwsQ0FNbkJoQixJQU5tQixDQU1iSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBUm1CLEVBU25CQyxLQVRtQixDQVNaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FUYSxDQUF0QjtBQVVBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNc0IsYUFBTixDQUFvQnBELE9BQXBCLEVBQTZCO0FBQzNCLFVBQU04QixPQUFPLEdBQUcsTUFBTVosNENBQUssQ0FBQztBQUMxQkMsWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWhCLHNEQUFXLDRCQUZPO0FBRzFCRSxVQUFJLEVBQUVOLE9BSG9CO0FBSTFCcUIsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmlCLEtBQUQsQ0FBTCxDQU1uQmhCLElBTm1CLENBTWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FSbUIsRUFTbkJDLEtBVG1CLENBU1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVRhLENBQXRCO0FBVUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU11QixrQkFBTixDQUF5QnJELE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU04QixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsOEJBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNd0Isb0JBQU4sQ0FBMkJ0RCxPQUEzQixFQUFvQztBQUNsQyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHFDQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXlCLGtCQUFOLENBQXlCdkQsT0FBekIsRUFBa0M7QUFDaEMsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsNkJBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm9CLEVBT3BCQyxLQVBvQixDQU9iZSxLQUFELElBQVdyQixRQUFRLENBQUNxQixLQVBOLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNdUQsZ0JBQU4sQ0FBdUJ4RCxPQUF2QixFQUFnQztBQUM5QixVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVywyQkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNd0Qsa0JBQU4sQ0FBeUJ6RCxPQUF6QixFQUFrQztBQUNoQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVywrQkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNeUQsZ0JBQU4sQ0FBdUIxRCxPQUF2QixFQUFnQztBQUM5QixVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNMEQsZ0JBQU4sQ0FBdUIzRCxPQUF2QixFQUFnQztBQUM5QixVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw2QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNMkQsa0JBQU4sQ0FBeUI1RCxPQUF6QixFQUFrQztBQUNoQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw4QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNNEQsbUJBQU4sQ0FBMEI3RCxPQUExQixFQUFtQztBQUNqQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNNkQsbUJBQU4sQ0FBMEI5RCxPQUExQixFQUFtQztBQUNqQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNOEQscUJBQU4sQ0FBNEIvRCxPQUE1QixFQUFxQztBQUNuQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyxpQ0FETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNK0QsdUJBQU4sQ0FBOEJoRSxPQUE5QixFQUF1QztBQUNyQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyxtQ0FETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3JCLFFBQVA7QUFDRDs7QUFFRCxRQUFNZ0UsZUFBTixDQUFzQmpFLE9BQXRCLEVBQStCO0FBQzdCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLHVDQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPckIsUUFBUDtBQUNEOztBQTNkcUI7O0FBZ2VULG1FQUFJSCxpQkFBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1ZUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTW9FLGNBQU4sQ0FBcUI7QUFDbkIsUUFBTUMsZ0JBQU4sQ0FBdUI7QUFBRTVCLGdCQUFGO0FBQWdCNkIsV0FBaEI7QUFBeUJDLFlBQXpCO0FBQW1DQztBQUFuQyxHQUF2QixFQUF1RTtBQUNyRSxVQUFNeEMsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHdCQURNLEVBRXBCO0FBQUVtQyxrQkFBRjtBQUFnQmdDLGdCQUFVLEVBQUVILE9BQU8sQ0FBQ0csVUFBcEM7QUFBZ0RGLGNBQWhEO0FBQTBEQztBQUExRCxLQUZvQixFQUluQmpFLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUNuQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7O0FBQ0QsYUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBVG1CLEVBVW5CQyxLQVZtQixDQVVaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FWYSxDQUF0QjtBQVdBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNMEMsV0FBTixDQUFrQnhFLE9BQWxCLEVBQTJCO0FBQzFCO0FBQ0VXLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDNkQscUVBQXRDO0FBQ0Q5RCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxvQkFBWixFQUFpQ1osT0FBakM7QUFDQSxRQUFJa0MsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUNBLFVBQU1tQyxVQUFVLEdBQUduQyxZQUFuQjtBQUVBLFVBQU10QyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUFpQixHQUFFQyxzREFBVyxvQkFBOUIsRUFBbUQ7QUFDeEVtQyxrQkFBWSxFQUFFbUMsVUFEMEQ7QUFFeEVsQyxhQUFPLEVBQUUsQ0FGK0Q7QUFHeEVtQyxlQUFTLEVBQUVGLHFFQUg2RDtBQUl4RUcsY0FBUSxFQUFFLGlDQUo4RDtBQUt4RUMsYUFBTyxFQUFFO0FBTCtELEtBQW5ELENBQXZCLENBVHlCLENBZ0IxQjs7QUFDQ2xFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGdDQUFaLEVBQTZDWCxRQUE3QyxFQUNDSSxJQURELENBQ09KLFFBQUQsSUFBYztBQUNyQjtBQUNHLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBRW5DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxPQUhELE1BR087QUFDTCxlQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7QUFDRixLQVRELEVBVUdDLEtBVkgsQ0FVVWUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVlQ7QUFXQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU02RSxvQkFBTixHQUE2QjtBQUMzQixVQUFNN0UsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsK0JBRE8sRUFFckI7QUFDRW9DLGFBQU8sRUFBRTtBQURYLEtBRnFCLEVBTXBCbkMsSUFOb0IsQ0FNZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7QUFDRixLQVpvQixFQWFwQkMsS0Fib0IsQ0FhYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBYmMsQ0FBdkI7QUFjQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU04RSxvQkFBTixDQUEyQi9FLE9BQTNCLEVBQW9DO0FBQ2xDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLCtCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7QUFDRixLQVZvQixFQVdwQkMsS0FYb0IsQ0FXYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGMsQ0FBdkI7QUFZQSxXQUFPckIsUUFBUDtBQUNEOztBQUVELFFBQU0rRSxrQkFBTixDQUF5QmhGLE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDZCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxPQUZELE1BRU87QUFDTCxlQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0Q7QUFDRixLQVZvQixFQVdwQkMsS0FYb0IsQ0FXYmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGMsQ0FBdkI7QUFZQSxXQUFPckIsUUFBUDtBQUNEOztBQS9Ga0I7O0FBa0dOLG1FQUFJaUUsY0FBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0R0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNZSxPQUFOLENBQWM7QUFDWixRQUFNQyxXQUFOLENBQWtCQyxRQUFsQixFQUE0QjtBQUMxQixRQUFJbkYsT0FBTyxHQUFHO0FBQ1p1QyxrQkFBWSxFQUFFLEVBREY7QUFFWkMsYUFBTyxFQUFFLENBRkc7QUFHWm1DLGVBQVMsRUFBRUYscUVBSEM7QUFJWkcsY0FBUSxFQUFFUSw2RUFBVyxDQUFDLEdBQUQsQ0FKVDtBQUtaUCxhQUFPLEVBQUVRLHdFQUFNO0FBTEgsS0FBZDtBQVFBLFVBQU1DLFdBQVcsR0FBR0MsNENBQUssQ0FBQ0QsV0FBMUI7QUFDQSxRQUFJRSxNQUFNLEdBQUdGLFdBQVcsQ0FBQ0UsTUFBWixFQUFiO0FBRUFBLFVBQU0sSUFBSUEsTUFBTSxDQUFDQyxNQUFQLENBQWMsd0NBQWQsQ0FBVixDQVowQixDQWExQjs7QUFDQUQsVUFBTSxHQUFHRCw0Q0FBSyxDQUFDRCxXQUFOLENBQWtCRSxNQUFsQixFQUFUO0FBRUEsVUFBTTFELE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxvQkFETSxFQUVwQkosT0FGb0IsRUFHcEI7QUFDRTBGLGlCQUFXLEVBQUVGLE1BQU0sQ0FBQ0c7QUFEdEIsS0FIb0IsRUFPbkJ0RixJQVBtQixDQU9iSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBVG1CLEVBVW5CQyxLQVZtQixDQVVaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FWYSxDQUF0QixDQWhCMEIsQ0EyQjFCOztBQUNBa0UsVUFBTSxDQUFDQyxNQUFQLENBQWMsaUNBQWQ7QUFDQSxXQUFPM0QsT0FBUDtBQUNEOztBQUVELFFBQU04RCxZQUFOLENBQW1CNUYsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxtQ0FETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0rRCxrQkFBTixDQUF5QjdGLE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU04QixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsa0NBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRCxHQXZEVyxDQXdEWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFsRVk7O0FBcUVDLG1FQUFJbUQsT0FBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6RUE7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFPQSxNQUFNYSxpQkFBTixDQUF3QjtBQUN0QixRQUFNQyxVQUFOLENBQWlCQyxNQUFqQixFQUF5QjtBQUN2QixVQUFNbEUsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDK0YsR0FBWCxDQUNuQixHQUFFQyxtREFBUSxhQUFZQyxrRUFBYyxDQUFDSCxNQUFELENBQVMsRUFEMUIsRUFHbkIzRixJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTG1CLEVBTW5CQyxLQU5tQixDQU1aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNc0UsbUJBQU4sQ0FBMEJKLE1BQTFCLEVBQWtDO0FBQ2hDLFVBQU1sRSxPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsOEJBRE0sRUFFcEI7QUFDRW9DLGFBQU8sRUFBRSxFQURYO0FBRUU2RCxpQkFBVyxFQUFFTCxNQUFNLENBQUNLLFdBRnRCO0FBR0VDLGFBQU8sRUFBRU4sTUFBTSxDQUFDTztBQUhsQixLQUZvQixFQVFuQmxHLElBUm1CLENBUWJKLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0x1RyxhQUFLLEVBQUV2RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQm1HLFFBRHJCO0FBRUxDLGtCQUFVLEVBQUV6RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQnFHO0FBRjFCLE9BQVA7QUFJRCxLQWJtQixFQWVuQnBHLEtBZm1CLENBZVplLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWZhLENBQXRCO0FBZ0JBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNOEUsV0FBTixDQUFrQlosTUFBbEIsRUFBMEI7QUFDeEIsVUFBTWxFLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxrQ0FBZCxHQUFrRDRGLE1BQU0sQ0FBQ2EsSUFEckMsRUFFcEI7QUFDRXJFLGFBQU8sRUFBRSxDQURYO0FBRUVELGtCQUFZLEVBQUUsRUFGaEI7QUFHRW9DLGVBQVMsRUFBRUYscUVBSGI7QUFJRUcsY0FBUSxFQUFFLGlDQUpaO0FBS0VDLGFBQU8sRUFBRTtBQUxYLEtBRm9CLEVBVW5CeEUsSUFWbUIsQ0FVYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHVHLGFBQUssRUFBRXZHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CbUcsUUFEckI7QUFFTEMsa0JBQVUsRUFBRXpHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Cd0c7QUFGMUIsT0FBUDtBQUlELEtBZm1CLEVBaUJuQnZHLEtBakJtQixDQWlCWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBakJhLENBQXRCO0FBa0JBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNaUYsbUJBQU4sQ0FBMEIvRyxPQUExQixFQUFtQ2dHLE1BQW5DLEVBQTJDO0FBQ3pDLFVBQU1sRSxPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsbUNBQWQsR0FBbUQ0RixNQUFNLENBQUNhLElBRHRDLEVBRXBCN0csT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0x1RyxhQUFLLEVBQUV2RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQm1HLFFBRHJCO0FBRUxDLGtCQUFVLEVBQUV6RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQndHO0FBRjFCLE9BQVA7QUFJRCxLQVRtQixFQVduQnZHLEtBWG1CLENBV1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1rRix1QkFBTixDQUE4QmhILE9BQTlCLEVBQXVDZ0csTUFBdkMsRUFBK0M7QUFDN0MsVUFBTWxFLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx5Q0FBZCxHQUF5RDRGLE1BQU0sQ0FBQ2EsSUFENUMsRUFFcEI3RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHVHLGFBQUssRUFBRXZHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CMkcsVUFEckI7QUFFTFAsa0JBQVUsRUFBRXpHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Cd0c7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CdkcsS0FYbUIsQ0FXWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9GLG1CQUFOLENBQTBCbEgsT0FBMUIsRUFBbUNnRyxNQUFuQyxFQUEyQztBQUN6QyxVQUFNbEUsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHNDQUFkLEdBQXNENEYsTUFBTSxDQUFDYSxJQUR6QyxFQUVwQjdHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMdUcsYUFBSyxFQUFFdkcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJtRyxRQURyQjtBQUVMQyxrQkFBVSxFQUFFekcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ3RztBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkJ2RyxLQVhtQixDQVdaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNcUYsbUJBQU4sQ0FBMEJuSCxPQUExQixFQUFtQztBQUNqQyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHlDQUFkLEdBQXlESixPQUFPLENBQUM2RyxJQUQ3QyxFQUVwQjdHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEJVLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBMkJYLFFBQTNCO0FBQ0EsYUFBTztBQUNMdUcsYUFBSyxFQUFFdkcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJtRyxRQURyQjtBQUVMQyxrQkFBVSxFQUFFekcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ3RztBQUYxQixPQUFQO0FBSUQsS0FWbUIsRUFZbkJ2RyxLQVptQixDQVlaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FaYSxDQUF0QjtBQWFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNc0YsMkJBQU4sQ0FBa0NwSCxPQUFsQyxFQUEyQztBQUN6QyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG1DQUFkLEdBQW1ESixPQUFPLENBQUM2RyxJQUR2QyxFQUVwQjdHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMdUcsYUFBSyxFQUFFdkcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJtRyxRQURyQjtBQUVMQyxrQkFBVSxFQUFFekcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ3RztBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkJ2RyxLQVhtQixDQVdaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNdUYsK0JBQU4sQ0FBc0NySCxPQUF0QyxFQUErQztBQUM3QyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHlDQUFkLEdBQXlESixPQUFPLENBQUM2RyxJQUQ3QyxFQUVwQjdHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMdUcsYUFBSyxFQUFFdkcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUIyRyxVQURyQjtBQUVMUCxrQkFBVSxFQUFFekcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ3RztBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkJ2RyxLQVhtQixDQVdaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNd0YsMkJBQU4sQ0FBa0N0SCxPQUFsQyxFQUEyQztBQUN6QyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHNDQUFkLEdBQXNESixPQUFPLENBQUM2RyxJQUQxQyxFQUVwQjdHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMdUcsYUFBSyxFQUFFdkcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJtRyxRQURyQjtBQUVMQyxrQkFBVSxFQUFFekcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ3RztBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkJ2RyxLQVhtQixDQVdaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNeUYsbUJBQU4sQ0FBMEJ2QixNQUExQixFQUFrQztBQUNoQyxVQUFNbEUsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHlDQUFkLEdBQXlENEYsTUFBTSxDQUFDYSxJQUQ1QyxFQUduQnhHLElBSG1CLENBR2JKLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0x1RyxhQUFLLEVBQUV2RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQjJHLFVBRHJCO0FBRUxQLGtCQUFVLEVBQUV6RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQndHO0FBRjFCLE9BQVA7QUFJRCxLQVJtQixFQVVuQnZHLEtBVm1CLENBVVplLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVZhLENBQXRCO0FBV0EsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0wRixTQUFOLEdBQWtCO0FBQ2hCLFVBQU0xRixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FBaUIsR0FBRUMsc0RBQVcscUJBQTlCLEVBQ25CQyxJQURtQixDQUNiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBSG1CLEVBSW5CQyxLQUptQixDQUlaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FKYSxDQUF0QjtBQUtBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNMkYsb0JBQU4sR0FBNkI7QUFDM0I7QUFDQSxVQUFNM0YsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDBCQURNLEVBR25CQyxJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTG1CLEVBTW5CQyxLQU5tQixDQU1aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNNEYsZUFBTixHQUF3QjtBQUN0QixVQUFNNUYsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDK0YsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxpQkFBMUIsRUFDbkI3RixJQURtQixDQUNiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBSG1CLEVBSW5CQyxLQUptQixDQUlaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FKYSxDQUF0QjtBQUtBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNNkYsZUFBTixDQUFzQkMsRUFBdEIsRUFBMEI7QUFDeEJqSCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QmdILEVBQTlCO0FBQ0EsUUFBSTFGLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQTVCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDc0IsUUFBdEM7QUFDQXZCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaLEVBQXVDeUIsU0FBdkM7QUFDQTFCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUFaLEVBQTBDMkIsWUFBMUM7QUFDQTVCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQXlDNkQscUVBQXpDO0FBQ0E5RCxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEwQzJCLFlBQTFDO0FBQ0EsVUFBTXRDLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDhCQURPLEVBRXJCO0FBQ0VtQyxrQkFERjtBQUVFcUYsUUFGRjtBQUdFcEYsYUFBTyxFQUFFLENBSFg7QUFJRW1DLGVBQVMsRUFBRUYscUVBSmI7QUFLRUcsY0FBUSxFQUFHLEdBQUVpRCx1REFBWSxZQUFXRCxFQUFHLEVBTHpDO0FBTUUvQyxhQUFPLEVBQUVRLHdFQUFNO0FBTmpCLEtBRnFCLEVBV3BCaEYsSUFYb0IsQ0FXZEosUUFBRCxJQUFjO0FBQ2xCVSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWixFQUE2QlgsUUFBN0I7QUFDQSxhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0Fkb0IsRUFlcEJDLEtBZm9CLENBZWJlLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWZjLENBQXZCO0FBZ0JBLFdBQU9yQixRQUFQO0FBQ0Q7O0FBRUQsUUFBTTZILGdCQUFOLENBQXVCOUgsT0FBdkIsRUFBZ0M7QUFDOUIsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsMEJBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm9CLEVBT3BCQyxLQVBvQixDQU9iZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYyxDQUF2QjtBQVFBLFdBQU9yQixRQUFQO0FBQ0Q7O0FBRUQsUUFBTThILHFCQUFOLENBQTRCL0gsT0FBNUIsRUFBcUM7QUFDbkMsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQytGLEdBQVgsQ0FDbkIsR0FBRUMsbURBQVEsNEJBQTJCbEcsT0FBUSxFQUQxQixFQUduQkssSUFIbUIsQ0FHYkosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBYixFQUFtQjtBQUNqQixZQUFJTCxRQUFRLENBQUNLLElBQVQsQ0FBYzBILE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUIsaUJBQU8vSCxRQUFRLENBQUNLLElBQVQsQ0FBYyxDQUFkLENBQVA7QUFDRDtBQUNGLE9BSkQsTUFJTztBQUNMLGVBQU8sSUFBUDtBQUNEO0FBQ0YsS0FYbUIsRUFZbkJDLEtBWm1CLENBWWIsTUFBTTtBQUNYLGFBQU8sSUFBUDtBQUNELEtBZG1CLENBQXRCO0FBZUEsV0FBT3VCLE9BQVA7QUFDRDs7QUFDRCxRQUFNbUcsa0JBQU4sQ0FBeUJqSSxPQUF6QixFQUFrQztBQUNoQyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDK0YsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxnQkFBZWxHLE9BQVEsRUFBakQsRUFDbkJLLElBRG1CLENBQ2JKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQWIsRUFBbUI7QUFDakIsWUFBSUwsUUFBUSxDQUFDSyxJQUFULENBQWMwSCxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQzVCLGlCQUFPL0gsUUFBUSxDQUFDSyxJQUFULENBQWMsQ0FBZCxDQUFQO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTCxlQUFPLElBQVA7QUFDRDtBQUNGLEtBVG1CLEVBVW5CQyxLQVZtQixDQVViLE1BQU07QUFDWCxhQUFPLElBQVA7QUFDRCxLQVptQixDQUF0QjtBQWFBLFdBQU91QixPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9HLG1CQUFOLENBQTBCbEksT0FBMUIsRUFBbUM7QUFDakMsUUFBSW1JLEtBQUssR0FBRyxFQUFaO0FBQ0FuSSxXQUFPLENBQUNvSSxPQUFSLENBQWlCQyxJQUFELElBQVU7QUFDeEIsVUFBSUYsS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDaEJBLGFBQUssR0FBSSxTQUFRRSxJQUFLLEVBQXRCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xGLGFBQUssR0FBR0EsS0FBSyxHQUFJLFVBQVNFLElBQUssRUFBL0I7QUFDRDtBQUNGLEtBTkQ7QUFPQSxVQUFNdkcsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDK0YsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxXQUFVaUMsS0FBTSxFQUExQyxFQUNuQjlILElBRG1CLENBQ2JKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FIbUIsRUFJbkJDLEtBSm1CLENBSVplLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQUphLENBQXRCO0FBS0EsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1vRyxtQkFBTixDQUEwQmxJLE9BQTFCLEVBQW1DO0FBQ2pDLFFBQUltSSxLQUFLLEdBQUcsRUFBWjtBQUNBbkksV0FBTyxDQUFDb0ksT0FBUixDQUFpQkMsSUFBRCxJQUFVO0FBQ3hCLFVBQUlGLEtBQUssS0FBSyxFQUFkLEVBQWtCO0FBQ2hCQSxhQUFLLEdBQUksU0FBUUUsSUFBSyxFQUF0QjtBQUNELE9BRkQsTUFFTztBQUNMRixhQUFLLEdBQUdBLEtBQUssR0FBSSxVQUFTRSxJQUFLLEVBQS9CO0FBQ0Q7QUFDRixLQU5EO0FBT0EsVUFBTXZHLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQytGLEdBQVgsQ0FBZ0IsR0FBRUMsbURBQVEsV0FBVWlDLEtBQU0sRUFBMUMsRUFDbkI5SCxJQURtQixDQUNiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBSG1CLEVBSW5CQyxLQUptQixDQUlaZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FKYSxDQUF0QjtBQUtBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNd0csdUJBQU4sQ0FBOEJ0SSxPQUE5QixFQUF1QztBQUNyQyxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDK0YsR0FBWCxDQUNuQixHQUFFQyxtREFBUSxhQUFZQyxrRUFBYyxDQUFDbkcsT0FBRCxDQUFVLEVBRDNCLEVBR25CSyxJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTG1CLEVBTW5CQyxLQU5tQixDQU1aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNcUMsZ0JBQU4sQ0FBdUJuRSxPQUF2QixFQUFnQztBQUM5QlcsV0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBcUNaLE9BQXJDO0FBQ0EsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx3QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUNELFFBQU15RyxTQUFOLENBQWdCdkksT0FBaEIsRUFBeUI7QUFDdkIsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywrQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0wRyxVQUFOLENBQWlCeEksT0FBakIsRUFBMEI7QUFDeEJXLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDWixPQUF0QztBQUNBLFVBQU04QixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsZ0NBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNMkcsT0FBTixDQUFjekksT0FBZCxFQUF1QjtBQUNyQlcsV0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQlosT0FBM0I7QUFDQSxVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG9CQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTRHLFVBQU4sQ0FBaUIxSSxPQUFqQixFQUEwQjtBQUN4QixVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDJCQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTZHLDRCQUFOLENBQW1DM0ksT0FBbkMsRUFBNEM7QUFDMUMsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU04RyxTQUFOLENBQWdCNUksT0FBaEIsRUFBeUI7QUFDdkIsVUFBTThCLE9BQU8sR0FBRyxNQUFNNUIsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywwQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1plLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0rRyxpQkFBTixDQUF3QjdJLE9BQXhCLEVBQWlDO0FBQy9CLFVBQU04QixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsMkJBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNZ0gsZUFBTixDQUFzQjlJLE9BQXRCLEVBQStCO0FBQzdCVyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUE4Q1osT0FBOUM7QUFDQVcsV0FBTyxDQUFDQyxHQUFSLENBQVksb0NBQVosRUFBaURSLHNEQUFqRDtBQUNBLFVBQU0wQixPQUFPLEdBQUcsTUFBTTVCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsbUNBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aZSxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNaUgsaUJBQU4sQ0FBd0IvSSxPQUF4QixFQUFpQztBQUMvQixVQUFNOEIsT0FBTyxHQUFHLE1BQU01QixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLGdDQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmUsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBdmNxQjs7QUEwY1QsbUVBQUlnRSxpQkFBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsZEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE1BQU1rRCxVQUFVLEdBQUcsK0JBQW5CLEMsQ0FBb0Q7O0FBQzdDLE1BQU1DLFdBQVcsR0FBRywrQkFBcEIsQyxDQUFxRDs7QUFDckQsTUFBTUMsWUFBWSxHQUFHLCtCQUFyQixDLENBQXNEOztBQUU3RCxJQUFJQyxnQkFBZ0IsR0FBRyx1Q0FBdkI7QUFDQSxJQUFJQyxRQUFRLEdBQUcsZ0NBQWY7O0FBQ0EsVUFBbUM7QUFDakMsTUFBSUMsTUFBTSxDQUFDQyxRQUFQLENBQWdCQyxRQUFoQixJQUE0Qix3QkFBaEMsRUFBMEQ7QUFDeERKLG9CQUFnQixHQUFHLGdDQUFuQjtBQUNBQyxZQUFRLEdBQUcsZ0NBQVg7QUFDRDs7QUFDRCxNQUFJQyxNQUFNLENBQUNDLFFBQVAsQ0FBZ0JDLFFBQWhCLElBQTRCLHVCQUFoQyxFQUF5RDtBQUN2REosb0JBQWdCLEdBQUcsK0JBQW5CO0FBQ0FDLFlBQVEsR0FBRywrQkFBWDtBQUNEO0FBQ0Y7O0FBRU0sTUFBTWhKLFVBQVUsR0FBRytJLGdCQUFuQjtBQUNBLE1BQU10QixXQUFXLEdBQUd1QixRQUFwQjtBQUVBLE1BQU1JLGFBQWEsR0FBRztBQUMzQkMsUUFBTSxFQUFFO0FBRG1CLENBQXRCO0FBSUEsTUFBTXZELE9BQU8sR0FBSSxHQUFFOEMsVUFBVyxFQUE5QjtBQUVRekQsMkdBQUssQ0FBQ21FLE1BQU4sQ0FBYTtBQUMxQnhELFNBRDBCO0FBRTFCN0UsU0FBTyxFQUFFbUk7QUFGaUIsQ0FBYixDQUFmO0FBS08sTUFBTXJELGNBQWMsR0FBSWdDLEtBQUQsSUFBVztBQUN2QyxTQUFPd0IsTUFBTSxDQUFDQyxJQUFQLENBQVl6QixLQUFaLEVBQ0owQixHQURJLENBRUZDLEdBQUQsSUFBVSxHQUFFQyxrQkFBa0IsQ0FBQ0QsR0FBRCxDQUFNLElBQUdDLGtCQUFrQixDQUFDNUIsS0FBSyxDQUFDMkIsR0FBRCxDQUFOLENBQWEsRUFGbkUsRUFJSkUsSUFKSSxDQUlDLEdBSkQsQ0FBUDtBQUtELENBTk07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQXNCQTs7QUFFQSxNQUFNQyxZQUFZLEdBQUl2SyxJQUFELElBQVU7QUFDN0JHLG1EQUFZLENBQUNILElBQUQsQ0FBWixDQUFtQjtBQUNqQkMsV0FBTyxFQUFFLFVBRFE7QUFFakJDLGVBQVcsRUFBRTtBQUZJLEdBQW5CO0FBSUQsQ0FMRDs7QUFNQSxNQUFNSCxTQUFTLEdBQUcsQ0FBQ0MsSUFBRCxFQUFPQyxPQUFQLEVBQWdCQyxXQUFoQixLQUFnQztBQUNoREMsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLFVBQVVzSyxlQUFWLENBQTBCO0FBQUVsSztBQUFGLENBQTFCLEVBQXVDO0FBQ3JDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQytCLFdBQW5CLEVBQWdDN0IsT0FBaEMsQ0FBM0I7QUFDQSxVQUFNb0ssOERBQUcsQ0FBQ25LLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixHQUFyQixJQUE0QjJKLGtFQUFrQixDQUFDcEssUUFBUSxDQUFDSyxJQUFWLENBQS9DLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVOEosa0JBQVYsQ0FBNkI7QUFBRXRLO0FBQUYsQ0FBN0IsRUFBMEM7QUFDeEMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FDekJySyx1RUFBaUIsQ0FBQ21DLHdCQURPLEVBRXpCakMsT0FGeUIsQ0FBM0I7O0FBS0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCZixrREFBTyxDQUFDMkIsS0FBUixDQUFjLG1DQUFkO0FBQ0FpSix3REFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVo7QUFDQSxZQUFNSiw4REFBRyxDQUFDSywyREFBTSxFQUFQLENBQVQ7QUFDRDs7QUFDRCxRQUFJeEssUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCLFlBQU0wSiw4REFBRyxDQUFDTSx5RUFBeUIsQ0FBQ3pLLFFBQVEsQ0FBQ0ssSUFBVixDQUExQixDQUFUO0FBQ0Q7QUFDRixHQWRELENBY0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVbUsscUJBQVYsQ0FBZ0M7QUFBRTNLO0FBQUYsQ0FBaEMsRUFBNkM7QUFDM0MsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FDekJySyx1RUFBaUIsQ0FBQzJDLDJCQURPLEVBRXpCekMsT0FGeUIsQ0FBM0I7O0FBS0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCZixrREFBTyxDQUFDMkIsS0FBUixDQUFjLG1DQUFkO0FBQ0Q7O0FBRUQsUUFBSXJCLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixHQUFyQixJQUE0QlQsUUFBUSxDQUFDSyxJQUFULENBQWNzSyxPQUE5QyxFQUF1RDtBQUNyRGpMLGtEQUFPLENBQUNpTCxPQUFSLENBQWdCLCtCQUFoQjtBQUNEOztBQUVELFFBQUkzSyxRQUFRLENBQUNxQixLQUFiLEVBQW9CO0FBQ2xCckIsY0FBUSxDQUFDcUIsS0FBVCxDQUFldUksR0FBZixDQUFvQnZJLEtBQUQsSUFBVztBQUM1QnpCLHlEQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCRixpQkFBTyxFQUFFMkI7QUFEVyxTQUF0QjtBQUdELE9BSkQ7QUFLRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ0Usa0JBQWtCLEVBQW5CLENBQVQ7QUFDQSxVQUFNRiw4REFBRyxDQUFDUyw0RUFBNEIsQ0FBQzVLLFFBQUQsQ0FBN0IsQ0FBVDtBQUNELEdBdkJELENBdUJFLE9BQU9PLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVXNLLDBCQUFWLENBQXFDO0FBQUU5SztBQUFGLENBQXJDLEVBQWtEO0FBQ2hELE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQ3pCckssdUVBQWlCLENBQUM0QyxzQkFETyxFQUV6QjFDLE9BRnlCLENBQTNCO0FBSUEsVUFBTW9LLDhEQUFHLENBQUNXLDZFQUE2QixDQUFDOUssUUFBUSxDQUFDSyxJQUFWLENBQTlCLENBQVQ7QUFDRCxHQU5ELENBTUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVd0ssc0JBQVYsR0FBbUM7QUFDakMsTUFBSTtBQUNGLFVBQU0vSyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQzZDLG9CQUFuQixDQUEzQjtBQUNBLFVBQU15SCw4REFBRyxDQUFDYSx5RUFBeUIsQ0FBQ2hMLFFBQVEsQ0FBQ0ssSUFBVixDQUExQixDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTBLLHNCQUFWLENBQWlDO0FBQUVsTDtBQUFGLENBQWpDLEVBQThDO0FBQzVDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQ3pCckssdUVBQWlCLENBQUM4QyxvQkFETyxFQUV6QjVDLE9BRnlCLENBQTNCOztBQUlBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQztBQUM5QmYsa0RBQU8sQ0FBQ2lMLE9BQVIsQ0FBZ0IzSyxRQUFRLENBQUNLLElBQVQsQ0FBY1gsT0FBOUI7QUFDRCxLQUZELE1BRU87QUFDTEEsa0RBQU8sQ0FBQzJCLEtBQVIsQ0FBYyxpQ0FBZDtBQUNEOztBQUNELFVBQU04SSw4REFBRyxDQUFDZSxrRUFBa0IsRUFBbkIsQ0FBVDtBQUNELEdBWEQsQ0FXRSxPQUFPM0ssR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVNEssaUJBQVYsQ0FBNEI7QUFBRXBMO0FBQUYsQ0FBNUIsRUFBeUM7QUFDdkMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ3JLLHVFQUFpQixDQUFDb0QsYUFBbkIsRUFBa0NsRCxPQUFsQyxDQUEzQjs7QUFDQSxRQUFJQyxRQUFRLENBQUNTLFFBQVQsSUFBcUIsS0FBekIsRUFBZ0M7QUFDOUJmLGtEQUFPLENBQUNpTCxPQUFSLENBQWdCM0ssUUFBUSxDQUFDSyxJQUFULENBQWNYLE9BQTlCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLGtEQUFPLENBQUMyQixLQUFSLENBQWMseUJBQWQ7QUFDRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ2Usa0VBQWtCLEVBQW5CLENBQVQ7QUFDRCxHQVJELENBUUUsT0FBTzNLLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTZLLGNBQVYsQ0FBeUI7QUFBRXJMO0FBQUYsQ0FBekIsRUFBc0M7QUFDcEMsTUFBSTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQU1vSyw4REFBRyxDQUFDZSxrRUFBa0IsRUFBbkIsQ0FBVDtBQUNELEdBUkQsQ0FRRSxPQUFPM0ssR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVOEssZUFBVixDQUEwQjtBQUFFdEw7QUFBRixDQUExQixFQUF1QztBQUNyQyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDckssdUVBQWlCLENBQUNtQixXQUFuQixFQUFnQ2pCLE9BQWhDLENBQTNCOztBQUNBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQyxDQUMvQixDQURELE1BQ087QUFDTGYsa0RBQU8sQ0FBQzJCLEtBQVIsQ0FBYyw2QkFBZDtBQUNEOztBQUVELFVBQU04SSw4REFBRyxDQUFDbUIsMEVBQTBCLENBQUN0TCxRQUFRLENBQUNLLElBQVQsQ0FBY2tMLElBQWYsQ0FBM0IsQ0FBVDtBQUNELEdBUkQsQ0FRRSxPQUFPaEwsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVaUwsMEJBQVYsQ0FBcUM7QUFBRXpMO0FBQUYsQ0FBckMsRUFBa0Q7QUFDaEQsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ3JLLHVFQUFpQixDQUFDMkIsY0FBbkIsRUFBbUN6QixPQUFuQyxDQUEzQjs7QUFDQSxRQUFJQyxRQUFRLENBQUNTLFFBQVQsSUFBcUIsS0FBekIsRUFBZ0MsQ0FDL0IsQ0FERCxNQUNPO0FBQ0xmLGtEQUFPLENBQUMyQixLQUFSLENBQWMsNkJBQWQ7QUFDRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ3NCLDZFQUE2QixDQUFDekwsUUFBUSxDQUFDSyxJQUFULENBQWNxTCxRQUFmLENBQTlCLENBQVQ7QUFDRCxHQVBELENBT0UsT0FBT25MLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVW9MLHVCQUFWLENBQWtDO0FBQUU1TDtBQUFGLENBQWxDLEVBQStDO0FBQzdDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQzRCLFdBQW5CLEVBQWdDMUIsT0FBaEMsQ0FBM0I7O0FBQ0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEtBQXpCLEVBQWdDLENBQy9CLENBREQsTUFDTztBQUNMZixrREFBTyxDQUFDMkIsS0FBUixDQUFjLDhCQUFkO0FBQ0QsS0FMQyxDQU1GOztBQUNELEdBUEQsQ0FPRSxPQUFPZCxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVVxTCxtQkFBVixDQUE4QjtBQUFFN0w7QUFBRixDQUE5QixFQUEyQztBQUN6QyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDckssdUVBQWlCLENBQUNrQyxlQUFuQixFQUFvQ2hDLE9BQXBDLENBQTNCOztBQUNBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQyxDQUMvQixDQURELE1BQ087QUFDTGYsa0RBQU8sQ0FBQzJCLEtBQVIsQ0FBY3JCLFFBQVEsQ0FBQ04sT0FBdkI7QUFDRDs7QUFDRCxVQUFNeUssOERBQUcsQ0FBQzBCLHNFQUFzQixDQUFDN0wsUUFBUSxDQUFDSyxJQUFWLENBQXZCLENBQVQ7QUFDRCxHQVBELENBT0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVdUwsc0JBQVYsQ0FBaUM7QUFBRS9MO0FBQUYsQ0FBakMsRUFBOEM7QUFDNUMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ3JLLHVFQUFpQixDQUFDaUMsa0JBQW5CLEVBQXVDL0IsT0FBdkMsQ0FBM0I7QUFDQSxRQUFJZ00sWUFBWSxHQUFHO0FBQ2pCekosa0JBQVksRUFBRXZDLE9BQU8sQ0FBQ3VDLFlBREw7QUFFakJDLGFBQU8sRUFBRTtBQUZRLEtBQW5CO0FBSUEsVUFBTTRILDhEQUFHLENBQUN2SSwyREFBVyxDQUFDbUssWUFBRCxDQUFaLENBQVQ7QUFDRCxHQVBELENBT0UsT0FBT3hMLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVXlMLGdCQUFWLENBQTJCO0FBQUVqTTtBQUFGLENBQTNCLEVBQXdDO0FBQ3RDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQzBELGdCQUFuQixFQUFxQ3hELE9BQXJDLENBQTNCO0FBQ0EsVUFBTW9LLDhEQUFHLENBQUM4QixtRUFBbUIsQ0FBQ2pNLFFBQVEsQ0FBQ0ssSUFBVixDQUFwQixDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTJMLHFCQUFWLENBQWdDO0FBQUVuTTtBQUFGLENBQWhDLEVBQTZDO0FBQzNDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQzJELGtCQUFuQixFQUF1Q3pELE9BQXZDLENBQTNCO0FBQ0EsVUFBTW9LLDhEQUFHLENBQUNnQyxxRkFBcUMsQ0FBQ25NLFFBQVEsQ0FBQ0ssSUFBVixDQUF0QyxDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTZMLG9CQUFWLENBQStCO0FBQUVyTTtBQUFGLENBQS9CLEVBQTRDO0FBQzFDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNySyx1RUFBaUIsQ0FBQzZELGdCQUFuQixFQUFxQzNELE9BQXJDLENBQTNCO0FBRUEsVUFBTW9LLDhEQUFHLENBQUNrQyx1RUFBdUIsQ0FBQ3JNLFFBQVEsQ0FBQ0ssSUFBVixDQUF4QixDQUFUO0FBQ0QsR0FKRCxDQUlFLE9BQU9FLEdBQVAsRUFBWTtBQUNaZixhQUFTLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsa0NBQW5CLENBQVQ7QUFDQWtCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVK0wsa0JBQVYsQ0FBNkI7QUFBRXZNO0FBQUYsQ0FBN0IsRUFBMEM7QUFDeEMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ3JLLHVFQUFpQixDQUFDOEQsa0JBQW5CLEVBQXVDNUQsT0FBdkMsQ0FBM0I7QUFDQSxVQUFNb0ssOERBQUcsQ0FBQ29DLHlFQUF5QixDQUFDdk0sUUFBUSxDQUFDSyxJQUFWLENBQTFCLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pmLGFBQVMsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQixtQ0FBbkIsQ0FBVDtBQUNBa0IsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVVpTSx1QkFBVixDQUFrQztBQUFFek07QUFBRixDQUFsQyxFQUErQztBQUM3QyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDckssdUVBQWlCLENBQUNnRSxtQkFBbkIsRUFBd0M5RCxPQUF4QyxDQUEzQjtBQUNBLFVBQU1vSyw4REFBRyxDQUFDc0MsMEVBQTBCLENBQUN6TSxRQUFRLENBQUNLLElBQVYsQ0FBM0IsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPRSxHQUFQLEVBQVk7QUFDWmYsYUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG1DQUFuQixDQUFUO0FBQ0FrQixXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVW1NLGtCQUFWLEdBQStCO0FBQzdCLE1BQUk7QUFDRixVQUFNMU0sUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDckssdUVBQWlCLENBQUNrQixVQUFuQixDQUEzQjtBQUNBLFVBQU1vSiw4REFBRyxDQUFDd0MscUVBQXFCLENBQUMzTSxRQUFELENBQXRCLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT08sR0FBUCxFQUFZO0FBQ1pmLGFBQVMsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQixtQ0FBbkIsQ0FBVDtBQUNBa0IsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVVxTSx1QkFBVixDQUFrQztBQUFFN007QUFBRixDQUFsQyxFQUErQztBQUM3QyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDckssdUVBQWlCLENBQUMrRCxtQkFBbkIsRUFBd0M3RCxPQUF4QyxDQUEzQjtBQUNBLFVBQU1vSyw4REFBRyxDQUFDMEMsMkVBQTJCLENBQUM3TSxRQUFRLENBQUNLLElBQVYsQ0FBNUIsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPRSxHQUFQLEVBQVk7QUFDWmYsYUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG9DQUFuQixDQUFUO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVc04sZUFBVixDQUEwQjtBQUFFL007QUFBRixDQUExQixFQUF1QztBQUNyQyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUN6QnJLLHVFQUFpQixDQUFDQyxvQkFETyxFQUV6QkMsT0FGeUIsQ0FBM0I7QUFJQSxVQUFNb0ssOERBQUcsQ0FDUG5LLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixHQUFyQixJQUE0QnNNLDBFQUEwQixDQUFDL00sUUFBUSxDQUFDSyxJQUFWLENBRC9DLENBQVQ7QUFHRCxHQVJELENBUUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pmLGFBQVMsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQiw2QkFBbkIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRWMsVUFBVXdOLFFBQVYsR0FBcUI7QUFDbEM7QUFDQTtBQUNBO0FBQ0EsUUFBTUMsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUNQQyxtREFBVyxDQUFDQyx5QkFETCxFQUVQNUIsMEJBRk8sQ0FERCxDQUFELENBQVQ7QUFNQSxRQUFNeUIsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDRSxzQkFBYixFQUFxQzFCLHVCQUFyQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1zQiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNHLHNCQUFiLEVBQXFDakMsZUFBckMsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNNEIsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDSSxhQUFiLEVBQTRCdEQsZUFBNUIsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNZ0QsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDSyxvQkFBYixFQUFtQ25ELGtCQUFuQyxDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU00Qyw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNNLHVCQUFiLEVBQXNDL0MscUJBQXRDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTXVDLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FDUEMsbURBQVcsQ0FBQ08seUJBREwsRUFFUDdDLDBCQUZPLENBREQsQ0FBRCxDQUFUO0FBTUEsUUFBTW9DLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ1Esb0JBQWIsRUFBbUM1QyxzQkFBbkMsQ0FERCxDQUFELENBQVQ7QUFHQSxRQUFNa0MsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDUyxvQkFBYixFQUFtQzNDLHNCQUFuQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1nQyw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNVLFdBQWIsRUFBMEJ6QyxjQUExQixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU02Qiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNXLGNBQWIsRUFBNkIzQyxpQkFBN0IsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNOEIsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDWSxpQkFBYixFQUFnQ25DLG1CQUFoQyxDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1xQiw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNhLHlCQUFiLEVBQXdDbEMsc0JBQXhDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTW1CLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ2MsY0FBYixFQUE2QmpDLGdCQUE3QixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1pQiw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQ1BDLG1EQUFXLENBQUNlLGlDQURMLEVBRVBoQyxxQkFGTyxDQURELENBQUQsQ0FBVDtBQU1BLFFBQU1lLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ2dCLGtCQUFiLEVBQWlDL0Isb0JBQWpDLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTWEsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDaUIscUJBQWIsRUFBb0M5QixrQkFBcEMsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNVyw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNrQixzQkFBYixFQUFxQzdCLHVCQUFyQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1TLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ21CLGdCQUFiLEVBQStCNUIsa0JBQS9CLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTU8sOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDb0IscUJBQWIsRUFBb0MzQix1QkFBcEMsQ0FERCxDQUFELENBQVQ7QUFHQSxRQUFNSyw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNxQix1QkFBYixFQUFzQzFCLGVBQXRDLENBQVYsQ0FBRCxDQUFUO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pYRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1LLFdBQVcsR0FBRztBQUN6QnNCLFVBQVEsRUFBRSxVQURlO0FBRXpCQyxrQkFBZ0IsRUFBRSxrQkFGTztBQUd6QkMsZ0JBQWMsRUFBRSxnQkFIUztBQUt6QkMseUJBQXVCLEVBQUUseUJBTEE7QUFNekJDLGlDQUErQixFQUFFLGlDQU5SO0FBUXpCQyxVQUFRLEVBQUUsVUFSZTtBQVN6QkMsYUFBVyxFQUFFLGFBVFk7QUFVekJDLDhCQUE0QixFQUFFLDhCQVZMO0FBWXpCQyxZQUFVLEVBQUUsWUFaYTtBQWF6QkMsb0JBQWtCLEVBQUUsb0JBYks7QUFjekJDLGtCQUFnQixFQUFFLGtCQWRPO0FBZ0J6QkMsY0FBWSxFQUFFLGNBaEJXO0FBaUJ6QkMsc0JBQW9CLEVBQUUsc0JBakJHO0FBa0J6QkMsb0JBQWtCLEVBQUUsb0JBbEJLO0FBb0J6QkMsY0FBWSxFQUFFLGNBcEJXO0FBcUJ6QkMsYUFBVyxFQUFFLGFBckJZO0FBdUJ6QkMscUJBQW1CLEVBQUUscUJBdkJJO0FBd0J6QkMsbUJBQWlCLEVBQUUsbUJBeEJNO0FBMEJ6QkMseUJBQXVCLEVBQUUseUJBMUJBO0FBNEJ6QkMsd0JBQXNCLEVBQUUsd0JBNUJDO0FBNkJ6QkMsZ0NBQThCLEVBQUUsZ0NBN0JQO0FBK0J6QkMsZ0JBQWMsRUFBRSxnQkEvQlM7QUFpQ3pCQyx3QkFBc0IsRUFBRSx3QkFqQ0M7QUFtQ3pCQywwQkFBd0IsRUFBRSwwQkFuQ0Q7QUFxQ3pCQyxpQ0FBK0IsRUFBRSxpQ0FyQ1I7QUF1Q3pCQyxzQkFBb0IsRUFBRSxzQkF2Q0c7QUF5Q3pCQyxzQkFBb0IsRUFBRSxxQkF6Q0c7QUEyQ3pCQyxvQkFBa0IsRUFBRSxvQkEzQ0s7QUE2Q3pCQyxpQ0FBK0IsRUFBRTtBQTdDUixDQUFwQjtBQWdEQSxTQUFTQyx3QkFBVCxDQUFrQ3ZRLE9BQWxDLEVBQTJDO0FBQ2hELFNBQU87QUFBRU4sUUFBSSxFQUFFME4sV0FBVyxDQUFDNkIsNEJBQXBCO0FBQWtEalA7QUFBbEQsR0FBUDtBQUNEO0FBRU0sU0FBU3dRLHFCQUFULENBQStCeFEsT0FBL0IsRUFBd0M7QUFDN0MsU0FBTztBQUFFTixRQUFJLEVBQUUwTixXQUFXLENBQUNrRCwrQkFBcEI7QUFBcUR0UTtBQUFyRCxHQUFQO0FBQ0Q7QUFFTSxTQUFTeVEsaUJBQVQsQ0FBMkJ6USxPQUEzQixFQUFvQztBQUN6QyxTQUFPO0FBQUVOLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ2dELG9CQUFwQjtBQUEwQ3BRO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVMwUSxnQkFBVCxDQUEwQjFRLE9BQTFCLEVBQW1DO0FBQ3hDLFNBQU87QUFBRU4sUUFBSSxFQUFFME4sV0FBVyxDQUFDaUQsa0JBQXBCO0FBQXdDclE7QUFBeEMsR0FBUDtBQUNEO0FBRU0sU0FBUzJRLGtCQUFULENBQTRCM1EsT0FBNUIsRUFBcUM7QUFDMUMsU0FBTztBQUFFTixRQUFJLEVBQUUwTixXQUFXLENBQUMrQyxvQkFBcEI7QUFBMENuUTtBQUExQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTNFEsMkJBQVQsQ0FBcUM1USxPQUFyQyxFQUE4QztBQUNuRCxTQUFPO0FBQUVOLFFBQUksRUFBRTBOLFdBQVcsQ0FBQzhDLCtCQUFwQjtBQUFxRGxRO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVM2USxvQkFBVCxDQUE4QjdRLE9BQTlCLEVBQXVDO0FBQzVDLFNBQU87QUFBRU4sUUFBSSxFQUFFME4sV0FBVyxDQUFDNEMsc0JBQXBCO0FBQTRDaFE7QUFBNUMsR0FBUDtBQUNEO0FBRU0sU0FBUzhRLHNCQUFULENBQWdDOVEsT0FBaEMsRUFBeUM7QUFDOUMsU0FBTztBQUFFTixRQUFJLEVBQUUwTixXQUFXLENBQUM2Qyx3QkFBcEI7QUFBOENqUTtBQUE5QyxHQUFQO0FBQ0Q7QUFFTSxTQUFTK1EsYUFBVCxDQUF1Qi9RLE9BQXZCLEVBQWdDO0FBQ3JDLFNBQU87QUFBRU4sUUFBSSxFQUFFME4sV0FBVyxDQUFDMkMsY0FBcEI7QUFBb0MvUDtBQUFwQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTZ1IsMEJBQVQsR0FBc0M7QUFDM0MsU0FBTztBQUNMdFIsUUFBSSxFQUFFME4sV0FBVyxDQUFDeUM7QUFEYixHQUFQO0FBR0Q7QUFFTSxTQUFTb0IsaUNBQVQsQ0FBMkNqUixPQUEzQyxFQUFvRDtBQUN6RCxTQUFPO0FBQ0xOLFFBQUksRUFBRTBOLFdBQVcsQ0FBQzBDLDhCQURiO0FBRUw5UDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVN5SSxPQUFULEdBQW1CO0FBQ3hCM0gsT0FBSyxDQUFDLFNBQUQsQ0FBTDtBQUNBLFNBQU87QUFBRXBCLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ3NCO0FBQXBCLEdBQVA7QUFDRDtBQUVNLFNBQVN3QyxjQUFULENBQXdCbFIsT0FBeEIsRUFBaUM7QUFDdEMsU0FBTztBQUNMTixRQUFJLEVBQUUwTixXQUFXLENBQUN1QixnQkFEYjtBQUVMM087QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTbVIsWUFBVCxDQUFzQjdQLEtBQXRCLEVBQTZCO0FBQ2xDLFNBQU87QUFDTDVCLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ3dCLGNBRGI7QUFFTHROO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBUzhQLHFCQUFULENBQStCcFIsT0FBL0IsRUFBd0M7QUFDN0NjLE9BQUssQ0FBQyxNQUFELENBQUw7QUFDQUgsU0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQlosT0FBM0I7QUFFQSxTQUFPO0FBQ0xOLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ3dDLHVCQURiO0FBRUw1UDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVNxUixPQUFULENBQWlCclIsT0FBakIsRUFBMEI7QUFDL0IsU0FBTztBQUFFTixRQUFJLEVBQUUwTixXQUFXLENBQUMyQixRQUFwQjtBQUE4Qi9PO0FBQTlCLEdBQVA7QUFDRDtBQUVNLFNBQVNzUixVQUFULENBQW9CbE4sT0FBcEIsRUFBNkI7QUFDbEMsU0FBTztBQUFFMUUsUUFBSSxFQUFFME4sV0FBVyxDQUFDNEIsV0FBcEI7QUFBaUM1SztBQUFqQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTbU4sZUFBVCxDQUF5Qm5OLE9BQXpCLEVBQWtDO0FBQ3ZDLFNBQU87QUFBRTFFLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ2lDLFlBQXBCO0FBQWtDakw7QUFBbEMsR0FBUDtBQUNEO0FBRU0sU0FBU29OLGVBQVQsQ0FBeUJwTixPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQUUxRSxRQUFJLEVBQUUwTixXQUFXLENBQUNvQyxZQUFwQjtBQUFrQ3BMO0FBQWxDLEdBQVA7QUFDRDtBQUVNLFNBQVNxTixpQkFBVCxDQUEyQnpSLE9BQTNCLEVBQW9DO0FBQ3pDLFNBQU87QUFDTE4sUUFBSSxFQUFFME4sV0FBVyxDQUFDc0MsbUJBRGI7QUFFTDFQO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBUzBSLGVBQVQsQ0FBeUIxUixPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQ0xOLFFBQUksRUFBRTBOLFdBQVcsQ0FBQ3VDLGlCQURiO0FBRUwzUDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVMyUixTQUFULEdBQXFCO0FBQzFCLFNBQU87QUFBRWpTLFFBQUksRUFBRTBOLFdBQVcsQ0FBQzhCO0FBQXBCLEdBQVA7QUFDRDtBQUVNLFNBQVMwQyxnQkFBVCxHQUE0QjtBQUNqQyxTQUFPO0FBQUVsUyxRQUFJLEVBQUUwTixXQUFXLENBQUMrQjtBQUFwQixHQUFQO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xLRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFVQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTWxGLFlBQVksR0FBRyxDQUFDdkssSUFBRCxFQUFPQyxPQUFQLEtBQW1CO0FBQ3RDRSxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBRGlCO0FBRWpCQyxlQUFXLEVBQUUsMkNBRkk7QUFHakJpUyxZQUFRLEVBQUU7QUFITyxHQUFuQjtBQUtELENBTkQ7O0FBT0EsTUFBTUMsWUFBWSxHQUFJcFMsSUFBRCxJQUFVO0FBQzdCRyxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBQU8sRUFBRSxlQURRO0FBRWpCQyxlQUFXLEVBQUUsK0NBRkk7QUFHakJpUyxZQUFRLEVBQUU7QUFITyxHQUFuQjtBQUtELENBTkQ7O0FBUU8sTUFBTUUsZUFBZSxHQUFJQyxHQUFELElBQzdCckksTUFBTSxDQUFDc0ksTUFBUCxDQUFjRCxHQUFkLEVBQ0dFLE1BREgsQ0FDVSxDQUFDQyxHQUFELEVBQU07QUFBRTlOLFVBQUY7QUFBWStOO0FBQVosQ0FBTixLQUE4QkQsR0FBRyxHQUFHOU4sUUFBUSxHQUFHK04sS0FEekQsRUFDZ0UsQ0FEaEUsRUFFR0MsT0FGSCxDQUVXLENBRlgsQ0FESzs7QUFLUCxVQUFVQyxXQUFWLEdBQXdCO0FBQ3RCeFIsT0FBSyxDQUFDLE9BQUQsQ0FBTDs7QUFDQSxNQUFJO0FBQ0YsUUFBSW9CLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUNBLFFBQUl4QyxPQUFPLEdBQUc7QUFDWnVDLGtCQURZO0FBRVpDO0FBRlksS0FBZDtBQUlKN0IsV0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBeUNaLE9BQXpDO0FBQ0ksVUFBTUMsUUFBUSxHQUFHLE1BQU1rSywrREFBSSxDQUFDakcsb0VBQWMsQ0FBQ00sV0FBaEIsRUFBNkJ4RSxPQUE3QixDQUEzQjtBQUNBVyxXQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWixFQUF5Q1osT0FBekM7QUFDQVcsV0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQVosRUFBOEJYLFFBQTlCO0FBQ0EsVUFBTW1LLDhEQUFHLENBQUM4Ryw4REFBYyxDQUFDalIsUUFBUSxDQUFDSyxJQUFWLENBQWYsQ0FBVDtBQUNELEdBZEQsQ0FjRSxPQUFPRSxHQUFQLEVBQVk7QUFDWixVQUFNNEosOERBQUcsQ0FBQytHLDREQUFZLENBQUMzUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVStSLFdBQVYsQ0FBc0I7QUFBRXZTO0FBQUYsQ0FBdEIsRUFBbUM7QUFDakNjLE9BQUssQ0FBQyxhQUFELENBQUw7O0FBQ0EsTUFBSTtBQUNGLFVBQU1iLFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ2pHLG9FQUFjLENBQUNDLGdCQUFoQixFQUFrQ25FLE9BQWxDLENBQTNCO0FBRUFpSyxnQkFBWSxDQUFDaEssUUFBUSxDQUFDdVMsTUFBVixFQUFrQnZTLFFBQVEsQ0FBQ04sT0FBM0IsQ0FBWjtBQUNBLFVBQU15Syw4REFBRyxDQUFDM0IsdURBQU8sQ0FBQ3pJLE9BQU8sQ0FBQ3VDLFlBQVQsQ0FBUixDQUFUO0FBQ0QsR0FMRCxDQUtFLE9BQU8vQixHQUFQLEVBQVk7QUFDWixVQUFNNEosOERBQUcsQ0FBQytHLDREQUFZLENBQUMzUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVWlTLGNBQVYsQ0FBeUJ6UyxPQUF6QixFQUFrQztBQUNoQyxNQUFJO0FBQ0YsVUFBTTtBQUFFb0U7QUFBRixRQUFjcEUsT0FBcEI7QUFDQSxRQUFJMFMsU0FBUyxHQUFHblIsSUFBSSxDQUFDZSxLQUFMLENBQ2RmLElBQUksQ0FBQ2UsS0FBTCxDQUFXSCxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsaUJBQXJCLENBQVgsRUFBb0R1USxJQUR0QyxDQUFoQjtBQUlBLFFBQUlDLEtBQUssR0FBR0YsU0FBUyxDQUFDRyxTQUFWLENBQW9CQyxTQUFwQixDQUErQnpLLElBQUQsSUFBVUEsSUFBSSxDQUFDVCxFQUFMLEtBQVl4RCxPQUFPLENBQUN3RCxFQUE1RCxDQUFaO0FBQ0E4SyxhQUFTLENBQUNLLFNBQVYsR0FBc0JMLFNBQVMsQ0FBQ0ssU0FBVixHQUFzQjNPLE9BQU8sQ0FBQ0MsUUFBcEQ7QUFDQXFPLGFBQVMsQ0FBQ0csU0FBVixDQUFvQkcsTUFBcEIsQ0FBMkJKLEtBQTNCLEVBQWtDLENBQWxDO0FBQ0FGLGFBQVMsQ0FBQ08sTUFBVixHQUFtQmxCLGVBQWUsQ0FBQ1csU0FBUyxDQUFDRyxTQUFYLENBQWxDOztBQUNBLFFBQUlILFNBQVMsQ0FBQ0csU0FBVixDQUFvQjdLLE1BQXBCLEtBQStCLENBQW5DLEVBQXNDO0FBQ3BDMEssZUFBUyxDQUFDRyxTQUFWLEdBQXNCLEVBQXRCO0FBQ0FILGVBQVMsQ0FBQ08sTUFBVixHQUFtQixDQUFuQjtBQUNBUCxlQUFTLENBQUNLLFNBQVYsR0FBc0IsQ0FBdEI7QUFDRDs7QUFDRCxVQUFNM0ksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0FaLGdCQUFZLENBQUMsU0FBRCxDQUFaO0FBQ0QsR0FqQkQsQ0FpQkUsT0FBT3RSLEdBQVAsRUFBWTtBQUNaLFVBQU00Siw4REFBRyxDQUFDK0csNERBQVksQ0FBQzNRLEdBQUQsQ0FBYixDQUFUO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVMFMsZUFBVixDQUEwQmxULE9BQTFCLEVBQW1DO0FBQ2pDLE1BQUk7QUFDRixVQUFNO0FBQUVvRTtBQUFGLFFBQWNwRSxPQUFwQjtBQUNBLFFBQUkwUyxTQUFTLEdBQUduUixJQUFJLENBQUNlLEtBQUwsQ0FDZGYsSUFBSSxDQUFDZSxLQUFMLENBQVdILFlBQVksQ0FBQ0MsT0FBYixDQUFxQixpQkFBckIsQ0FBWCxFQUFvRHVRLElBRHRDLENBQWhCO0FBR0EsUUFBSVEsWUFBWSxHQUFHVCxTQUFTLENBQUNHLFNBQVYsQ0FBb0JPLElBQXBCLENBQ2hCL0ssSUFBRCxJQUFVQSxJQUFJLENBQUNULEVBQUwsS0FBWXhELE9BQU8sQ0FBQ3dELEVBRGIsQ0FBbkI7O0FBR0EsUUFBSXVMLFlBQUosRUFBa0I7QUFDaEJBLGtCQUFZLENBQUM5TyxRQUFiO0FBQ0FxTyxlQUFTLENBQUNLLFNBQVY7QUFDQUwsZUFBUyxDQUFDTyxNQUFWLEdBQW1CbEIsZUFBZSxDQUFDVyxTQUFTLENBQUNHLFNBQVgsQ0FBbEM7QUFDRDs7QUFDRCxVQUFNekksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0QsR0FkRCxDQWNFLE9BQU9sUyxHQUFQLEVBQVk7QUFDWixVQUFNNEosOERBQUcsQ0FBQytHLDREQUFZLENBQUMzUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTZTLG1CQUFWLENBQThCclQsT0FBOUIsRUFBdUM7QUFDckMsTUFBSTtBQUNGLFVBQU07QUFBRW9FO0FBQUYsUUFBY3BFLE9BQXBCO0FBQ0EsVUFBTTBTLFNBQVMsR0FBR25SLElBQUksQ0FBQ2UsS0FBTCxDQUNoQmYsSUFBSSxDQUFDZSxLQUFMLENBQVdILFlBQVksQ0FBQ0MsT0FBYixDQUFxQixpQkFBckIsQ0FBWCxFQUFvRHVRLElBRHBDLENBQWxCO0FBR0EsUUFBSVEsWUFBWSxHQUFHVCxTQUFTLENBQUNHLFNBQVYsQ0FBb0JPLElBQXBCLENBQ2hCL0ssSUFBRCxJQUFVQSxJQUFJLENBQUNULEVBQUwsS0FBWXhELE9BQU8sQ0FBQ3dELEVBRGIsQ0FBbkI7O0FBSUEsUUFBSXVMLFlBQUosRUFBa0I7QUFDaEJBLGtCQUFZLENBQUM5TyxRQUFiO0FBQ0FxTyxlQUFTLENBQUNLLFNBQVY7QUFDQUwsZUFBUyxDQUFDTyxNQUFWLEdBQW1CbEIsZUFBZSxDQUFDVyxTQUFTLENBQUNHLFNBQVgsQ0FBbEM7QUFDRDs7QUFDRCxVQUFNekksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0QsR0FmRCxDQWVFLE9BQU9sUyxHQUFQLEVBQVk7QUFDWixVQUFNNEosOERBQUcsQ0FBQytHLDREQUFZLENBQUMzUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVThTLGFBQVYsR0FBMEI7QUFDeEIsTUFBSTtBQUNGLFVBQU1DLFNBQVMsR0FBRztBQUNoQlYsZUFBUyxFQUFFLEVBREs7QUFFaEJJLFlBQU0sRUFBRSxDQUZRO0FBR2hCRixlQUFTLEVBQUUsQ0FISztBQUloQkosVUFBSSxFQUFFO0FBSlUsS0FBbEI7QUFNQSxVQUFNdkksOERBQUcsQ0FBQ3dILGdFQUFnQixDQUFDMkIsU0FBRCxDQUFqQixDQUFUO0FBQ0QsR0FSRCxDQVFFLE9BQU8vUyxHQUFQLEVBQVk7QUFDWixVQUFNNEosOERBQUcsQ0FBQ3NILCtEQUFlLENBQUNsUixHQUFELENBQWhCLENBQVQ7QUFDRDtBQUNGOztBQUVELFVBQVVnVCx3QkFBVixHQUFxQztBQUNuQyxNQUFJO0FBQ0YsVUFBTXZULFFBQVEsR0FBRyxNQUFNa0ssK0RBQUksQ0FBQ2pHLG9FQUFjLENBQUNZLG9CQUFoQixDQUEzQjtBQUNBLFVBQU1zRiw4REFBRyxDQUFDNkcsaUZBQWlDLENBQUNoUixRQUFRLENBQUNLLElBQVQsQ0FBY21ULE1BQWYsQ0FBbEMsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPalQsR0FBUCxFQUFZLENBQUU7QUFDakI7O0FBRUQsVUFBVWtULHFCQUFWLENBQWdDO0FBQUUxVDtBQUFGLENBQWhDLEVBQTZDO0FBQzNDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWtLLCtEQUFJLENBQUNyRSx1RUFBaUIsQ0FBQzRDLFVBQW5CLEVBQStCMUksT0FBL0IsQ0FBM0I7O0FBQ0EsUUFBSUMsUUFBUSxJQUFJQSxRQUFRLENBQUNTLFFBQVQsSUFBcUIsR0FBckMsRUFBMEM7QUFDeENpVCwyRkFBbUIsQ0FBQyxTQUFELEVBQVksU0FBWixFQUF1QixpQkFBdkIsQ0FBbkI7QUFDRDs7QUFDRCxVQUFNdkosOERBQUcsQ0FBQzNCLHVEQUFPLEVBQVIsQ0FBVDtBQUNELEdBTkQsQ0FNRSxPQUFPakksR0FBUCxFQUFZO0FBQ1ptVCx5RkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix3QkFBbkIsQ0FBbkI7QUFDRDtBQUNGOztBQUVjLFVBQVUxRyxRQUFWLEdBQXFCO0FBQ25DO0FBQ0MsUUFBTUMsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDc0IsUUFBYixFQUF1QjRELFdBQXZCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTXBGLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzJCLFFBQWIsRUFBdUJ3RCxXQUF2QixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1yRiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUM0QixXQUFiLEVBQTBCeUQsY0FBMUIsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNdkYsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDaUMsWUFBYixFQUEyQjZELGVBQTNCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTWhHLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ29DLFlBQWIsRUFBMkI2RCxtQkFBM0IsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNbkcsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDOEIsVUFBYixFQUF5Qm9FLGFBQXpCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTXBHLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ3lDLHNCQUFiLEVBQXFDMkQsd0JBQXJDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTXRHLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzZCLDRCQUFiLEVBQTJDeUUscUJBQTNDLENBREQsQ0FBRCxDQUFUO0FBR0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JMRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNekosWUFBWSxHQUFJdkssSUFBRCxJQUFVO0FBQzdCRyxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBQU8sRUFBRSxxQkFEUTtBQUVqQkMsZUFBVyxFQUFFO0FBRkksR0FBbkI7QUFJRCxDQUxEOztBQU9BLE1BQU1rUyxZQUFZLEdBQUcsQ0FBQ3BTLElBQUQsRUFBT0MsT0FBUCxFQUFnQkMsV0FBaEIsS0FBZ0M7QUFDbkRDLG1EQUFZLENBQUNILElBQUQsQ0FBWixDQUFtQjtBQUNqQkMsV0FBTyxFQUFFLHVCQURRO0FBRWpCQyxlQUFXLEVBQUU7QUFGSSxHQUFuQjtBQUlELENBTEQ7O0FBT0EsTUFBTWdVLGtCQUFrQixHQUFHLENBQUNsVSxJQUFELEVBQU9DLE9BQVAsRUFBZ0JDLFdBQWhCLEtBQWdDO0FBQ3pEQyxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBRGlCO0FBRWpCQztBQUZpQixHQUFuQjtBQUlELENBTEQ7O0FBT0EsTUFBTWlVLFNBQVMsR0FBRyxDQUFDblUsSUFBRCxFQUFPQyxPQUFQLEVBQWdCQyxXQUFoQixLQUFnQztBQUNoREMsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLFVBQVVrVSxtQkFBVixHQUFnQztBQUM5QixNQUFJO0FBQ0YsUUFBSTVSLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUNBLFFBQUl4QyxPQUFPLEdBQUc7QUFDWnVDLGtCQURZO0FBRVpDO0FBRlksS0FBZDtBQUtBLFVBQU11UixZQUFZLEdBQUcsTUFBTTVKLCtEQUFJLENBQzdCNkosd0VBQWtCLENBQUNDLG9CQURVLEVBRTdCalUsT0FGNkIsQ0FBL0I7QUFLQSxVQUFNb0ssOERBQUcsQ0FDUCxDQUFBMkosWUFBWSxTQUFaLElBQUFBLFlBQVksV0FBWixZQUFBQSxZQUFZLENBQUVyVCxRQUFkLEtBQTBCLEtBQTFCLElBQ0V3VCxzRUFBc0IsQ0FBQ0gsWUFBWSxDQUFDelQsSUFBZCxDQUZqQixDQUFUO0FBSUQsR0FuQkQsQ0FtQkUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVMlQscUJBQVYsQ0FBZ0M7QUFBRS9QO0FBQUYsQ0FBaEMsRUFBNkM7QUFDM0MsTUFBSTtBQUNGLFFBQUlsQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBQ0EsUUFBSXZDLE9BQU8sR0FBRztBQUNadUMsa0JBRFk7QUFFWmdDLGdCQUFVLEVBQUVILE9BRkE7QUFHWjFFLFVBQUksRUFBRTtBQUhNLEtBQWQ7QUFNQSxVQUFNcVUsWUFBWSxHQUFHLE1BQU01SiwrREFBSSxDQUM3QjZKLHdFQUFrQixDQUFDSSxvQkFEVSxFQUU3QnBVLE9BRjZCLENBQS9CO0FBSUE2VCxhQUFTLENBQ1BFLFlBQVksQ0FBQ3ZCLE1BRE4sRUFFUHVCLFlBQVksQ0FBQ3BVLE9BRk4sRUFHUG9VLFlBQVksQ0FBQ3pULElBQWIsQ0FBa0JYLE9BSFgsQ0FBVDtBQUtBLFVBQU15Syw4REFBRyxDQUFDaUssK0RBQWUsRUFBaEIsQ0FBVDtBQUNBLFVBQU1qSyw4REFBRyxDQUFDekMsdUVBQWUsQ0FBQ3ZELE9BQUQsQ0FBaEIsQ0FBVDtBQUNELEdBckJELENBcUJFLE9BQU81RCxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVU4VCxzQkFBVixDQUFpQztBQUFFbFE7QUFBRixDQUFqQyxFQUE4QztBQUM1QyxNQUFJO0FBQ0YsUUFBSWxDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJdkMsT0FBTyxHQUFHO0FBQ1p1QyxrQkFEWTtBQUVaZ0MsZ0JBQVUsRUFBRUg7QUFGQSxLQUFkO0FBSUEsVUFBTTJQLFlBQVksR0FBRyxNQUFNNUosK0RBQUksQ0FDN0I2Six3RUFBa0IsQ0FBQ08seUJBRFUsRUFFN0J2VSxPQUY2QixDQUEvQjtBQUlBNFQsc0JBQWtCLENBQ2hCLFNBRGdCLEVBRWhCRyxZQUFZLENBQUNwVSxPQUZHLEVBR2hCb1UsWUFBWSxDQUFDelQsSUFBYixDQUFrQlgsT0FIRixDQUFsQjtBQUtBLFVBQU15Syw4REFBRyxDQUFDaUssK0RBQWUsRUFBaEIsQ0FBVDtBQUVBLFVBQU1qSyw4REFBRyxDQUFDekMsdUVBQWUsQ0FBQ3ZELE9BQUQsQ0FBaEIsQ0FBVDtBQUNELEdBcEJELENBb0JFLE9BQU81RCxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVVnVSxxQkFBVixHQUFrQztBQUNoQyxNQUFJO0FBQ0YsVUFBTWpCLFNBQVMsR0FBRztBQUNoQmtCLG1CQUFhLEVBQUUsRUFEQztBQUVoQkMsbUJBQWEsRUFBRTtBQUZDLEtBQWxCO0FBSUEsVUFBTXRLLDhEQUFHLENBQUN1Syx5RUFBeUIsQ0FBQ3BCLFNBQUQsQ0FBMUIsQ0FBVDtBQUNELEdBTkQsQ0FNRSxPQUFPL1MsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFDRCxVQUFVb1UsaUNBQVYsQ0FBNEM7QUFBRXhRO0FBQUYsQ0FBNUMsRUFBeUQ7QUFDdkQsTUFBSTtBQUNGLFFBQUlsQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBQ0EsUUFBSXZDLE9BQU8sR0FBRztBQUNadUMsa0JBRFk7QUFFWmdDLGdCQUFVLEVBQUVILE9BRkE7QUFHWjFFLFVBQUksRUFBRTtBQUhNLEtBQWQ7QUFNQSxVQUFNcVUsWUFBWSxHQUFHLE1BQU01SiwrREFBSSxDQUM3QjZKLHdFQUFrQixDQUFDSSxvQkFEVSxFQUU3QnBVLE9BRjZCLENBQS9CO0FBSUE2VCxhQUFTLENBQ1BFLFlBQVksQ0FBQ3ZCLE1BRE4sRUFFUHVCLFlBQVksQ0FBQ3BVLE9BRk4sRUFHUG9VLFlBQVksQ0FBQ3pULElBQWIsQ0FBa0JYLE9BSFgsQ0FBVDtBQUtBLFVBQU15Syw4REFBRyxDQUFDaUssK0RBQWUsRUFBaEIsQ0FBVDtBQUNBLFVBQU1qSyw4REFBRyxDQUFDeUssa0ZBQTBCLENBQUMsSUFBRCxDQUEzQixDQUFUO0FBQ0QsR0FyQkQsQ0FxQkUsT0FBT3JVLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVXNVLHNDQUFWLENBQWlEO0FBQUUxUTtBQUFGLENBQWpELEVBQThEO0FBQzVELE1BQUk7QUFDRixRQUFJbEMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUNBLFFBQUl2QyxPQUFPLEdBQUc7QUFDWnVDLGtCQURZO0FBRVpnQyxnQkFBVSxFQUFFSDtBQUZBLEtBQWQ7QUFJQSxVQUFNMlAsWUFBWSxHQUFHLE1BQU01SiwrREFBSSxDQUM3QjZKLHdFQUFrQixDQUFDTyx5QkFEVSxFQUU3QnZVLE9BRjZCLENBQS9CO0FBSUE0VCxzQkFBa0IsQ0FDaEIsU0FEZ0IsRUFFaEJHLFlBQVksQ0FBQ3BVLE9BRkcsRUFHaEJvVSxZQUFZLENBQUN6VCxJQUFiLENBQWtCWCxPQUhGLENBQWxCO0FBS0EsVUFBTXlLLDhEQUFHLENBQUNpSywrREFBZSxFQUFoQixDQUFUO0FBQ0EsVUFBTWpLLDhEQUFHLENBQUN5SyxrRkFBMEIsQ0FBQyxLQUFELENBQTNCLENBQVQ7QUFDRCxHQW5CRCxDQW1CRSxPQUFPclUsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFYyxVQUFVeU0sUUFBVixHQUFxQjtBQUNsQyxRQUFNQyw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUMySCxpQkFBYixFQUFnQ2pCLG1CQUFoQyxDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU01Ryw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUM0SCxpQkFBYixFQUFnQ2IscUJBQWhDLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTWpILDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzZILG9CQUFiLEVBQW1DWCxzQkFBbkMsQ0FERCxDQUFELENBQVQ7QUFHQSxRQUFNcEgsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUNQQyxtREFBVyxDQUFDOEgsa0NBREwsRUFFUE4saUNBRk8sQ0FERCxDQUFELENBQVQ7QUFNQSxRQUFNMUgsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUNQQyxtREFBVyxDQUFDK0gsdUNBREwsRUFFUEwsc0NBRk8sQ0FERCxDQUFELENBQVQ7QUFNRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFNRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNTSxTQUFTLEdBQUdDLG1CQUFPLENBQUMscUVBQUQsQ0FBekI7O0FBRU8sU0FBU0MsbUJBQVQsQ0FBNkJDLFNBQTdCLEVBQXdDO0FBQzdDQyxvREFBTSxDQUFDQyxPQUFQLENBQWVGLFNBQWYsRUFBMEJHLFNBQTFCLEVBQXFDO0FBQ25DQyxXQUFPLEVBQUU7QUFEMEIsR0FBckM7QUFHRDtBQUVNLFNBQVNDLDBCQUFULENBQW9DeFIsT0FBcEMsRUFBNkM7QUFDbEQsTUFBSUEsT0FBTyxDQUFDeVIsV0FBUixLQUF3QixLQUE1QixFQUFtQztBQUNqQyx3QkFDRTtBQUFHLGVBQVMsRUFBQyx5QkFBYjtBQUFBLHdCQUNNelIsT0FBTyxDQUFDeVIsV0FBUixHQUFzQnpSLE9BQU8sQ0FBQ3lSLFdBQTlCLEdBQTRDLENBRGxELGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwwQkFDTXpSLE9BQU8sQ0FBQzBSLFlBQVIsR0FBdUIxUixPQUFPLENBQUMwUixZQUEvQixHQUE4QyxDQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQVFEOztBQUNELE1BQUkxUixPQUFPLENBQUMyUixnQkFBUixLQUE2QixLQUFqQyxFQUF3QztBQUN0Qyx3QkFDRTtBQUFHLGVBQVMsRUFBQyx5QkFBYjtBQUFBLHdCQUNNM1IsT0FBTyxDQUFDMlIsZ0JBRGQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUNNM1IsT0FBTyxDQUFDMFIsWUFBUixHQUF1QjFSLE9BQU8sQ0FBQzBSLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0QsTUFBSTFSLE9BQU8sQ0FBQzRSLFVBQVIsS0FBdUIsS0FBM0IsRUFBa0M7QUFDaEMsd0JBQ0U7QUFBRyxlQUFTLEVBQUMseUJBQWI7QUFBQSx3QkFDTTVSLE9BQU8sQ0FBQzRSLFVBRGQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUNNNVIsT0FBTyxDQUFDMFIsWUFBUixHQUF1QjFSLE9BQU8sQ0FBQzBSLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0Qsc0JBQ0U7QUFBRyxhQUFTLEVBQUMsbUJBQWI7QUFBQSxzQkFDTTFSLE9BQU8sQ0FBQzBSLFlBQVIsR0FBdUIxUixPQUFPLENBQUMwUixZQUEvQixHQUE4QyxDQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQUtEO0FBRU0sU0FBU0csc0JBQVQsQ0FBZ0N4UCxRQUFoQyxFQUEwQztBQUMvQyxNQUFJeVAsZ0JBQWdCLEdBQUd6UCxRQUFRLENBQUN5TCxNQUFULENBQWdCLENBQUNpRSxJQUFELEVBQU9DLElBQVAsS0FBZ0I7QUFDckQsV0FDRUMsTUFBTSxDQUFDQyxXQUFXLENBQUNILElBQUQsQ0FBWixDQUFOLEdBQ0FFLE1BQU0sQ0FDSkMsV0FBVyxDQUNURixJQUFJLENBQUNHLG9CQUFMLElBQTZCLENBQTdCLEdBQ0lILElBQUksQ0FBQ0ksa0JBRFQsR0FFSUosSUFBSSxDQUFDRyxvQkFIQSxDQURQLENBRlI7QUFVRCxHQVhzQixFQVdwQixDQVhvQixDQUF2QjtBQWFBLFNBQU9MLGdCQUFQO0FBQ0Q7QUFFTSxTQUFTTyxxQkFBVCxDQUErQmhRLFFBQS9CLEVBQXlDO0FBQzlDLE1BQUlpUSxxQkFBcUIsR0FBR2pRLFFBQVEsQ0FBQ3lMLE1BQVQsQ0FBZ0IsQ0FBQ2lFLElBQUQsRUFBT0MsSUFBUCxLQUFnQjtBQUMxRCxXQUFPQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ0gsSUFBRCxDQUFaLENBQU4sR0FBNEJFLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRixJQUFJLENBQUNPLFVBQU4sQ0FBWixDQUF6QztBQUNELEdBRjJCLEVBRXpCLENBRnlCLENBQTVCO0FBSUEsU0FBT0QscUJBQVA7QUFDRDtBQUVNLFNBQVNFLHlCQUFULENBQW1DblEsUUFBbkMsRUFBNkM7QUFDbEQsTUFBSW9RLGNBQWMsR0FBR3BRLFFBQVEsQ0FBQ3lMLE1BQVQsQ0FBZ0IsQ0FBQ2lFLElBQUQsRUFBT0MsSUFBUCxLQUFnQjtBQUNuRCxXQUNFQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ0gsSUFBRCxDQUFaLENBQU4sR0FBNEJFLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRixJQUFJLENBQUNVLGVBQU4sQ0FBWixDQURwQztBQUdELEdBSm9CLEVBSWxCLENBSmtCLENBQXJCO0FBTUEsU0FBT0QsY0FBUDtBQUNEO0FBRU0sU0FBU1AsV0FBVCxDQUFxQlMsR0FBckIsRUFBMEI7QUFDL0IsTUFBSUMsV0FBVyxHQUFHRCxHQUFILGFBQUdBLEdBQUgsdUJBQUdBLEdBQUcsQ0FBRUUsUUFBTCxHQUFnQkMsS0FBaEIsQ0FBc0IsR0FBdEIsQ0FBbEI7O0FBQ0EsTUFBSUYsV0FBVyxJQUFJLENBQUFBLFdBQVcsU0FBWCxJQUFBQSxXQUFXLFdBQVgsWUFBQUEsV0FBVyxDQUFFaFAsTUFBYixJQUFzQixDQUF6QyxFQUE0QztBQUMxQyxXQUFPZ1AsV0FBVyxDQUFDOUUsTUFBWixDQUFtQixDQUFDaUUsSUFBRCxFQUFPQyxJQUFQLEtBQWdCRCxJQUFJLEdBQUdDLElBQTFDLENBQVA7QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPLENBQVA7QUFDRDtBQUNGO0FBRU0sU0FBU2UsOEJBQVQsQ0FBd0NDLFdBQXhDLEVBQXFEO0FBQzFELFNBQU8sSUFBSUMsSUFBSSxDQUFDQyxZQUFULENBQXNCLE9BQXRCLEVBQStCO0FBQ3BDQyxTQUFLLEVBQUUsVUFENkI7QUFFcENDLFlBQVEsRUFBRTtBQUYwQixHQUEvQixFQUdKQyxNQUhJLENBR0duQixXQUFXLENBQUNjLFdBQUQsQ0FIZCxDQUFQO0FBSUQ7QUFFTSxTQUFTTSxXQUFULENBQXFCQyxXQUFyQixFQUFrQztBQUN2QyxNQUFJQyxNQUFNLEdBQUd4QyxTQUFTLENBQUN5QyxPQUFWLENBQWtCRixXQUFsQixDQUFiO0FBQ0Q7QUFFTSxTQUFTRyxXQUFULENBQXFCQyxRQUFyQixFQUErQkMsU0FBL0IsRUFBMEM7QUFDL0MsTUFBSUMsT0FBTyxHQUFHN0MsU0FBUyxDQUFDOEMsR0FBVixDQUNaNUIsV0FBVyxDQUFDeUIsUUFBUSxJQUFJLENBQWIsQ0FEQyxFQUVaekIsV0FBVyxDQUFDMEIsU0FBUyxJQUFJLENBQWQsQ0FGQyxDQUFkO0FBSUEsU0FBT0MsT0FBUDtBQUNEO0FBRU0sU0FBU0UsV0FBVCxDQUFxQkosUUFBckIsRUFBK0JDLFNBQS9CLEVBQTBDO0FBQy9DLE1BQUlJLE9BQU8sR0FBR2hELFNBQVMsQ0FBQ2lELEdBQVYsQ0FDWi9CLFdBQVcsQ0FBQ3lCLFFBQVEsSUFBSSxDQUFiLENBREMsRUFFWnpCLFdBQVcsQ0FBQzBCLFNBQVMsSUFBSSxDQUFkLENBRkMsQ0FBZDtBQUlBLFNBQU9JLE9BQVA7QUFDRDtBQUVNLFNBQVNFLFdBQVQsQ0FBcUJDLGdCQUFyQixFQUF1Q0MsaUJBQXZDLEVBQTBEO0FBQy9ELE1BQUlDLE9BQU8sR0FBR3JELFNBQVMsQ0FBQ3NELEdBQVYsQ0FDWnBDLFdBQVcsQ0FBQ2lDLGdCQUFnQixJQUFJLENBQXJCLENBREMsRUFFWmpDLFdBQVcsQ0FBQ2tDLGlCQUFpQixJQUFJLENBQXRCLENBRkMsQ0FBZDtBQUtBLFNBQU9DLE9BQVA7QUFDRDtBQUNNLFNBQVNFLFdBQVQsQ0FBcUJKLGdCQUFyQixFQUF1Q0MsaUJBQXZDLEVBQTBEO0FBQy9ELE1BQUlJLE9BQU8sR0FBR3hELFNBQVMsQ0FBQ3lELEdBQVYsQ0FDWnZDLFdBQVcsQ0FBQ2lDLGdCQUFnQixJQUFJLENBQXJCLENBREMsRUFFWmpDLFdBQVcsQ0FBQ2tDLGlCQUFpQixJQUFJLENBQXRCLENBRkMsQ0FBZDtBQUtBLFNBQU9JLE9BQVA7QUFDRDtBQUVNLFNBQVNFLGNBQVQsQ0FBd0IvQixHQUF4QixFQUE2QjtBQUNsQyxNQUFJQSxHQUFHLEtBQUtyQixTQUFaLEVBQXVCO0FBQ3JCLFdBQU9xRCxVQUFVLENBQUNoQyxHQUFELENBQVYsQ0FDSkUsUUFESSxHQUVKeEIsT0FGSSxDQUVJLHlCQUZKLEVBRStCLEtBRi9CLENBQVA7QUFHRCxHQUpELE1BSU8sQ0FDTjtBQUNGO0FBRU0sU0FBU3VELGtCQUFULENBQTRCQyxXQUE1QixFQUF5Q0MsSUFBekMsRUFBK0M7QUFDcEQsTUFBSUQsV0FBVyxDQUFDalIsTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQixVQUFNNFAsTUFBTSxHQUFHcUIsV0FBVyxDQUFDN0YsSUFBWixDQUFrQi9LLElBQUQsSUFBVUEsSUFBSSxDQUFDNlEsSUFBTCxLQUFjQSxJQUFJLENBQUNqQyxRQUFMLEVBQXpDLENBQWY7O0FBQ0EsUUFBSVcsTUFBTSxLQUFLbEMsU0FBZixFQUEwQjtBQUN4QixhQUFPa0MsTUFBTSxDQUFDblIsUUFBZDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sRUFBUDtBQUNEO0FBQ0YsR0FQRCxNQU9PO0FBQ0wsV0FBTyxFQUFQO0FBQ0Q7QUFDRjtBQUVNLFNBQVMwUyxhQUFULENBQXVCQyxPQUF2QixFQUFnQ0YsSUFBaEMsRUFBc0M7QUFDM0MsTUFBSUUsT0FBTyxDQUFDcFIsTUFBUixHQUFpQixDQUFyQixFQUF3QjtBQUN0QixVQUFNcVIsTUFBTSxHQUFHRCxPQUFPLENBQUNoRyxJQUFSLENBQWMvSyxJQUFELElBQVVBLElBQUksQ0FBQzZRLElBQUwsS0FBY0EsSUFBSSxDQUFDakMsUUFBTCxFQUFyQyxDQUFmOztBQUNBLFFBQUlvQyxNQUFNLEtBQUszRCxTQUFmLEVBQTBCO0FBQ3hCLGFBQU8yRCxNQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxJQUFQO0FBQ0Q7QUFDRixHQVBELE1BT087QUFDTCxXQUFPLElBQVA7QUFDRDtBQUNGO0FBRU0sU0FBU0MsdUJBQVQsQ0FBaUN0WixPQUFqQyxFQUEwQztBQUMvQyxNQUFJbUksS0FBSyxHQUFHLEVBQVo7O0FBQ0EsTUFBSW5JLE9BQU8sQ0FBQ2dJLE1BQVIsR0FBaUIsQ0FBckIsRUFBd0I7QUFDdEJoSSxXQUFPLENBQUNvSSxPQUFSLENBQWlCQyxJQUFELElBQVU7QUFDeEIsVUFBSUYsS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDaEJBLGFBQUssR0FBSSxXQUFVRSxJQUFLLEVBQXhCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xGLGFBQUssR0FBR0EsS0FBSyxHQUFJLFlBQVdFLElBQUssRUFBakM7QUFDRDtBQUNGLEtBTkQ7QUFPRDs7QUFDRCxTQUFPRixLQUFQO0FBQ0Q7QUFFTSxTQUFTb1Isa0JBQVQsQ0FBNEJuVixPQUE1QixFQUFxQztBQUMxQyxNQUFJb1YsSUFBSjs7QUFDQSxNQUFJcFYsT0FBTyxDQUFDcVYsS0FBUixJQUFpQnJWLE9BQU8sQ0FBQ3FWLEtBQVIsS0FBa0IsSUFBdkMsRUFBNkM7QUFDM0NELFFBQUksR0FBR3BWLE9BQU8sQ0FBQ3FWLEtBQVIsQ0FBYzVQLEdBQWQsQ0FBbUI0UCxLQUFELElBQVc7QUFDbEMsVUFBSUEsS0FBSyxDQUFDL1osSUFBTixLQUFlLE1BQW5CLEVBQTJCO0FBQ3pCLDRCQUFPO0FBQUssbUJBQVMsRUFBQyxtQkFBZjtBQUFBLG9CQUFvQytaLEtBQUssQ0FBQ0M7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBUDtBQUNELE9BRkQsTUFFTyxJQUFJRCxLQUFLLENBQUMvWixJQUFOLEtBQWUsVUFBbkIsRUFBK0I7QUFDcEMsNEJBQU87QUFBSyxtQkFBUyxFQUFDLDZCQUFmO0FBQUEsb0JBQThDK1osS0FBSyxDQUFDQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFQO0FBQ0QsT0FGTSxNQUVBO0FBQ0wsNEJBQU87QUFBSyxtQkFBUyxFQUFDLHVCQUFmO0FBQUEsb0JBQXdDRCxLQUFLLENBQUNDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQVA7QUFDRDtBQUNGLEtBUk0sQ0FBUDtBQVNEOztBQUNELFNBQU9GLElBQVA7QUFDRDtLQWRlRCxrQjtBQWdCVCxTQUFTSSxrQkFBVCxDQUE0QnZWLE9BQTVCLEVBQXFDO0FBQzFDLE1BQUlvVixJQUFKOztBQUNBLE1BQUlwVixPQUFPLENBQUN3VixPQUFSLEtBQW9CLElBQXhCLEVBQThCO0FBQzVCSixRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLHdCQUFiO0FBQUEsd0JBQ01WLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQ2dPLEtBQVQsQ0FEcEIsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUEwQjBHLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQzRSLFVBQVQsQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFNRCxHQVBELE1BT087QUFDTHdELFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsbUJBQWI7QUFBQSx3QkFBcUNWLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQ2dPLEtBQVQsQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFHRDs7QUFDRCxTQUFPb0gsSUFBUDtBQUNEO01BZmVHLGtCO0FBaUJULFNBQVNFLHNCQUFULENBQWdDelYsT0FBaEMsRUFBeUM7QUFDOUMsTUFBSW9WLElBQUo7O0FBQ0EsTUFBSXBWLE9BQU8sQ0FBQzRSLFVBQVIsS0FBdUIsS0FBM0IsRUFBa0M7QUFDaEN3RCxRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLHdCQUFiO0FBQUEsd0JBQ01wVixPQUFPLENBQUM0UixVQURkLGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwwQkFBMEI1UixPQUFPLENBQUMwUixZQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQU1ELEdBUEQsTUFPTztBQUNMMEQsUUFBSSxnQkFBRztBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUFxQ3BWLE9BQU8sQ0FBQzBSLFlBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFQO0FBQ0Q7O0FBQ0QsU0FBTzBELElBQVA7QUFDRDtNQWJlSyxzQjtBQWVULFNBQVNDLG1CQUFULENBQTZCMVYsT0FBN0IsRUFBc0M7QUFDM0MsTUFBSW9WLElBQUo7O0FBQ0EsTUFBSXBWLE9BQU8sQ0FBQ3dWLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJKLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsbUJBQWI7QUFBQSx3QkFDTVYsY0FBYyxDQUFDMVUsT0FBTyxDQUFDNFIsVUFBVCxDQURwQixFQUMwQyxHQUQxQyxlQUVFO0FBQU0saUJBQVMsRUFBQyxVQUFoQjtBQUFBLDBCQUNNOEMsY0FBYyxDQUFDMVUsT0FBTyxDQUFDMFIsWUFBVCxDQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQVFELEdBVEQsTUFTTztBQUNMMEQsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUNNVixjQUFjLENBQUMxVSxPQUFPLENBQUM0UixVQUFULENBRHBCLEVBQzBDLEdBRDFDLGVBRUU7QUFBTSxpQkFBUyxFQUFDLFVBQWhCO0FBQUEsMEJBQ004QyxjQUFjLENBQUMxVSxPQUFPLENBQUMwUixZQUFULENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0QsU0FBTzBELElBQVA7QUFDRDtBQUVNLFNBQVNPLDBCQUFULENBQW9DM1YsT0FBcEMsRUFBNkM7QUFDbEQsTUFBSW9WLElBQUo7O0FBQ0EsTUFBSXBWLE9BQU8sQ0FBQ3dWLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJKLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx3QkFDTVYsY0FBYyxDQUFDMVUsT0FBTyxDQUFDZ08sS0FBVCxDQURwQixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQTBCMEcsY0FBYyxDQUFDMVUsT0FBTyxDQUFDNFIsVUFBVCxDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFPRCxHQVJELE1BUU87QUFDTHdELFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsbUJBQWI7QUFBQSx3QkFBcUNWLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQ2dPLEtBQVQsQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFHRDs7QUFDRCxTQUFPb0gsSUFBUDtBQUNEO01BaEJlTywwQjtBQWtCVCxTQUFTQywrQkFBVCxDQUF5QzVWLE9BQXpDLEVBQWtEO0FBQ3ZELE1BQUlvVixJQUFKO0FBRUFBLE1BQUksZ0JBQ0Y7QUFBRyxhQUFTLEVBQUMsbUJBQWI7QUFBQSxzQkFDTVYsY0FBYyxDQUFDMVUsT0FBTyxDQUFDeVIsV0FBUixHQUFzQnpSLE9BQU8sQ0FBQ3lSLFdBQTlCLEdBQTRDLENBQTdDLENBRHBCLGVBRUU7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLHdCQUNNaUQsY0FBYyxDQUFDMVUsT0FBTyxDQUFDMFIsWUFBUixHQUF1QjFSLE9BQU8sQ0FBQzBSLFlBQS9CLEdBQThDLENBQS9DLENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBQSxnQkFBUTFSLE9BQU8sQ0FBQzZWLEtBQVIsR0FBZ0I3VixPQUFPLENBQUM2VixLQUF4QixHQUFnQztBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFVQSxTQUFPVCxJQUFQO0FBQ0Q7TUFkZVEsK0I7QUFlVCxTQUFTRSxnQ0FBVCxDQUEwQzlWLE9BQTFDLEVBQW1EO0FBQ3hELE1BQUlvVixJQUFKO0FBRUFBLE1BQUksZ0JBQ0Y7QUFBRyxhQUFTLEVBQUMsbUJBQWI7QUFBQSxzQkFDTVYsY0FBYyxDQUFDMVUsT0FBTyxDQUFDNFIsVUFBUixHQUFxQjVSLE9BQU8sQ0FBQzRSLFVBQTdCLEdBQTBDLENBQTNDLENBRHBCLGVBRUU7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLHdCQUNNOEMsY0FBYyxDQUFDMVUsT0FBTyxDQUFDZ08sS0FBUixHQUFnQmhPLE9BQU8sQ0FBQ2dPLEtBQXhCLEdBQWdDLENBQWpDLENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBQSxnQkFBUWhPLE9BQU8sQ0FBQzZWLEtBQVIsR0FBZ0I3VixPQUFPLENBQUM2VixLQUF4QixHQUFnQztBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFVQSxTQUFPVCxJQUFQO0FBQ0Q7TUFkZVUsZ0M7QUFnQlQsU0FBU0Msc0JBQVQsQ0FBZ0MvVixPQUFoQyxFQUF5QztBQUM5QyxNQUFJb1YsSUFBSjs7QUFFQSxNQUFJcFYsT0FBTyxDQUFDZ1csU0FBWixFQUF1QjtBQUNyQlosUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV3BWLE9BQU8sQ0FBQ3dELEVBQUcsRUFBdkQ7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUcsR0FBRTFCLGdFQUFRLEdBQUU5QixPQUFPLENBQUNnVyxTQUFSLENBQWtCaFosR0FBSSxFQUQxQztBQUVFLGVBQUcsRUFBRWdELE9BQU8sQ0FBQ2lXO0FBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBWUQsR0FiRCxNQWFPO0FBQ0xiLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdwVixPQUFPLENBQUN3RCxFQUFHLEVBQXZEO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQUssZUFBRyxFQUFDLDJCQUFUO0FBQXFDLGVBQUcsRUFBQztBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFTRDs7QUFFRCxTQUFPNFIsSUFBUDtBQUNEO01BN0JlVyxzQjtBQStCVCxTQUFTRywyQkFBVCxDQUFxQ2xXLE9BQXJDLEVBQThDO0FBQ25ELE1BQUlvVixJQUFKOztBQUVBLE1BQUlwVixPQUFPLENBQUNtVyxLQUFSLENBQWN2UyxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQUE7O0FBQzVCd1IsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV3BWLE9BQU8sQ0FBQ0csVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBRUgsT0FBRixhQUFFQSxPQUFGLDBDQUFFQSxPQUFPLENBQUVtVyxLQUFULENBQWUsQ0FBZixDQUFGLG9EQUFFLGdCQUFtQkEsS0FEMUI7QUFFRSxlQUFHLEVBQUVuVyxPQUFPLENBQUNvVyxZQUZmO0FBR0UsaUJBQUssRUFBQyxPQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNELEdBZkQsTUFlTztBQUNMaEIsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV3BWLE9BQU8sQ0FBQ0csVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBQywyQkFETjtBQUVFLGVBQUcsRUFBQyxTQUZOO0FBR0UsaUJBQUssRUFBQyxPQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNEOztBQUVELFNBQU9pVixJQUFQO0FBQ0Q7TUFwQ2VjLDJCO0FBc0NULFNBQVNHLDRCQUFULENBQXNDclcsT0FBdEMsRUFBK0M7QUFDcEQsTUFBSW9WLElBQUo7O0FBRUEsTUFBSXBWLE9BQU8sQ0FBQ21XLEtBQVIsQ0FBY3ZTLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJ3UixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFFSCxPQUFGLGFBQUVBLE9BQUYsMkNBQUVBLE9BQU8sQ0FBRW1XLEtBQVQsQ0FBZSxDQUFmLENBQUYscURBQUUsaUJBQW1CQSxLQUQxQjtBQUVFLGVBQUcsRUFBRW5XLE9BQU8sQ0FBQ29XLFlBRmY7QUFHRSxpQkFBSyxFQUFDLE1BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0QsR0FmRCxNQWVPO0FBQ0xoQixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFDLDJCQUROO0FBRUUsZUFBRyxFQUFDLFNBRk47QUFHRSxpQkFBSyxFQUFDLE1BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0Q7O0FBRUQsU0FBT2lWLElBQVA7QUFDRDtNQXBDZWlCLDRCO0FBc0NULFNBQVNDLHdCQUFULENBQWtDdFcsT0FBbEMsRUFBMkM7QUFDaEQsTUFBSW9WLElBQUo7O0FBRUEsTUFBSXBWLE9BQU8sQ0FBQ21XLEtBQVIsQ0FBY3ZTLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJ3UixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFFSCxPQUFGLGFBQUVBLE9BQUYsMkNBQUVBLE9BQU8sQ0FBRW1XLEtBQVQsQ0FBZSxDQUFmLENBQUYscURBQUUsaUJBQW1CQSxLQUQxQjtBQUVFLGVBQUcsRUFBRW5XLE9BQU8sQ0FBQ29XLFlBRmY7QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0QsR0FmRCxNQWVPO0FBQ0xoQixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFDLDJCQUROO0FBRUUsZUFBRyxFQUFDLFNBRk47QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0Q7O0FBRUQsU0FBT2lWLElBQVA7QUFDRDtPQXBDZWtCLHdCO0FBc0NULFNBQVNDLFdBQVQsR0FBdUI7QUFDNUJoYSxTQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0QiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC4yMzZlYzdlZGQyY2UyMWM5Mjc3My5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcmVzcG9uc2l2ZUZvbnRTaXplcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5pbXBvcnQgUmVwb3NpdG9yeSwgeyBiYXNlVXJsLCBzZXJpYWxpemVRdWVyeSwgYXBpYmFzZXVybCB9IGZyb20gXCIuL1JlcG9zaXRvcnlcIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuY29uc3QgbW9kYWxPcGVuID0gKHR5cGUsIG1lc3NhZ2UsIGRlc2NyaXB0aW9uKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2UsXHJcbiAgICBkZXNjcmlwdGlvbixcclxuICB9KTtcclxufTtcclxuXHJcbmNsYXNzIEFjY291bnRSZXBvc2l0b3J5IHtcclxuICBhc3luYyBnZXRVc2VyUHVyY2hhc2VZZWFycyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL3llYXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBGZXRjaGluZyBZZWFycyBmcm9tIFNlcnZlclwiKTtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuXHJcbiAgYXN5bmMgY2hhbmdlUGFzc3dvcmQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wYXNzd29yZC9jaGFuZ2VgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyByZWdpc3Rlck5ld1VzZXIocGF5bG9hZCkge1xyXG4gICAgYWxlcnQoXCJkXCIpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi41NTUuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZWdpc3RlcmAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGVkaXRDdXN0b21lclByb2ZpbGUocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9lZGl0L3Byb2ZpbGVgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZnVuY3Rpb24gKHJlc3BvbnNlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENvdW50cnkoKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY291bnRyeWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENoYXRMaXN0KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jaGF0L2xpc3RgLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2hhdE1lc3NhZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NoYXQvbWVzc2FnZWAsXHJcbiAgICAgIGRhdGE6IHBheWxvYWQsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuXHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzZW5kTWVzc2FnZShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2hhdC9zZW5kYCxcclxuICAgICAgZGF0YTogcGF5bG9hZCxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG5cclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFN0YXRlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc3RhdGVgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDaXR5KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2l0eWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE15T3JkZXJzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9teXB1cmNoYXNlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNhbmNlbE9yZGVyUmVxdWVzdChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVzcG9uc2UvY2FuY2VsL3JlcXVlc3RgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0T3JkZXJEZXRhaWxzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9vcmRlci9kZXRhaWxgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgLy8gYXN5bmMgZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsKHsgYWNjZXNzX3Rva2VuIH0pIHtcclxuICBhc3luYyBnZXRDdXN0b21lclByb2ZpbGVEZXRhaWwoKSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2ZpbGVgLFxyXG4gICAgICB7IGFjY2Vzc190b2tlbiwgbGFuZ19pZDogMSB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlQ3VzdG9tZXJQcm9maWxlRGV0YWlsKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9lZGl0L3Byb2ZpbGVgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3cyhwYXlsb2FkKSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3JlY2VudC92aWV3c2AsXHJcbiAgICAgIHsgYWNjZXNzX3Rva2VuLCBsYW5nX2lkOiAxIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDdXN0b21lckFkZHJlc3NlcygpIHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkcmVzc2AsXHJcbiAgICAgIHsgYWNjZXNzX3Rva2VuIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG4gIGFzeW5jIG1ha2VEZWZhdWx0QWRkcmVzc2VzKHBheWxvYWQpIHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuXHJcbiAgICB2YXIgdXNlclVwZGF0ZUZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgdXNlclVwZGF0ZUZvcm1EYXRhLmFwcGVuZChcImFjY2Vzc190b2tlblwiLCBhY2Nlc3NfdG9rZW4pO1xyXG4gICAgdXNlclVwZGF0ZUZvcm1EYXRhLmFwcGVuZChcImFkZHJlc3NfaWRcIiwgcGF5bG9hZC5hZGRyZXNzX2lkKTtcclxuICAgIHVzZXJVcGRhdGVGb3JtRGF0YS5hcHBlbmQoXCJpc19kZWZhdWx0XCIsIHBheWxvYWQuZGVmYXVsdCk7XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZGVmYXVsdC9hZGRyZXNzYCxcclxuICAgICAgZGF0YTogdXNlclVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGRlbGV0ZUFkZHJlc3MocGF5bG9hZCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIHZhciB1c2VyVXBkYXRlRm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICB1c2VyVXBkYXRlRm9ybURhdGEuYXBwZW5kKFwiYWNjZXNzX3Rva2VuXCIsIGFjY2Vzc190b2tlbik7XHJcbiAgICB1c2VyVXBkYXRlRm9ybURhdGEuYXBwZW5kKFwiYWRkcmVzc19pZFwiLCBwYXlsb2FkLmFkZHJlc3NfaWQpO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3JlbW92ZS9hZGRyZXNzYCxcclxuICAgICAgZGF0YTogdXNlclVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGFkZEFkZHJlc3MocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkL2FkZHJlc3NgLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZUFkZHJlc3MocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZWRpdC9hZGRyZXNzYCxcclxuICAgICAgZGF0YTogcGF5bG9hZCxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXR1cm5PcmRlclJlcXVlc3QocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3JldHVybi9yZXF1ZXN0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJldHVyblNoaXBtZW50RGV0YWlsKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9vcmRlci9yZXR1cm4vc2hpcG1lbnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY3JlYXRlU3VwcG9ydFRva2VuKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY3JlYXRlLXRpY2tldGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHJlc3BvbnNlLmVycm9yKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGxpc3RTdXBwb3J0VG9rZW4ocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9saXN0LXRpY2tldGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VwcG9ydE1lc3NhZ2VCeUlEKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc3VwcG9ydC1tZXNzYWdlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBhZGRUaWNrZXRNZXNzYWdlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkLXRpY2tldC1tZXNzYWdlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRXYWxsZXREZXRhaWxzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvd2FsbGV0L2Ftb3VudGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0QXVjdGlvbkNhcnREYXRhKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYXVjdGlvbi9kZXRhaWxgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFVzZXJOb3RpZmljYXRpb24ocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci92aWV3L25vdGlmaWNhdGlvbnNgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEF1Y3Rpb25PcmRlckxpc3QocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hdWN0aW9uL29yZGVyL2xpc3RgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHNlbmRSZWdpc3Rlck1vYmlsZU9UUChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3JlZ2lzdGVyL3NlbmQvb3RwYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyB2ZXJpZnlSZWdpc3Rlck1vYmlsZU9UUChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3JlZ2lzdGVyL3ZlcmlmeS9vdHBgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHZlcmlmeUZvcmdvdE9UUChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2xvZ2luL2ZvcmdvdC92ZXJpZnktb3RwYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5ldyBBY2NvdW50UmVwb3NpdG9yeSgpO1xyXG4iLCJpbXBvcnQgeyByZXNwb25zaXZlRm9udFNpemVzIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCB7IGdldERldmljZUlkIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7IGJhc2VVcmwsIHNlcmlhbGl6ZVF1ZXJ5LCBhcGliYXNldXJsIH0gZnJvbSBcIi4vUmVwb3NpdG9yeVwiO1xyXG5cclxuY2xhc3MgQ2FydFJlcG9zaXRvcnkge1xyXG4gIGFzeW5jIGFkZFByb2R1Y3RUb0NhcnQoeyBhY2Nlc3NfdG9rZW4sIHByb2R1Y3QsIHF1YW50aXR5LCBjYXJ0X3R5cGUgfSkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2FkZC1jYXJ0YCxcclxuICAgICAgeyBhY2Nlc3NfdG9rZW4sIHByb2R1Y3RfaWQ6IHByb2R1Y3QucHJvZHVjdF9pZCwgcXVhbnRpdHksIGNhcnRfdHlwZSB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENhcnRJdGVtKHBheWxvYWQpIHtcclxuICAgLy8gYWxlcnQoXCJkXCIpXHJcbiAgICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuY2NjY2MuLlwiLGdldERldmljZUlkKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuLi5cIixwYXlsb2FkKVxyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgY29uc3QgdXNlcl90b2tlbiA9IGFjY2Vzc190b2tlbjtcclxuXHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsIHtcclxuICAgICAgYWNjZXNzX3Rva2VuOiB1c2VyX3Rva2VuLFxyXG4gICAgICBsYW5nX2lkOiAxLFxyXG4gICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICBwYWdlX3VybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvcHJvZHVjdC8yXCIsXHJcbiAgICAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICB9KVxyXG4gICAvLyBhbGVydChcIjMzMzNcIilcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmJiYmJiLi4uYmJiLi40NDQ0NDQ0NDQ0NDQuXCIscmVzcG9uc2UpXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgLy8gICBhbGVydChcIjQ0NDQ0NDQ0XCIpXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgIFxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZldGNoUGxhdGZvcm1Wb3VjaGVyKCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jb3Vwb24vcGxhdGZvcm1gLFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFuZ19pZDogXCJcIixcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNoZWNrUGxhdGZvcm1Wb3VjaGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY291cG9uL3BsYXRmb3JtYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNoZWNrU2VsbGVyVm91Y2hlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NvdXBvbi9zZWxsZXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IENhcnRSZXBvc2l0b3J5KCk7XHJcbiIsImltcG9ydCBSZXBvc2l0b3J5LCB7IGFwaWJhc2V1cmwgfSBmcm9tIFwiLi9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgZ2V0RGV2aWNlSWQsIG1ha2VQYWdlVXJsLCBvc1R5cGUgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuXHJcbmNsYXNzIEhvbWVhcGkge1xyXG4gIGFzeW5jIGdldEhvbWVkYXRhKHBhdGhOYW1lKSB7XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgYWNjZXNzX3Rva2VuOiBcIlwiLFxyXG4gICAgICBsYW5nX2lkOiAxLFxyXG4gICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICBwYWdlX3VybDogbWFrZVBhZ2VVcmwoXCIvXCIpLFxyXG4gICAgICBvc190eXBlOiBvc1R5cGUoKSxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgQ2FuY2VsVG9rZW4gPSBheGlvcy5DYW5jZWxUb2tlbjtcclxuICAgIGxldCBzb3VyY2UgPSBDYW5jZWxUb2tlbi5zb3VyY2UoKTtcclxuXHJcbiAgICBzb3VyY2UgJiYgc291cmNlLmNhbmNlbChcIk9wZXJhdGlvbiBjYW5jZWxlZCBkdWUgdG8gbmV3IHJlcXVlc3QuXCIpO1xyXG4gICAgLy8gc2F2ZSB0aGUgbmV3IHJlcXVlc3QgZm9yIGNhbmNlbGxhdGlvblxyXG4gICAgc291cmNlID0gYXhpb3MuQ2FuY2VsVG9rZW4uc291cmNlKCk7XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2hvbWVgLFxyXG4gICAgICBwYXlsb2FkLFxyXG4gICAgICB7XHJcbiAgICAgICAgY2FuY2VsVG9rZW46IHNvdXJjZS50b2tlbixcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICAvLyBjYW5jZWwgdGhlIHJlcXVlc3QgKHRoZSBtZXNzYWdlIHBhcmFtZXRlciBpcyBvcHRpb25hbClcclxuICAgIHNvdXJjZS5jYW5jZWwoXCJPcGVyYXRpb24gY2FuY2VsZWQgYnkgdGhlIHVzZXIuXCIpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdWJtaXRSZXZpZXcocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Bvc3QtcHJvZHVjdC1yZXZpZXdgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0U2VsbGVyUmV2aWV3KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wb3N0LXNlbGxlci1yZXZpZXdgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuICAvLyBhc3luYyBnZXRIb21lZGF0YSgpIHtcclxuICAvLyAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3NcclxuICAvLyAgICAgLmdldChgaHR0cHM6Ly9lc3RycmFkb3dlYi5jb20va2FuZ3Rhby9hcGkvY3VzdG9tZXIvaG9tZWAsIHtcclxuICAvLyAgICAgICBoZWFkZXJzOiB7XHJcbiAgLy8gICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAvLyAgICAgICB9LFxyXG4gIC8vICAgICB9KVxyXG4gIC8vICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgLy8gICAgIC5jYXRjaCgoZXJyb3IpID0+IGVycm9yKTtcclxuICAvLyAgIHJldHVybiByZXNwb25zZTtcclxuICAvLyB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5ldyBIb21lYXBpKCk7XHJcbiIsImltcG9ydCB7IGdldERldmljZUlkLCBvc1R5cGUgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHtcclxuICBiYXNlVXJsLFxyXG4gIHNlcmlhbGl6ZVF1ZXJ5LFxyXG4gIGFwaWJhc2V1cmwsXHJcbiAgYmFzZVBhdGhVcmwsXHJcbn0gZnJvbSBcIi4vUmVwb3NpdG9yeVwiO1xyXG5cclxuY2xhc3MgUHJvZHVjdFJlcG9zaXRvcnkge1xyXG4gIGFzeW5jIGdldFJlY29yZHMocGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoXHJcbiAgICAgIGAke2Jhc2VVcmx9L3Byb2R1Y3RzPyR7c2VyaWFsaXplUXVlcnkocGFyYW1zKX1gXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2VhcmNoZWRQcm9kdWN0cyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LXNlYXJjaGAsXHJcbiAgICAgIHtcclxuICAgICAgICBsYW5nX2lkOiBcIlwiLFxyXG4gICAgICAgIGNhdGVnb3J5X2lkOiBwYXJhbXMuY2F0ZWdvcnlfaWQsXHJcbiAgICAgICAga2V5d29yZDogcGFyYW1zLnRpdGxlX2NvbnRhaW5zLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLm5vX29mX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHMocGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1saXN0P3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IFwiXCIsXHJcbiAgICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgICBwYWdlX3VybDogXCJodHRwczovL2FiYy5jb20vcHJvZHVjdHMvdXMvaW1nXCIsXHJcbiAgICAgICAgb3NfdHlwZTogXCJXRUJcIixcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE5ld0RlYWxzUHJvZHVjdHMocGF5bG9hZCwgcGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1kZWFscz9wYWdlPWAgKyBwYXJhbXMucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob2NraW5nU2FsZVByb2R1Y3RzKHBheWxvYWQsIHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Nob2NrLXNhbGUtcHJvZHVjdHM/cGFnZT1gICsgcGFyYW1zLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEuc2hvY2tfc2FsZSxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEZlYXR1cmVkUHJvZHVjdHMocGF5bG9hZCwgcGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1mZWF0dXJlZD9wYWdlPWAgKyBwYXJhbXMucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzYnlGaWx0ZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtbGlzdC1maWx0ZXI/cGFnZT1gICsgcGF5bG9hZC5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiIyMjIyMjIyMjIyMjXCIscmVzcG9uc2UpXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXROZXdEZWFsc1Byb2R1Y3RzYnlGaWx0ZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZGVhbHM/cGFnZT1gICsgcGF5bG9hZC5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvY2tpbmdTYWxlUHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZS1wcm9kdWN0cz9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEuc2hvY2tfc2FsZSxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEZlYXR1cmVkUHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1mZWF0dXJlZD9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja2luZ1Byb2R1Y3RzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Nob2NrLXNhbGUtcHJvZHVjdHM/cGFnZT1gICsgcGFyYW1zLnBhZ2VcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEuc2hvY2tfc2FsZSxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEJyYW5kcygpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2JyYW5kYClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0Q2F0ZWdvcmllcygpIHtcclxuICAgIC8vIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9wcm9kdWN0LWNhdGVnb3JpZXNgKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NhdC1zdWJjYXRgXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0VG90YWxSZWNvcmRzKCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L3Byb2R1Y3RzL2NvdW50YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5SWQoaWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS4uXCIsaWQpXHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEudXNlcmRhdGEuXCIsdXNlcmRhdGEpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuLnBhcnNlZGF0YVwiLHBhcnNlZGF0YSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS5hY2Nlc3NfdG9rZW4uXCIsYWNjZXNzX3Rva2VuKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLmdldERldmljZUlkLlwiLGdldERldmljZUlkKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLmFjY2Vzc190b2tlbi5cIixhY2Nlc3NfdG9rZW4pXHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZGV0YWlsYCxcclxuICAgICAge1xyXG4gICAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgICBpZCxcclxuICAgICAgICBsYW5nX2lkOiAxLFxyXG4gICAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgICAgcGFnZV91cmw6IGAke2Jhc2VQYXRoVXJsfS9wcm9kdWN0LyR7aWR9YCxcclxuICAgICAgICBvc190eXBlOiBvc1R5cGUoKSxcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvY2tTYWxlQnlpZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Nob2NrLXNhbGVgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlDYXRlZ29yeShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoXHJcbiAgICAgIGAke2Jhc2VVcmx9L3Byb2R1Y3QtY2F0ZWdvcmllcz9zbHVnPSR7cGF5bG9hZH1gXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhWzBdO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlCcmFuZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vYnJhbmRzP3NsdWc9JHtwYXlsb2FkfWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhWzBdO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5QnJhbmRzKHBheWxvYWQpIHtcclxuICAgIGxldCBxdWVyeSA9IFwiXCI7XHJcbiAgICBwYXlsb2FkLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHF1ZXJ5ID09PSBcIlwiKSB7XHJcbiAgICAgICAgcXVlcnkgPSBgaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcXVlcnkgPSBxdWVyeSArIGAmaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L2JyYW5kcz8ke3F1ZXJ5fWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUJyYW5kcyhwYXlsb2FkKSB7XHJcbiAgICBsZXQgcXVlcnkgPSBcIlwiO1xyXG4gICAgcGF5bG9hZC5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgIGlmIChxdWVyeSA9PT0gXCJcIikge1xyXG4gICAgICAgIHF1ZXJ5ID0gYGlkX2luPSR7aXRlbX1gO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHF1ZXJ5ID0gcXVlcnkgKyBgJmlkX2luPSR7aXRlbX1gO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9icmFuZHM/JHtxdWVyeX1gKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlQcmljZVJhbmdlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChcclxuICAgICAgYCR7YmFzZVVybH0vcHJvZHVjdHM/JHtzZXJpYWxpemVRdWVyeShwYXlsb2FkKX1gXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgYWRkUHJvZHVjdFRvQ2FydChwYXlsb2FkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi4uNTY1NjU2NTY1NjU2NTYuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2FkZC1jYXJ0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbiAgYXN5bmMgY2hhbmdlUXR5KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXJ0L2NoYW5nZS1xdHlgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGxhY2VPcmRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi4uLjMzMzMzMzMzMzMuLi4uLi4uXCIscGF5bG9hZClcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9vcmRlci9wbGFjZW9yZGVyYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENhcnQocGF5bG9hZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYWFhYS4uLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NhcnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZGVsZXRlQ2FydChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZGVsZXRlLWNhcnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0QXVjdGlvblByb2R1Y3RCeUF1Y3Rpb25JZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYXVjdGlvbmAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjcmVhdGVCaWQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NyZWF0ZS1iaWRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvcERldGFpbEJ5SWQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Nob3AtZGV0YWlsYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENoZWNrb3V0SW5mbyhwYXlsb2FkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLmdldENoZWNrb3V0SW5mby4uLiBhcHlsb2FkLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi5nZXRDaGVja291dEluZm8uLi4gYXBpYmFzZXVybC4uXCIsYXBpYmFzZXVybClcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9vcmRlci9jaGVja291dC1pbmZvYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHBsYWNlQXVjdGlvbk9yZGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hdWN0aW9uL2NoZWNrb3V0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IG5ldyBQcm9kdWN0UmVwb3NpdG9yeSgpO1xyXG4iLCJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmNvbnN0IGJhc2VEb21haW4gPSBcImh0dHBzOi8vYmV0YS5hcGlub3V0aGVtZXMuY29tXCI7IC8vIEFQSSBmb3IgcHJvZHVjdHNcclxuZXhwb3J0IGNvbnN0IGJhc2VQb3N0VXJsID0gXCJodHRwczovL2JldGEuYXBpbm91dGhlbWVzLmNvbVwiOyAvLyBBUEkgZm9yIHBvc3RcclxuZXhwb3J0IGNvbnN0IGJhc2VTdG9yZVVSTCA9IFwiaHR0cHM6Ly9iZXRhLmFwaW5vdXRoZW1lcy5jb21cIjsgLy8gQVBJIGZvciB2ZW5kb3Ioc3RvcmUpXHJcblxyXG5sZXQgYXBpYmFzZXVybEN1c3RvbSA9IFwiaHR0cHM6Ly9kZXYtYmlnYmFza2V0LmVzdHJyYWRvd2ViLmNvbVwiO1xyXG5sZXQgYmFzZVBhdGggPSBcImh0dHBzOi8vZGV2LWthbmd0YW8udmVyY2VsLmFwcFwiO1xyXG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gIGlmICh3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUgPT0gXCJ1YXQta2FuZ3Rhby52ZXJjZWwuYXBwXCIpIHtcclxuICAgIGFwaWJhc2V1cmxDdXN0b20gPSBcImh0dHBzOi8vdWF0LWt0LmVzdHJyYWRvd2ViLmNvbVwiO1xyXG4gICAgYmFzZVBhdGggPSBcImh0dHBzOi8vdWF0LWthbmd0YW8udmVyY2VsLmFwcFwiO1xyXG4gIH1cclxuICBpZiAod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lID09IFwicWEta2FuZ3Rhby52ZXJjZWwuYXBwXCIpIHtcclxuICAgIGFwaWJhc2V1cmxDdXN0b20gPSBcImh0dHBzOi8vcWEta3QuZXN0cnJhZG93ZWIuY29tXCI7XHJcbiAgICBiYXNlUGF0aCA9IFwiaHR0cHM6Ly9xYS1rYW5ndGFvLnZlcmNlbC5hcHBcIjtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhcGliYXNldXJsID0gYXBpYmFzZXVybEN1c3RvbTtcclxuZXhwb3J0IGNvbnN0IGJhc2VQYXRoVXJsID0gYmFzZVBhdGg7XHJcblxyXG5leHBvcnQgY29uc3QgY3VzdG9tSGVhZGVycyA9IHtcclxuICBBY2NlcHQ6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGJhc2VVcmwgPSBgJHtiYXNlRG9tYWlufWA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBheGlvcy5jcmVhdGUoe1xyXG4gIGJhc2VVcmwsXHJcbiAgaGVhZGVyczogY3VzdG9tSGVhZGVycyxcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3Qgc2VyaWFsaXplUXVlcnkgPSAocXVlcnkpID0+IHtcclxuICByZXR1cm4gT2JqZWN0LmtleXMocXVlcnkpXHJcbiAgICAubWFwKFxyXG4gICAgICAoa2V5KSA9PiBgJHtlbmNvZGVVUklDb21wb25lbnQoa2V5KX09JHtlbmNvZGVVUklDb21wb25lbnQocXVlcnlba2V5XSl9YFxyXG4gICAgKVxyXG4gICAgLmpvaW4oXCImXCIpO1xyXG59O1xyXG4iLCJpbXBvcnQgeyB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgeyBhbGwsIHB1dCwgdGFrZUV2ZXJ5LCBjYWxsIH0gZnJvbSBcInJlZHV4LXNhZ2EvZWZmZWN0c1wiO1xyXG5pbXBvcnQgQWNjb3VudFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL0FjY291bnRSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIGFjdGlvblR5cGVzLFxyXG4gIGdldEN1c3RvbWVyUHJvZmlsZVN1Y2Nlc3MsXHJcbiAgdXBkYXRlQ3VzdG9tZXJQcm9maWxlU3VjY2VzcyxcclxuICBnZXRDdXN0b21lclJlY2VudFZpZXdzU3VjY2VzcyxcclxuICBnZXRDdXN0b21lckFkZHJlc3NTdWNjZXNzLFxyXG4gIGdldEN1c3RvbWVyQWRkcmVzcyxcclxuICBnZXRDdXN0b21lckNoYXRMaXN0U3VjY2VzcyxcclxuICBnZXRDdXN0b21lckNoYXRNZXNzYWdlU3VjY2VzcyxcclxuICBnZXRNeU9yZGVyc1N1Y2Nlc3MsXHJcbiAgZ2V0T3JkZXJEZXRhaWxzU3VjY2VzcyxcclxuICBnZXRNeU9yZGVycyxcclxuICBnZXRUb2tlbkxpc3RTdWNjZXNzLFxyXG4gIGdldFN1cHBvcnRNZXNzYWdlZnJvbVN1cHBvcnRJZFN1Y2Nlc3MsXHJcbiAgZ2V0V2FsbGV0RGV0YWlsc1N1Y2Nlc3MsXHJcbiAgZ2V0QXVjdGlvbkNhcnREYXRhU3VjY2VzcyxcclxuICBnZXRBdWN0aW9uT3JkZXJMaXN0U3VjY2VzcyxcclxuICBnZXRDb3VudHJ5RGF0YVN1Y2Nlc3MsXHJcbiAgZ2V0VXNlck5vdGlmaWNhdGlvbnNTdWNjZXNzLFxyXG4gIGdldEN1c3RvbWVyQ2hhdE1lc3NhZ2UsXHJcbiAgZ2V0VXNlclB1cmNoYXNlWWVhclN1Y2Nlc3MsXHJcbn0gZnJvbSBcIi4vYWN0aW9uXCI7XHJcbmltcG9ydCB7IGxvZ091dCB9IGZyb20gXCIuLi9hdXRoL2FjdGlvblwiO1xyXG5cclxuY29uc3QgbW9kYWxTdWNjZXNzID0gKHR5cGUpID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZTogXCJXZWxsY29tZVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiWW91IGFyZSBsb2dnZWQgaW4gc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBtb2RhbE9wZW4gPSAodHlwZSwgbWVzc2FnZSwgZGVzY3JpcHRpb24pID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuZnVuY3Rpb24qIGdldE15T3JkZXJzU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuZ2V0TXlPcmRlcnMsIHBheWxvYWQpO1xyXG4gICAgeWllbGQgcHV0KHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCAmJiBnZXRNeU9yZGVyc1N1Y2Nlc3MocmVzcG9uc2UuZGF0YSkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBnZXRDdXN0b21lclByb2ZpbGUoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBBY2NvdW50UmVwb3NpdG9yeS5nZXRDdXN0b21lclByb2ZpbGVEZXRhaWwsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IDQwMSkge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiSW52YWxpZCBBY2Nlc3MgVG9rZW4hIExvZ2luIEFnYWluXCIpO1xyXG4gICAgICByb3V0ZXIucHVzaChcIi9hY2NvdW50L2xvZ2luXCIpO1xyXG4gICAgICB5aWVsZCBwdXQobG9nT3V0KCkpO1xyXG4gICAgfVxyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJQcm9maWxlU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIHVwZGF0ZUN1c3RvbWVyUHJvZmlsZSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoXHJcbiAgICAgIEFjY291bnRSZXBvc2l0b3J5LnVwZGF0ZUN1c3RvbWVyUHJvZmlsZURldGFpbCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gNDAxKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJJbnZhbGlkIEFjY2VzcyBUb2tlbiEgTG9naW4gQWdhaW5cIik7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCAmJiByZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiUHJvZmlsZSB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlLmVycm9yKSB7XHJcbiAgICAgIHJlc3BvbnNlLmVycm9yLm1hcCgoZXJyb3IpID0+IHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnJvcixcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJQcm9maWxlKCkpO1xyXG4gICAgeWllbGQgcHV0KHVwZGF0ZUN1c3RvbWVyUHJvZmlsZVN1Y2Nlc3MocmVzcG9uc2UpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3c1NsdWcoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBBY2NvdW50UmVwb3NpdG9yeS5nZXRDdXN0b21lclJlY2VudFZpZXdzLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgeWllbGQgcHV0KGdldEN1c3RvbWVyUmVjZW50Vmlld3NTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0Q3VzdG9tZXJBZGRyZXNzU2x1ZygpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldEN1c3RvbWVyQWRkcmVzc2VzKTtcclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lckFkZHJlc3NTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogbWFrZURlZmF1bHRBZGRyZXNzU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoXHJcbiAgICAgIEFjY291bnRSZXBvc2l0b3J5Lm1ha2VEZWZhdWx0QWRkcmVzc2VzLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKHJlc3BvbnNlLmRhdGEubWVzc2FnZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRXJyb3IgVXBkYXRpbmcgRGVmYXVsdCBBZGRyZXNzIVwiKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lckFkZHJlc3MoKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGRlbGV0ZUFkZHJlc3NTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5kZWxldGVBZGRyZXNzLCBwYXlsb2FkKTtcclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIERlbGV0aW5nIEFkZHJlc3MhXCIpO1xyXG4gICAgfVxyXG4gICAgeWllbGQgcHV0KGdldEN1c3RvbWVyQWRkcmVzcygpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogYWRkQWRkcmVzc1NhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgLy8gY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmFkZEFkZHJlc3MsIHBheWxvYWQpO1xyXG4gICAgLy8gaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgIC8vICAgbWVzc2FnZS5zdWNjZXNzKHJlc3BvbnNlLmRhdGEubWVzc2FnZSk7XHJcbiAgICAvLyB9IGVsc2Uge1xyXG4gICAgLy8gICBtZXNzYWdlLmVycm9yKFwiRXJyb3IgVXBkYXRpbmcgQWRkcmVzcyFcIik7XHJcbiAgICAvLyB9XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJBZGRyZXNzKCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBnZXRDaGF0TGlzdFNhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldENoYXRMaXN0LCBwYXlsb2FkKTtcclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgQ2hhdHMhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lckNoYXRMaXN0U3VjY2VzcyhyZXNwb25zZS5kYXRhLmxpc3QpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0Q3VzdG9tZXJDaGF0TWVzc2FnZVNhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldENoYXRNZXNzYWdlLCBwYXlsb2FkKTtcclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgQ2hhdHMhXCIpO1xyXG4gICAgfVxyXG4gICAgeWllbGQgcHV0KGdldEN1c3RvbWVyQ2hhdE1lc3NhZ2VTdWNjZXNzKHJlc3BvbnNlLmRhdGEubWVzc2FnZXMpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogc2VuZE1lc3NhZ2VUb1NlbGxlclNhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LnNlbmRNZXNzYWdlLCBwYXlsb2FkKTtcclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRXJyb3IgV2hpbGUgU2VuZGluZyBNZXNzYWdlIVwiKTtcclxuICAgIH1cclxuICAgIC8vIHlpZWxkIHB1dChnZXRDdXN0b21lckNoYXRNZXNzYWdlU3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2VzKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldE9yZGVyRGV0YWlsc1NhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldE9yZGVyRGV0YWlscywgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihyZXNwb25zZS5tZXNzYWdlKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dChnZXRPcmRlckRldGFpbHNTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogY2FuY2VsT3JkZXJSZXF1ZXN0U2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuY2FuY2VsT3JkZXJSZXF1ZXN0LCBwYXlsb2FkKTtcclxuICAgIGxldCBkYXRhX3BheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbjogcGF5bG9hZC5hY2Nlc3NfdG9rZW4sXHJcbiAgICAgIGxhbmdfaWQ6IFwiMVwiLFxyXG4gICAgfTtcclxuICAgIHlpZWxkIHB1dChnZXRNeU9yZGVycyhkYXRhX3BheWxvYWQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0VG9rZW5MaXN0U2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkubGlzdFN1cHBvcnRUb2tlbiwgcGF5bG9hZCk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0VG9rZW5MaXN0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldFN1cHBvcnRNZXNzYWdlU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuc3VwcG9ydE1lc3NhZ2VCeUlELCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRTdXBwb3J0TWVzc2FnZWZyb21TdXBwb3J0SWRTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0VXNlcldhbGxldERldGFpbHMoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldFdhbGxldERldGFpbHMsIHBheWxvYWQpO1xyXG5cclxuICAgIHlpZWxkIHB1dChnZXRXYWxsZXREZXRhaWxzU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBtb2RhbE9wZW4oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgV2FsbGV0IERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEF1Y3Rpb25EYXRhU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuZ2V0QXVjdGlvbkNhcnREYXRhLCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRBdWN0aW9uQ2FydERhdGFTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBBdWN0aW9uIERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEF1Y3Rpb25PcmRlckxpc3RTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRBdWN0aW9uT3JkZXJMaXN0LCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRBdWN0aW9uT3JkZXJMaXN0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBtb2RhbE9wZW4oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgQXVjdGlvbiBEYXRhXCIpO1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBnZXRDb3VudHJ5RGF0YVNhZ2EoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRDb3VudHJ5KTtcclxuICAgIHlpZWxkIHB1dChnZXRDb3VudHJ5RGF0YVN1Y2Nlc3MocmVzcG9uc2UpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBDb3VudHJ5IERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldFVzZXJOb3RpZmljYXRpb25TYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRVc2VyTm90aWZpY2F0aW9uLCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRVc2VyTm90aWZpY2F0aW9uc1N1Y2Nlc3MocmVzcG9uc2UuZGF0YSkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbW9kYWxPcGVuKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIkVycm9yIFdoaWxlIEZldGNoaW5nIE5vdGlmaWNhdGlvbnNcIik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0UHVyY2hhc2VZZWFyKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChcclxuICAgICAgQWNjb3VudFJlcG9zaXRvcnkuZ2V0VXNlclB1cmNoYXNlWWVhcnMsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICB5aWVsZCBwdXQoXHJcbiAgICAgIHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCAmJiBnZXRVc2VyUHVyY2hhc2VZZWFyU3VjY2VzcyhyZXNwb25zZS5kYXRhKVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBZZWFycyFcIik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiogcm9vdFNhZ2EoKSB7XHJcbiAgLy8geWllbGQgYWxsKFtcclxuICAvLyAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfTkVXX1NFTExFUl9DSEFUUywgZ2V0TmV3U2VsbGVyQ2hhdHNTYWdhKSxcclxuICAvLyBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KFxyXG4gICAgICBhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfQ0hBVF9NRVNTQUdFLFxyXG4gICAgICBnZXRDdXN0b21lckNoYXRNZXNzYWdlU2FnYVxyXG4gICAgKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLlNFTkRfTUVTU0FHRV9UT19TRUxMRVIsIHNlbmRNZXNzYWdlVG9TZWxsZXJTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfQ0hBVF9MSVNULCBnZXRDaGF0TGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX01ZX09SREVSUywgZ2V0TXlPcmRlcnNTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9DVVNUT01FUl9QUk9GSUxFLCBnZXRDdXN0b21lclByb2ZpbGUpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5VUERBVEVfQ1VTVE9NRVJfUFJPRklMRSwgdXBkYXRlQ3VzdG9tZXJQcm9maWxlKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KFxyXG4gICAgICBhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfUkVDRU5UX1ZJRVdTLFxyXG4gICAgICBnZXRDdXN0b21lclJlY2VudFZpZXdzU2x1Z1xyXG4gICAgKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9DVVNUT01FUl9BRERSRVNTLCBnZXRDdXN0b21lckFkZHJlc3NTbHVnKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLk1BS0VfREVGQVVMVF9BRERSRVNTLCBtYWtlRGVmYXVsdEFkZHJlc3NTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5BRERfQUREUkVTUywgYWRkQWRkcmVzc1NhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuREVMRVRFX0FERFJFU1MsIGRlbGV0ZUFkZHJlc3NTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9PUkRFUl9ERVRBSUxTLCBnZXRPcmRlckRldGFpbHNTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoYWN0aW9uVHlwZXMuTUFLRV9DQU5DRUxfT1JERVJfUkVRVUVTVCwgY2FuY2VsT3JkZXJSZXF1ZXN0U2FnYSksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX1RPS0VOX0xJU1QsIGdldFRva2VuTGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShcclxuICAgICAgYWN0aW9uVHlwZXMuR0VUX1NVUFBPUlRfTUVTU0FHRV9CWV9TVVBQT1JUX0lELFxyXG4gICAgICBnZXRTdXBwb3J0TWVzc2FnZVNhZ2FcclxuICAgICksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX1dBTExFVF9ERVRBSUxTLCBnZXRVc2VyV2FsbGV0RGV0YWlscyldKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQVVDVElPTl9DQVJUX0RBVEEsIGdldEF1Y3Rpb25EYXRhU2FnYSldKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9BVUNUSU9OX09SREVSX0xJU1QsIGdldEF1Y3Rpb25PcmRlckxpc3RTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQ09VTlRSWV9EQVRBLCBnZXRDb3VudHJ5RGF0YVNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfVVNFUl9OT1RJRklDQVRJT04sIGdldFVzZXJOb3RpZmljYXRpb25TYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfVVNFUl9QVVJDSEFTRV9ZRUFSUywgZ2V0UHVyY2hhc2VZZWFyKV0pO1xyXG59XHJcbiIsImV4cG9ydCBjb25zdCBhY3Rpb25UeXBlcyA9IHtcclxuICBHRVRfQ0FSVDogXCJHRVRfQ0FSVFwiLFxyXG4gIEdFVF9DQVJUX1NVQ0NFU1M6IFwiR0VUX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIEdFVF9DQVJUX0VSUk9SOiBcIkdFVF9DQVJUX0VSUk9SXCIsXHJcblxyXG4gIEdFVF9DQVJUX1RPVEFMX1FVQU5USVRZOiBcIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZXCIsXHJcbiAgR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlfU1VDQ0VTUzogXCJHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWV9TVUNDRVNTXCIsXHJcblxyXG4gIEFERF9JVEVNOiBcIkFERF9JVEVNXCIsXHJcbiAgUkVNT1ZFX0lURU06IFwiUkVNT1ZFX0lURU1cIixcclxuICBSRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXOiBcIlJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVdcIixcclxuXHJcbiAgQ0xFQVJfQ0FSVDogXCJDTEVBUl9DQVJUXCIsXHJcbiAgQ0xFQVJfQ0FSVF9TVUNDRVNTOiBcIkNMRUFSX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIENMRUFSX0NBUlRfRVJST1I6IFwiQ0xFQVJfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBJTkNSRUFTRV9RVFk6IFwiSU5DUkVBU0VfUVRZXCIsXHJcbiAgSU5DUkVBU0VfUVRZX1NVQ0NFU1M6IFwiSU5DUkVBU0VfUVRZX1NVQ0NFU1NcIixcclxuICBJTkNSRUFTRV9RVFlfRVJST1I6IFwiSU5DUkVBU0VfUVRZX0VSUk9SXCIsXHJcblxyXG4gIERFQ1JFQVNFX1FUWTogXCJERUNSRUFTRV9RVFlcIixcclxuICBVUERBVEVfQ0FSVDogXCJVUERBVEVfQ0FSVFwiLFxyXG5cclxuICBVUERBVEVfQ0FSVF9TVUNDRVNTOiBcIlVQREFURV9DQVJUX1NVQ0NFU1NcIixcclxuICBVUERBVEVfQ0FSVF9FUlJPUjogXCJVUERBVEVfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBVUERBVEVfU0VMRUNURURfQUREUkVTUzogXCJVUERBVEVfU0VMRUNURURfQUREUkVTU1wiLFxyXG5cclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSOiBcIkZFVENIX1BMQVRGT1JNX1ZPVUNIRVJcIixcclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSX1NVQ0NFU1M6IFwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTXCIsXHJcblxyXG4gIFRPVEFMX0RJU0NPVU5UOiBcIlRPVEFMX0RJU0NPVU5UXCIsXHJcblxyXG4gIEFQUExJRURfU0VMTEVSX1ZPVUNIRVI6IFwiQVBQTElFRF9TRUxMRVJfVk9VQ0hFUlwiLFxyXG5cclxuICBBUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVI6IFwiQVBQTElFRF9QTEFURk9STV9WT1VDSEVSXCIsXHJcblxyXG4gIEdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUU6IFwiR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRVwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9ESVNDT1VOVDogXCJTRUxMRVJfV0lTRV9ESVNDT1VOVFwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9NRVNTQUdFUzogXCJTRUxMRVJfV0lTRU1FU1NBR0VTXCIsXHJcblxyXG4gIFVTRURfV0FMTEVUX0FNT1VOVDogXCJVU0VEX1dBTExFVF9BTU9VTlRcIixcclxuXHJcbiAgU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUjogXCJTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSXCIsXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3KHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5SRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RlZFBheW1lbnRPcHRpb24ocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTEVDVEVEX1BBWU1FTlRfT1BUSU9OX0JZX1VTRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbGxlcldpc2VNZXNzYWdlKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5TRUxMRVJfV0lTRV9NRVNTQUdFUywgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlZFdhbGxldEFtb3VudChwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuVVNFRF9XQUxMRVRfQU1PVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxsZXJXaXNlRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTExFUl9XSVNFX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBncmFuZFRvdGFsV2l0aERpc2NvdW50VmFsdWUocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUUsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGxpZWRTZWxsZXJWb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1NFTExFUl9WT1VDSEVSLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBsaWVkUGxhdGZvcm1Wb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvdGFsRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlRPVEFMX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbigpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUixcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hQbGF0Zm9ybVZvdWNoZXJBY3Rpb25TdWNjZXNzKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydCgpIHtcclxuICBhbGVydChcImdldENhcnRcIilcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5HRVRfQ0FSVCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydFN1Y2Nlc3MocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5HRVRfQ0FSVF9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydEVycm9yKGVycm9yKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUX0VSUk9SLFxyXG4gICAgZXJyb3IsXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVNlbGVjdGVkQWRkcmVzcyhwYXlsb2FkKSB7XHJcbiAgYWxlcnQoXCJjYWxsXCIpXHJcbiAgY29uc29sZS5sb2coXCIuLjU1NTU1NS4uLi5cIixwYXlsb2FkKVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX1NFTEVDVEVEX0FERFJFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhZGRJdGVtKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BRERfSVRFTSwgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlSXRlbShwcm9kdWN0KSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuUkVNT1ZFX0lURU0sIHByb2R1Y3QgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluY3JlYXNlSXRlbVF0eShwcm9kdWN0KSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuSU5DUkVBU0VfUVRZLCBwcm9kdWN0IH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZWNyZWFzZUl0ZW1RdHkocHJvZHVjdCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkRFQ1JFQVNFX1FUWSwgcHJvZHVjdCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2FydFN1Y2Nlc3MocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5VUERBVEVfQ0FSVF9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2FydEVycm9yKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX0NBUlRfRVJST1IsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjbGVhckNhcnQoKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuQ0xFQVJfQ0FSVCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJDYXJ0U3VjY2VzcygpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5DTEVBUl9DQVJUX1NVQ0NFU1MgfTtcclxufVxyXG4iLCJpbXBvcnQgeyBhbGwsIHB1dCwgdGFrZUV2ZXJ5LCBjYWxsIH0gZnJvbSBcInJlZHV4LXNhZ2EvZWZmZWN0c1wiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBhY3Rpb25UeXBlcyxcclxuICBnZXRDYXJ0RXJyb3IsXHJcbiAgZ2V0Q2FydFN1Y2Nlc3MsXHJcbiAgdXBkYXRlQ2FydFN1Y2Nlc3MsXHJcbiAgdXBkYXRlQ2FydEVycm9yLFxyXG4gIGdldENhcnQsXHJcbiAgY2xlYXJDYXJ0U3VjY2VzcyxcclxuICBmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvblN1Y2Nlc3MsXHJcbn0gZnJvbSBcIi4vYWN0aW9uXCI7XHJcbmltcG9ydCBDYXJ0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvQ2FydFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IFByb2R1Y3RSZXBvc2l0b3J5IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9Qcm9kdWN0UmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyBkaXNwbGF5Tm90aWZpY2F0aW9uIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcblxyXG5jb25zdCBtb2RhbFN1Y2Nlc3MgPSAodHlwZSwgbWVzc2FnZSkgPT4ge1xyXG4gIG5vdGlmaWNhdGlvblt0eXBlXSh7XHJcbiAgICBtZXNzYWdlLFxyXG4gICAgZGVzY3JpcHRpb246IFwiVGhpcyBwcm9kdWN0IGhhcyBiZWVuIGFkZGVkIHRvIHlvdXIgY2FydCFcIixcclxuICAgIGR1cmF0aW9uOiAxLFxyXG4gIH0pO1xyXG59O1xyXG5jb25zdCBtb2RhbFdhcm5pbmcgPSAodHlwZSkgPT4ge1xyXG4gIG5vdGlmaWNhdGlvblt0eXBlXSh7XHJcbiAgICBtZXNzYWdlOiBcIlJlbW92ZSBBIEl0ZW1cIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgcHJvZHVjdCBoYXMgYmVlbiByZW1vdmVkIGZyb20geW91ciBjYXJ0IVwiLFxyXG4gICAgZHVyYXRpb246IDEsXHJcbiAgfSk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgY2FsY3VsYXRlQW1vdW50ID0gKG9iaikgPT5cclxuICBPYmplY3QudmFsdWVzKG9iailcclxuICAgIC5yZWR1Y2UoKGFjYywgeyBxdWFudGl0eSwgcHJpY2UgfSkgPT4gYWNjICsgcXVhbnRpdHkgKiBwcmljZSwgMClcclxuICAgIC50b0ZpeGVkKDIpO1xyXG5cclxuZnVuY3Rpb24qIGdldENhcnRTYWdhKCkge1xyXG4gIGFsZXJ0KFwiYmJiYmJcIilcclxuICB0cnkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgbGV0IGxhbmdfaWQgPSAxO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgbGFuZ19pZCxcclxuICAgIH07XHJcbmNvbnNvbGUubG9nKFwiLi4uZ2V0Q2FydFNhZ2EuLnBheWxvYWQuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKENhcnRSZXBvc2l0b3J5LmdldENhcnRJdGVtLCBwYXlsb2FkKTtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uZ2V0Q2FydFNhZ2EuLnBheWxvYWQuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uLi5hYmNkLi4uLi5cIixyZXNwb25zZSlcclxuICAgIHlpZWxkIHB1dChnZXRDYXJ0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGFkZEl0ZW1TYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgYWxlcnQoXCJhYWFhYWFhYWFhYVwiKVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQ2FydFJlcG9zaXRvcnkuYWRkUHJvZHVjdFRvQ2FydCwgcGF5bG9hZCk7XHJcblxyXG4gICAgbW9kYWxTdWNjZXNzKHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UubWVzc2FnZSk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydChwYXlsb2FkLmFjY2Vzc190b2tlbikpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgeWllbGQgcHV0KGdldENhcnRFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVJdGVtU2FnYShwYXlsb2FkKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHsgcHJvZHVjdCB9ID0gcGF5bG9hZDtcclxuICAgIGxldCBsb2NhbENhcnQgPSBKU09OLnBhcnNlKFxyXG4gICAgICBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicGVyc2lzdDpLYW5ndGFvXCIpKS5jYXJ0XHJcbiAgICApO1xyXG5cclxuICAgIGxldCBpbmRleCA9IGxvY2FsQ2FydC5jYXJ0SXRlbXMuZmluZEluZGV4KChpdGVtKSA9PiBpdGVtLmlkID09PSBwcm9kdWN0LmlkKTtcclxuICAgIGxvY2FsQ2FydC5jYXJ0VG90YWwgPSBsb2NhbENhcnQuY2FydFRvdGFsIC0gcHJvZHVjdC5xdWFudGl0eTtcclxuICAgIGxvY2FsQ2FydC5jYXJ0SXRlbXMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgIGxvY2FsQ2FydC5hbW91bnQgPSBjYWxjdWxhdGVBbW91bnQobG9jYWxDYXJ0LmNhcnRJdGVtcyk7XHJcbiAgICBpZiAobG9jYWxDYXJ0LmNhcnRJdGVtcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgbG9jYWxDYXJ0LmNhcnRJdGVtcyA9IFtdO1xyXG4gICAgICBsb2NhbENhcnQuYW1vdW50ID0gMDtcclxuICAgICAgbG9jYWxDYXJ0LmNhcnRUb3RhbCA9IDA7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlQ2FydFN1Y2Nlc3MobG9jYWxDYXJ0KSk7XHJcbiAgICBtb2RhbFdhcm5pbmcoXCJ3YXJuaW5nXCIpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgeWllbGQgcHV0KGdldENhcnRFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBpbmNyZWFzZVF0eVNhZ2EocGF5bG9hZCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB7IHByb2R1Y3QgfSA9IHBheWxvYWQ7XHJcbiAgICBsZXQgbG9jYWxDYXJ0ID0gSlNPTi5wYXJzZShcclxuICAgICAgSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInBlcnNpc3Q6S2FuZ3Rhb1wiKSkuY2FydFxyXG4gICAgKTtcclxuICAgIGxldCBzZWxlY3RlZEl0ZW0gPSBsb2NhbENhcnQuY2FydEl0ZW1zLmZpbmQoXHJcbiAgICAgIChpdGVtKSA9PiBpdGVtLmlkID09PSBwcm9kdWN0LmlkXHJcbiAgICApO1xyXG4gICAgaWYgKHNlbGVjdGVkSXRlbSkge1xyXG4gICAgICBzZWxlY3RlZEl0ZW0ucXVhbnRpdHkrKztcclxuICAgICAgbG9jYWxDYXJ0LmNhcnRUb3RhbCsrO1xyXG4gICAgICBsb2NhbENhcnQuYW1vdW50ID0gY2FsY3VsYXRlQW1vdW50KGxvY2FsQ2FydC5jYXJ0SXRlbXMpO1xyXG4gICAgfVxyXG4gICAgeWllbGQgcHV0KHVwZGF0ZUNhcnRTdWNjZXNzKGxvY2FsQ2FydCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgeWllbGQgcHV0KGdldENhcnRFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBkZWNyZWFzZUl0ZW1RdHlTYWdhKHBheWxvYWQpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgeyBwcm9kdWN0IH0gPSBwYXlsb2FkO1xyXG4gICAgY29uc3QgbG9jYWxDYXJ0ID0gSlNPTi5wYXJzZShcclxuICAgICAgSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInBlcnNpc3Q6S2FuZ3Rhb1wiKSkuY2FydFxyXG4gICAgKTtcclxuICAgIGxldCBzZWxlY3RlZEl0ZW0gPSBsb2NhbENhcnQuY2FydEl0ZW1zLmZpbmQoXHJcbiAgICAgIChpdGVtKSA9PiBpdGVtLmlkID09PSBwcm9kdWN0LmlkXHJcbiAgICApO1xyXG5cclxuICAgIGlmIChzZWxlY3RlZEl0ZW0pIHtcclxuICAgICAgc2VsZWN0ZWRJdGVtLnF1YW50aXR5LS07XHJcbiAgICAgIGxvY2FsQ2FydC5jYXJ0VG90YWwtLTtcclxuICAgICAgbG9jYWxDYXJ0LmFtb3VudCA9IGNhbGN1bGF0ZUFtb3VudChsb2NhbENhcnQuY2FydEl0ZW1zKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dCh1cGRhdGVDYXJ0U3VjY2Vzcyhsb2NhbENhcnQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHlpZWxkIHB1dChnZXRDYXJ0RXJyb3IoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogY2xlYXJDYXJ0U2FnYSgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZW1wdHlDYXJ0ID0ge1xyXG4gICAgICBjYXJ0SXRlbXM6IFtdLFxyXG4gICAgICBhbW91bnQ6IDAsXHJcbiAgICAgIGNhcnRUb3RhbDogMCxcclxuICAgICAgY2FydDogW10sXHJcbiAgICB9O1xyXG4gICAgeWllbGQgcHV0KGNsZWFyQ2FydFN1Y2Nlc3MoZW1wdHlDYXJ0KSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlQ2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGZldGNoUGxhdGZvcm1Wb3VjaGVyU2FnYSgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKENhcnRSZXBvc2l0b3J5LmZldGNoUGxhdGZvcm1Wb3VjaGVyKTtcclxuICAgIHlpZWxkIHB1dChmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvblN1Y2Nlc3MocmVzcG9uc2UuZGF0YS5jb3Vwb24pKTtcclxuICB9IGNhdGNoIChlcnIpIHt9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVGcm9tQ2FydE5ld1NhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKFByb2R1Y3RSZXBvc2l0b3J5LmRlbGV0ZUNhcnQsIHBheWxvYWQpO1xyXG4gICAgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwic3VjY2Vzc1wiLCBcIlN1Y2Nlc3NcIiwgXCJQcm9kdWN0IFJlbW92ZWRcIik7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydCgpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgaW4gcmVtb3ZpbmcgSXRlbVwiKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uKiByb290U2FnYSgpIHtcclxuIC8vIGFsZXJ0KFwiY2NjY1wiKVxyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9DQVJULCBnZXRDYXJ0U2FnYSldKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5BRERfSVRFTSwgYWRkSXRlbVNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuUkVNT1ZFX0lURU0sIHJlbW92ZUl0ZW1TYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLklOQ1JFQVNFX1FUWSwgaW5jcmVhc2VRdHlTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkRFQ1JFQVNFX1FUWSwgZGVjcmVhc2VJdGVtUXR5U2FnYSldKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5DTEVBUl9DQVJULCBjbGVhckNhcnRTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUiwgZmV0Y2hQbGF0Zm9ybVZvdWNoZXJTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLlJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVcsIHJlbW92ZUZyb21DYXJ0TmV3U2FnYSksXHJcbiAgXSk7XHJcbn1cclxuIiwiaW1wb3J0IHsgYWxsLCBwdXQsIHRha2VFdmVyeSwgY2FsbCB9IGZyb20gXCJyZWR1eC1zYWdhL2VmZmVjdHNcIjtcclxuaW1wb3J0IHsgbWVzc2FnZSwgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHtcclxuICBhY3Rpb25UeXBlcyxcclxuICBnZXRXaXNobGlzdExpc3RTdWNjZXNzLFxyXG4gIHVwZGF0ZVdpc2hsaXN0TGlzdFN1Y2Nlc3MsXHJcbiAgZ2V0V2lzaGxpc3RMaXN0LFxyXG4gIGNsZWFyV2lzaGxpc3QsXHJcbn0gZnJvbSBcIi4vYWN0aW9uXCI7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgYXBpYmFzZXVybCB9IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IFdpc2hsaXN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvV2lzaGxpc3RSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IGdldFByb2R1Y3RzQnlJZCwgdXBkYXRlU2hvY2tpbmdzYWxlV2lzaGxpc3QgfSBmcm9tIFwiLi4vcHJvZHVjdC9hY3Rpb25cIjtcclxuXHJcbmNvbnN0IG1vZGFsU3VjY2VzcyA9ICh0eXBlKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2U6IFwiQWRkZWQgdG8gd2lzaGxpc2h0IVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiVGhpcyBwcm9kdWN0IGhhcyBiZWVuIGFkZGVkIHRvIHdpc2hsaXN0IVwiLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuY29uc3QgbW9kYWxXYXJuaW5nID0gKHR5cGUsIG1lc3NhZ2UsIGRlc2NyaXB0aW9uKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2U6IFwiUmVtb3ZlZCBmcm9tIHdpc2hsaXN0XCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJUaGlzIHByb2R1Y3QgaGFzIGJlZW4gcmVtb3ZlZCBmcm9tIHdpc2hsaXN0IVwiLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuY29uc3QgbW9kYWxSZW1vdmVXYXJuaW5nID0gKHR5cGUsIG1lc3NhZ2UsIGRlc2NyaXB0aW9uKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2UsXHJcbiAgICBkZXNjcmlwdGlvbixcclxuICB9KTtcclxufTtcclxuXHJcbmNvbnN0IG1vZGFsU2hvdyA9ICh0eXBlLCBtZXNzYWdlLCBkZXNjcmlwdGlvbikgPT4ge1xyXG4gIG5vdGlmaWNhdGlvblt0eXBlXSh7XHJcbiAgICBtZXNzYWdlLFxyXG4gICAgZGVzY3JpcHRpb24sXHJcbiAgfSk7XHJcbn07XHJcblxyXG5mdW5jdGlvbiogZ2V0V2lzaGxpc3RMaXN0U2FnYSgpIHtcclxuICB0cnkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgbGV0IGxhbmdfaWQgPSAxO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgbGFuZ19pZCxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LmdldFByb2R1Y3RUb1dpc2hsaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG5cclxuICAgIHlpZWxkIHB1dChcclxuICAgICAgcmVzcG9uc2VEYXRhPy5odHRwY29kZSA9PSBcIjIwMFwiICYmXHJcbiAgICAgICAgZ2V0V2lzaGxpc3RMaXN0U3VjY2VzcyhyZXNwb25zZURhdGEuZGF0YSlcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGFkZEl0ZW1Ub1dpc2hsaXN0U2FnYSh7IHByb2R1Y3QgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LFxyXG4gICAgICB0eXBlOiBcIndlYlwiLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZXNwb25zZURhdGEgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBXaXNobGlzdFJlcG9zaXRvcnkuYWRkUHJvZHVjdFRvV2lzaExpc3QsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICBtb2RhbFNob3coXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5zdGF0dXMsXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5tZXNzYWdlLFxyXG4gICAgICByZXNwb25zZURhdGEuZGF0YS5tZXNzYWdlXHJcbiAgICApO1xyXG4gICAgeWllbGQgcHV0KGdldFdpc2hsaXN0TGlzdCgpKTtcclxuICAgIHlpZWxkIHB1dChnZXRQcm9kdWN0c0J5SWQocHJvZHVjdCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVJdGVtV2lzaGxpc3RTYWdhKHsgcHJvZHVjdCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBhY2Nlc3NfdG9rZW4sXHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3QsXHJcbiAgICB9O1xyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LnJlbW92ZVByb2R1Y3RGcm9tV2lzaExpc3QsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICBtb2RhbFJlbW92ZVdhcm5pbmcoXHJcbiAgICAgIFwid2FybmluZ1wiLFxyXG4gICAgICByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgcmVzcG9uc2VEYXRhLmRhdGEubWVzc2FnZVxyXG4gICAgKTtcclxuICAgIHlpZWxkIHB1dChnZXRXaXNobGlzdExpc3QoKSk7XHJcblxyXG4gICAgeWllbGQgcHV0KGdldFByb2R1Y3RzQnlJZChwcm9kdWN0KSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGNsZWFyV2lzaGxpc3RMaXN0U2FnYSgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZW1wdHlDYXJ0ID0ge1xyXG4gICAgICB3aXNobGlzdEl0ZW1zOiBbXSxcclxuICAgICAgd2lzaGxpc3RUb3RhbDogMCxcclxuICAgIH07XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlV2lzaGxpc3RMaXN0U3VjY2VzcyhlbXB0eUNhcnQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcbmZ1bmN0aW9uKiBhZGRTaG9ja2luZ1NhbGVJdGVtVG9XaXNobGlzdFNhZ2EoeyBwcm9kdWN0IH0pIHtcclxuICB0cnkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdCxcclxuICAgICAgdHlwZTogXCJ3ZWJcIixcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb1dpc2hMaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgbW9kYWxTaG93KFxyXG4gICAgICByZXNwb25zZURhdGEuc3RhdHVzLFxyXG4gICAgICByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgcmVzcG9uc2VEYXRhLmRhdGEubWVzc2FnZVxyXG4gICAgKTtcclxuICAgIHlpZWxkIHB1dChnZXRXaXNobGlzdExpc3QoKSk7XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlU2hvY2tpbmdzYWxlV2lzaGxpc3QodHJ1ZSkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0U2FnYSh7IHByb2R1Y3QgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LFxyXG4gICAgfTtcclxuICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHlpZWxkIGNhbGwoXHJcbiAgICAgIFdpc2hsaXN0UmVwb3NpdG9yeS5yZW1vdmVQcm9kdWN0RnJvbVdpc2hMaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgbW9kYWxSZW1vdmVXYXJuaW5nKFxyXG4gICAgICBcIndhcm5pbmdcIixcclxuICAgICAgcmVzcG9uc2VEYXRhLm1lc3NhZ2UsXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5kYXRhLm1lc3NhZ2VcclxuICAgICk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0V2lzaGxpc3RMaXN0KCkpO1xyXG4gICAgeWllbGQgcHV0KHVwZGF0ZVNob2NraW5nc2FsZVdpc2hsaXN0KGZhbHNlKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24qIHJvb3RTYWdhKCkge1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9XSVNITElTVF9MSVNULCBnZXRXaXNobGlzdExpc3RTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkFERF9JVEVNX1dJU0hMSVNILCBhZGRJdGVtVG9XaXNobGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5SRU1PVkVfSVRFTV9XSVNITElTSCwgcmVtb3ZlSXRlbVdpc2hsaXN0U2FnYSksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShcclxuICAgICAgYWN0aW9uVHlwZXMuQUREX1NIT0NLSU5HX1NBTEVfSVRFTV9UT19XSVNITElTVCxcclxuICAgICAgYWRkU2hvY2tpbmdTYWxlSXRlbVRvV2lzaGxpc3RTYWdhXHJcbiAgICApLFxyXG4gIF0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoXHJcbiAgICAgIGFjdGlvblR5cGVzLlJFTU9WRV9TSE9DS0lOR19TQUxFX0lURU1fRlJPTV9XSVNITElTVCxcclxuICAgICAgcmVtb3ZlU2hvY2tpbmdTYWxlSXRlbUZyb21XaXNobGlzdFNhZ2FcclxuICAgICksXHJcbiAgXSk7XHJcbn1cclxuIiwiLypcclxuICogUmVhY3QgdGVtcGxhdGUgaGVscGVyc1xyXG4gKiBBdXRob3I6IE5vdXRoZW1lc1xyXG4gKiBEZXZlbG9wZWQ6IGRpYXJ5Zm9ybGlmZVxyXG4gKiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGF6eUxvYWQgZnJvbSBcInJlYWN0LWxhenlsb2FkXCI7XHJcbmltcG9ydCB7IGJhc2VVcmwgfSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBSb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBleGFjdE1hdGggPSByZXF1aXJlKFwiZXhhY3QtbWF0aFwiKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByb3V0ZVdpdGhvdXRSZWZyZXNoKHJvdXRlTGluaykge1xyXG4gIFJvdXRlci5yZXBsYWNlKHJvdXRlTGluaywgdW5kZWZpbmVkLCB7XHJcbiAgICBzaGFsbG93OiB0cnVlLFxyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaG9tZVBhZ2VQcm9kdWN0UHJpY2VIZWxwZXIocHJvZHVjdCkge1xyXG4gIGlmIChwcm9kdWN0Lm9mZmVyX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBSTSB7cHJvZHVjdC5vZmZlcl9wcmljZSA/IHByb2R1Y3Qub2ZmZXJfcHJpY2UgOiAwfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgICAgUk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICBpZiAocHJvZHVjdC5zaG9ja19zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBSTSB7cHJvZHVjdC5zaG9ja19zYWxlX3ByaWNlfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgICAgUk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICBpZiAocHJvZHVjdC5zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBSTSB7cHJvZHVjdC5zYWxlX3ByaWNlfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgICAgUk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgUk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgPC9wPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZXR1cm5Ub3RhbE9mQ2FydFZhbHVlKHByb2R1Y3RzKSB7XHJcbiAgbGV0IGNhcnRfdG90YWxfcHJpY2UgPSBwcm9kdWN0cy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIE51bWJlcihwcmljZUhlbHBlcihwcmV2KSkgK1xyXG4gICAgICBOdW1iZXIoXHJcbiAgICAgICAgcHJpY2VIZWxwZXIoXHJcbiAgICAgICAgICBuZXh0LnRvdGFsX2Rpc2NvdW50X3ByaWNlID09IDBcclxuICAgICAgICAgICAgPyBuZXh0LnRvdGFsX2FjdHVhbF9wcmljZVxyXG4gICAgICAgICAgICA6IG5leHQudG90YWxfZGlzY291bnRfcHJpY2VcclxuICAgICAgICApXHJcbiAgICAgIClcclxuICAgICk7XHJcbiAgfSwgMCk7XHJcblxyXG4gIHJldHVybiBjYXJ0X3RvdGFsX3ByaWNlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmV0dXJuVG90YWxDb21taXNzaW9uKHByb2R1Y3RzKSB7XHJcbiAgbGV0IGNhcnRfdG90YWxfY29tbWlzc2lvbiA9IHByb2R1Y3RzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4ge1xyXG4gICAgcmV0dXJuIE51bWJlcihwcmljZUhlbHBlcihwcmV2KSkgKyBOdW1iZXIocHJpY2VIZWxwZXIobmV4dC5jb21taXNzaW9uKSk7XHJcbiAgfSwgMCk7XHJcblxyXG4gIHJldHVybiBjYXJ0X3RvdGFsX2NvbW1pc3Npb247XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZXR1cm5Ub3RhbE9mQ2FydFRheFZhbHVlKHByb2R1Y3RzKSB7XHJcbiAgbGV0IGNhcnRfdG90YWxfdGF4ID0gcHJvZHVjdHMucmVkdWNlKChwcmV2LCBuZXh0KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICBOdW1iZXIocHJpY2VIZWxwZXIocHJldikpICsgTnVtYmVyKHByaWNlSGVscGVyKG5leHQudG90YWxfdGF4X3ZhbHVlKSlcclxuICAgICk7XHJcbiAgfSwgMCk7XHJcblxyXG4gIHJldHVybiBjYXJ0X3RvdGFsX3RheDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHByaWNlSGVscGVyKG51bSkge1xyXG4gIGxldCBudW1iZXJBcnJheSA9IG51bT8udG9TdHJpbmcoKS5zcGxpdChcIixcIik7XHJcbiAgaWYgKG51bWJlckFycmF5ICYmIG51bWJlckFycmF5Py5sZW5ndGggPiAwKSB7XHJcbiAgICByZXR1cm4gbnVtYmVyQXJyYXkucmVkdWNlKChwcmV2LCBuZXh0KSA9PiBwcmV2ICsgbmV4dCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAwO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdChjdXJyZW5jeVZhbCkge1xyXG4gIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoXCJtcy1NWVwiLCB7XHJcbiAgICBzdHlsZTogXCJjdXJyZW5jeVwiLFxyXG4gICAgY3VycmVuY3k6IFwiTVlSXCIsXHJcbiAgfSkuZm9ybWF0KHByaWNlSGVscGVyKGN1cnJlbmN5VmFsKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBtYXRoRm9ybXVsYShmb3JtdWxhVGV4dCkge1xyXG4gIGxldCByZXN1bHQgPSBleGFjdE1hdGguZm9ybXVsYShmb3JtdWxhVGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkaXZDdXJyZW5jeShmaXJzdFZhbCwgc2Vjb25kVmFsKSB7XHJcbiAgbGV0IGRpdkRhdGEgPSBleGFjdE1hdGguZGl2KFxyXG4gICAgcHJpY2VIZWxwZXIoZmlyc3RWYWwgfHwgMCksXHJcbiAgICBwcmljZUhlbHBlcihzZWNvbmRWYWwgfHwgMSlcclxuICApO1xyXG4gIHJldHVybiBkaXZEYXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbXVsQ3VycmVuY3koZmlyc3RWYWwsIHNlY29uZFZhbCkge1xyXG4gIGxldCBtdWxEYXRhID0gZXhhY3RNYXRoLm11bChcclxuICAgIHByaWNlSGVscGVyKGZpcnN0VmFsIHx8IDEpLFxyXG4gICAgcHJpY2VIZWxwZXIoc2Vjb25kVmFsIHx8IDEpXHJcbiAgKTtcclxuICByZXR1cm4gbXVsRGF0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFkZEN1cnJlbmN5KGN1cnJlbmN5VmFsRmlyc3QsIGN1cnJlbmN5VmFsU2Vjb25kKSB7XHJcbiAgbGV0IGFkZERhdGEgPSBleGFjdE1hdGguYWRkKFxyXG4gICAgcHJpY2VIZWxwZXIoY3VycmVuY3lWYWxGaXJzdCB8fCAwKSxcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsU2Vjb25kIHx8IDApXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIGFkZERhdGE7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHN1YkN1cnJlbmN5KGN1cnJlbmN5VmFsRmlyc3QsIGN1cnJlbmN5VmFsU2Vjb25kKSB7XHJcbiAgbGV0IHN1YkRhdGEgPSBleGFjdE1hdGguc3ViKFxyXG4gICAgcHJpY2VIZWxwZXIoY3VycmVuY3lWYWxGaXJzdCB8fCAwKSxcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsU2Vjb25kIHx8IDApXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIHN1YkRhdGE7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRDdXJyZW5jeShudW0pIHtcclxuICBpZiAobnVtICE9PSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBwYXJzZUZsb2F0KG51bSlcclxuICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgLnJlcGxhY2UoLyhcXGQpKD89KFxcZHszfSkrKD8hXFxkKSkvZywgXCIkMSxcIik7XHJcbiAgfSBlbHNlIHtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb2xsZXRpb25CeVNsdWcoY29sbGVjdGlvbnMsIHNsdWcpIHtcclxuICBpZiAoY29sbGVjdGlvbnMubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gY29sbGVjdGlvbnMuZmluZCgoaXRlbSkgPT4gaXRlbS5zbHVnID09PSBzbHVnLnRvU3RyaW5nKCkpO1xyXG4gICAgaWYgKHJlc3VsdCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHJldHVybiByZXN1bHQucHJvZHVjdHM7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiBbXTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRJdGVtQnlTbHVnKGJhbm5lcnMsIHNsdWcpIHtcclxuICBpZiAoYmFubmVycy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBiYW5uZXIgPSBiYW5uZXJzLmZpbmQoKGl0ZW0pID0+IGl0ZW0uc2x1ZyA9PT0gc2x1Zy50b1N0cmluZygpKTtcclxuICAgIGlmIChiYW5uZXIgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICByZXR1cm4gYmFubmVyO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNvbnZlcnRTbHVnc1F1ZXJ5U3RyaW5nKHBheWxvYWQpIHtcclxuICBsZXQgcXVlcnkgPSBcIlwiO1xyXG4gIGlmIChwYXlsb2FkLmxlbmd0aCA+IDApIHtcclxuICAgIHBheWxvYWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAocXVlcnkgPT09IFwiXCIpIHtcclxuICAgICAgICBxdWVyeSA9IGBzbHVnX2luPSR7aXRlbX1gO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHF1ZXJ5ID0gcXVlcnkgKyBgJnNsdWdfaW49JHtpdGVtfWA7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICByZXR1cm4gcXVlcnk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0QmFkZ2UocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG4gIGlmIChwcm9kdWN0LmJhZGdlICYmIHByb2R1Y3QuYmFkZ2UgIT09IG51bGwpIHtcclxuICAgIHZpZXcgPSBwcm9kdWN0LmJhZGdlLm1hcCgoYmFkZ2UpID0+IHtcclxuICAgICAgaWYgKGJhZGdlLnR5cGUgPT09IFwic2FsZVwiKSB7XHJcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fYmFkZ2VcIj57YmFkZ2UudmFsdWV9PC9kaXY+O1xyXG4gICAgICB9IGVsc2UgaWYgKGJhZGdlLnR5cGUgPT09IFwib3V0U3RvY2tcIikge1xyXG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2JhZGdlIG91dC1zdG9ja1wiPntiYWRnZS52YWx1ZX08L2Rpdj47XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fYmFkZ2UgaG90XCI+e2JhZGdlLnZhbHVlfTwvZGl2PjtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5pc19zYWxlID09PSB0cnVlKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBzYWxlXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UpfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfTwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX08L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZV9OZXcocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG4gIGlmIChwcm9kdWN0LnNhbGVfcHJpY2UgIT09IGZhbHNlKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBzYWxlXCI+XHJcbiAgICAgICAgUk0ge3Byb2R1Y3Quc2FsZV9wcmljZX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5STSB7cHJvZHVjdC5hY3R1YWxfcHJpY2V9PC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L3A+O1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGZlYXR1cmVwcm9kdWN0cHJpY2UocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG4gIGlmIChwcm9kdWN0LmlzX3NhbGUgPT09IHRydWUpIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Quc2FsZV9wcmljZSl9e1wiIFwifVxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxpbi1wcmR0XCI+XHJcbiAgICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5hY3R1YWxfcHJpY2UpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlKX17XCIgXCJ9XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGluLXByZHRcIj5cclxuICAgICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LmFjdHVhbF9wcmljZSl9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5pc19zYWxlID09PSB0cnVlKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBzYWxlXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UpfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfTwvZGVsPlxyXG4gICAgICAgIDxzbWFsbD4xOCUgb2ZmPC9zbWFsbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5STSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9PC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZE90aGVyKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgdmlldyA9IChcclxuICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0Lm9mZmVyX3ByaWNlID8gcHJvZHVjdC5vZmZlcl9wcmljZSA6IDApfVxyXG4gICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5hY3R1YWxfcHJpY2UgPyBwcm9kdWN0LmFjdHVhbF9wcmljZSA6IDApfVxyXG4gICAgICA8L2RlbD5cclxuICAgICAgPHNtYWxsPntwcm9kdWN0Lm9mZmVyID8gcHJvZHVjdC5vZmZlciA6IDB9PC9zbWFsbD5cclxuICAgIDwvcD5cclxuICApO1xyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlRXhwYW5kZWRPdGhlcjEocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICB2aWV3ID0gKFxyXG4gICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Quc2FsZV9wcmljZSA/IHByb2R1Y3Quc2FsZV9wcmljZSA6IDApfVxyXG4gICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSA/IHByb2R1Y3QucHJpY2UgOiAwKX1cclxuICAgICAgPC9kZWw+XHJcbiAgICAgIDxzbWFsbD57cHJvZHVjdC5vZmZlciA/IHByb2R1Y3Qub2ZmZXIgOiAwfTwvc21hbGw+XHJcbiAgICA8L3A+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0VGh1bWJuYWlsKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgaWYgKHByb2R1Y3QudGh1bWJuYWlsKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17YCR7YmFzZVVybH0ke3Byb2R1Y3QudGh1bWJuYWlsLnVybH1gfVxyXG4gICAgICAgICAgICAgIGFsdD17cHJvZHVjdC50aXRsZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZyBzcmM9XCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCIgYWx0PVwiS2FuZ3Rhb1wiIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFRodW1ibmFpbE90aGVyKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgaWYgKHByb2R1Y3QuaW1hZ2UubGVuZ3RoID4gMCkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlfVxyXG4gICAgICAgICAgICAgIGFsdD17cHJvZHVjdC5wcm9kdWN0X25hbWV9XHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9XCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJcclxuICAgICAgICAgICAgICBhbHQ9XCJLYW5ndGFvXCJcclxuICAgICAgICAgICAgICB3aWR0aD1cIjMwMHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCIyMDBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFRodW1ibmFpbERldGFpbChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LmltYWdlLmxlbmd0aCA+IDApIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiNTBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiNTBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIlxyXG4gICAgICAgICAgICAgIGFsdD1cIkthbmd0YW9cIlxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiNTBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiNTBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2hvY2tpbmdwcm9kdWN0dGh1bWJuYWlsKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgaWYgKHByb2R1Y3QuaW1hZ2UubGVuZ3RoID4gMCkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlfVxyXG4gICAgICAgICAgICAgIGFsdD17cHJvZHVjdC5wcm9kdWN0X25hbWV9XHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9XCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJcclxuICAgICAgICAgICAgICBhbHQ9XCJLYW5ndGFvXCJcclxuICAgICAgICAgICAgICB3aWR0aD1cIjMwMHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCIyMDBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY29sb3JIZWxwZXIoKSB7XHJcbiAgY29uc29sZS5sb2coXCJoZWxsb1wiKTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9