webpackHotUpdate_N_E("pages/index",{

/***/ "./components/elements/products/ProductShockingSaleSlide.jsx":
/*!*******************************************************************!*\
  !*** ./components/elements/products/ProductShockingSaleSlide.jsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/Rating */ "./components/elements/Rating.jsx");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/ProductThumbnail */ "./components/elements/common/ProductThumbnail.jsx");
/* harmony import */ var _CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../CountDownSimpleDiff */ "./components/elements/CountDownSimpleDiff.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductShockingSaleSlide.jsx";








const ProductShockingSaleSlide = ({
  product
}) => {
  var _product$image$;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Card"], {
      bordered: false,
      className: " text-capitalize",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-block--countdown-deal d-flex justify-content-center mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          className: "figure-timer--font",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "End in:"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__["default"], {
            endTime: product.end_time,
            classAdd: "home-shockingsale--slider"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__["default"], {
            imageLink: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__container text-truncate",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__content mt-4",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-product__title",
              style: {
                fontSize: "large",
                fontWeight: 500,
                marginTop: "1rem"
              },
              children: product.product_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "ps-product__rating",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__["default"], {
              rating: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 15
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 50
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "ps-product__price",
            style: {
              fontWeight: "lighter"
            },
            children: ["SAR ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                className: "ml-2",
                children: ["SAR ", product.actual_price ? product.actual_price : 0]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              style: {
                color: "red"
              },
              className: "ml-2",
              children: product.offer ? product.offer : 0
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

_c = ProductShockingSaleSlide;
/* harmony default export */ __webpack_exports__["default"] = (ProductShockingSaleSlide);

var _c;

$RefreshReg$(_c, "ProductShockingSaleSlide");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/home-default/Advert.jsx":
/*!**************************************************************!*\
  !*** ./components/partials/homepage/home-default/Advert.jsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\home-default\\Advert.jsx",
    _s = $RefreshSig$();



const Advert = ({
  homeitems,
  loading
}) => {
  _s();

  var _homeitems$web_banner, _homeitems$web_banner2;

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("....33333333...", homeitems);
  }, []);
  let mainCarouselView;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$web_banner = homeitems.web_banners) === null || _homeitems$web_banner === void 0 ? void 0 : (_homeitems$web_banner2 = _homeitems$web_banner.web_middle_large) === null || _homeitems$web_banner2 === void 0 ? void 0 : _homeitems$web_banner2.length) > 0) {
    mainCarouselView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-md-6 mb-30",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "banner-thumb",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "shop-grid-4-column.html",
            className: "zoom-in d-block overflow-hidden",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: homeitems.web_banners.web_middle_large[0].media,
              alt: "banner-thumb-naile"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 15,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 9
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 5
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-md-6 mb-30",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "banner-thumb mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "shop-grid-4-column.html",
            className: "zoom-in d-block overflow-hidden",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: homeitems.web_banners.web_middle_small[0].media,
              alt: "banner-thumb-naile"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 9
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "banner-thumb",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "shop-grid-4-column.html",
            className: "zoom-in d-block overflow-hidden",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: homeitems.web_banners.web_middle_small[1].media,
              alt: "banner-thumb-naile"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 9
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 5
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 5
    }, undefined); // const carouseItems = homeitems.main_banner.map((item, index) => (
    //   <div key={index}>{mainBannerMedia(item)}</div>
    // ));
    // mainCarouselView = (
    //   <Slider {...carouselStandard} className="ps-carousel">
    //     {carouseItems}
    //   </Slider>
    // );
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-advert",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: mainCarouselView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 5
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 3
    }, undefined)
  }, void 0, false);
};

_s(Advert, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = Advert;
/* harmony default export */ __webpack_exports__["default"] = (Advert);
/*connect(state => state.media)();*/

var _c;

$RefreshReg$(_c, "Advert");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGUuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2hvbWUtZGVmYXVsdC9BZHZlcnQuanN4Il0sIm5hbWVzIjpbIlByb2R1Y3RTaG9ja2luZ1NhbGVTbGlkZSIsInByb2R1Y3QiLCJlbmRfdGltZSIsInNob2NrX3NhbGVfaWQiLCJwcm9kdWN0X2lkIiwiaW1hZ2UiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJtYXJnaW5Ub3AiLCJwcm9kdWN0X25hbWUiLCJyYXRpbmciLCJvZmZlcl9wcmljZSIsImFjdHVhbF9wcmljZSIsImNvbG9yIiwib2ZmZXIiLCJBZHZlcnQiLCJob21laXRlbXMiLCJsb2FkaW5nIiwidXNlRWZmZWN0IiwiY29uc29sZSIsImxvZyIsIm1haW5DYXJvdXNlbFZpZXciLCJ3ZWJfYmFubmVycyIsIndlYl9taWRkbGVfbGFyZ2UiLCJsZW5ndGgiLCJtZWRpYSIsIndlYl9taWRkbGVfc21hbGwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQSx3QkFBd0IsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFpQjtBQUFBOztBQUNoRCxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLHlDQUFEO0FBQU0sY0FBUSxFQUFFLEtBQWhCO0FBQXVCLGVBQVMsRUFBQyxrQkFBakM7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsNkRBQWY7QUFBQSwrQkFDRTtBQUFRLG1CQUFTLEVBQUMsb0JBQWxCO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSxxRUFBQyw0REFBRDtBQUNFLG1CQUFPLEVBQUVBLE9BQU8sQ0FBQ0MsUUFEbkI7QUFFRSxvQkFBUSxFQUFFO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBVUUscUVBQUMsZ0RBQUQ7QUFDRSxZQUFJLEVBQUcsZ0JBQWVELE9BQU8sQ0FBQ0UsYUFBYyxVQUFTRixPQUFPLENBQUNHLFVBQVcsRUFEMUU7QUFBQSwrQkFHRTtBQUFBLGlDQUNFLHFFQUFDLGdFQUFEO0FBQWtCLHFCQUFTLEVBQUVILE9BQUYsYUFBRUEsT0FBRiwwQ0FBRUEsT0FBTyxDQUFFSSxLQUFULENBQWUsQ0FBZixDQUFGLG9EQUFFLGdCQUFtQkE7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGLGVBaUJFO0FBQUssaUJBQVMsRUFBQyxxQ0FBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQywwQkFBZjtBQUFBLGtDQUNFLHFFQUFDLGdEQUFEO0FBQ0UsZ0JBQUksRUFBRyxnQkFBZUosT0FBTyxDQUFDRSxhQUFjLFVBQVNGLE9BQU8sQ0FBQ0csVUFBVyxFQUQxRTtBQUFBLG1DQUdFO0FBQ0UsdUJBQVMsRUFBQyxtQkFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTEUsd0JBQVEsRUFBRSxPQURMO0FBRUxDLDBCQUFVLEVBQUUsR0FGUDtBQUdMQyx5QkFBUyxFQUFFO0FBSE4sZUFGVDtBQUFBLHdCQVFHUCxPQUFPLENBQUNRO0FBUlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFlRTtBQUFLLHFCQUFTLEVBQUMsb0JBQWY7QUFBQSxvQ0FDRSxxRUFBQyxtRUFBRDtBQUFRLG9CQUFNLEVBQUVSLE9BQU8sQ0FBQ1M7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixvQkFDcUM7QUFBQSx3QkFBT1QsT0FBTyxDQUFDUztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFmRixlQWtCRTtBQUNFLHFCQUFTLEVBQUMsbUJBRFo7QUFFRSxpQkFBSyxFQUFFO0FBQ0xILHdCQUFVLEVBQUU7QUFEUCxhQUZUO0FBQUEsK0JBTU9OLE9BQU8sQ0FBQ1UsV0FBUixHQUFzQlYsT0FBTyxDQUFDVSxXQUE5QixHQUE0QyxDQU5uRCxlQU9FO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLE1BQWY7QUFBQSxtQ0FDS1YsT0FBTyxDQUFDVyxZQUFSLEdBQXVCWCxPQUFPLENBQUNXLFlBQS9CLEdBQThDLENBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEYsZUFZRTtBQUFPLG1CQUFLLEVBQUU7QUFBRUMscUJBQUssRUFBRTtBQUFULGVBQWQ7QUFBZ0MsdUJBQVMsRUFBQyxNQUExQztBQUFBLHdCQUNHWixPQUFPLENBQUNhLEtBQVIsR0FBZ0JiLE9BQU8sQ0FBQ2EsS0FBeEIsR0FBZ0M7QUFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBMkRELENBNUREOztLQUFNZCx3QjtBQThEU0EsdUZBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RFQTs7QUFDQSxNQUFNZSxNQUFNLEdBQUcsQ0FBQztBQUFFQyxXQUFGO0FBQWFDO0FBQWIsQ0FBRCxLQUE0QjtBQUFBOztBQUFBOztBQUV6Q0MseURBQVMsQ0FBQyxNQUFNO0FBQ2xCQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QkosU0FBOUI7QUFFRyxHQUhRLEVBR04sRUFITSxDQUFUO0FBSUEsTUFBSUssZ0JBQUo7O0FBQ0EsTUFBSSxDQUFDSixPQUFELElBQVksQ0FBQUQsU0FBUyxTQUFULElBQUFBLFNBQVMsV0FBVCxxQ0FBQUEsU0FBUyxDQUFFTSxXQUFYLDBHQUF3QkMsZ0JBQXhCLGtGQUEwQ0MsTUFBMUMsSUFBbUQsQ0FBbkUsRUFBc0U7QUFDcEVILG9CQUFnQixnQkFDaEI7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFBLDhCQUNBO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQUEsaUNBQ0k7QUFBRyxnQkFBSSxFQUFDLHlCQUFSO0FBQWtDLHFCQUFTLEVBQUMsaUNBQTVDO0FBQUEsbUNBQ0k7QUFBSyxpQkFBRyxFQUFFTCxTQUFTLENBQUNNLFdBQVYsQ0FBc0JDLGdCQUF0QixDQUF1QyxDQUF2QyxFQUEwQ0UsS0FBcEQ7QUFBMkQsaUJBQUcsRUFBQztBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURBLGVBUUE7QUFBSyxpQkFBUyxFQUFDLGdCQUFmO0FBQUEsZ0NBQ0k7QUFBSyxtQkFBUyxFQUFDLG9CQUFmO0FBQUEsaUNBQ0k7QUFBRyxnQkFBSSxFQUFDLHlCQUFSO0FBQWtDLHFCQUFTLEVBQUMsaUNBQTVDO0FBQUEsbUNBQ0k7QUFBSyxpQkFBRyxFQUFFVCxTQUFTLENBQUNNLFdBQVYsQ0FBc0JJLGdCQUF0QixDQUF1QyxDQUF2QyxFQUEwQ0QsS0FBcEQ7QUFBMkQsaUJBQUcsRUFBQztBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFNSTtBQUFLLG1CQUFTLEVBQUMsY0FBZjtBQUFBLGlDQUNJO0FBQUcsZ0JBQUksRUFBQyx5QkFBUjtBQUFrQyxxQkFBUyxFQUFDLGlDQUE1QztBQUFBLG1DQUNJO0FBQUssaUJBQUcsRUFBRVQsU0FBUyxDQUFDTSxXQUFWLENBQXNCSSxnQkFBdEIsQ0FBdUMsQ0FBdkMsRUFBMENELEtBQXBEO0FBQTJELGlCQUFHLEVBQUM7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREEsQ0FEb0UsQ0F1QnBFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFDRCxzQkFFQTtBQUFBLDJCQUlBO0FBQUssZUFBUyxFQUFDLFdBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLGtCQUNHSjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkEsbUJBRkE7QUFvQkQsQ0EzREQ7O0dBQU1OLE07O0tBQUFBLE07QUE2RFNBLHFFQUFmO0FBQ0EiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNTg2YmU5ZGY2ODk4ODNhYTM5MWQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQgfSBmcm9tIFwifi91dGlsaXRpZXMvcHJvZHVjdC1oZWxwZXJcIjtcclxuaW1wb3J0IFJhdGluZyBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL1JhdGluZ1wiO1xyXG5pbXBvcnQgeyBDYXJkIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFByb2R1Y3RUaHVtYm5haWwgZnJvbSBcIi4uL2NvbW1vbi9Qcm9kdWN0VGh1bWJuYWlsXCI7XHJcbmltcG9ydCBDb3VudERvd25TaW1wbGVEaWZmIGZyb20gXCIuLi9Db3VudERvd25TaW1wbGVEaWZmXCI7XHJcblxyXG5jb25zdCBQcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGUgPSAoeyBwcm9kdWN0IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPENhcmQgYm9yZGVyZWQ9e2ZhbHNlfSBjbGFzc05hbWU9XCIgdGV4dC1jYXBpdGFsaXplXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1ibG9jay0tY291bnRkb3duLWRlYWwgZC1mbGV4IGp1c3RpZnktY29udGVudC1jZW50ZXIgbWItM1wiPlxyXG4gICAgICAgICAgPGZpZ3VyZSBjbGFzc05hbWU9XCJmaWd1cmUtdGltZXItLWZvbnRcIj5cclxuICAgICAgICAgICAgPGZpZ2NhcHRpb24+RW5kIGluOjwvZmlnY2FwdGlvbj5cclxuICAgICAgICAgICAgPENvdW50RG93blNpbXBsZURpZmZcclxuICAgICAgICAgICAgICBlbmRUaW1lPXtwcm9kdWN0LmVuZF90aW1lfVxyXG4gICAgICAgICAgICAgIGNsYXNzQWRkPXtcImhvbWUtc2hvY2tpbmdzYWxlLS1zbGlkZXJcIn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZmlndXJlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICBocmVmPXtgc2hvY2tpbmdzYWxlLyR7cHJvZHVjdC5zaG9ja19zYWxlX2lkfT9wcl9pZD0ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICA8UHJvZHVjdFRodW1ibmFpbCBpbWFnZUxpbms9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX0gLz5cclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19jb250YWluZXIgdGV4dC10cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19jb250ZW50IG10LTRcIj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICBocmVmPXtgc2hvY2tpbmdzYWxlLyR7cHJvZHVjdC5zaG9ja19zYWxlX2lkfT9wcl9pZD0ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3RpdGxlXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjFyZW1cIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3JhdGluZ1wiPlxyXG4gICAgICAgICAgICAgIDxSYXRpbmcgcmF0aW5nPXtwcm9kdWN0LnJhdGluZ30gLz4gPHNwYW4+e3Byb2R1Y3QucmF0aW5nfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcImxpZ2h0ZXJcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU0FSIHtwcm9kdWN0Lm9mZmVyX3ByaWNlID8gcHJvZHVjdC5vZmZlcl9wcmljZSA6IDB9XHJcbiAgICAgICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICBTQVIge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgICAgICAgICAgPC9kZWw+XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICA8c21hbGwgc3R5bGU9e3sgY29sb3I6IFwicmVkXCIgfX0gY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3Qub2ZmZXIgPyBwcm9kdWN0Lm9mZmVyIDogMH1cclxuICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9DYXJkPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2R1Y3RTaG9ja2luZ1NhbGVTbGlkZTtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuY29uc3QgQWR2ZXJ0ID0gKHsgaG9tZWl0ZW1zLCBsb2FkaW5nIH0pID0+IHtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuY29uc29sZS5sb2coXCIuLi4uMzMzMzMzMzMuLi5cIixob21laXRlbXMpXHJcbiAgIFxyXG4gIH0sIFtdKTtcclxuICBsZXQgbWFpbkNhcm91c2VsVmlldztcclxuICBpZiAoIWxvYWRpbmcgJiYgaG9tZWl0ZW1zPy53ZWJfYmFubmVycz8ud2ViX21pZGRsZV9sYXJnZT8ubGVuZ3RoID4gMCkge1xyXG4gICAgbWFpbkNhcm91c2VsVmlldyA9KFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTYgbWItMzBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhbm5lci10aHVtYlwiPlxyXG4gICAgICAgICAgICA8YSBocmVmPVwic2hvcC1ncmlkLTQtY29sdW1uLmh0bWxcIiBjbGFzc05hbWU9XCJ6b29tLWluIGQtYmxvY2sgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17aG9tZWl0ZW1zLndlYl9iYW5uZXJzLndlYl9taWRkbGVfbGFyZ2VbMF0ubWVkaWF9IGFsdD1cImJhbm5lci10aHVtYi1uYWlsZVwiLz5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC02IG1iLTMwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYW5uZXItdGh1bWIgbWItMzBcIj5cclxuICAgICAgICAgICAgPGEgaHJlZj1cInNob3AtZ3JpZC00LWNvbHVtbi5odG1sXCIgY2xhc3NOYW1lPVwiem9vbS1pbiBkLWJsb2NrIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9e2hvbWVpdGVtcy53ZWJfYmFubmVycy53ZWJfbWlkZGxlX3NtYWxsWzBdLm1lZGlhfSBhbHQ9XCJiYW5uZXItdGh1bWItbmFpbGVcIi8+XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhbm5lci10aHVtYlwiPlxyXG4gICAgICAgICAgICA8YSBocmVmPVwic2hvcC1ncmlkLTQtY29sdW1uLmh0bWxcIiBjbGFzc05hbWU9XCJ6b29tLWluIGQtYmxvY2sgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17aG9tZWl0ZW1zLndlYl9iYW5uZXJzLndlYl9taWRkbGVfc21hbGxbMV0ubWVkaWF9IGFsdD1cImJhbm5lci10aHVtYi1uYWlsZVwiLz5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PilcclxuICAgIC8vIGNvbnN0IGNhcm91c2VJdGVtcyA9IGhvbWVpdGVtcy5tYWluX2Jhbm5lci5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAvLyAgIDxkaXYga2V5PXtpbmRleH0+e21haW5CYW5uZXJNZWRpYShpdGVtKX08L2Rpdj5cclxuICAgIC8vICkpO1xyXG4gICAgLy8gbWFpbkNhcm91c2VsVmlldyA9IChcclxuICAgIC8vICAgPFNsaWRlciB7Li4uY2Fyb3VzZWxTdGFuZGFyZH0gY2xhc3NOYW1lPVwicHMtY2Fyb3VzZWxcIj5cclxuICAgIC8vICAgICB7Y2Fyb3VzZUl0ZW1zfVxyXG4gICAgLy8gICA8L1NsaWRlcj5cclxuICAgIC8vICk7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcblxyXG4gIDw+XHJcblxyXG5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcy1hZHZlcnRcIj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgIHttYWluQ2Fyb3VzZWxWaWV3fVxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG5cclxuXHJcblxyXG4gIDwvPlxyXG4gICBcclxuICAgIFxyXG5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWR2ZXJ0O1xyXG4vKmNvbm5lY3Qoc3RhdGUgPT4gc3RhdGUubWVkaWEpKCk7Ki9cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==