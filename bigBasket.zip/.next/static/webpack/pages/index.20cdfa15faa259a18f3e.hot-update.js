webpackHotUpdate_N_E("pages/index",{

/***/ "./components/partials/homepage/home-default/BottomCategory.jsx":
/*!**********************************************************************!*\
  !*** ./components/partials/homepage/home-default/BottomCategory.jsx ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\home-default\\BottomCategory.jsx",
    _s = $RefreshSig$();



const BottomCategory = ({
  homeitems,
  loading
}) => {
  _s();

  var _homeitems$category;

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {}, []);
  let mainCarouselView;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$category = homeitems.category) === null || _homeitems$category === void 0 ? void 0 : _homeitems$category.length) > 0) {
    mainCarouselView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "organic-food-fresh-banner",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "offer-banner",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              href: "product-style-2.html",
              className: "banner-hover",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: homeitems.category[0].image,
                alt: "offer-banner",
                className: "img-fluid"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 19,
                columnNumber: 29
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 18,
              columnNumber: 25
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "banner-content",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: homeitems.category[0].category_name
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 22,
                columnNumber: 29
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                children: homeitems.category[0].media
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 30
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "product-style-2.html",
                className: "btn-style2",
                children: "Shop now"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 24,
                columnNumber: 29
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "offer-banner",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              href: "product-style-2.html",
              className: "banner-hover",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: homeitems.category[0].image,
                alt: "offer-banner",
                className: "img-fluid"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 25
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "banner-content",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: homeitems.category[0].category_name
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 29
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                children: homeitems.category[0].media
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 34,
                columnNumber: 30
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "product-style-2.html",
                className: "btn-style2",
                children: "Shop now"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 35,
                columnNumber: 29
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 21
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "offer-banner",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              href: "product-style-2.html",
              className: "banner-hover",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: homeitems.category[0].image,
                alt: "offer-banner",
                className: "img-fluid"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 25
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "banner-content",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: homeitems.category[0].category_name
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 29
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                children: homeitems.category[0].media
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 45,
                columnNumber: 30
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "product-style-2.html",
                className: "btn-style2",
                children: "Shop now"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 46,
                columnNumber: 29
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 43,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 13
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 9
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-bottomcategory",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: mainCarouselView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 5
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 3
    }, undefined)
  }, void 0, false);
};

_s(BottomCategory, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = BottomCategory;
/* harmony default export */ __webpack_exports__["default"] = (BottomCategory);
/*connect(state => state.media)();*/

var _c;

$RefreshReg$(_c, "BottomCategory");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/home-default/FeatureAndRecent.jsx":
/*!************************************************************************!*\
  !*** ./components/partials/homepage/home-default/FeatureAndRecent.jsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\home-default\\FeatureAndRecent.jsx",
    _s = $RefreshSig$();




const FeatureAndRecent = ({
  homeitems,
  getFeatureProduct,
  loading
}) => {
  _s();

  var _getFeatureProduct$pr, _homeitems$center_off;

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log(".....f....", getFeatureProduct);
  }, []);
  let mainCarouselView;

  if (!loading && (getFeatureProduct === null || getFeatureProduct === void 0 ? void 0 : (_getFeatureProduct$pr = getFeatureProduct.products) === null || _getFeatureProduct$pr === void 0 ? void 0 : _getFeatureProduct$pr.length) > 0) {
    // const carouseItems = homeitems.main_banner.map((item, index) => (
    //   <div key={index}>{mainBannerMedia(item)}</div>
    // ));
    mainCarouselView = homeitems.featured_products.slice(0, 3).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "product-list mb-30",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "card product-card border-0",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "card-body p-0",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "media",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "product-thumbnail",
              style: {
                display: item.image.length > 0 ? 'block' : 'none'
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                href: "/product/[pid]",
                as: `/product/${item.product_id}`,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "single-product.html",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    className: "first-img",
                    src: item.image.length > 0 ? item.image[0].thumbnail : '',
                    alt: "thumbnail"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 25,
                    columnNumber: 30
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 25
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 21
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "media-body",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "product-desc",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                  className: "title",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "shop-grid-4-column.html",
                    children: item.product_name
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 31,
                    columnNumber: 51
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 29
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "d-flex align-items-center justify-content-between",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                    className: "product-price",
                    children: ["SAR ", item.actual_price]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 33,
                    columnNumber: 33
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 32,
                  columnNumber: 29
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 17
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 9
    }, undefined));
  }

  let mainCarouselView1;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$center_off = homeitems.center_offer_banner) === null || _homeitems$center_off === void 0 ? void 0 : _homeitems$center_off.length) > 0) {
    // const carouseItems = homeitems.main_banner.map((item, index) => (
    //   <div key={index}>{mainBannerMedia(item)}</div>
    // ));
    mainCarouselView1 = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "col-12 col-md-8 mx-auto col-lg-4 mb-50",
      style: {
        display: homeitems.center_offer_banner.length > 0 ? 'block' : 'none'
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "banner-thumb",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "shop-grid-4-column.html",
          className: "zoom-in d-block overflow-hidden position-relative zIndex-3",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: homeitems.center_offer_banner.length > 0 ? homeitems.center_offer_banner[0].media : '',
            alt: "banner-thumb-naile"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 18
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 9
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "featurandrecent",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12 col-lg-4 mb-50",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                className: "title text-dark text-capitalize",
                children: "Featured products "
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "featured-init",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "slider-item",
                children: mainCarouselView
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 13
          }, undefined), mainCarouselView1, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12 col-lg-4 mb-50",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                className: "title text-dark text-capitalize",
                children: "Recommended Products"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 85,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "featured-init2 slick-nav",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "slider-item",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 95,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 94,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Brixton Patrol All Terrain Anorak Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 101,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 101,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 104,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 103,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 100,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 93,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 92,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 90,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 118,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 117,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Juicy Couture Solid Sleeve Puffer Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 124,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 124,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 127,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 126,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 123,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 122,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 116,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 115,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 114,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 141,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 140,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "New Balance Fresh Foam LAZR v1 Sport"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 147,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 147,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 150,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 149,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 146,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 145,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 139,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 138,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 137,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 164,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 163,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Couture Juicy Quilted Terry Track Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 172,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 172,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 175,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 174,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 171,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 170,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 162,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 161,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 160,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 159,
                  columnNumber: 25
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 89,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 88,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 9
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 5
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 5
    }, undefined)
  }, void 0, false);
};

_s(FeatureAndRecent, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = FeatureAndRecent;
/* harmony default export */ __webpack_exports__["default"] = (FeatureAndRecent);
/*connect(state => state.media)();*/

var _c;

$RefreshReg$(_c, "FeatureAndRecent");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/new-deals-daily/newdealsdaily.jsx":
/*!************************************************************************!*\
  !*** ./components/partials/homepage/new-deals-daily/newdealsdaily.jsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/elements/skeletons/SkeletonProduct */ "./components/elements/skeletons/SkeletonProduct.jsx");
/* harmony import */ var _utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/utilities/carousel-helpers */ "./utilities/carousel-helpers.js");
/* harmony import */ var _components_elements_products_ProductDealOfDay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/elements/products/ProductDealOfDay */ "./components/elements/products/ProductDealOfDay.jsx");
/* harmony import */ var _components_elements_products_ProductDealOfDaySlider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/components/elements/products/ProductDealOfDaySlider */ "./components/elements/products/ProductDealOfDaySlider.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _utilities_strapi_fetch_data_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/utilities/strapi-fetch-data-helpers */ "./utilities/strapi-fetch-data-helpers.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\new-deals-daily\\newdealsdaily.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }











const Newdealsdaily = ({
  homeitems,
  loading
}) => {
  // Views
  console.log("...kkkkkkkk....", homeitems);

  const checkdealsobject = homeitems => {
    if ("products" in homeitems) {
      return true;
    } else {
      return false;
    }
  };

  let productItemsView;

  if (!loading) {
    var _homeitems$products;

    if (checkdealsobject && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$products = homeitems.products) === null || _homeitems$products === void 0 ? void 0 : _homeitems$products.length) > 0) {
      var _homeitems$products2, _homeitems$products3, _homeitems$products4, _homeitems$products5;

      const slideItems = (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$products2 = homeitems.products) === null || _homeitems$products2 === void 0 ? void 0 : _homeitems$products2.length) > 5 ? homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$products3 = homeitems.products) === null || _homeitems$products3 === void 0 ? void 0 : _homeitems$products3.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_products_ProductDealOfDaySlider__WEBPACK_IMPORTED_MODULE_8__["default"], {
        product: item
      }, item.product_id, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 15
      }, undefined)) : homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$products4 = homeitems.products) === null || _homeitems$products4 === void 0 ? void 0 : _homeitems$products4.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_products_ProductDealOfDay__WEBPACK_IMPORTED_MODULE_7__["default"], {
        product: item
      }, item.product_id, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 15
      }, undefined));
      productItemsView = (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$products5 = homeitems.products) === null || _homeitems$products5 === void 0 ? void 0 : _homeitems$products5.length) > 5 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, _utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_6__["carouselStandard1"]), {}, {
        className: "ps-carousel outside",
        children: slideItems
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "align-content-lg-stretch row",
        children: slideItems
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, undefined);
    } else {
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("p", {
        children: "No product(s) found."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 26
      }, undefined);
    }
  } else {
    const skeletons = Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["generateTempArray"])(6).map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "col-xl-3 col-lg-3 col-md-3",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined)
    }, item, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, undefined));
    productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "row",
      children: skeletons
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 24
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    className: "ps-deal-of-day newarrivals",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "ps-container",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "ps-section__header justify-content-center",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
          className: "ps-block--countdown-deal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
            className: "ps-block__left",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("h3", {
              children: "New Arrivals"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 63,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("p", {
              className: "text-center p-3",
              children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 64,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 7
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "d-flex justify-content-end vual",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
          href: "/newdeals",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
            children: "View All"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "ps-section__content",
        children: productItemsView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 5
  }, undefined);
};

_c = Newdealsdaily;
/* harmony default export */ __webpack_exports__["default"] = (Newdealsdaily);

var _c;

$RefreshReg$(_c, "Newdealsdaily");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/shockingsale/shockingsale.jsx":
/*!********************************************************************!*\
  !*** ./components/partials/homepage/shockingsale/shockingsale.jsx ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_static_img_custom_images_shocking_sale_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/public/static/img/custom_images/shocking_sale.jpg */ "./public/static/img/custom_images/shocking_sale.jpg");
/* harmony import */ var _public_static_img_custom_images_shocking_sale_jpg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_public_static_img_custom_images_shocking_sale_jpg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/skeletons/SkeletonProduct */ "./components/elements/skeletons/SkeletonProduct.jsx");
/* harmony import */ var _components_elements_products_ProductShockingSale__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/elements/products/ProductShockingSale */ "./components/elements/products/ProductShockingSale.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/elements/carousel/NextArrow */ "./components/elements/carousel/NextArrow.jsx");
/* harmony import */ var _components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/components/elements/carousel/PrevArrow */ "./components/elements/carousel/PrevArrow.jsx");
/* harmony import */ var _components_elements_products_ProductShockingSaleSlide__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/components/elements/products/ProductShockingSaleSlide */ "./components/elements/products/ProductShockingSaleSlide.jsx");



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\shockingsale\\shockingsale.jsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }












const Shockingsale = ({
  collectionSlug,
  homeitems,
  loading
}) => {
  // const [productItems, setProductItems] = useState(null);
  // const [loading, setLoading] = useState(true);
  // async function getProducts() {
  //   setLoading(true);
  //   const responseData = await getProductsByCollectionHelper(collectionSlug);
  //   if (responseData) {
  //     setProductItems(responseData.items);
  //     setTimeout(
  //       function () {
  //         setLoading(false);
  //       }.bind(this),
  //       250
  //     );
  //   }
  // }
  // useEffect(() => {
  //   getProducts();
  // }, []);
  const checkSalesobject = homeitems => {
    if ("shocking_sale" in homeitems) {
      return true;
    } else {
      return false;
    }
  };

  const carouselStandard = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 750,
    slidesToShow: 4,
    slidesToScroll: 1,
    nextArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 16
    }, undefined),
    prevArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 16
    }, undefined),
    responsive: [{
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    }, {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        initialSlide: 1
      }
    }, {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  }; // Views

  let productItemsView;

  if (!loading) {
    if (checkSalesobject(homeitems) && homeitems && homeitems.shocking_sale.length > 0) {
      const shockingsale_products = homeitems.shocking_sale; // const slideItems = shockingsale_products.map((item, index) => {
      //   return <ProductShockingSale product={item} key={index} />;
      // });

      const slideItems = shockingsale_products.length > 4 ? shockingsale_products.map((item, index) => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductShockingSaleSlide__WEBPACK_IMPORTED_MODULE_11__["default"], {
          product: item
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 22
        }, undefined);
      }) : shockingsale_products.map((item, index) => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductShockingSale__WEBPACK_IMPORTED_MODULE_7__["default"], {
          product: item
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 22
        }, undefined);
      });
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
        children: shockingsale_products.length > 4 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_5___default.a, _objectSpread(_objectSpread({}, carouselStandard), {}, {
          className: "ps-carousel outside",
          children: slideItems
        }), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 103,
          columnNumber: 13
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "align-content-lg-stretch row",
          children: slideItems
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 107,
          columnNumber: 13
        }, undefined)
      }, void 0, false);
    } else {
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: "No product(s) found."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 26
      }, undefined);
    }
  } else {
    const skeletons = Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__["generateTempArray"])(6).map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "col-xl-2 col-lg-3 col-sm-3 col-6",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, undefined)
    }, item, false, {
      fileName: _jsxFileName,
      lineNumber: 116,
      columnNumber: 7
    }, undefined));
    productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: skeletons
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 120,
      columnNumber: 24
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-deal-of-day shockingsale" // style={{
    //   backgroundImage: `url(${background})`,
    //   backgroundPosition: "bottom",
    // }}
    ,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-container",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-section__header justify-content-center d-flex",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-block--countdown-deal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "ps-block__left",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
              className: "text-center",
              children: "Shocking Sale"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 135,
              columnNumber: 13
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text-center p-3",
              children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 136,
              columnNumber: 13
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 11
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
          href: "/shockingsale",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: "View All"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 152,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 151,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: homeitems.shocking_sale.length > 4 ? "" : `row align-content-lg-stretch`,
        style: {
          marginLeft: homeitems.shocking_sale.length > 4 ? "" : "2rem"
        },
        children: productItemsView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 155,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 131,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 124,
    columnNumber: 5
  }, undefined);
};

_c = Shockingsale;
/* harmony default export */ __webpack_exports__["default"] = (Shockingsale);

var _c;

$RefreshReg$(_c, "Shockingsale");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/HeaderDefault.jsx":
/*!*****************************************************!*\
  !*** ./components/shared/headers/HeaderDefault.jsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/common/Logo */ "./components/elements/common/Logo.js");
/* harmony import */ var _components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/shared/headers/modules/SearchHeader */ "./components/shared/headers/modules/SearchHeader.jsx");
/* harmony import */ var _components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/shared/navigation/NavigationDefault */ "./components/shared/navigation/NavigationDefault.jsx");
/* harmony import */ var _components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/shared/headers/modules/HeaderActions */ "./components/shared/headers/modules/HeaderActions.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/shared/menus/MenuCategoriesDropdown */ "./components/shared/menus/MenuCategoriesDropdown.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\HeaderDefault.jsx",
    _s = $RefreshSig$();









 // import Dropdown from 'react-bootstrap/Dropdown';

const HeaderDefault = () => {
  _s();

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (true) {
      window.addEventListener("scroll", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__["stickyHeader"]);
    }
  }, []);

  const aaa = e => {
    // alert("d")
    console.log("ghfhfh", e.target.value);
    localStorage.setItem("langId", e.target.value);
    window.location.reload();
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
    className: "header header--1",
    "data-sticky": "true",
    id: "headerSticky",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "head-top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "d-flex justify-content-end",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "top-content",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "top-url",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("select", {
                  onChange: e => aaa(e),
                  nme: "cars",
                  id: "cars",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "1",
                    children: "Lang"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 34,
                    columnNumber: 19
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "1",
                    children: "English"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 35,
                    columnNumber: 5
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "2",
                    children: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 36,
                    columnNumber: 5
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 15
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "top-li",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: " Sign In"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 52,
                  columnNumber: 20
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 39,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "header__top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__left",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__categ",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "d-flex justify-content-center align-items-center ofr",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "",
            children: "Offer Zone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__right",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, undefined);
};

_s(HeaderDefault, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = HeaderDefault;
/* harmony default export */ __webpack_exports__["default"] = (HeaderDefault);

var _c;

$RefreshReg$(_c, "HeaderDefault");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/MiniCart.jsx":
/*!********************************************************!*\
  !*** ./components/shared/headers/modules/MiniCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductOnCart */ "./components/elements/products/ProductOnCart.jsx");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\MiniCart.jsx",
    _s = $RefreshSig$();











const MiniCart = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(_c = _s(({
  cart
}) => {
  var _cart$product, _cartdata$product, _cartdata$product2;

  _s();

  let cartItemsView;
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(state => state.auth);
  const productItemWithSeller = cart === null || cart === void 0 ? void 0 : (_cart$product = cart.product) === null || _cart$product === void 0 ? void 0 : _cart$product.map(productItem => {
    var _productItem$seller, _productItem$seller2, _productItem$seller3, _productItem$seller3$;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "stor-tit",
        children: productItem === null || productItem === void 0 ? void 0 : (_productItem$seller2 = productItem.seller) === null || _productItem$seller2 === void 0 ? void 0 : _productItem$seller2.seller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }, undefined), productItem === null || productItem === void 0 ? void 0 : (_productItem$seller3 = productItem.seller) === null || _productItem$seller3 === void 0 ? void 0 : (_productItem$seller3$ = _productItem$seller3.products) === null || _productItem$seller3$ === void 0 ? void 0 : _productItem$seller3$.map(cartProduct => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: cartProduct
      }, cartProduct === null || cartProduct === void 0 ? void 0 : cartProduct.cart_id, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined))]
    }, productItem === null || productItem === void 0 ? void 0 : (_productItem$seller = productItem.seller) === null || _productItem$seller === void 0 ? void 0 : _productItem$seller.seller_id, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, undefined);
  });
  const {
    0: cartdata,
    1: setCartdata
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: totalItems,
    1: setTotalItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log(".productItemNext......cart.....", cart); // console.log(".productItemNext...........", productItemNext)

    let isMounted = true;

    if (isMounted) {
      var _cart$product2;

      //alert("bhbhhbhhh")
      const cartTotalProductsFromAllSeller = cart === null || cart === void 0 ? void 0 : (_cart$product2 = cart.product) === null || _cart$product2 === void 0 ? void 0 : _cart$product2.reduce((productItemPrev, productItemNext) => {
        return Number(productItemPrev) + Number(productItemNext.seller.products.length);
      }, 0);
      setTotalItems(cartTotalProductsFromAllSeller);
      setCartdata(cart);
    }

    return () => {
      isMounted = false;
    };
  }, [cart === null || cart === void 0 ? void 0 : cart.product]); // async getCartItem(payload) {

  const getCartItem = payload => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]
    });
    console.log("....aaaaaaaaaaaaaaaa...", user_token);
    console.log("....bbbbbbbbbbbbbbbb...", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]);
    const data = axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: localStorage.getItem("langId"),
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }).then(response => response.data).then(data => {
      console.log("...iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setCartdata(data.data);
        setTotalItems(data.data.cart_count); //   alert("yes")
        //  setOfferData(data.data)
        // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {// notification["error"]({
      //   message: error,
      // });
    });
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]); // console.log("....bbbbb...bbb...",payload)
    // let userdata = localStorage.getItem("user");
    // let parsedata = JSON.parse(userdata);
    // let access_token = parsedata?.access_token;
    // const user_token = access_token;
    // const response =  Repository.post(`${apibaseurl}/api/customer/cart`, {
    //   access_token: user_token,
    //   lang_id: 1,
    //   device_id: getDeviceId,
    //   page_url: "http://localhost:3000/product/2",
    //   os_type: "WEB",
    // })
    // console.log("....bbbbb...bbb..444444444444.",response)
    //   // .then((response) => {
    //     if (response.data.httpcode == "200") {
    //       return response.data;
    //     }
    //   //   return response.data;
    //   // })
    //   // .catch((error) => ({ error: JSON.stringify(error) }));
    // return response;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("..557..", cart);
    getCartItem();

    if (cart == undefined) {
      // alert("ddfffd")
      (auth === null || auth === void 0 ? void 0 : auth.access_token) && dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
    }
  }, [auth.access_token, cart === null || cart === void 0 ? void 0 : cart.product]);

  if (cartdata !== null && cartdata !== undefined && cartdata !== null && cartdata !== void 0 && (_cartdata$product = cartdata.product) !== null && _cartdata$product !== void 0 && _cartdata$product.length && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product2 = cartdata.product) === null || _cartdata$product2 === void 0 ? void 0 : _cartdata$product2.length) !== 0) {
    var _cartdata$product3;

    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: productItemWithSeller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 143,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__footer",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          children: ["Sub Total:", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            children: cartdata && cartdata !== null && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product3 = cartdata.product) === null || _cartdata$product3 === void 0 ? void 0 : _cartdata$product3.length) > 0 ? Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__["currencyHelperConvertToRinggit"])(cartdata.grand_total) : 0
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 147,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/shopping-cart",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "View Cart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 155,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 154,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/checkout",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "Checkout"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 158,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 157,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 153,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 144,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 142,
      columnNumber: 7
    }, undefined);
  } else {
    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          children: "No products in cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 7
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-cart--mini",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "header__extra",
      href: "#",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-bag2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          children: cartdata !== null && cartdata !== undefined && totalItems > 0 ? totalItems : 0
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 179,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 178,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 176,
      columnNumber: 7
    }, undefined), cartItemsView]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 175,
    columnNumber: 5
  }, undefined);
}, "lT+bflo29ZWMxNMJEjF2ThtquLk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"]];
}));
_c2 = MiniCart;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(state => state.cart)(MiniCart));

var _c, _c2;

$RefreshReg$(_c, "MiniCart$React.memo");
$RefreshReg$(_c2, "MiniCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/@popperjs/core/lib/createPopper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/contains.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getParentNode.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/instanceOf.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isLayoutViewport.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isTableElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js":
false,

/***/ "./node_modules/@popperjs/core/lib/enums.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/arrow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/computeStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/eventListeners.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/flip.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/hide.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/offset.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/popperOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/preventOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper-base.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/debounce.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/detectOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/expandToHashMap.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/format.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getAltAxis.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getBasePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getFreshSideObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getVariation.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/math.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergeByName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergePaddingObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/orderModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/rectToClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/uniqueBy.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/userAgent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/validateModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/within.js":
false,

/***/ "./node_modules/@react-aria/ssr/dist/module.js":
false,

/***/ "./node_modules/@restart/hooks/esm/index.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCallbackRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCommittedRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventCallback.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useForceUpdate.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useGlobalListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useImage.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useIsomorphicEffect.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeState.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeStateFromProps.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergedRefs.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMounted.js":
false,

/***/ "./node_modules/@restart/hooks/esm/usePrevious.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useRafInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useResizeObserver.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useSafeState.js":
false,

/***/ "./node_modules/@restart/ui/esm/Anchor.js":
false,

/***/ "./node_modules/@restart/ui/esm/Button.js":
false,

/***/ "./node_modules/@restart/ui/esm/DataKey.js":
false,

/***/ "./node_modules/@restart/ui/esm/Dropdown.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownItem.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownMenu.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownToggle.js":
false,

/***/ "./node_modules/@restart/ui/esm/NavContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/SelectableContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/mergeOptionsWithPopperConfig.js":
false,

/***/ "./node_modules/@restart/ui/esm/popper.js":
false,

/***/ "./node_modules/@restart/ui/esm/ssr.js":
false,

/***/ "./node_modules/@restart/ui/esm/useClickOutside.js":
false,

/***/ "./node_modules/@restart/ui/esm/usePopper.js":
false,

/***/ "./node_modules/@restart/ui/esm/useWindow.js":
false,

/***/ "./node_modules/dequal/dist/index.mjs":
false,

/***/ "./node_modules/dom-helpers/esm/addEventListener.js":
false,

/***/ "./node_modules/dom-helpers/esm/camelize.js":
false,

/***/ "./node_modules/dom-helpers/esm/canUseDOM.js":
false,

/***/ "./node_modules/dom-helpers/esm/contains.js":
false,

/***/ "./node_modules/dom-helpers/esm/listen.js":
false,

/***/ "./node_modules/dom-helpers/esm/ownerDocument.js":
false,

/***/ "./node_modules/dom-helpers/esm/querySelectorAll.js":
false,

/***/ "./node_modules/dom-helpers/esm/removeEventListener.js":
false,

/***/ "./node_modules/invariant/browser.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Button.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Dropdown.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownItem.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownMenu.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownToggle.js":
false,

/***/ "./node_modules/react-bootstrap/esm/InputGroupContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/NavbarContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/ThemeProvider.js":
false,

/***/ "./node_modules/react-bootstrap/esm/createWithBsPrefix.js":
false,

/***/ "./node_modules/react-bootstrap/esm/types.js":
false,

/***/ "./node_modules/react-bootstrap/esm/useWrappedRefWithWarning.js":
false,

/***/ "./node_modules/react/cjs/react-jsx-runtime.development.js":
false,

/***/ "./node_modules/react/jsx-runtime.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/hook.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/index.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/uncontrollable.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/utils.js":
false,

/***/ "./pages/index.jsx":
/*!*************************!*\
  !*** ./pages/index.jsx ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_partials_homepage_home_default_SiteFeatures__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/SiteFeatures */ "./components/partials/homepage/home-default/SiteFeatures.jsx");
/* harmony import */ var _components_partials_shop_ShopItems1__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/components/partials/shop/ShopItems1 */ "./components/partials/shop/ShopItems1.jsx");
/* harmony import */ var _components_partials_commons_DownLoadApp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/partials/commons/DownLoadApp */ "./components/partials/commons/DownLoadApp.jsx");
/* harmony import */ var _components_layouts_ContainerHomeDefault__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/layouts/ContainerHomeDefault */ "./components/layouts/ContainerHomeDefault.jsx");
/* harmony import */ var _components_partials_homepage_home_default_FeatureAndRecent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/FeatureAndRecent */ "./components/partials/homepage/home-default/FeatureAndRecent.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Advert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Advert */ "./components/partials/homepage/home-default/Advert.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Discount__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Discount */ "./components/partials/homepage/home-default/Discount.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_partials_homepage_home_default_Brand__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Brand */ "./components/partials/homepage/home-default/Brand.jsx");
/* harmony import */ var _components_partials_homepage_home_default_BottomCategory__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/BottomCategory */ "./components/partials/homepage/home-default/BottomCategory.jsx");
/* harmony import */ var _components_partials_homepage_home_default_HomeDefaultBanner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/HomeDefaultBanner */ "./components/partials/homepage/home-default/HomeDefaultBanner.jsx");
/* harmony import */ var _components_partials_homepage_category_homecategories__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~/components/partials/homepage/category/homecategories */ "./components/partials/homepage/category/homecategories.jsx");
/* harmony import */ var _components_partials_homepage_new_deals_daily_newdealsdaily__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/components/partials/homepage/new-deals-daily/newdealsdaily */ "./components/partials/homepage/new-deals-daily/newdealsdaily.jsx");
/* harmony import */ var _components_partials_homepage_new_deals_daily_newdealsdaily1__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~/components/partials/homepage/new-deals-daily/newdealsdaily1 */ "./components/partials/homepage/new-deals-daily/newdealsdaily1.jsx");
/* harmony import */ var _components_partials_homepage_shockingsale_shockingsale__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~/components/partials/homepage/shockingsale/shockingsale */ "./components/partials/homepage/shockingsale/shockingsale.jsx");
/* harmony import */ var _components_partials_homepage_featureproducts_featureproducts__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~/components/partials/homepage/featureproducts/featureproducts */ "./components/partials/homepage/featureproducts/featureproducts.jsx");
/* harmony import */ var _components_partials_homepage_auction_auction__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~/components/partials/homepage/auction/auction */ "./components/partials/homepage/auction/auction.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Bestseller__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Bestseller */ "./components/partials/homepage/home-default/Bestseller.jsx");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var _components_shared_footers_modules_FooterLinks__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ~/components/shared/footers/modules/FooterLinks */ "./components/shared/footers/modules/FooterLinks.jsx");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _utilities_home_helper__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ~/utilities/home-helper */ "./utilities/home-helper.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _store_home_action__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ~/store/home/action */ "./store/home/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");


var _jsxFileName = "E:\\bigBasket\\pages\\index.jsx",
    _s = $RefreshSig$();





























const HomepageDefaultPage = () => {
  _s();

  var _homeitems$category, _homeitems$shocking_s, _homeitems$new_arriva;

  const {
    0: homeitems,
    1: setHomeitems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: getFeatureProduct,
    1: setFeatureProduct
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: getNewArrData,
    1: setNewArrData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: getOfferData,
    1: setOfferData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_24__["useRouter"])();
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_26__["useDispatch"])();

  async function loadHomedata() {
    let responseData = await Object(_utilities_home_helper__WEBPACK_IMPORTED_MODULE_23__["getHomedata"])(router.asPath);

    if (responseData) {
      dispatch(Object(_store_home_action__WEBPACK_IMPORTED_MODULE_25__["getHomeSuccess"])(responseData.data));
      setHomeitems(responseData.data);
    }

    setTimeout(() => {
      setLoading(false);
    }, 250);
  } //  dev-bigbasket.estrradoweb.com/api/customer/product-featured


  const featuredProduct = () => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]
    });
    const data = axios__WEBPACK_IMPORTED_MODULE_22___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]}/api/customer/product-featured`, {
      lang_id: 1,
      category_id: "",
      subcategory_id: "",
      brand_id: "",
      featured: 1,
      limit: 10,
      offset: 0,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      page_url: "products/us/img",
      os_type: "WEB",
      access_token: user_token,
      max_price: "",
      min_price: "" // access_token: user_token,
      // lang_id: 1,
      // device_id: getDeviceId,
      // page_url: "http://localhost:3000/product/2",
      // os_type: "WEB",

    }).then(response => response.data).then(data => {
      console.log("...featured.....", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setFeatureProduct(data.data); // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {
      notification["error"]({
        message: error
      });
    });
  };

  const newArrailval = () => {
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]
    });
    const data = axios__WEBPACK_IMPORTED_MODULE_22___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]}/api/customer/products-latest`, {
      category_id: "",
      page_url: "https://products/us/img",
      low_to_high: "0",
      limit: 10,
      subcategory_id: "0",
      brand_id: "0",
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      latest: "0",
      os_type: "web",
      access_token: "",
      high_to_low: "0",
      lang_id: 1,
      popular: "0",
      offset: 0 // access_token: user_token,
      // lang_id: 1,
      // device_id: getDeviceId,
      // page_url: "http://localhost:3000/product/2",
      // os_type: "WEB",

    }).then(response => response.data).then(data => {
      console.log("...newArrailval.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setNewArrData(data.data); // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {// notification["error"]({
      //   message: error,
      // });
    });
  };

  const offer = () => {
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]
    });
    const data = axios__WEBPACK_IMPORTED_MODULE_22___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_20__["apibaseurl"]}/api/customer/offer/list`).then(response => response.data).then(data => {
      console.log("...offerrrrrrrrrrrr.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setOfferData(data.data); // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {
      notification["error"]({
        message: error
      });
    });
  };

  const {
    homedata
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_26__["useSelector"])(state => state.home);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("...homedata....", homedata);

    if (homedata == null) {
      loadHomedata();
    } else {
      setHomeitems(homedata);
      setTimeout(() => {
        setLoading(false);
      }, 250);
    }

    offer();
    featuredProduct();
    newArrailval();
  }, [homedata]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_27__["Spin"], {
    spinning: loading,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layouts_ContainerHomeDefault__WEBPACK_IMPORTED_MODULE_5__["default"], {
      title: "Big Basket",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_HomeDefaultBanner__WEBPACK_IMPORTED_MODULE_12__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 209,
        columnNumber: 9
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$category = homeitems.category) === null || _homeitems$category === void 0 ? void 0 : _homeitems$category.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_new_deals_daily_newdealsdaily1__WEBPACK_IMPORTED_MODULE_15__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 213,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_shop_ShopItems1__WEBPACK_IMPORTED_MODULE_3__["default"], {
        homeitems: homeitems
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 219,
        columnNumber: 9
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$shocking_s = homeitems.shocking_sale) === null || _homeitems$shocking_s === void 0 ? void 0 : _homeitems$shocking_s.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_shockingsale_shockingsale__WEBPACK_IMPORTED_MODULE_16__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 222,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_Advert__WEBPACK_IMPORTED_MODULE_7__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 231,
        columnNumber: 12
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$new_arriva = homeitems.new_arrivals) === null || _homeitems$new_arriva === void 0 ? void 0 : _homeitems$new_arriva.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_new_deals_daily_newdealsdaily__WEBPACK_IMPORTED_MODULE_14__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: getNewArrData,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 234,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_FeatureAndRecent__WEBPACK_IMPORTED_MODULE_6__["default"], {
        homeitems: homeitems,
        getFeatureProduct: getFeatureProduct,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 248,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_Discount__WEBPACK_IMPORTED_MODULE_8__["default"], {
        getOfferData: getOfferData,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 249,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_BottomCategory__WEBPACK_IMPORTED_MODULE_11__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_Brand__WEBPACK_IMPORTED_MODULE_10__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 251,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "top-stories",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-container",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_footers_modules_FooterLinks__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 260,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 259,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 258,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 208,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 207,
    columnNumber: 5
  }, undefined);
};

_s(HomepageDefaultPage, "/yATddzSUi0tD5BRCgO4PRexhe8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_24__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_26__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_26__["useSelector"]];
});

_c = HomepageDefaultPage;
/* harmony default export */ __webpack_exports__["default"] = (HomepageDefaultPage);

var _c;

$RefreshReg$(_c, "HomepageDefaultPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvQm90dG9tQ2F0ZWdvcnkuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2hvbWUtZGVmYXVsdC9GZWF0dXJlQW5kUmVjZW50LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9uZXctZGVhbHMtZGFpbHkvbmV3ZGVhbHNkYWlseS5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2Uvc2hvY2tpbmdzYWxlL3Nob2NraW5nc2FsZS5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvSGVhZGVyRGVmYXVsdC5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9NaW5pQ2FydC5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2luZGV4LmpzeCJdLCJuYW1lcyI6WyJCb3R0b21DYXRlZ29yeSIsImhvbWVpdGVtcyIsImxvYWRpbmciLCJ1c2VFZmZlY3QiLCJtYWluQ2Fyb3VzZWxWaWV3IiwiY2F0ZWdvcnkiLCJsZW5ndGgiLCJpbWFnZSIsImNhdGVnb3J5X25hbWUiLCJtZWRpYSIsIkZlYXR1cmVBbmRSZWNlbnQiLCJnZXRGZWF0dXJlUHJvZHVjdCIsImNvbnNvbGUiLCJsb2ciLCJwcm9kdWN0cyIsImZlYXR1cmVkX3Byb2R1Y3RzIiwic2xpY2UiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJkaXNwbGF5IiwicHJvZHVjdF9pZCIsInRodW1ibmFpbCIsInByb2R1Y3RfbmFtZSIsImFjdHVhbF9wcmljZSIsIm1haW5DYXJvdXNlbFZpZXcxIiwiY2VudGVyX29mZmVyX2Jhbm5lciIsIk5ld2RlYWxzZGFpbHkiLCJjaGVja2RlYWxzb2JqZWN0IiwicHJvZHVjdEl0ZW1zVmlldyIsInNsaWRlSXRlbXMiLCJjYXJvdXNlbFN0YW5kYXJkMSIsInNrZWxldG9ucyIsImdlbmVyYXRlVGVtcEFycmF5IiwiU2hvY2tpbmdzYWxlIiwiY29sbGVjdGlvblNsdWciLCJjaGVja1NhbGVzb2JqZWN0IiwiY2Fyb3VzZWxTdGFuZGFyZCIsImRvdHMiLCJhcnJvd3MiLCJpbmZpbml0ZSIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJuZXh0QXJyb3ciLCJwcmV2QXJyb3ciLCJyZXNwb25zaXZlIiwiYnJlYWtwb2ludCIsInNldHRpbmdzIiwiaW5pdGlhbFNsaWRlIiwic2hvY2tpbmdfc2FsZSIsInNob2NraW5nc2FsZV9wcm9kdWN0cyIsIm1hcmdpbkxlZnQiLCJIZWFkZXJEZWZhdWx0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInN0aWNreUhlYWRlciIsImFhYSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImxvY2FsU3RvcmFnZSIsInNldEl0ZW0iLCJsb2NhdGlvbiIsInJlbG9hZCIsIk1pbmlDYXJ0IiwiUmVhY3QiLCJtZW1vIiwiY2FydCIsImNhcnRJdGVtc1ZpZXciLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwiYXV0aCIsInVzZVNlbGVjdG9yIiwic3RhdGUiLCJwcm9kdWN0SXRlbVdpdGhTZWxsZXIiLCJwcm9kdWN0IiwicHJvZHVjdEl0ZW0iLCJzZWxsZXIiLCJjYXJ0UHJvZHVjdCIsImNhcnRfaWQiLCJzZWxsZXJfaWQiLCJjYXJ0ZGF0YSIsInNldENhcnRkYXRhIiwidXNlU3RhdGUiLCJ0b3RhbEl0ZW1zIiwic2V0VG90YWxJdGVtcyIsImlzTW91bnRlZCIsImNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlciIsInJlZHVjZSIsInByb2R1Y3RJdGVtUHJldiIsInByb2R1Y3RJdGVtTmV4dCIsIk51bWJlciIsImdldENhcnRJdGVtIiwicGF5bG9hZCIsInVzZXJkYXRhIiwiZ2V0SXRlbSIsInBhcnNlZGF0YSIsIkpTT04iLCJwYXJzZSIsImFjY2Vzc190b2tlbiIsInVzZXJfdG9rZW4iLCJhcGliYXNldXJsIiwiZ2V0RGV2aWNlSWQiLCJkYXRhIiwiQXhpb3MiLCJwb3N0IiwibGFuZ19pZCIsImRldmljZV9pZCIsInBhZ2VfdXJsIiwib3NfdHlwZSIsInRoZW4iLCJyZXNwb25zZSIsImh0dHBjb2RlIiwic3RhdHVzIiwiY2FydF9jb3VudCIsImNhdGNoIiwiZXJyb3IiLCJ1bmRlZmluZWQiLCJnZXRDYXJ0IiwiY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IiwiZ3JhbmRfdG90YWwiLCJjb25uZWN0IiwiSG9tZXBhZ2VEZWZhdWx0UGFnZSIsInNldEhvbWVpdGVtcyIsInNldEZlYXR1cmVQcm9kdWN0IiwiZ2V0TmV3QXJyRGF0YSIsInNldE5ld0FyckRhdGEiLCJnZXRPZmZlckRhdGEiLCJzZXRPZmZlckRhdGEiLCJzZXRMb2FkaW5nIiwicm91dGVyIiwidXNlUm91dGVyIiwibG9hZEhvbWVkYXRhIiwicmVzcG9uc2VEYXRhIiwiZ2V0SG9tZWRhdGEiLCJhc1BhdGgiLCJnZXRIb21lU3VjY2VzcyIsInNldFRpbWVvdXQiLCJmZWF0dXJlZFByb2R1Y3QiLCJjYXRlZ29yeV9pZCIsInN1YmNhdGVnb3J5X2lkIiwiYnJhbmRfaWQiLCJmZWF0dXJlZCIsImxpbWl0Iiwib2Zmc2V0IiwibWF4X3ByaWNlIiwibWluX3ByaWNlIiwibm90aWZpY2F0aW9uIiwibWVzc2FnZSIsIm5ld0FycmFpbHZhbCIsImxvd190b19oaWdoIiwibGF0ZXN0IiwiaGlnaF90b19sb3ciLCJwb3B1bGFyIiwib2ZmZXIiLCJob21lZGF0YSIsImhvbWUiLCJuZXdfYXJyaXZhbHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBLE1BQU1BLGNBQWMsR0FBRyxDQUFDO0FBQUVDLFdBQUY7QUFBYUM7QUFBYixDQUFELEtBQTRCO0FBQUE7O0FBQUE7O0FBRWpEQyx5REFBUyxDQUFDLE1BQU0sQ0FHZixDQUhRLEVBR04sRUFITSxDQUFUO0FBS0EsTUFBSUMsZ0JBQUo7O0FBQ0EsTUFBSSxDQUFDRixPQUFELElBQVksQ0FBQUQsU0FBUyxTQUFULElBQUFBLFNBQVMsV0FBVCxtQ0FBQUEsU0FBUyxDQUFFSSxRQUFYLDRFQUFxQkMsTUFBckIsSUFBOEIsQ0FBOUMsRUFBaUQ7QUFFL0NGLG9CQUFnQixnQkFDWjtBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsNkJBQ0k7QUFBSyxpQkFBUyxFQUFDLEtBQWY7QUFBQSwrQkFDSTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxrQ0FFSTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG9DQUNJO0FBQUcsa0JBQUksRUFBQyxzQkFBUjtBQUErQix1QkFBUyxFQUFDLGNBQXpDO0FBQUEscUNBQ0k7QUFBSyxtQkFBRyxFQUFFSCxTQUFTLENBQUNJLFFBQVYsQ0FBbUIsQ0FBbkIsRUFBc0JFLEtBQWhDO0FBQXVDLG1CQUFHLEVBQUMsY0FBM0M7QUFBMEQseUJBQVMsRUFBQztBQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUlJO0FBQUssdUJBQVMsRUFBQyxnQkFBZjtBQUFBLHNDQUNJO0FBQUEsMEJBQU9OLFNBQVMsQ0FBQ0ksUUFBVixDQUFtQixDQUFuQixFQUFzQkc7QUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQUVLO0FBQUEsMEJBQUtQLFNBQVMsQ0FBQ0ksUUFBVixDQUFtQixDQUFuQixFQUFzQkk7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGTCxlQUdJO0FBQUcsb0JBQUksRUFBQyxzQkFBUjtBQUErQix5QkFBUyxFQUFDLFlBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkosZUFhSTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLG9DQUNJO0FBQUcsa0JBQUksRUFBQyxzQkFBUjtBQUErQix1QkFBUyxFQUFDLGNBQXpDO0FBQUEscUNBQ0E7QUFBSyxtQkFBRyxFQUFFUixTQUFTLENBQUNJLFFBQVYsQ0FBbUIsQ0FBbkIsRUFBc0JFLEtBQWhDO0FBQXVDLG1CQUFHLEVBQUMsY0FBM0M7QUFBMEQseUJBQVMsRUFBQztBQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUlJO0FBQUssdUJBQVMsRUFBQyxnQkFBZjtBQUFBLHNDQUNJO0FBQUEsMEJBQU9OLFNBQVMsQ0FBQ0ksUUFBVixDQUFtQixDQUFuQixFQUFzQkc7QUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQUVLO0FBQUEsMEJBQUtQLFNBQVMsQ0FBQ0ksUUFBVixDQUFtQixDQUFuQixFQUFzQkk7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGTCxlQUdJO0FBQUcsb0JBQUksRUFBQyxzQkFBUjtBQUErQix5QkFBUyxFQUFDLFlBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYkosZUF3Qkk7QUFBSyxxQkFBUyxFQUFDLGNBQWY7QUFBQSxvQ0FDSTtBQUFHLGtCQUFJLEVBQUMsc0JBQVI7QUFBK0IsdUJBQVMsRUFBQyxjQUF6QztBQUFBLHFDQUNBO0FBQUssbUJBQUcsRUFBRVIsU0FBUyxDQUFDSSxRQUFWLENBQW1CLENBQW5CLEVBQXNCRSxLQUFoQztBQUF1QyxtQkFBRyxFQUFDLGNBQTNDO0FBQTBELHlCQUFTLEVBQUM7QUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFJSTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQSxzQ0FDSTtBQUFBLDBCQUFPTixTQUFTLENBQUNJLFFBQVYsQ0FBbUIsQ0FBbkIsRUFBc0JHO0FBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSztBQUFBLDBCQUFLUCxTQUFTLENBQUNJLFFBQVYsQ0FBbUIsQ0FBbkIsRUFBc0JJO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRkwsZUFHSTtBQUFHLG9CQUFJLEVBQUMsc0JBQVI7QUFBK0IseUJBQVMsRUFBQyxZQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESjtBQTJDRDs7QUFDRCxzQkFFQTtBQUFBLDJCQUlBO0FBQUssZUFBUyxFQUFDLG1CQUFmO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBQSxrQkFDSUw7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpBLG1CQUZBO0FBb0JELENBMUVEOztHQUFNSixjOztLQUFBQSxjO0FBNEVTQSw2RUFBZjtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlFQTtBQUNBOztBQUNBLE1BQU1VLGdCQUFnQixHQUFHLENBQUM7QUFBRVQsV0FBRjtBQUFhVSxtQkFBYjtBQUFnQ1Q7QUFBaEMsQ0FBRCxLQUErQztBQUFBOztBQUFBOztBQUV0RUMseURBQVMsQ0FBQyxNQUFNO0FBRWZTLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJGLGlCQUF6QjtBQUNBLEdBSFEsRUFHTixFQUhNLENBQVQ7QUFLQSxNQUFJUCxnQkFBSjs7QUFDQSxNQUFJLENBQUNGLE9BQUQsSUFBWSxDQUFBUyxpQkFBaUIsU0FBakIsSUFBQUEsaUJBQWlCLFdBQWpCLHFDQUFBQSxpQkFBaUIsQ0FBRUcsUUFBbkIsZ0ZBQTZCUixNQUE3QixJQUFzQyxDQUF0RCxFQUF5RDtBQUN2RDtBQUNBO0FBQ0E7QUFDQUYsb0JBQWdCLEdBQ1pILFNBQVMsQ0FBQ2MsaUJBQVYsQ0FBNEJDLEtBQTVCLENBQWtDLENBQWxDLEVBQXFDLENBQXJDLEVBQXdDQyxHQUF4QyxDQUE0QyxDQUFDQyxJQUFELEVBQU9DLEtBQVAsa0JBQzVDO0FBQUssZUFBUyxFQUFDLG9CQUFmO0FBQUEsNkJBQ0E7QUFBSyxpQkFBUyxFQUFDLDRCQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsT0FBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyxtQkFBZjtBQUFrQyxtQkFBSyxFQUFFO0FBQUNDLHVCQUFPLEVBQUdGLElBQUksQ0FBQ1gsS0FBTCxDQUFXRCxNQUFYLEdBQW9CLENBQXBCLEdBQXdCLE9BQXhCLEdBQWdDO0FBQTNDLGVBQXpDO0FBQUEscUNBRUEscUVBQUMsZ0RBQUQ7QUFBTSxvQkFBSSxFQUFDLGdCQUFYO0FBQTRCLGtCQUFFLEVBQUcsWUFBV1ksSUFBSSxDQUFDRyxVQUFXLEVBQTVEO0FBQUEsdUNBQ0k7QUFBRyxzQkFBSSxFQUFDLHFCQUFSO0FBQUEseUNBQ0s7QUFBSyw2QkFBUyxFQUFDLFdBQWY7QUFBMkIsdUJBQUcsRUFBRUgsSUFBSSxDQUFDWCxLQUFMLENBQVdELE1BQVgsR0FBb0IsQ0FBcEIsR0FBd0JZLElBQUksQ0FBQ1gsS0FBTCxDQUFXLENBQVgsRUFBY2UsU0FBdEMsR0FBaUQsRUFBakY7QUFBcUYsdUJBQUcsRUFBQztBQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBU0k7QUFBSyx1QkFBUyxFQUFDLFlBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsY0FBZjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxPQUFkO0FBQUEseUNBQXNCO0FBQUcsd0JBQUksRUFBQyx5QkFBUjtBQUFBLDhCQUFtQ0osSUFBSSxDQUFDSztBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFFSTtBQUFLLDJCQUFTLEVBQUMsbURBQWY7QUFBQSx5Q0FDSTtBQUFJLDZCQUFTLEVBQUMsZUFBZDtBQUFBLHVDQUFtQ0wsSUFBSSxDQUFDTSxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURBLENBREo7QUE0QkQ7O0FBR0QsTUFBSUMsaUJBQUo7O0FBQ0EsTUFBSSxDQUFDdkIsT0FBRCxJQUFZLENBQUFELFNBQVMsU0FBVCxJQUFBQSxTQUFTLFdBQVQscUNBQUFBLFNBQVMsQ0FBRXlCLG1CQUFYLGdGQUFnQ3BCLE1BQWhDLElBQXlDLENBQXpELEVBQTREO0FBQzFEO0FBQ0E7QUFDQTtBQUNBbUIscUJBQWlCLGdCQUNiO0FBQUssZUFBUyxFQUFDLHdDQUFmO0FBQXdELFdBQUssRUFBRTtBQUFDTCxlQUFPLEVBQUduQixTQUFTLENBQUN5QixtQkFBVixDQUE4QnBCLE1BQTlCLEdBQXVDLENBQXZDLEdBQTJDLE9BQTNDLEdBQW1EO0FBQTlELE9BQS9EO0FBQUEsNkJBQ0E7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBQSwrQkFDSTtBQUFHLGNBQUksRUFBQyx5QkFBUjtBQUNJLG1CQUFTLEVBQUMsNERBRGQ7QUFBQSxpQ0FFSztBQUFLLGVBQUcsRUFBRUwsU0FBUyxDQUFDeUIsbUJBQVYsQ0FBOEJwQixNQUE5QixHQUF1QyxDQUF2QyxHQUEyQ0wsU0FBUyxDQUFDeUIsbUJBQVYsQ0FBOEIsQ0FBOUIsRUFBaUNqQixLQUE1RSxHQUFtRixFQUE3RjtBQUFpRyxlQUFHLEVBQUM7QUFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESjtBQVdEOztBQUNELHNCQUVBO0FBQUEsMkJBRUU7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDQTtBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsa0NBQ0k7QUFBSyxxQkFBUyxFQUFDLHVCQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLHFCQUFmO0FBQUEscUNBQ0k7QUFBSSx5QkFBUyxFQUFDLGlDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUlJO0FBQUssdUJBQVMsRUFBQyxlQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSwwQkFDQ0w7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosRUFjS3FCLGlCQWRMLGVBZUk7QUFBSyxxQkFBUyxFQUFDLHVCQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLHFCQUFmO0FBQUEscUNBQ0k7QUFBSSx5QkFBUyxFQUFDLGlDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUlJO0FBQUssdUJBQVMsRUFBQywwQkFBZjtBQUFBLHFDQUNJO0FBQUsseUJBQVMsRUFBQyxhQUFmO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEseUNBQ0k7QUFBSyw2QkFBUyxFQUFDLDRCQUFmO0FBQUEsMkNBQ0k7QUFBSywrQkFBUyxFQUFDLGVBQWY7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsT0FBZjtBQUFBLGdEQUNJO0FBQUssbUNBQVMsRUFBQyxtQkFBZjtBQUFBLGlEQUNJO0FBQUcsZ0NBQUksRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBTUk7QUFBSyxtQ0FBUyxFQUFDLFlBQWY7QUFBQSxpREFDSTtBQUFLLHFDQUFTLEVBQUMsY0FBZjtBQUFBLG9EQUNJO0FBQUksdUNBQVMsRUFBQyxPQUFkO0FBQUEscURBQXNCO0FBQUcsb0NBQUksRUFBQyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQURKLGVBR0k7QUFBSyx1Q0FBUyxFQUFDLG1EQUFmO0FBQUEscURBQ0k7QUFBSSx5Q0FBUyxFQUFDLGVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBd0JJO0FBQUssMkJBQVMsRUFBQyxvQkFBZjtBQUFBLHlDQUNJO0FBQUssNkJBQVMsRUFBQyw0QkFBZjtBQUFBLDJDQUNJO0FBQUssK0JBQVMsRUFBQyxlQUFmO0FBQUEsNkNBQ0k7QUFBSyxpQ0FBUyxFQUFDLE9BQWY7QUFBQSxnREFDSTtBQUFLLG1DQUFTLEVBQUMsbUJBQWY7QUFBQSxpREFDSTtBQUFHLGdDQUFJLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FESixlQU1JO0FBQUssbUNBQVMsRUFBQyxZQUFmO0FBQUEsaURBQ0k7QUFBSyxxQ0FBUyxFQUFDLGNBQWY7QUFBQSxvREFDSTtBQUFJLHVDQUFTLEVBQUMsT0FBZDtBQUFBLHFEQUFzQjtBQUFHLG9DQUFJLEVBQUMseUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FESixlQUdJO0FBQUssdUNBQVMsRUFBQyxtREFBZjtBQUFBLHFEQUNJO0FBQUkseUNBQVMsRUFBQyxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF4QkosZUErQ0k7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEseUNBQ0k7QUFBSyw2QkFBUyxFQUFDLDRCQUFmO0FBQUEsMkNBQ0k7QUFBSywrQkFBUyxFQUFDLGVBQWY7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsT0FBZjtBQUFBLGdEQUNJO0FBQUssbUNBQVMsRUFBQyxtQkFBZjtBQUFBLGlEQUNJO0FBQUcsZ0NBQUksRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBTUk7QUFBSyxtQ0FBUyxFQUFDLFlBQWY7QUFBQSxpREFDSTtBQUFLLHFDQUFTLEVBQUMsY0FBZjtBQUFBLG9EQUNJO0FBQUksdUNBQVMsRUFBQyxPQUFkO0FBQUEscURBQXNCO0FBQUcsb0NBQUksRUFBQyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQURKLGVBR0k7QUFBSyx1Q0FBUyxFQUFDLG1EQUFmO0FBQUEscURBQ0k7QUFBSSx5Q0FBUyxFQUFDLGVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQS9DSixlQXNFSTtBQUFLLDJCQUFTLEVBQUMsY0FBZjtBQUFBLHlDQUNJO0FBQUssNkJBQVMsRUFBQyw0QkFBZjtBQUFBLDJDQUNJO0FBQUssK0JBQVMsRUFBQyxlQUFmO0FBQUEsNkNBQ0k7QUFBSyxpQ0FBUyxFQUFDLE9BQWY7QUFBQSxnREFDSTtBQUFLLG1DQUFTLEVBQUMsbUJBQWY7QUFBQSxpREFDSTtBQUFHLGdDQUFJLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FESixlQVFJO0FBQUssbUNBQVMsRUFBQyxZQUFmO0FBQUEsaURBQ0k7QUFBSyxxQ0FBUyxFQUFDLGNBQWY7QUFBQSxvREFDSTtBQUFJLHVDQUFTLEVBQUMsT0FBZDtBQUFBLHFEQUFzQjtBQUFHLG9DQUFJLEVBQUMseUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FESixlQUdJO0FBQUssdUNBQVMsRUFBQyxtREFBZjtBQUFBLHFEQUNJO0FBQUkseUNBQVMsRUFBQyxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRixtQkFGQTtBQXVJRCxDQW5NRDs7R0FBTWYsZ0I7O0tBQUFBLGdCO0FBcU1TQSwrRUFBZjtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeE1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNaUIsYUFBYSxHQUFHLENBQUM7QUFBRTFCLFdBQUY7QUFBYUM7QUFBYixDQUFELEtBQTRCO0FBQ2hEO0FBQ0FVLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaLEVBQThCWixTQUE5Qjs7QUFDQSxRQUFNMkIsZ0JBQWdCLEdBQUkzQixTQUFELElBQWU7QUFDdEMsUUFBSSxjQUFjQSxTQUFsQixFQUE2QjtBQUMzQixhQUFPLElBQVA7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPLEtBQVA7QUFDRDtBQUNGLEdBTkQ7O0FBT0EsTUFBSTRCLGdCQUFKOztBQUNBLE1BQUksQ0FBQzNCLE9BQUwsRUFBYztBQUFBOztBQUNaLFFBQUkwQixnQkFBZ0IsSUFBSTNCLFNBQXBCLElBQWlDLENBQUFBLFNBQVMsU0FBVCxJQUFBQSxTQUFTLFdBQVQsbUNBQUFBLFNBQVMsQ0FBRWEsUUFBWCw0RUFBcUJSLE1BQXJCLElBQThCLENBQW5FLEVBQXNFO0FBQUE7O0FBRXBFLFlBQU13QixVQUFVLEdBQ2QsQ0FBQTdCLFNBQVMsU0FBVCxJQUFBQSxTQUFTLFdBQVQsb0NBQUFBLFNBQVMsQ0FBRWEsUUFBWCw4RUFBcUJSLE1BQXJCLElBQThCLENBQTlCLEdBQ0lMLFNBREosYUFDSUEsU0FESiwrQ0FDSUEsU0FBUyxDQUFFYSxRQURmLHlEQUNJLHFCQUFxQkcsR0FBckIsQ0FBMEJDLElBQUQsaUJBQ3ZCLHFFQUFDLDRGQUFEO0FBQXdCLGVBQU8sRUFBRUE7QUFBakMsU0FBNENBLElBQUksQ0FBQ0csVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixDQURKLEdBSUlwQixTQUpKLGFBSUlBLFNBSkosK0NBSUlBLFNBQVMsQ0FBRWEsUUFKZix5REFJSSxxQkFBcUJHLEdBQXJCLENBQTBCQyxJQUFELGlCQUN2QixxRUFBQyxzRkFBRDtBQUFrQixlQUFPLEVBQUVBO0FBQTNCLFNBQXNDQSxJQUFJLENBQUNHLFVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsQ0FMTjtBQVNBUSxzQkFBZ0IsR0FDZCxDQUFBNUIsU0FBUyxTQUFULElBQUFBLFNBQVMsV0FBVCxvQ0FBQUEsU0FBUyxDQUFFYSxRQUFYLDhFQUFxQlIsTUFBckIsSUFBOEIsQ0FBOUIsZ0JBQ0UscUVBQUMsa0RBQUQsa0NBQVl5Qiw2RUFBWjtBQUErQixpQkFBUyxFQUFDLHFCQUF6QztBQUFBLGtCQUNHRDtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZ0JBS0U7QUFBSyxpQkFBUyxFQUFDLDhCQUFmO0FBQUEsa0JBQStDQTtBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5KO0FBUUQsS0FuQkQsTUFtQk87QUFDTEQsc0JBQWdCLGdCQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFuQjtBQUNEO0FBQ0YsR0F2QkQsTUF1Qk87QUFDTCxVQUFNRyxTQUFTLEdBQUdDLG1GQUFpQixDQUFDLENBQUQsQ0FBakIsQ0FBcUJoQixHQUFyQixDQUEwQkMsSUFBRCxpQkFDekM7QUFBSyxlQUFTLEVBQUMsNEJBQWY7QUFBQSw2QkFDRSxxRUFBQyxzRkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsT0FBaURBLElBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRGdCLENBQWxCO0FBS0FXLG9CQUFnQixnQkFBRztBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsZ0JBQXNCRztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFuQjtBQUNEOztBQUVELHNCQUNFO0FBQUssYUFBUyxFQUFDLDRCQUFmO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsY0FBZjtBQUFBLDhCQUNBO0FBQUssaUJBQVMsRUFBQywyQ0FBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQywwQkFBZjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxnQkFBZjtBQUFBLG9DQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUU7QUFBRyx1QkFBUyxFQUFDLGlCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURBLGVBU0U7QUFBSyxpQkFBUyxFQUFDLGlDQUFmO0FBQUEsK0JBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxjQUFJLEVBQUMsV0FBWDtBQUFBLGlDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEYsZUFjRTtBQUFLLGlCQUFTLEVBQUMscUJBQWY7QUFBQSxrQkFBc0NIO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBb0JELENBL0REOztLQUFNRixhO0FBaUVTQSw0RUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNTyxZQUFZLEdBQUcsQ0FBQztBQUFFQyxnQkFBRjtBQUFrQmxDLFdBQWxCO0FBQTZCQztBQUE3QixDQUFELEtBQTRDO0FBQy9EO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBLFFBQU1rQyxnQkFBZ0IsR0FBSW5DLFNBQUQsSUFBZTtBQUN0QyxRQUFJLG1CQUFtQkEsU0FBdkIsRUFBa0M7QUFDaEMsYUFBTyxJQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxLQUFQO0FBQ0Q7QUFDRixHQU5EOztBQVFBLFFBQU1vQyxnQkFBZ0IsR0FBRztBQUN2QkMsUUFBSSxFQUFFLEtBRGlCO0FBRXZCQyxVQUFNLEVBQUUsSUFGZTtBQUd2QkMsWUFBUSxFQUFFLElBSGE7QUFJdkJDLFNBQUssRUFBRSxHQUpnQjtBQUt2QkMsZ0JBQVksRUFBRSxDQUxTO0FBTXZCQyxrQkFBYyxFQUFFLENBTk87QUFPdkJDLGFBQVMsZUFBRSxxRUFBQywrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBZO0FBUXZCQyxhQUFTLGVBQUUscUVBQUMsZ0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFSWTtBQVN2QkMsY0FBVSxFQUFFLENBQ1Y7QUFDRUMsZ0JBQVUsRUFBRSxJQURkO0FBRUVDLGNBQVEsRUFBRTtBQUNSTixvQkFBWSxFQUFFLENBRE47QUFFUkMsc0JBQWMsRUFBRSxDQUZSO0FBR1JILGdCQUFRLEVBQUUsSUFIRjtBQUlSRixZQUFJLEVBQUU7QUFKRTtBQUZaLEtBRFUsRUFVVjtBQUNFUyxnQkFBVSxFQUFFLEdBRGQ7QUFFRUMsY0FBUSxFQUFFO0FBQ1JOLG9CQUFZLEVBQUUsQ0FETjtBQUVSQyxzQkFBYyxFQUFFLENBRlI7QUFHUk0sb0JBQVksRUFBRTtBQUhOO0FBRlosS0FWVSxFQWtCVjtBQUNFRixnQkFBVSxFQUFFLEdBRGQ7QUFFRUMsY0FBUSxFQUFFO0FBQ1JOLG9CQUFZLEVBQUUsQ0FETjtBQUVSQyxzQkFBYyxFQUFFO0FBRlI7QUFGWixLQWxCVTtBQVRXLEdBQXpCLENBN0IrRCxDQWtFL0Q7O0FBQ0EsTUFBSWQsZ0JBQUo7O0FBRUEsTUFBSSxDQUFDM0IsT0FBTCxFQUFjO0FBQ1osUUFDRWtDLGdCQUFnQixDQUFDbkMsU0FBRCxDQUFoQixJQUNBQSxTQURBLElBRUFBLFNBQVMsQ0FBQ2lELGFBQVYsQ0FBd0I1QyxNQUF4QixHQUFpQyxDQUhuQyxFQUlFO0FBQ0EsWUFBTTZDLHFCQUFxQixHQUFHbEQsU0FBUyxDQUFDaUQsYUFBeEMsQ0FEQSxDQUdBO0FBQ0E7QUFDQTs7QUFDQSxZQUFNcEIsVUFBVSxHQUNkcUIscUJBQXFCLENBQUM3QyxNQUF0QixHQUErQixDQUEvQixHQUNJNkMscUJBQXFCLENBQUNsQyxHQUF0QixDQUEwQixDQUFDQyxJQUFELEVBQU9DLEtBQVAsS0FBaUI7QUFDekMsNEJBQU8scUVBQUMsK0ZBQUQ7QUFBMEIsaUJBQU8sRUFBRUQ7QUFBbkMsV0FBOENDLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVA7QUFDRCxPQUZELENBREosR0FJSWdDLHFCQUFxQixDQUFDbEMsR0FBdEIsQ0FBMEIsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ3pDLDRCQUFPLHFFQUFDLHlGQUFEO0FBQXFCLGlCQUFPLEVBQUVEO0FBQTlCLFdBQXlDQyxLQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFQO0FBQ0QsT0FGRCxDQUxOO0FBUUFVLHNCQUFnQixnQkFDZDtBQUFBLGtCQUNHc0IscUJBQXFCLENBQUM3QyxNQUF0QixHQUErQixDQUEvQixnQkFDQyxxRUFBQyxrREFBRCxrQ0FBWStCLGdCQUFaO0FBQThCLG1CQUFTLEVBQUMscUJBQXhDO0FBQUEsb0JBQ0dQO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERCxnQkFLQztBQUFLLG1CQUFTLEVBQUMsOEJBQWY7QUFBQSxvQkFBK0NBO0FBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOSix1QkFERjtBQVdELEtBN0JELE1BNkJPO0FBQ0xELHNCQUFnQixnQkFBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbkI7QUFDRDtBQUNGLEdBakNELE1BaUNPO0FBQ0wsVUFBTUcsU0FBUyxHQUFHQyxtRkFBaUIsQ0FBQyxDQUFELENBQWpCLENBQXFCaEIsR0FBckIsQ0FBMEJDLElBQUQsaUJBQ3pDO0FBQUssZUFBUyxFQUFDLGtDQUFmO0FBQUEsNkJBQ0UscUVBQUMsc0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLE9BQXVEQSxJQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURnQixDQUFsQjtBQUtBVyxvQkFBZ0IsZ0JBQUc7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFBLGdCQUFzQkc7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbkI7QUFDRDs7QUFFRCxzQkFDRTtBQUNFLGFBQVMsRUFBQyw2QkFEWixDQUVFO0FBQ0E7QUFDQTtBQUNBO0FBTEY7QUFBQSwyQkFPRTtBQUFLLGVBQVMsRUFBQyxjQUFmO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFDLGtEQUFmO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLDBCQUFmO0FBQUEsaUNBQ0E7QUFBSyxpQkFBSyxFQUFDLGdCQUFYO0FBQUEsb0NBQ0U7QUFBSSx1QkFBUyxFQUFDLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFHLHVCQUFTLEVBQUMsaUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQW1CRSxxRUFBQyxnREFBRDtBQUFNLGNBQUksRUFBQyxlQUFYO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUF3QkU7QUFDRSxpQkFBUyxFQUNQL0IsU0FBUyxDQUFDaUQsYUFBVixDQUF3QjVDLE1BQXhCLEdBQWlDLENBQWpDLEdBQ0ksRUFESixHQUVLLDhCQUpUO0FBTUUsYUFBSyxFQUFFO0FBQ0w4QyxvQkFBVSxFQUFFbkQsU0FBUyxDQUFDaUQsYUFBVixDQUF3QjVDLE1BQXhCLEdBQWlDLENBQWpDLEdBQXFDLEVBQXJDLEdBQTBDO0FBRGpELFNBTlQ7QUFBQSxrQkFVR3VCO0FBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBK0NELENBOUpEOztLQUFNSyxZO0FBZ0tTQSwyRUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUVBLE1BQU1tQixhQUFhLEdBQUcsTUFBTTtBQUFBOztBQUMxQmxELHlEQUFTLENBQUMsTUFBTTtBQUNkLGNBQXFCO0FBQ25CbUQsWUFBTSxDQUFDQyxnQkFBUCxDQUF3QixRQUF4QixFQUFrQ0Msc0VBQWxDO0FBQ0Q7QUFDRixHQUpRLEVBSU4sRUFKTSxDQUFUOztBQUtBLFFBQU1DLEdBQUcsR0FBSUMsQ0FBRCxJQUFPO0FBRXBCO0FBQ0Q5QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCNkMsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQTlCO0FBQ0FDLGdCQUFZLENBQUNDLE9BQWIsQ0FBcUIsUUFBckIsRUFBOEJKLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUF2QztBQUNBTixVQUFNLENBQUNTLFFBQVAsQ0FBZ0JDLE1BQWhCO0FBQ0MsR0FOQzs7QUFPQSxzQkFDRTtBQUFRLGFBQVMsRUFBQyxrQkFBbEI7QUFBcUMsbUJBQVksTUFBakQ7QUFBd0QsTUFBRSxFQUFDLGNBQTNEO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsVUFBZjtBQUFBLDZCQUNFO0FBQUssYUFBSyxFQUFDLGNBQVg7QUFBQSwrQkFDRTtBQUFLLGVBQUssRUFBQyw0QkFBWDtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxhQUFmO0FBQUEsbUNBQ0U7QUFBSSx1QkFBUyxFQUFDLFNBQWQ7QUFBQSxzQ0FDQTtBQUFBLHVDQUNJO0FBQVEsMEJBQVEsRUFBR04sQ0FBRCxJQUFPRCxHQUFHLENBQUNDLENBQUQsQ0FBNUI7QUFBaUMscUJBQUcsRUFBQyxNQUFyQztBQUE0QyxvQkFBRSxFQUFDLE1BQS9DO0FBQUEsMENBQ0E7QUFBVSx5QkFBSyxFQUFDLEdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURBLGVBRWQ7QUFBVSx5QkFBSyxFQUFDLEdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZjLGVBR2Q7QUFBUSx5QkFBSyxFQUFDLEdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSGM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFEQSxlQVFFO0FBQUkseUJBQVMsRUFBQyxRQUFkO0FBQUEsdUNBYUcscUVBQUMsZ0RBQUQ7QUFBTSxzQkFBSSxFQUFDLGdCQUFYO0FBQUEseUNBQ1A7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFETztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBd0NFO0FBQUssZUFBUyxFQUFDLGFBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQUEsaUNBQ0UscUVBQUMsd0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFLRTtBQUFLLG1CQUFTLEVBQUMsZUFBZjtBQUFBLGlDQUNFLHFFQUFDLHVGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUxGLGVBUUU7QUFBSyxtQkFBUyxFQUFDLHNEQUFmO0FBQUEsaUNBQ0U7QUFBRyxnQkFBSSxFQUFDLEVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJGLGVBV0U7QUFBSyxtQkFBUyxFQUFDLGdCQUFmO0FBQUEsaUNBQ0UscUVBQUMsdUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWEYsZUFjRTtBQUFLLG1CQUFTLEVBQUMsZUFBZjtBQUFBLGlDQUNFLHFFQUFDLHdGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0VELENBN0VEOztHQUFNTCxhOztLQUFBQSxhO0FBK0VTQSw0RUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1ZLFFBQVEsZ0JBQUdDLDRDQUFLLENBQUNDLElBQU4sU0FBVyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFjO0FBQUE7O0FBQUE7O0FBQ3hDLE1BQUlDLGFBQUo7QUFDQSxRQUFNQyxRQUFRLEdBQUdDLCtEQUFXLEVBQTVCO0FBQ0EsUUFBTUMsSUFBSSxHQUFHQywrREFBVyxDQUFFQyxLQUFELElBQVdBLEtBQUssQ0FBQ0YsSUFBbEIsQ0FBeEI7QUFFQSxRQUFNRyxxQkFBcUIsR0FBR1AsSUFBSCxhQUFHQSxJQUFILHdDQUFHQSxJQUFJLENBQUVRLE9BQVQsa0RBQUcsY0FBZTNELEdBQWYsQ0FBb0I0RCxXQUFEO0FBQUE7O0FBQUEsd0JBQy9DO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDLFVBQWI7QUFBQSxrQkFBeUJBLFdBQXpCLGFBQXlCQSxXQUF6QiwrQ0FBeUJBLFdBQVcsQ0FBRUMsTUFBdEMseURBQXlCLHFCQUFxQkE7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQUVHRCxXQUZILGFBRUdBLFdBRkgsK0NBRUdBLFdBQVcsQ0FBRUMsTUFGaEIsa0ZBRUcscUJBQXFCaEUsUUFGeEIsMERBRUcsc0JBQStCRyxHQUEvQixDQUFvQzhELFdBQUQsaUJBQ2xDLHFFQUFDLG1GQUFEO0FBQWUsZUFBTyxFQUFFQTtBQUF4QixTQUEwQ0EsV0FBMUMsYUFBMENBLFdBQTFDLHVCQUEwQ0EsV0FBVyxDQUFFQyxPQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURELENBRkg7QUFBQSxPQUFVSCxXQUFWLGFBQVVBLFdBQVYsOENBQVVBLFdBQVcsQ0FBRUMsTUFBdkIsd0RBQVUsb0JBQXFCRyxTQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUQrQztBQUFBLEdBQW5CLENBQTlCO0FBUUEsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCQyxzREFBUSxDQUFDLElBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEJGLHNEQUFRLENBQUMsQ0FBRCxDQUE1QztBQUVBakYseURBQVMsQ0FBQyxNQUFNO0FBQ2RTLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaLEVBQStDdUQsSUFBL0MsRUFEYyxDQUVmOztBQUNDLFFBQUltQixTQUFTLEdBQUcsSUFBaEI7O0FBRUEsUUFBSUEsU0FBSixFQUFlO0FBQUE7O0FBQ2I7QUFDQSxZQUFNQyw4QkFBOEIsR0FBR3BCLElBQUgsYUFBR0EsSUFBSCx5Q0FBR0EsSUFBSSxDQUFFUSxPQUFULG1EQUFHLGVBQWVhLE1BQWYsQ0FDckMsQ0FBQ0MsZUFBRCxFQUFrQkMsZUFBbEIsS0FBc0M7QUFDcEMsZUFDRUMsTUFBTSxDQUFDRixlQUFELENBQU4sR0FFQ0UsTUFBTSxDQUFDRCxlQUFlLENBQUNiLE1BQWhCLENBQXVCaEUsUUFBdkIsQ0FBZ0NSLE1BQWpDLENBSFQ7QUFLRCxPQVBvQyxFQVFyQyxDQVJxQyxDQUF2QztBQVdBZ0YsbUJBQWEsQ0FBQ0UsOEJBQUQsQ0FBYjtBQUNBTCxpQkFBVyxDQUFDZixJQUFELENBQVg7QUFDRDs7QUFDRCxXQUFPLE1BQU07QUFDWG1CLGVBQVMsR0FBRyxLQUFaO0FBQ0QsS0FGRDtBQUdELEdBeEJRLEVBd0JOLENBQUNuQixJQUFELGFBQUNBLElBQUQsdUJBQUNBLElBQUksQ0FBRVEsT0FBUCxDQXhCTSxDQUFULENBaEJ3QyxDQTBDeEM7O0FBRUUsUUFBTWlCLFdBQVcsR0FBSUMsT0FBRCxJQUFhO0FBQ2pDLFFBQUlDLFFBQVEsR0FBR2xDLFlBQVksQ0FBQ21DLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdILFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRyxZQUE5QjtBQUNBLFVBQU1DLFVBQVUsR0FBR0QsWUFBbkI7QUFDQXhGLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFaLEVBQXFEO0FBQUN5RixzRkFBVUE7QUFBWCxLQUFyRDtBQUNBMUYsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0N3RixVQUF0QztBQUNBekYsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0MwRixxRUFBdEM7QUFFQSxVQUFNQyxJQUFJLEdBQUdDLDRDQUFLLENBQUNDLElBQU4sQ0FDVixHQUFFSixvRUFBVyxvQkFESCxFQUVYO0FBQ0VGLGtCQUFZLEVBQUVDLFVBRGhCO0FBRUVNLGFBQU8sRUFBQzlDLFlBQVksQ0FBQ21DLE9BQWIsQ0FBcUIsUUFBckIsQ0FGVjtBQUdFWSxlQUFTLEVBQUVMLHFFQUhiO0FBSUVNLGNBQVEsRUFBRSxpQ0FKWjtBQUtFQyxhQUFPLEVBQUU7QUFMWCxLQUZXLEVBU1ZDLElBVFUsQ0FTSkMsUUFBRCxJQUFjQSxRQUFRLENBQUNSLElBVGxCLEVBVVZPLElBVlUsQ0FVSlAsSUFBRCxJQUFVO0FBQ2Q1RixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWixFQUFvRDJGLElBQXBELEVBRGMsQ0FFbEI7O0FBQ0ksVUFBSUEsSUFBSSxDQUFDUyxRQUFMLElBQWlCLEdBQWpCLElBQXdCVCxJQUFJLENBQUNVLE1BQUwsSUFBZSxPQUEzQyxFQUFvRCxDQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUNELFVBQUlWLElBQUksQ0FBQ1MsUUFBTCxJQUFpQixHQUFqQixJQUF3QlQsSUFBSSxDQUFDVSxNQUFMLElBQWUsU0FBM0MsRUFBc0Q7QUFDcEQvQixtQkFBVyxDQUFDcUIsSUFBSSxDQUFDQSxJQUFOLENBQVg7QUFDQWxCLHFCQUFhLENBQUNrQixJQUFJLENBQUNBLElBQUwsQ0FBVVcsVUFBWCxDQUFiLENBRm9ELENBR3ZEO0FBQ0M7QUFDRTtBQUNBO0FBQ0E7QUFDRDs7QUFDQztBQUNEO0FBQ0YsS0E5QlUsRUErQlZDLEtBL0JVLENBK0JIQyxLQUFELElBQVcsQ0FDaEI7QUFDQTtBQUNBO0FBQ0QsS0FuQ1UsQ0FBYjtBQXNDQ3pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDMEYscUVBQXRDLEVBL0NnQyxDQWdEbEM7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsR0F0RUM7O0FBdUVGcEcseURBQVMsQ0FBQyxNQUFNO0FBQ2RTLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBc0J1RCxJQUF0QjtBQUNBeUIsZUFBVzs7QUFDWCxRQUFJekIsSUFBSSxJQUFJa0QsU0FBWixFQUF1QjtBQUN0QjtBQUNDLE9BQUE5QyxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRTRCLFlBQU4sS0FBc0I5QixRQUFRLENBQUNpRCxrRUFBTyxFQUFSLENBQTlCO0FBQ0Q7QUFDRixHQVBRLEVBT04sQ0FBQy9DLElBQUksQ0FBQzRCLFlBQU4sRUFBb0JoQyxJQUFwQixhQUFvQkEsSUFBcEIsdUJBQW9CQSxJQUFJLENBQUVRLE9BQTFCLENBUE0sQ0FBVDs7QUFTQSxNQUNFTSxRQUFRLEtBQUssSUFBYixJQUNBQSxRQUFRLEtBQUtvQyxTQURiLElBRUFwQyxRQUZBLGFBRUFBLFFBRkEsb0NBRUFBLFFBQVEsQ0FBRU4sT0FGViw4Q0FFQSxrQkFBbUJ0RSxNQUZuQixJQUdBLENBQUE0RSxRQUFRLFNBQVIsSUFBQUEsUUFBUSxXQUFSLGtDQUFBQSxRQUFRLENBQUVOLE9BQVYsMEVBQW1CdEUsTUFBbkIsTUFBOEIsQ0FKaEMsRUFLRTtBQUFBOztBQUNBK0QsaUJBQWEsZ0JBQ1g7QUFBSyxlQUFTLEVBQUMsa0JBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSxrQkFBaUNNO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLGlCQUFTLEVBQUMsaUJBQWY7QUFBQSxnQ0FDRTtBQUFBLGdEQUVFO0FBQUEsc0JBQ0dPLFFBQVEsSUFBSUEsUUFBUSxLQUFLLElBQXpCLElBQWlDLENBQUFBLFFBQVEsU0FBUixJQUFBQSxRQUFRLFdBQVIsa0NBQUFBLFFBQVEsQ0FBRU4sT0FBViwwRUFBbUJ0RSxNQUFuQixJQUE0QixDQUE3RCxHQUNHa0gsZ0dBQThCLENBQUN0QyxRQUFRLENBQUN1QyxXQUFWLENBRGpDLEdBRUc7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVNFO0FBQUEsa0NBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxnQkFBSSxFQUFDLHdCQUFYO0FBQUEsbUNBQ0U7QUFBRyx1QkFBUyxFQUFDLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUUscUVBQUMsZ0RBQUQ7QUFBTSxnQkFBSSxFQUFDLG1CQUFYO0FBQUEsbUNBQ0U7QUFBRyx1QkFBUyxFQUFDLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBdUJELEdBN0JELE1BNkJPO0FBQ0xwRCxpQkFBYSxnQkFDWDtBQUFLLGVBQVMsRUFBQyxrQkFBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLCtCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFPRDs7QUFFRCxzQkFDRTtBQUFLLGFBQVMsRUFBQyxlQUFmO0FBQUEsNEJBQ0U7QUFBRyxlQUFTLEVBQUMsZUFBYjtBQUE2QixVQUFJLEVBQUMsR0FBbEM7QUFBQSw4QkFDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQSwrQkFDRTtBQUFBLG9CQUNHYSxRQUFRLEtBQUssSUFBYixJQUFxQkEsUUFBUSxLQUFLb0MsU0FBbEMsSUFBK0NqQyxVQUFVLEdBQUcsQ0FBNUQsR0FDR0EsVUFESCxHQUVHO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLEVBV0doQixhQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FsTGdCO0FBQUEsVUFFRUUsdURBRkYsRUFHRkUsdURBSEU7QUFBQSxHQUFqQjtNQUFNUixRO0FBb0xTeUQsMEhBQU8sQ0FBRWhELEtBQUQsSUFBV0EsS0FBSyxDQUFDTixJQUFsQixDQUFQLENBQStCSCxRQUEvQixDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUxBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNMEQsbUJBQW1CLEdBQUcsTUFBTTtBQUFBOztBQUFBOztBQUNoQyxRQUFNO0FBQUEsT0FBQzFILFNBQUQ7QUFBQSxPQUFZMkg7QUFBWixNQUE0QnhDLHNEQUFRLENBQUMsRUFBRCxDQUExQztBQUNBLFFBQU07QUFBQSxPQUFDekUsaUJBQUQ7QUFBQSxPQUFvQmtIO0FBQXBCLE1BQXlDekMsc0RBQVEsQ0FBQyxFQUFELENBQXZEO0FBQ0EsUUFBTTtBQUFBLE9BQUMwQyxhQUFEO0FBQUEsT0FBZ0JDO0FBQWhCLE1BQWlDM0Msc0RBQVEsQ0FBQyxFQUFELENBQS9DO0FBQ0EsUUFBTTtBQUFBLE9BQUM0QyxZQUFEO0FBQUEsT0FBZUM7QUFBZixNQUErQjdDLHNEQUFRLENBQUMsRUFBRCxDQUE3QztBQUNBLFFBQU07QUFBQSxPQUFDbEYsT0FBRDtBQUFBLE9BQVVnSTtBQUFWLE1BQXdCOUMsc0RBQVEsQ0FBQyxJQUFELENBQXRDO0FBQ0EsUUFBTStDLE1BQU0sR0FBR0MsOERBQVMsRUFBeEI7QUFDQSxRQUFNOUQsUUFBUSxHQUFHQyxnRUFBVyxFQUE1Qjs7QUFFQSxpQkFBZThELFlBQWYsR0FBOEI7QUFDNUIsUUFBSUMsWUFBWSxHQUFHLE1BQU1DLDJFQUFXLENBQUNKLE1BQU0sQ0FBQ0ssTUFBUixDQUFwQzs7QUFDQSxRQUFJRixZQUFKLEVBQWtCO0FBQ2hCaEUsY0FBUSxDQUFDbUUsMEVBQWMsQ0FBQ0gsWUFBWSxDQUFDOUIsSUFBZCxDQUFmLENBQVI7QUFDQW9CLGtCQUFZLENBQUNVLFlBQVksQ0FBQzlCLElBQWQsQ0FBWjtBQUNEOztBQUNEa0MsY0FBVSxDQUFDLE1BQU07QUFDZlIsZ0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRCxLQUZTLEVBRVAsR0FGTyxDQUFWO0FBR0QsR0FsQitCLENBbUJsQzs7O0FBRUEsUUFBTVMsZUFBZSxHQUFHLE1BQU07QUFDNUIsUUFBSTVDLFFBQVEsR0FBR2xDLFlBQVksQ0FBQ21DLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdILFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRyxZQUE5QjtBQUNBLFVBQU1DLFVBQVUsR0FBR0QsWUFBbkI7QUFDQXhGLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFaLEVBQXFEO0FBQUN5RixzRkFBVUE7QUFBWCxLQUFyRDtBQUNBLFVBQU1FLElBQUksR0FBR0MsNkNBQUssQ0FBQ0MsSUFBTixDQUNWLEdBQUVKLG9FQUFXLGdDQURILEVBRVg7QUFHSUssYUFBTyxFQUFDLENBSFo7QUFJSWlDLGlCQUFXLEVBQUMsRUFKaEI7QUFLSUMsb0JBQWMsRUFBQyxFQUxuQjtBQU1JQyxjQUFRLEVBQUUsRUFOZDtBQU9BQyxjQUFRLEVBQUMsQ0FQVDtBQVFJQyxXQUFLLEVBQUMsRUFSVjtBQVNJQyxZQUFNLEVBQUMsQ0FUWDtBQVVJckMsZUFBUyxFQUFDTCxxRUFWZDtBQVdJTSxjQUFRLEVBQUMsaUJBWGI7QUFZSUMsYUFBTyxFQUFDLEtBWlo7QUFhSVYsa0JBQVksRUFBQ0MsVUFiakI7QUFjSTZDLGVBQVMsRUFBQyxFQWRkO0FBZUlDLGVBQVMsRUFBQyxFQWZkLENBa0JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBdEJGLEtBRlcsRUEwQlZwQyxJQTFCVSxDQTBCSkMsUUFBRCxJQUFjQSxRQUFRLENBQUNSLElBMUJsQixFQTJCVk8sSUEzQlUsQ0EyQkpQLElBQUQsSUFBVTtBQUNkNUYsYUFBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFBK0IyRixJQUEvQixFQURjLENBRWxCOztBQUNJLFVBQUlBLElBQUksQ0FBQ1MsUUFBTCxJQUFpQixHQUFqQixJQUF3QlQsSUFBSSxDQUFDVSxNQUFMLElBQWUsT0FBM0MsRUFBb0QsQ0FDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFDRCxVQUFJVixJQUFJLENBQUNTLFFBQUwsSUFBaUIsR0FBakIsSUFBd0JULElBQUksQ0FBQ1UsTUFBTCxJQUFlLFNBQTNDLEVBQXNEO0FBQ3BEVyx5QkFBaUIsQ0FBQ3JCLElBQUksQ0FBQ0EsSUFBTixDQUFqQixDQURvRCxDQUVwRDtBQUNBO0FBQ0E7QUFDRDs7QUFDQztBQUNEO0FBQ0YsS0E1Q1UsRUE2Q1ZZLEtBN0NVLENBNkNIQyxLQUFELElBQVc7QUFDaEIrQixrQkFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsZUFBTyxFQUFFaEM7QUFEVyxPQUF0QjtBQUdELEtBakRVLENBQWI7QUFrREQsR0F4REQ7O0FBeURBLFFBQU1pQyxZQUFZLEdBQUcsTUFBTTtBQUN6QjFJLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFaLEVBQXFEO0FBQUN5RixzRkFBVUE7QUFBWCxLQUFyRDtBQUNBLFVBQU1FLElBQUksR0FBR0MsNkNBQUssQ0FBQ0MsSUFBTixDQUNWLEdBQUVKLG9FQUFXLCtCQURILEVBRVg7QUFHRXNDLGlCQUFXLEVBQUUsRUFIZjtBQUlFL0IsY0FBUSxFQUFFLHlCQUpaO0FBS0UwQyxpQkFBVyxFQUFFLEdBTGY7QUFNRVAsV0FBSyxFQUFFLEVBTlQ7QUFPRUgsb0JBQWMsRUFBRSxHQVBsQjtBQVFHQyxjQUFRLEVBQUUsR0FSYjtBQVNJbEMsZUFBUyxFQUFFTCxxRUFUZjtBQVVLaUQsWUFBTSxFQUFFLEdBVmI7QUFXSzFDLGFBQU8sRUFBRSxLQVhkO0FBWUtWLGtCQUFZLEVBQUUsRUFabkI7QUFhTXFELGlCQUFXLEVBQUUsR0FibkI7QUFjTTlDLGFBQU8sRUFBRSxDQWRmO0FBZU0rQyxhQUFPLEVBQUUsR0FmZjtBQWdCTVQsWUFBTSxFQUFFLENBaEJkLENBa0JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBdEJGLEtBRlcsRUEwQlZsQyxJQTFCVSxDQTBCSkMsUUFBRCxJQUFjQSxRQUFRLENBQUNSLElBMUJsQixFQTJCVk8sSUEzQlUsQ0EyQkpQLElBQUQsSUFBVTtBQUNkNUYsYUFBTyxDQUFDQyxHQUFSLENBQVksa0JBQVosRUFBK0IyRixJQUEvQixFQURjLENBRWxCOztBQUNJLFVBQUlBLElBQUksQ0FBQ1MsUUFBTCxJQUFpQixHQUFqQixJQUF3QlQsSUFBSSxDQUFDVSxNQUFMLElBQWUsT0FBM0MsRUFBb0QsQ0FDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFDRCxVQUFJVixJQUFJLENBQUNTLFFBQUwsSUFBaUIsR0FBakIsSUFBd0JULElBQUksQ0FBQ1UsTUFBTCxJQUFlLFNBQTNDLEVBQXNEO0FBQ3JEYSxxQkFBYSxDQUFDdkIsSUFBSSxDQUFDQSxJQUFOLENBQWIsQ0FEcUQsQ0FFcEQ7QUFDQTtBQUNBO0FBQ0Q7O0FBQ0M7QUFDRDtBQUNGLEtBNUNVLEVBNkNWWSxLQTdDVSxDQTZDSEMsS0FBRCxJQUFXLENBQ2hCO0FBQ0E7QUFDQTtBQUNELEtBakRVLENBQWI7QUFrREQsR0FwREQ7O0FBcURFLFFBQU1zQyxLQUFLLEdBQUcsTUFBTTtBQUNsQi9JLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFaLEVBQXFEO0FBQUN5RixzRkFBVUE7QUFBWCxLQUFyRDtBQUNBLFVBQU1FLElBQUksR0FBR0MsNkNBQUssQ0FBQ0MsSUFBTixDQUNWLEdBQUVKLG9FQUFXLDBCQURILEVBRVZTLElBRlUsQ0FFSkMsUUFBRCxJQUFjQSxRQUFRLENBQUNSLElBRmxCLEVBR1ZPLElBSFUsQ0FHSlAsSUFBRCxJQUFVO0FBQ2Q1RixhQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBWixFQUFtQzJGLElBQW5DLEVBRGMsQ0FFbEI7O0FBQ0ksVUFBSUEsSUFBSSxDQUFDUyxRQUFMLElBQWlCLEdBQWpCLElBQXdCVCxJQUFJLENBQUNVLE1BQUwsSUFBZSxPQUEzQyxFQUFvRCxDQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUNELFVBQUlWLElBQUksQ0FBQ1MsUUFBTCxJQUFpQixHQUFqQixJQUF3QlQsSUFBSSxDQUFDVSxNQUFMLElBQWUsU0FBM0MsRUFBc0Q7QUFDcERlLG9CQUFZLENBQUN6QixJQUFJLENBQUNBLElBQU4sQ0FBWixDQURvRCxDQUVwRDtBQUNBO0FBQ0E7QUFDRDs7QUFDQztBQUNEO0FBQ0YsS0FwQlUsRUFxQlZZLEtBckJVLENBcUJIQyxLQUFELElBQVc7QUFDaEIrQixrQkFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsZUFBTyxFQUFFaEM7QUFEVyxPQUF0QjtBQUdELEtBekJVLENBQWI7QUEwQkQsR0E1QkQ7O0FBNkJBLFFBQU07QUFBRXVDO0FBQUYsTUFBZW5GLGdFQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDbUYsSUFBbEIsQ0FBaEM7QUFDQTFKLHlEQUFTLENBQUMsTUFBTTtBQUNkUyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QitJLFFBQTlCOztBQUNBLFFBQUlBLFFBQVEsSUFBSSxJQUFoQixFQUFzQjtBQUNwQnZCLGtCQUFZO0FBQ2IsS0FGRCxNQUVPO0FBQ0xULGtCQUFZLENBQUNnQyxRQUFELENBQVo7QUFDQWxCLGdCQUFVLENBQUMsTUFBTTtBQUNmUixrQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNELE9BRlMsRUFFUCxHQUZPLENBQVY7QUFHRDs7QUFFTHlCLFNBQUs7QUFDTGhCLG1CQUFlO0FBQ2ZXLGdCQUFZO0FBQ1QsR0FkUSxFQWNOLENBQUNNLFFBQUQsQ0FkTSxDQUFUO0FBZ0JBLHNCQUNFLHFFQUFDLDBDQUFEO0FBQU0sWUFBUSxFQUFFMUosT0FBaEI7QUFBQSwyQkFDRSxxRUFBQyxnRkFBRDtBQUFzQixXQUFLLEVBQUMsWUFBNUI7QUFBQSw4QkFDRSxxRUFBQyxxR0FBRDtBQUFtQixpQkFBUyxFQUFFRCxTQUE5QjtBQUF5QyxlQUFPLEVBQUVDO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFJSSxDQUFDQSxPQUFELElBQVlELFNBQVosSUFBeUIsQ0FBQUEsU0FBUyxTQUFULElBQUFBLFNBQVMsV0FBVCxtQ0FBQUEsU0FBUyxDQUFFSSxRQUFYLDRFQUFxQkMsTUFBckIsSUFBOEIsQ0FBdkQsaUJBQ0EscUVBQUMscUdBQUQ7QUFDRSxzQkFBYyxFQUFDLGlCQURqQjtBQUVFLGlCQUFTLEVBQUVMLFNBRmI7QUFHRSxlQUFPLEVBQUVDO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMSixlQVdFLHFFQUFDLDRFQUFEO0FBQWEsaUJBQVMsRUFBRUQ7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRixFQWFHLENBQUNDLE9BQUQsSUFBWUQsU0FBWixJQUF5QixDQUFBQSxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUVpRCxhQUFYLGdGQUEwQjVDLE1BQTFCLElBQW1DLENBQTVELGlCQUNDLHFFQUFDLGdHQUFEO0FBQ0Usc0JBQWMsRUFBQyxpQkFEakI7QUFFRSxpQkFBUyxFQUFFTCxTQUZiO0FBR0UsZUFBTyxFQUFFQztBQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEosZUF1QksscUVBQUMseUZBQUQ7QUFBUyxpQkFBUyxFQUFFRCxTQUFwQjtBQUErQixlQUFPLEVBQUVDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkJMLEVBeUJNLENBQUNBLE9BQUQsSUFBWUQsU0FBWixJQUF5QixDQUFBQSxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUU2SixZQUFYLGdGQUF5QnhKLE1BQXpCLElBQWtDLENBQTNELGlCQUNGLHFFQUFDLG9HQUFEO0FBQ0Usc0JBQWMsRUFBQyxpQkFEakI7QUFFRSxpQkFBUyxFQUFFd0gsYUFGYjtBQUdFLGVBQU8sRUFBRTVIO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExQkosZUF3Q0UscUVBQUMsbUdBQUQ7QUFBa0IsaUJBQVMsRUFBRUQsU0FBN0I7QUFBd0MseUJBQWlCLEVBQUVVLGlCQUEzRDtBQUE4RSxlQUFPLEVBQUVUO0FBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeENGLGVBeUNFLHFFQUFDLDJGQUFEO0FBQVUsb0JBQVksRUFBRThILFlBQXhCO0FBQXNDLGVBQU8sRUFBRTlIO0FBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekNGLGVBMENFLHFFQUFDLGtHQUFEO0FBQWdCLGlCQUFTLEVBQUVELFNBQTNCO0FBQXNDLGVBQU8sRUFBRUM7QUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkExQ0YsZUEyQ0UscUVBQUMseUZBQUQ7QUFBTyxpQkFBUyxFQUFFRCxTQUFsQjtBQUE2QixlQUFPLEVBQUVDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0NGLGVBa0RFO0FBQUssaUJBQVMsRUFBQyxhQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLGNBQWY7QUFBQSxpQ0FDRSxxRUFBQyx1RkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTRERCxDQTdPRDs7R0FBTXlILG1CO1VBTVdTLHNELEVBQ0U3RCx3RCxFQXlKSUUsd0Q7OztLQWhLakJrRCxtQjtBQStPU0Esa0ZBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMjBjZGZhMTVmYWEyNTlhMThmM2UuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmNvbnN0IEJvdHRvbUNhdGVnb3J5ID0gKHsgaG9tZWl0ZW1zLCBsb2FkaW5nIH0pID0+IHtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuXHJcbiAgIFxyXG4gIH0sIFtdKTtcclxuXHJcbiAgbGV0IG1haW5DYXJvdXNlbFZpZXc7XHJcbiAgaWYgKCFsb2FkaW5nICYmIGhvbWVpdGVtcz8uY2F0ZWdvcnk/Lmxlbmd0aCA+IDApIHtcclxuXHJcbiAgICBtYWluQ2Fyb3VzZWxWaWV3ID0gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9yZ2FuaWMtZm9vZC1mcmVzaC1iYW5uZXJcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvZmZlci1iYW5uZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInByb2R1Y3Qtc3R5bGUtMi5odG1sXCIgY2xhc3NOYW1lPVwiYmFubmVyLWhvdmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17aG9tZWl0ZW1zLmNhdGVnb3J5WzBdLmltYWdlfSBhbHQ9XCJvZmZlci1iYW5uZXJcIiBjbGFzc05hbWU9XCJpbWctZmx1aWRcIi8+IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmFubmVyLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntob21laXRlbXMuY2F0ZWdvcnlbMF0uY2F0ZWdvcnlfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntob21laXRlbXMuY2F0ZWdvcnlbMF0ubWVkaWF9PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJwcm9kdWN0LXN0eWxlLTIuaHRtbFwiIGNsYXNzTmFtZT1cImJ0bi1zdHlsZTJcIj5TaG9wIG5vdzwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9mZmVyLWJhbm5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwicHJvZHVjdC1zdHlsZS0yLmh0bWxcIiBjbGFzc05hbWU9XCJiYW5uZXItaG92ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2hvbWVpdGVtcy5jYXRlZ29yeVswXS5pbWFnZX0gYWx0PVwib2ZmZXItYmFubmVyXCIgY2xhc3NOYW1lPVwiaW1nLWZsdWlkXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmFubmVyLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntob21laXRlbXMuY2F0ZWdvcnlbMF0uY2F0ZWdvcnlfbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyPntob21laXRlbXMuY2F0ZWdvcnlbMF0ubWVkaWF9PC9oMj4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwicHJvZHVjdC1zdHlsZS0yLmh0bWxcIiBjbGFzc05hbWU9XCJidG4tc3R5bGUyXCI+U2hvcCBub3c8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvZmZlci1iYW5uZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInByb2R1Y3Qtc3R5bGUtMi5odG1sXCIgY2xhc3NOYW1lPVwiYmFubmVyLWhvdmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtob21laXRlbXMuY2F0ZWdvcnlbMF0uaW1hZ2V9IGFsdD1cIm9mZmVyLWJhbm5lclwiIGNsYXNzTmFtZT1cImltZy1mbHVpZFwiLz4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYW5uZXItY29udGVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2hvbWVpdGVtcy5jYXRlZ29yeVswXS5jYXRlZ29yeV9uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDI+e2hvbWVpdGVtcy5jYXRlZ29yeVswXS5tZWRpYX08L2gyPiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJwcm9kdWN0LXN0eWxlLTIuaHRtbFwiIGNsYXNzTmFtZT1cImJ0bi1zdHlsZTJcIj5TaG9wIG5vdzwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgIClcclxuXHJcbiAgfVxyXG4gIHJldHVybiAoXHJcblxyXG4gIDw+XHJcblxyXG5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcy1ib3R0b21jYXRlZ29yeVwiPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jb250YWluZXJcIj5cclxuICAgICAgIHttYWluQ2Fyb3VzZWxWaWV3fVxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG5cclxuXHJcblxyXG4gIDwvPlxyXG4gICBcclxuICAgIFxyXG5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQm90dG9tQ2F0ZWdvcnk7XHJcbi8qY29ubmVjdChzdGF0ZSA9PiBzdGF0ZS5tZWRpYSkoKTsqL1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmNvbnN0IEZlYXR1cmVBbmRSZWNlbnQgPSAoeyBob21laXRlbXMsIGdldEZlYXR1cmVQcm9kdWN0LCBsb2FkaW5nIH0pID0+IHtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuXHJcbiAgIGNvbnNvbGUubG9nKFwiLi4uLi5mLi4uLlwiLGdldEZlYXR1cmVQcm9kdWN0KVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgbGV0IG1haW5DYXJvdXNlbFZpZXc7XHJcbiAgaWYgKCFsb2FkaW5nICYmIGdldEZlYXR1cmVQcm9kdWN0Py5wcm9kdWN0cz8ubGVuZ3RoID4gMCkge1xyXG4gICAgLy8gY29uc3QgY2Fyb3VzZUl0ZW1zID0gaG9tZWl0ZW1zLm1haW5fYmFubmVyLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgIC8vICAgPGRpdiBrZXk9e2luZGV4fT57bWFpbkJhbm5lck1lZGlhKGl0ZW0pfTwvZGl2PlxyXG4gICAgLy8gKSk7XHJcbiAgICBtYWluQ2Fyb3VzZWxWaWV3ID0gKFxyXG4gICAgICAgIGhvbWVpdGVtcy5mZWF0dXJlZF9wcm9kdWN0cy5zbGljZSgwLCAzKS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWxpc3QgbWItMzBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcHJvZHVjdC1jYXJkIGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC10aHVtYm5haWxcInN0eWxlPXt7ZGlzcGxheSA6IGl0ZW0uaW1hZ2UubGVuZ3RoID4gMCA/ICdibG9jayc6J25vbmUnfX0+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtpdGVtLnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJzaW5nbGUtcHJvZHVjdC5odG1sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9XCJmaXJzdC1pbWdcIiBzcmM9e2l0ZW0uaW1hZ2UubGVuZ3RoID4gMCA/IGl0ZW0uaW1hZ2VbMF0udGh1bWJuYWlsIDonJ30gYWx0PVwidGh1bWJuYWlsXCIvPiAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtZGVzY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRpdGxlXCI+PGEgaHJlZj1cInNob3AtZ3JpZC00LWNvbHVtbi5odG1sXCI+e2l0ZW0ucHJvZHVjdF9uYW1lfTwvYT48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj5TQVIge2l0ZW0uYWN0dWFsX3ByaWNlfTwvaDY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgICApKVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIFxyXG4gIGxldCBtYWluQ2Fyb3VzZWxWaWV3MTtcclxuICBpZiAoIWxvYWRpbmcgJiYgaG9tZWl0ZW1zPy5jZW50ZXJfb2ZmZXJfYmFubmVyPy5sZW5ndGggPiAwKSB7XHJcbiAgICAvLyBjb25zdCBjYXJvdXNlSXRlbXMgPSBob21laXRlbXMubWFpbl9iYW5uZXIubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgLy8gICA8ZGl2IGtleT17aW5kZXh9PnttYWluQmFubmVyTWVkaWEoaXRlbSl9PC9kaXY+XHJcbiAgICAvLyApKTtcclxuICAgIG1haW5DYXJvdXNlbFZpZXcxID0gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC04IG14LWF1dG8gY29sLWxnLTQgbWItNTBcIiBzdHlsZT17e2Rpc3BsYXkgOiBob21laXRlbXMuY2VudGVyX29mZmVyX2Jhbm5lci5sZW5ndGggPiAwID8gJ2Jsb2NrJzonbm9uZSd9fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhbm5lci10aHVtYlwiPlxyXG4gICAgICAgICAgICA8YSBocmVmPVwic2hvcC1ncmlkLTQtY29sdW1uLmh0bWxcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiem9vbS1pbiBkLWJsb2NrIG92ZXJmbG93LWhpZGRlbiBwb3NpdGlvbi1yZWxhdGl2ZSB6SW5kZXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtob21laXRlbXMuY2VudGVyX29mZmVyX2Jhbm5lci5sZW5ndGggPiAwID8gaG9tZWl0ZW1zLmNlbnRlcl9vZmZlcl9iYW5uZXJbMF0ubWVkaWEgOicnfSBhbHQ9XCJiYW5uZXItdGh1bWItbmFpbGVcIi8+IFxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIClcclxuICAgIFxyXG4gIH1cclxuICByZXR1cm4gKFxyXG5cclxuICA8PlxyXG5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyYW5kcmVjZW50XCI+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1sZy00IG1iLTUwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGUgbWItMzBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGl0bGUgdGV4dC1kYXJrIHRleHQtY2FwaXRhbGl6ZVwiPkZlYXR1cmVkIHByb2R1Y3RzIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZWQtaW5pdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2xpZGVyLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7bWFpbkNhcm91c2VsVmlld31cclxuICAgICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge21haW5DYXJvdXNlbFZpZXcxfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbGctNCBtYi01MFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlIG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRpdGxlIHRleHQtZGFyayB0ZXh0LWNhcGl0YWxpemVcIj5SZWNvbW1lbmRlZCBQcm9kdWN0czwvaDI+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZWQtaW5pdDIgc2xpY2stbmF2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbGlkZXItaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtbGlzdCBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHByb2R1Y3QtY2FyZCBib3JkZXItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtdGh1bWJuYWlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInNpbmdsZS1wcm9kdWN0Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgY2xhc3NOYW1lPVwiZmlyc3QtaW1nXCIgc3JjPVwiYXNzZXRzL2ltZy9jYXRlZ29yeS81LmpwZ1wiIGFsdD1cInRodW1ibmFpbFwiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0aXRsZVwiPjxhIGhyZWY9XCJzaG9wLWdyaWQtNC1jb2x1bW4uaHRtbFwiPkJyaXh0b24gUGF0cm9sIEFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRlcnJhaW4gQW5vcmFrIEphY2tldDwvYT48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJwcm9kdWN0LXByaWNlXCI+JDExLjkwPC9oNj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtbGlzdCBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHByb2R1Y3QtY2FyZCBib3JkZXItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtdGh1bWJuYWlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInNpbmdsZS1wcm9kdWN0Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgY2xhc3NOYW1lPVwiZmlyc3QtaW1nXCIgc3JjPVwiYXNzZXRzL2ltZy9jYXRlZ29yeS82LmpwZ1wiIGFsdD1cInRodW1ibmFpbFwiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0aXRsZVwiPjxhIGhyZWY9XCJzaG9wLWdyaWQtNC1jb2x1bW4uaHRtbFwiPkp1aWN5IENvdXR1cmUgU29saWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTbGVldmUgUHVmZmVyIEphY2tldDwvYT48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJwcm9kdWN0LXByaWNlXCI+JDExLjkwPC9oNj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtbGlzdCBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHByb2R1Y3QtY2FyZCBib3JkZXItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5IHAtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtdGh1bWJuYWlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInNpbmdsZS1wcm9kdWN0Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgY2xhc3NOYW1lPVwiZmlyc3QtaW1nXCIgc3JjPVwiYXNzZXRzL2ltZy9jYXRlZ29yeS83LmpwZ1wiIGFsdD1cInRodW1ibmFpbFwiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0aXRsZVwiPjxhIGhyZWY9XCJzaG9wLWdyaWQtNC1jb2x1bW4uaHRtbFwiPk5ldyBCYWxhbmNlIEZyZXNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRm9hbSBMQVpSIHYxIFNwb3J0PC9hPjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj4kMTEuOTA8L2g2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcHJvZHVjdC1jYXJkIGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC10aHVtYm5haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwic2luZ2xlLXByb2R1Y3QuaHRtbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyBjbGFzc05hbWU9XCJmaXJzdC1pbWdcIiBzcmM9XCJhc3NldHMvaW1nL2NhdGVnb3J5LzguanBnXCIgYWx0PVwidGh1bWJuYWlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwic2Vjb25kLWltZ1wiIHNyYz1cImFzc2V0cy9pbWcvY2F0ZWdvcnkvOC4xLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJ0aHVtYm5haWxcIj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtZGVzY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGl0bGVcIj48YSBocmVmPVwic2hvcC1ncmlkLTQtY29sdW1uLmh0bWxcIj5Db3V0dXJlIEp1aWN5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUXVpbHRlZCBUZXJyeSBUcmFjayBKYWNrZXQ8L2E+PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwicHJvZHVjdC1wcmljZVwiPiQxMS45MDwvaDY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgPC8+XHJcbiAgIFxyXG4gICAgXHJcbiAgIFxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGZWF0dXJlQW5kUmVjZW50O1xyXG4vKmNvbm5lY3Qoc3RhdGUgPT4gc3RhdGUubWVkaWEpKCk7Ki9cclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xyXG5pbXBvcnQgU2tlbGV0b25Qcm9kdWN0IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvc2tlbGV0b25zL1NrZWxldG9uUHJvZHVjdFwiO1xyXG5pbXBvcnQge1xyXG4gIGNhcm91c2VsRnVsbHdpZHRoLFxyXG4gIGNhcm91c2VsU3RhbmRhcmQxLFxyXG59IGZyb20gXCJ+L3V0aWxpdGllcy9jYXJvdXNlbC1oZWxwZXJzXCI7XHJcbmltcG9ydCBQcm9kdWN0RGVhbE9mRGF5IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvcHJvZHVjdHMvUHJvZHVjdERlYWxPZkRheVwiO1xyXG5pbXBvcnQgUHJvZHVjdERlYWxPZkRheVNsaWRlciBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL3Byb2R1Y3RzL1Byb2R1Y3REZWFsT2ZEYXlTbGlkZXJcIjtcclxuaW1wb3J0IHsgZ2VuZXJhdGVUZW1wQXJyYXkgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IHsgZ2V0UHJvZHVjdHNCeUNvbGxlY3Rpb25IZWxwZXIgfSBmcm9tIFwifi91dGlsaXRpZXMvc3RyYXBpLWZldGNoLWRhdGEtaGVscGVyc1wiO1xyXG5cclxuY29uc3QgTmV3ZGVhbHNkYWlseSA9ICh7IGhvbWVpdGVtcywgbG9hZGluZyB9KSA9PiB7XHJcbiAgLy8gVmlld3NcclxuICBjb25zb2xlLmxvZyhcIi4uLmtra2tra2trLi4uLlwiLGhvbWVpdGVtcylcclxuICBjb25zdCBjaGVja2RlYWxzb2JqZWN0ID0gKGhvbWVpdGVtcykgPT4ge1xyXG4gICAgaWYgKFwicHJvZHVjdHNcIiBpbiBob21laXRlbXMpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfTtcclxuICBsZXQgcHJvZHVjdEl0ZW1zVmlldztcclxuICBpZiAoIWxvYWRpbmcpIHtcclxuICAgIGlmIChjaGVja2RlYWxzb2JqZWN0ICYmIGhvbWVpdGVtcyAmJiBob21laXRlbXM/LnByb2R1Y3RzPy5sZW5ndGggPiAwKSB7XHJcbiBcclxuICAgICAgY29uc3Qgc2xpZGVJdGVtcyA9XHJcbiAgICAgICAgaG9tZWl0ZW1zPy5wcm9kdWN0cz8ubGVuZ3RoID4gNVxyXG4gICAgICAgICAgPyBob21laXRlbXM/LnByb2R1Y3RzPy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICA8UHJvZHVjdERlYWxPZkRheVNsaWRlciBwcm9kdWN0PXtpdGVtfSBrZXk9e2l0ZW0ucHJvZHVjdF9pZH0gLz5cclxuICAgICAgICAgICAgKSlcclxuICAgICAgICAgIDogaG9tZWl0ZW1zPy5wcm9kdWN0cz8ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgPFByb2R1Y3REZWFsT2ZEYXkgcHJvZHVjdD17aXRlbX0ga2V5PXtpdGVtLnByb2R1Y3RfaWR9IC8+XHJcbiAgICAgICAgICAgICkpO1xyXG5cclxuICAgICAgcHJvZHVjdEl0ZW1zVmlldyA9XHJcbiAgICAgICAgaG9tZWl0ZW1zPy5wcm9kdWN0cz8ubGVuZ3RoID4gNSA/IChcclxuICAgICAgICAgIDxTbGlkZXIgey4uLmNhcm91c2VsU3RhbmRhcmQxfSBjbGFzc05hbWU9XCJwcy1jYXJvdXNlbCBvdXRzaWRlXCI+XHJcbiAgICAgICAgICAgIHtzbGlkZUl0ZW1zfVxyXG4gICAgICAgICAgPC9TbGlkZXI+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxpZ24tY29udGVudC1sZy1zdHJldGNoIHJvd1wiPntzbGlkZUl0ZW1zfTwvZGl2PlxyXG4gICAgICAgICk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBwcm9kdWN0SXRlbXNWaWV3ID0gPHA+Tm8gcHJvZHVjdChzKSBmb3VuZC48L3A+O1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICBjb25zdCBza2VsZXRvbnMgPSBnZW5lcmF0ZVRlbXBBcnJheSg2KS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wteGwtMyBjb2wtbGctMyBjb2wtbWQtM1wiIGtleT17aXRlbX0+XHJcbiAgICAgICAgPFNrZWxldG9uUHJvZHVjdCAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICkpO1xyXG4gICAgcHJvZHVjdEl0ZW1zVmlldyA9IDxkaXYgY2xhc3NOYW1lPVwicm93XCI+e3NrZWxldG9uc308L2Rpdj47XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1kZWFsLW9mLWRheSBuZXdhcnJpdmFsc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXNlY3Rpb25fX2hlYWRlciBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWJsb2NrLS1jb3VudGRvd24tZGVhbFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWJsb2NrX19sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzPk5ldyBBcnJpdmFsczwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zXCI+TG9yZW0gSXBzdW0gaXMgc2ltcGx5IGR1bW15IHRleHQgb2YgdGhlIHByaW50aW5nIGFuZCB0eXBlc2V0dGluZyBpbmR1c3RyeS48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZCB2dWFsXCI+XHJcbiAgICAgICAgICA8TGluayBocmVmPVwiL25ld2RlYWxzXCI+XHJcbiAgICAgICAgICAgIDxhPlZpZXcgQWxsPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtc2VjdGlvbl9fY29udGVudFwiPntwcm9kdWN0SXRlbXNWaWV3fTwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOZXdkZWFsc2RhaWx5O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBiYWNrZ3JvdW5kIGZyb20gXCJ+L3B1YmxpYy9zdGF0aWMvaW1nL2N1c3RvbV9pbWFnZXMvc2hvY2tpbmdfc2FsZS5qcGdcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xyXG5pbXBvcnQgU2tlbGV0b25Qcm9kdWN0IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvc2tlbGV0b25zL1NrZWxldG9uUHJvZHVjdFwiO1xyXG5pbXBvcnQgUHJvZHVjdFNob2NraW5nU2FsZSBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL3Byb2R1Y3RzL1Byb2R1Y3RTaG9ja2luZ1NhbGVcIjtcclxuaW1wb3J0IHsgZ2VuZXJhdGVUZW1wQXJyYXkgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IE5leHRBcnJvdyBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL2Nhcm91c2VsL05leHRBcnJvd1wiO1xyXG5pbXBvcnQgUHJldkFycm93IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvY2Fyb3VzZWwvUHJldkFycm93XCI7XHJcbmltcG9ydCBQcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGUgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGVcIjtcclxuXHJcbmNvbnN0IFNob2NraW5nc2FsZSA9ICh7IGNvbGxlY3Rpb25TbHVnLCBob21laXRlbXMsIGxvYWRpbmcgfSkgPT4ge1xyXG4gIC8vIGNvbnN0IFtwcm9kdWN0SXRlbXMsIHNldFByb2R1Y3RJdGVtc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICAvLyBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgLy8gYXN5bmMgZnVuY3Rpb24gZ2V0UHJvZHVjdHMoKSB7XHJcbiAgLy8gICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gIC8vICAgY29uc3QgcmVzcG9uc2VEYXRhID0gYXdhaXQgZ2V0UHJvZHVjdHNCeUNvbGxlY3Rpb25IZWxwZXIoY29sbGVjdGlvblNsdWcpO1xyXG4gIC8vICAgaWYgKHJlc3BvbnNlRGF0YSkge1xyXG4gIC8vICAgICBzZXRQcm9kdWN0SXRlbXMocmVzcG9uc2VEYXRhLml0ZW1zKTtcclxuICAvLyAgICAgc2V0VGltZW91dChcclxuICAvLyAgICAgICBmdW5jdGlvbiAoKSB7XHJcbiAgLy8gICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAvLyAgICAgICB9LmJpbmQodGhpcyksXHJcbiAgLy8gICAgICAgMjUwXHJcbiAgLy8gICAgICk7XHJcbiAgLy8gICB9XHJcbiAgLy8gfVxyXG5cclxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIC8vICAgZ2V0UHJvZHVjdHMoKTtcclxuICAvLyB9LCBbXSk7XHJcbiAgY29uc3QgY2hlY2tTYWxlc29iamVjdCA9IChob21laXRlbXMpID0+IHtcclxuICAgIGlmIChcInNob2NraW5nX3NhbGVcIiBpbiBob21laXRlbXMpIHtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2Fyb3VzZWxTdGFuZGFyZCA9IHtcclxuICAgIGRvdHM6IGZhbHNlLFxyXG4gICAgYXJyb3dzOiB0cnVlLFxyXG4gICAgaW5maW5pdGU6IHRydWUsXHJcbiAgICBzcGVlZDogNzUwLFxyXG4gICAgc2xpZGVzVG9TaG93OiA0LFxyXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICBuZXh0QXJyb3c6IDxOZXh0QXJyb3cgLz4sXHJcbiAgICBwcmV2QXJyb3c6IDxQcmV2QXJyb3cgLz4sXHJcbiAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBicmVha3BvaW50OiAxMDI0LFxyXG4gICAgICAgIHNldHRpbmdzOiB7XHJcbiAgICAgICAgICBzbGlkZXNUb1Nob3c6IDMsXHJcbiAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMyxcclxuICAgICAgICAgIGluZmluaXRlOiB0cnVlLFxyXG4gICAgICAgICAgZG90czogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgYnJlYWtwb2ludDogNjAwLFxyXG4gICAgICAgIHNldHRpbmdzOiB7XHJcbiAgICAgICAgICBzbGlkZXNUb1Nob3c6IDIsXHJcbiAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgICAgICAgIGluaXRpYWxTbGlkZTogMSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgYnJlYWtwb2ludDogNDgwLFxyXG4gICAgICAgIHNldHRpbmdzOiB7XHJcbiAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXHJcbiAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9O1xyXG5cclxuICAvLyBWaWV3c1xyXG4gIGxldCBwcm9kdWN0SXRlbXNWaWV3O1xyXG5cclxuICBpZiAoIWxvYWRpbmcpIHtcclxuICAgIGlmIChcclxuICAgICAgY2hlY2tTYWxlc29iamVjdChob21laXRlbXMpICYmXHJcbiAgICAgIGhvbWVpdGVtcyAmJlxyXG4gICAgICBob21laXRlbXMuc2hvY2tpbmdfc2FsZS5sZW5ndGggPiAwXHJcbiAgICApIHtcclxuICAgICAgY29uc3Qgc2hvY2tpbmdzYWxlX3Byb2R1Y3RzID0gaG9tZWl0ZW1zLnNob2NraW5nX3NhbGU7XHJcblxyXG4gICAgICAvLyBjb25zdCBzbGlkZUl0ZW1zID0gc2hvY2tpbmdzYWxlX3Byb2R1Y3RzLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgLy8gICByZXR1cm4gPFByb2R1Y3RTaG9ja2luZ1NhbGUgcHJvZHVjdD17aXRlbX0ga2V5PXtpbmRleH0gLz47XHJcbiAgICAgIC8vIH0pO1xyXG4gICAgICBjb25zdCBzbGlkZUl0ZW1zID1cclxuICAgICAgICBzaG9ja2luZ3NhbGVfcHJvZHVjdHMubGVuZ3RoID4gNFxyXG4gICAgICAgICAgPyBzaG9ja2luZ3NhbGVfcHJvZHVjdHMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiA8UHJvZHVjdFNob2NraW5nU2FsZVNsaWRlIHByb2R1Y3Q9e2l0ZW19IGtleT17aW5kZXh9IC8+O1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgOiBzaG9ja2luZ3NhbGVfcHJvZHVjdHMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiA8UHJvZHVjdFNob2NraW5nU2FsZSBwcm9kdWN0PXtpdGVtfSBrZXk9e2luZGV4fSAvPjtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgIHByb2R1Y3RJdGVtc1ZpZXcgPSAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIHtzaG9ja2luZ3NhbGVfcHJvZHVjdHMubGVuZ3RoID4gNCA/IChcclxuICAgICAgICAgICAgPFNsaWRlciB7Li4uY2Fyb3VzZWxTdGFuZGFyZH0gY2xhc3NOYW1lPVwicHMtY2Fyb3VzZWwgb3V0c2lkZVwiPlxyXG4gICAgICAgICAgICAgIHtzbGlkZUl0ZW1zfVxyXG4gICAgICAgICAgICA8L1NsaWRlcj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxpZ24tY29udGVudC1sZy1zdHJldGNoIHJvd1wiPntzbGlkZUl0ZW1zfTwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8Lz5cclxuICAgICAgKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHByb2R1Y3RJdGVtc1ZpZXcgPSA8cD5ObyBwcm9kdWN0KHMpIGZvdW5kLjwvcD47XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnN0IHNrZWxldG9ucyA9IGdlbmVyYXRlVGVtcEFycmF5KDYpLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC14bC0yIGNvbC1sZy0zIGNvbC1zbS0zIGNvbC02XCIga2V5PXtpdGVtfT5cclxuICAgICAgICA8U2tlbGV0b25Qcm9kdWN0IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKSk7XHJcbiAgICBwcm9kdWN0SXRlbXNWaWV3ID0gPGRpdiBjbGFzc05hbWU9XCJyb3dcIj57c2tlbGV0b25zfTwvZGl2PjtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cInBzLWRlYWwtb2YtZGF5IHNob2NraW5nc2FsZVwiXHJcbiAgICAgIC8vIHN0eWxlPXt7XHJcbiAgICAgIC8vICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCR7YmFja2dyb3VuZH0pYCxcclxuICAgICAgLy8gICBiYWNrZ3JvdW5kUG9zaXRpb246IFwiYm90dG9tXCIsXHJcbiAgICAgIC8vIH19XHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1zZWN0aW9uX19oZWFkZXIganVzdGlmeS1jb250ZW50LWNlbnRlciBkLWZsZXhcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtYmxvY2stLWNvdW50ZG93bi1kZWFsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicHMtYmxvY2tfX2xlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+U2hvY2tpbmcgU2FsZTwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtM1wiPkxvcmVtIElwc3VtIGlzIHNpbXBseSBkdW1teSB0ZXh0IG9mIHRoZSBwcmludGluZyBhbmQgdHlwZXNldHRpbmcgaW5kdXN0cnkuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInBzLWJsb2NrX19yaWdodFwiPlxyXG4gICAgICAgICAgICAgIHtzaG9ja2luZ19lbmR0aW1lICE9PSBcIlwiICYmIChcclxuICAgICAgICAgICAgICAgIDxmaWd1cmU+XHJcbiAgICAgICAgICAgICAgICAgIDxmaWdjYXB0aW9uPkVuZCBpbjo8L2ZpZ2NhcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8Q291bnREb3duU2ltcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgdGltZVRpbGxEYXRlPXtzaG9ja2luZ19lbmR0aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIHRpbWVGb3JtYXQ9XCJZWVlZLU1NLURELCBISDptbTpzc1wiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2hvY2tpbmdzYWxlXCI+XHJcbiAgICAgICAgICAgIDxhPlZpZXcgQWxsPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgIGhvbWVpdGVtcy5zaG9ja2luZ19zYWxlLmxlbmd0aCA+IDRcclxuICAgICAgICAgICAgICA/IFwiXCJcclxuICAgICAgICAgICAgICA6IGByb3cgYWxpZ24tY29udGVudC1sZy1zdHJldGNoYFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgbWFyZ2luTGVmdDogaG9tZWl0ZW1zLnNob2NraW5nX3NhbGUubGVuZ3RoID4gNCA/IFwiXCIgOiBcIjJyZW1cIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3Byb2R1Y3RJdGVtc1ZpZXd9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNob2NraW5nc2FsZTtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IExvZ28gZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9jb21tb24vTG9nb1wiO1xyXG5pbXBvcnQgU2VhcmNoSGVhZGVyIGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9TZWFyY2hIZWFkZXJcIjtcclxuaW1wb3J0IE5hdmlnYXRpb25EZWZhdWx0IGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL25hdmlnYXRpb24vTmF2aWdhdGlvbkRlZmF1bHRcIjtcclxuaW1wb3J0IEhlYWRlckFjdGlvbnMgZnJvbSBcIn4vY29tcG9uZW50cy9zaGFyZWQvaGVhZGVycy9tb2R1bGVzL0hlYWRlckFjdGlvbnNcIjtcclxuaW1wb3J0IHsgc3RpY2t5SGVhZGVyIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcbmltcG9ydCBNZW51Q2F0ZWdvcmllc0Ryb3Bkb3duIGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL21lbnVzL01lbnVDYXRlZ29yaWVzRHJvcGRvd25cIjtcclxuLy8gaW1wb3J0IERyb3Bkb3duIGZyb20gJ3JlYWN0LWJvb3RzdHJhcC9Ecm9wZG93bic7XHJcblxyXG5jb25zdCBIZWFkZXJEZWZhdWx0ID0gKCkgPT4ge1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocHJvY2Vzcy5icm93c2VyKSB7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIHN0aWNreUhlYWRlcik7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIGNvbnN0IGFhYSA9IChlKSA9PiB7XHJcblxyXG4gLy8gYWxlcnQoXCJkXCIpXHJcbmNvbnNvbGUubG9nKFwiZ2hmaGZoXCIsZS50YXJnZXQudmFsdWUpXHJcbmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFuZ0lkXCIsZS50YXJnZXQudmFsdWUpO1xyXG53aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbn07XHJcbiAgcmV0dXJuIChcclxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaGVhZGVyIGhlYWRlci0tMVwiIGRhdGEtc3RpY2t5PVwidHJ1ZVwiIGlkPVwiaGVhZGVyU3RpY2t5XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZC10b3BcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZC1mbGV4IGp1c3RpZnktY29udGVudC1lbmRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3AtY29udGVudFwiPlxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0b3AtdXJsXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBvbkNoYW5nZT17KGUpID0+IGFhYShlKX0gbm1lPVwiY2Fyc1wiIGlkPVwiY2Fyc1wiID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiAgIHZhbHVlPVwiMVwiID5MYW5nPC9vcHRpb24+XHJcbiAgICA8b3B0aW9uICAgdmFsdWU9XCIxXCIgPkVuZ2xpc2g8L29wdGlvbj5cclxuICAgIDxvcHRpb24gdmFsdWU9XCIyXCIgPtin2YTYudix2KjZitipPC9vcHRpb24+XHJcbiAgPC9zZWxlY3Q+XHJcbiAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwidG9wLWxpXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8YT4gRW5nIDwvYT4gKi99XHJcbiAgICAgICAgICAgICAgICAgey8qIDxzcGFuIG9uQ2xpY2s9eyhlKSA9PiBhYWEoZSl9PmZmZmZmZjwvc3Bhbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8RHJvcGRvd24+XHJcbiAgICAgIDxEcm9wZG93bi5Ub2dnbGUgdmFyaWFudD1cInN1Y2Nlc3NcIiBpZD1cImRyb3Bkb3duLWJhc2ljXCIgPlxyXG4gICAgICBTZWxlY3QgTGFuZ3VhZ2VcclxuICAgICAgPC9Ecm9wZG93bi5Ub2dnbGU+XHJcblxyXG4gICAgICA8RHJvcGRvd24uTWVudT5cclxuICAgICAgICA8RHJvcGRvd24uSXRlbSBldmVudEtleT1cIjFcIiBvblNlbGVjdD17YWFhfT5FbmdsaXNoPC9Ecm9wZG93bi5JdGVtPlxyXG4gICAgICAgIDxEcm9wZG93bi5JdGVtIGV2ZW50S2V5PVwiMlwiIG9uU2VsZWN0PXthYWF9Ptin2YTYudix2KjZitipPC9Ecm9wZG93bi5JdGVtPlxyXG4gICAgICA8L0Ryb3Bkb3duLk1lbnU+XHJcbiAgICA8L0Ryb3Bkb3duPiAqL31cclxuICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWNjb3VudC9sb2dpblwiPlxyXG4gICAgICAgICAgICA8YT4gU2lnbiBJbjwvYT5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIHsvKiA8TGluayBocmVmPVwiL2FjY291bnQvbG9naW5cIj5cclxuICAgICAgICAgICAgPGE+UmVnaXN0ZXI8L2E+XHJcbiAgICAgICAgICA8L0xpbms+ICovfVxyXG4gICAgICAgICAgICAgICAgICB7LyogPGEgaHJlZj1cIlwiPiBTaWduIEluIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIlwiPiBSZWdpc3RlciA8L2E+ICovfVxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX3RvcFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fbGVmdFwiPlxyXG4gICAgICAgICAgICA8TG9nbyAvPlxyXG4gICAgICAgICAgICB7LyogPE1lbnVDYXRlZ29yaWVzRHJvcGRvd24gLz4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19jYXRlZ1wiPlxyXG4gICAgICAgICAgICA8TWVudUNhdGVnb3JpZXNEcm9wZG93biAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlciBvZnJcIj5cclxuICAgICAgICAgICAgPGEgaHJlZj1cIlwiPk9mZmVyIFpvbmU8L2E+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19jZW50ZXJcIj5cclxuICAgICAgICAgICAgPFNlYXJjaEhlYWRlciAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fcmlnaHRcIj5cclxuICAgICAgICAgICAgPEhlYWRlckFjdGlvbnMgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgey8qIDxOYXZpZ2F0aW9uRGVmYXVsdCAvPiAqL31cclxuICAgIDwvaGVhZGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIZWFkZXJEZWZhdWx0O1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGNvbm5lY3QsIHVzZURpc3BhdGNoLCB1c2VTZWxlY3RvciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgZ2V0Q2FydCwgcmVtb3ZlSXRlbSB9IGZyb20gXCJ+L3N0b3JlL2NhcnQvYWN0aW9uXCI7XHJcbmltcG9ydCBQcm9kdWN0T25DYXJ0IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvcHJvZHVjdHMvUHJvZHVjdE9uQ2FydFwiO1xyXG5pbXBvcnQgUHJvZHVjdFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1Byb2R1Y3RSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IGN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdCB9IGZyb20gXCJ+L3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlclwiO1xyXG5pbXBvcnQgeyBnZXREZXZpY2VJZCB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgUmVwb3NpdG9yeSwgeyBiYXNlVXJsLCBzZXJpYWxpemVRdWVyeSwgYXBpYmFzZXVybCB9IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5XCI7XHJcbmNvbnN0IE1pbmlDYXJ0ID0gUmVhY3QubWVtbygoeyBjYXJ0IH0pID0+IHtcclxuICBsZXQgY2FydEl0ZW1zVmlldztcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcbiAgY29uc3QgYXV0aCA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuYXV0aCk7XHJcblxyXG4gIGNvbnN0IHByb2R1Y3RJdGVtV2l0aFNlbGxlciA9IGNhcnQ/LnByb2R1Y3Q/Lm1hcCgocHJvZHVjdEl0ZW0pID0+IChcclxuICAgIDxkaXYga2V5PXtwcm9kdWN0SXRlbT8uc2VsbGVyPy5zZWxsZXJfaWR9PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJzdG9yLXRpdFwiPntwcm9kdWN0SXRlbT8uc2VsbGVyPy5zZWxsZXJ9PC9wPlxyXG4gICAgICB7cHJvZHVjdEl0ZW0/LnNlbGxlcj8ucHJvZHVjdHM/Lm1hcCgoY2FydFByb2R1Y3QpID0+IChcclxuICAgICAgICA8UHJvZHVjdE9uQ2FydCBwcm9kdWN0PXtjYXJ0UHJvZHVjdH0ga2V5PXtjYXJ0UHJvZHVjdD8uY2FydF9pZH0gLz5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApKTtcclxuICBjb25zdCBbY2FydGRhdGEsIHNldENhcnRkYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0b3RhbEl0ZW1zLCBzZXRUb3RhbEl0ZW1zXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCIucHJvZHVjdEl0ZW1OZXh0Li4uLi4uY2FydC4uLi4uXCIsIGNhcnQpXHJcbiAgIC8vIGNvbnNvbGUubG9nKFwiLnByb2R1Y3RJdGVtTmV4dC4uLi4uLi4uLi4uXCIsIHByb2R1Y3RJdGVtTmV4dClcclxuICAgIGxldCBpc01vdW50ZWQgPSB0cnVlO1xyXG5cclxuICAgIGlmIChpc01vdW50ZWQpIHtcclxuICAgICAgLy9hbGVydChcImJoYmhoYmhoaFwiKVxyXG4gICAgICBjb25zdCBjYXJ0VG90YWxQcm9kdWN0c0Zyb21BbGxTZWxsZXIgPSBjYXJ0Py5wcm9kdWN0Py5yZWR1Y2UoXHJcbiAgICAgICAgKHByb2R1Y3RJdGVtUHJldiwgcHJvZHVjdEl0ZW1OZXh0KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICBOdW1iZXIocHJvZHVjdEl0ZW1QcmV2KSBcclxuICAgICAgICAgICAgICtcclxuICAgICAgICAgICAgIE51bWJlcihwcm9kdWN0SXRlbU5leHQuc2VsbGVyLnByb2R1Y3RzLmxlbmd0aClcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRUb3RhbEl0ZW1zKGNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlcik7XHJcbiAgICAgIHNldENhcnRkYXRhKGNhcnQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgaXNNb3VudGVkID0gZmFsc2U7XHJcbiAgICB9O1xyXG4gIH0sIFtjYXJ0Py5wcm9kdWN0XSk7XHJcbiAgXHJcbiAgLy8gYXN5bmMgZ2V0Q2FydEl0ZW0ocGF5bG9hZCkge1xyXG5cclxuICAgIGNvbnN0IGdldENhcnRJdGVtID0gKHBheWxvYWQpID0+IHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIGNvbnN0IHVzZXJfdG9rZW4gPSBhY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5lbWFpbC4uLmxvZ2luLi4uLiAke2FwaWJhc2V1cmx9Li4uXCIse2FwaWJhc2V1cmx9KVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYWFhYWFhYWFhYWFhYWFhYS4uLlwiLHVzZXJfdG9rZW4pXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYmJiYmJiYmJiYmJiLi4uXCIsZ2V0RGV2aWNlSWQpXHJcblxyXG4gICAgY29uc3QgZGF0YSA9IEF4aW9zLnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXJ0YCxcclxuICAgICAge1xyXG4gICAgICAgIGFjY2Vzc190b2tlbjogdXNlcl90b2tlbixcclxuICAgICAgICBsYW5nX2lkOmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ0lkXCIpLFxyXG4gICAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgICAgcGFnZV91cmw6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL3Byb2R1Y3QvMlwiLFxyXG4gICAgICAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLmlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaS5cIixkYXRhKVxyXG4gICAgLy8gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gcmVzcG9uc2UuLi5cIixyZXNwb25zZSlcclxuICAgICAgICBpZiAoZGF0YS5odHRwY29kZSA9PSA0MDAgJiYgZGF0YS5zdGF0dXMgPT0gXCJlcnJvclwiKSB7XHJcbiAgICAgICAgICAvLyBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAgLy8gcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZGF0YS5odHRwY29kZSA9PSAyMDAgJiYgZGF0YS5zdGF0dXMgPT0gXCJzdWNjZXNzXCIpIHtcclxuICAgICAgICAgIHNldENhcnRkYXRhKGRhdGEuZGF0YSlcclxuICAgICAgICAgIHNldFRvdGFsSXRlbXMoZGF0YS5kYXRhLmNhcnRfY291bnQpXHJcbiAgICAgICAvLyAgIGFsZXJ0KFwieWVzXCIpXHJcbiAgICAgICAgLy8gIHNldE9mZmVyRGF0YShkYXRhLmRhdGEpXHJcbiAgICAgICAgICAvLyBub3RpZmljYXRpb25bXCJzdWNjZXNzXCJdKHtcclxuICAgICAgICAgIC8vICAgbWVzc2FnZTogZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgIC8vIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlclwiLCBKU09OLnN0cmluZ2lmeShkYXRhLmRhdGEpKTtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAvLyBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgLy8gICBtZXNzYWdlOiBlcnJvcixcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgfSk7XHJcblxyXG5cclxuICAgICBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi5jY2NjYy4uXCIsZ2V0RGV2aWNlSWQpXHJcbiAgIC8vIGNvbnNvbGUubG9nKFwiLi4uLmJiYmJiLi4uYmJiLi4uXCIscGF5bG9hZClcclxuICAgIC8vIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIC8vIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIC8vIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIC8vIGNvbnN0IHVzZXJfdG9rZW4gPSBhY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgLy8gY29uc3QgcmVzcG9uc2UgPSAgUmVwb3NpdG9yeS5wb3N0KGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXJ0YCwge1xyXG4gICAgLy8gICBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAvLyAgIGxhbmdfaWQ6IDEsXHJcbiAgICAvLyAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAvLyAgIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgIC8vICAgb3NfdHlwZTogXCJXRUJcIixcclxuICAgIC8vIH0pXHJcbiAgICAvLyBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi4uNDQ0NDQ0NDQ0NDQ0LlwiLHJlc3BvbnNlKVxyXG4gICAgLy8gICAvLyAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgIC8vICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAvLyAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgIC8vICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAvLyAgIC8vIH0pXHJcbiAgICAvLyAgIC8vIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgLy8gcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCIuLjU1Ny4uXCIsY2FydClcclxuICAgIGdldENhcnRJdGVtKClcclxuICAgIGlmIChjYXJ0ID09IHVuZGVmaW5lZCkge1xyXG4gICAgIC8vIGFsZXJ0KFwiZGRmZmZkXCIpXHJcbiAgICAgIGF1dGg/LmFjY2Vzc190b2tlbiAmJiBkaXNwYXRjaChnZXRDYXJ0KCkpO1xyXG4gICAgfVxyXG4gIH0sIFthdXRoLmFjY2Vzc190b2tlbiwgY2FydD8ucHJvZHVjdF0pO1xyXG5cclxuICBpZiAoXHJcbiAgICBjYXJ0ZGF0YSAhPT0gbnVsbCAmJlxyXG4gICAgY2FydGRhdGEgIT09IHVuZGVmaW5lZCAmJlxyXG4gICAgY2FydGRhdGE/LnByb2R1Y3Q/Lmxlbmd0aCAmJlxyXG4gICAgY2FydGRhdGE/LnByb2R1Y3Q/Lmxlbmd0aCAhPT0gMFxyXG4gICkge1xyXG4gICAgY2FydEl0ZW1zVmlldyA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19pdGVtc1wiPntwcm9kdWN0SXRlbVdpdGhTZWxsZXJ9PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19mb290ZXJcIj5cclxuICAgICAgICAgIDxoMz5cclxuICAgICAgICAgICAgU3ViIFRvdGFsOlxyXG4gICAgICAgICAgICA8c3Ryb25nPlxyXG4gICAgICAgICAgICAgIHtjYXJ0ZGF0YSAmJiBjYXJ0ZGF0YSAhPT0gbnVsbCAmJiBjYXJ0ZGF0YT8ucHJvZHVjdD8ubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgPyBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQoY2FydGRhdGEuZ3JhbmRfdG90YWwpXHJcbiAgICAgICAgICAgICAgICA6IDB9XHJcbiAgICAgICAgICAgIDwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDxmaWd1cmU+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWNjb3VudC9zaG9wcGluZy1jYXJ0XCI+XHJcbiAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtYnRuXCI+VmlldyBDYXJ0PC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWNjb3VudC9jaGVja291dFwiPlxyXG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLWJ0blwiPkNoZWNrb3V0PC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjYXJ0SXRlbXNWaWV3ID0gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNhcnRfX2NvbnRlbnRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNhcnRfX2l0ZW1zXCI+XHJcbiAgICAgICAgICA8c3Bhbj5ObyBwcm9kdWN0cyBpbiBjYXJ0PC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0LS1taW5pXCI+XHJcbiAgICAgIDxhIGNsYXNzTmFtZT1cImhlYWRlcl9fZXh0cmFcIiBocmVmPVwiI1wiPlxyXG4gICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24tYmFnMlwiPjwvaT5cclxuICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgIDxpPlxyXG4gICAgICAgICAgICB7Y2FydGRhdGEgIT09IG51bGwgJiYgY2FydGRhdGEgIT09IHVuZGVmaW5lZCAmJiB0b3RhbEl0ZW1zID4gMFxyXG4gICAgICAgICAgICAgID8gdG90YWxJdGVtc1xyXG4gICAgICAgICAgICAgIDogMH1cclxuICAgICAgICAgIDwvaT5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvYT5cclxuICAgICAge2NhcnRJdGVtc1ZpZXd9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoKHN0YXRlKSA9PiBzdGF0ZS5jYXJ0KShNaW5pQ2FydCk7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaXRlRmVhdHVyZXMgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvU2l0ZUZlYXR1cmVzXCI7XHJcbmltcG9ydCBUcmVuZGluZ05vdyBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL3Nob3AvU2hvcEl0ZW1zMVwiO1xyXG5pbXBvcnQgRG93bkxvYWRBcHAgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9jb21tb25zL0Rvd25Mb2FkQXBwXCI7XHJcbmltcG9ydCBDb250YWluZXJIb21lRGVmYXVsdCBmcm9tIFwifi9jb21wb25lbnRzL2xheW91dHMvQ29udGFpbmVySG9tZURlZmF1bHRcIjtcclxuaW1wb3J0IEZlYXR1cmVBbmRSZWNlbnQgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvRmVhdHVyZUFuZFJlY2VudFwiO1xyXG5pbXBvcnQgQWR2ZXJ0IGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0FkdmVydFwiO1xyXG5pbXBvcnQgRGlzY291bnQgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvRGlzY291bnRcIjtcclxuaW1wb3J0IHsgZ2V0RGV2aWNlSWQgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IEJyYW5kIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0JyYW5kXCI7XHJcbmltcG9ydCBCb3R0b21DYXRlZ29yeSBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2hvbWUtZGVmYXVsdC9Cb3R0b21DYXRlZ29yeVwiO1xyXG5pbXBvcnQgSG9tZURlZmF1bHRCYW5uZXIgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvSG9tZURlZmF1bHRCYW5uZXJcIjtcclxuaW1wb3J0IEhvbWVjYXRlZ29yaWVzIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvY2F0ZWdvcnkvaG9tZWNhdGVnb3JpZXNcIjtcclxuaW1wb3J0IE5ld0RlYWxzRGFpbHkgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9uZXctZGVhbHMtZGFpbHkvbmV3ZGVhbHNkYWlseVwiO1xyXG5pbXBvcnQgU2hvcEJ5Q2F0ZWdvcnkgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9uZXctZGVhbHMtZGFpbHkvbmV3ZGVhbHNkYWlseTFcIjtcclxuaW1wb3J0IFNob2NraW5nc2FsZSBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL3Nob2NraW5nc2FsZS9zaG9ja2luZ3NhbGVcIjtcclxuaW1wb3J0IEZlYXR1cmVwcm9kdWN0cyBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2ZlYXR1cmVwcm9kdWN0cy9mZWF0dXJlcHJvZHVjdHNcIjtcclxuaW1wb3J0IEhvbWVhdWN0aW9uIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvYXVjdGlvbi9hdWN0aW9uXCI7XHJcbmltcG9ydCBCZXN0c2VsbGVyIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0Jlc3RzZWxsZXJcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHsgYXBpYmFzZXVybCB9IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBGb290ZXJMaW5rcyBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9mb290ZXJzL21vZHVsZXMvRm9vdGVyTGlua3NcIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXRIb21lZGF0YSB9IGZyb20gXCJ+L3V0aWxpdGllcy9ob21lLWhlbHBlclwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgZ2V0SG9tZVN1Y2Nlc3MgfSBmcm9tIFwifi9zdG9yZS9ob21lL2FjdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VEaXNwYXRjaCwgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBIb21lcGFnZURlZmF1bHRQYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtob21laXRlbXMsIHNldEhvbWVpdGVtc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dldEZlYXR1cmVQcm9kdWN0LCBzZXRGZWF0dXJlUHJvZHVjdF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dldE5ld0FyckRhdGEsIHNldE5ld0FyckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtnZXRPZmZlckRhdGEsIHNldE9mZmVyRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBsb2FkSG9tZWRhdGEoKSB7XHJcbiAgICBsZXQgcmVzcG9uc2VEYXRhID0gYXdhaXQgZ2V0SG9tZWRhdGEocm91dGVyLmFzUGF0aCk7XHJcbiAgICBpZiAocmVzcG9uc2VEYXRhKSB7XHJcbiAgICAgIGRpc3BhdGNoKGdldEhvbWVTdWNjZXNzKHJlc3BvbnNlRGF0YS5kYXRhKSk7XHJcbiAgICAgIHNldEhvbWVpdGVtcyhyZXNwb25zZURhdGEuZGF0YSk7XHJcbiAgICB9XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9LCAyNTApO1xyXG4gIH1cclxuLy8gIGRldi1iaWdiYXNrZXQuZXN0cnJhZG93ZWIuY29tL2FwaS9jdXN0b21lci9wcm9kdWN0LWZlYXR1cmVkXHJcblxyXG5jb25zdCBmZWF0dXJlZFByb2R1Y3QgPSAoKSA9PiB7XHJcbiAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgY29uc3QgdXNlcl90b2tlbiA9IGFjY2Vzc190b2tlbjtcclxuICBjb25zb2xlLmxvZyhcIi4uLi5lbWFpbC4uLmxvZ2luLi4uLiAke2FwaWJhc2V1cmx9Li4uXCIse2FwaWJhc2V1cmx9KVxyXG4gIGNvbnN0IGRhdGEgPSBBeGlvcy5wb3N0KFxyXG4gICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZmVhdHVyZWRgLFxyXG4gICAge1xyXG5cclxuICAgICAgXHJcbiAgICAgICAgbGFuZ19pZDoxLFxyXG4gICAgICAgIGNhdGVnb3J5X2lkOlwiXCIsXHJcbiAgICAgICAgc3ViY2F0ZWdvcnlfaWQ6XCJcIixcclxuICAgICAgICBicmFuZF9pZDogXCJcIixcclxuICAgIGZlYXR1cmVkOjEsXHJcbiAgICAgICAgbGltaXQ6MTAsXHJcbiAgICAgICAgb2Zmc2V0OjAsXHJcbiAgICAgICAgZGV2aWNlX2lkOmdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOlwicHJvZHVjdHMvdXMvaW1nXCIsXHJcbiAgICAgICAgb3NfdHlwZTpcIldFQlwiLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjp1c2VyX3Rva2VuLFxyXG4gICAgICAgIG1heF9wcmljZTpcIlwiLFxyXG4gICAgICAgIG1pbl9wcmljZTpcIlwiXHJcbiAgICBcclxuICAgIFxyXG4gICAgICAvLyBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAgIC8vIGxhbmdfaWQ6IDEsXHJcbiAgICAgIC8vIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgIC8vIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgICAgLy8gb3NfdHlwZTogXCJXRUJcIixcclxuICAgIH0pXHJcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLmZlYXR1cmVkLi4uLi5cIixkYXRhKVxyXG4gIC8vICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uIHJlc3BvbnNlLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgIGlmIChkYXRhLmh0dHBjb2RlID09IDQwMCAmJiBkYXRhLnN0YXR1cyA9PSBcImVycm9yXCIpIHtcclxuICAgICAgICAvLyBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgLy8gcmV0dXJuO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChkYXRhLmh0dHBjb2RlID09IDIwMCAmJiBkYXRhLnN0YXR1cyA9PSBcInN1Y2Nlc3NcIikge1xyXG4gICAgICAgIHNldEZlYXR1cmVQcm9kdWN0KGRhdGEuZGF0YSlcclxuICAgICAgICAvLyBub3RpZmljYXRpb25bXCJzdWNjZXNzXCJdKHtcclxuICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgIC8vIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlclwiLCBKU09OLnN0cmluZ2lmeShkYXRhLmRhdGEpKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICBtZXNzYWdlOiBlcnJvcixcclxuICAgICAgfSk7XHJcbiAgICB9KTtcclxufTtcclxuY29uc3QgbmV3QXJyYWlsdmFsID0gKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uICR7YXBpYmFzZXVybH0uLi5cIix7YXBpYmFzZXVybH0pXHJcbiAgY29uc3QgZGF0YSA9IEF4aW9zLnBvc3QoXHJcbiAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdHMtbGF0ZXN0YCxcclxuICAgIHtcclxuXHJcbiAgICAgIFxyXG4gICAgICBjYXRlZ29yeV9pZDogXCJcIiwgXHJcbiAgICAgIHBhZ2VfdXJsOiBcImh0dHBzOi8vcHJvZHVjdHMvdXMvaW1nXCIsIFxyXG4gICAgICBsb3dfdG9faGlnaDogXCIwXCIsIFxyXG4gICAgICBsaW1pdDogMTAsIFxyXG4gICAgICBzdWJjYXRlZ29yeV9pZDogXCIwXCIsXHJcbiAgICAgICBicmFuZF9pZDogXCIwXCIsXHJcbiAgICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgICAgbGF0ZXN0OiBcIjBcIiwgXHJcbiAgICAgICAgIG9zX3R5cGU6IFwid2ViXCIsIFxyXG4gICAgICAgICBhY2Nlc3NfdG9rZW46IFwiXCIsXHJcbiAgICAgICAgICBoaWdoX3RvX2xvdzogXCIwXCIsIFxyXG4gICAgICAgICAgbGFuZ19pZDogMSwgXHJcbiAgICAgICAgICBwb3B1bGFyOiBcIjBcIixcclxuICAgICAgICAgIG9mZnNldDogMFxyXG4gICAgXHJcbiAgICAgIC8vIGFjY2Vzc190b2tlbjogdXNlcl90b2tlbixcclxuICAgICAgLy8gbGFuZ19pZDogMSxcclxuICAgICAgLy8gZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgLy8gcGFnZV91cmw6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL3Byb2R1Y3QvMlwiLFxyXG4gICAgICAvLyBvc190eXBlOiBcIldFQlwiLFxyXG4gICAgfSlcclxuICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YSlcclxuICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiLi4ubmV3QXJyYWlsdmFsLlwiLGRhdGEpXHJcbiAgLy8gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gcmVzcG9uc2UuLi5cIixyZXNwb25zZSlcclxuICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gNDAwICYmIGRhdGEuc3RhdHVzID09IFwiZXJyb3JcIikge1xyXG4gICAgICAgIC8vIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgICAvLyByZXR1cm47XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gMjAwICYmIGRhdGEuc3RhdHVzID09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICBzZXROZXdBcnJEYXRhKGRhdGEuZGF0YSlcclxuICAgICAgICAvLyBub3RpZmljYXRpb25bXCJzdWNjZXNzXCJdKHtcclxuICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgIC8vIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlclwiLCBKU09OLnN0cmluZ2lmeShkYXRhLmRhdGEpKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgIC8vIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgLy8gICBtZXNzYWdlOiBlcnJvcixcclxuICAgICAgLy8gfSk7XHJcbiAgICB9KTtcclxufTtcclxuICBjb25zdCBvZmZlciA9ICgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uICR7YXBpYmFzZXVybH0uLi5cIix7YXBpYmFzZXVybH0pXHJcbiAgICBjb25zdCBkYXRhID0gQXhpb3MucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29mZmVyL2xpc3RgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi5vZmZlcnJycnJycnJycnJyLlwiLGRhdGEpXHJcbiAgICAvLyAgICBjb25zb2xlLmxvZyhcIi4uLi5lbWFpbC4uLmxvZ2luLi4uLiByZXNwb25zZS4uLlwiLHJlc3BvbnNlKVxyXG4gICAgICAgIGlmIChkYXRhLmh0dHBjb2RlID09IDQwMCAmJiBkYXRhLnN0YXR1cyA9PSBcImVycm9yXCIpIHtcclxuICAgICAgICAgIC8vIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIC8vICAgbWVzc2FnZTogZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgICAvLyByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChkYXRhLmh0dHBjb2RlID09IDIwMCAmJiBkYXRhLnN0YXR1cyA9PSBcInN1Y2Nlc3NcIikge1xyXG4gICAgICAgICAgc2V0T2ZmZXJEYXRhKGRhdGEuZGF0YSlcclxuICAgICAgICAgIC8vIG5vdGlmaWNhdGlvbltcInN1Y2Nlc3NcIl0oe1xyXG4gICAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAvLyB9KTtcclxuICAgICAgICAgLy8gbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1c2VyXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEuZGF0YSkpO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICB9O1xyXG4gIGNvbnN0IHsgaG9tZWRhdGEgfSA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuaG9tZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uaG9tZWRhdGEuLi4uXCIsaG9tZWRhdGEpXHJcbiAgICBpZiAoaG9tZWRhdGEgPT0gbnVsbCkge1xyXG4gICAgICBsb2FkSG9tZWRhdGEoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEhvbWVpdGVtcyhob21lZGF0YSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9LCAyNTApO1xyXG4gICAgfVxyXG5cclxub2ZmZXIoKVxyXG5mZWF0dXJlZFByb2R1Y3QoKVxyXG5uZXdBcnJhaWx2YWwoKVxyXG4gIH0sIFtob21lZGF0YV0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNwaW4gc3Bpbm5pbmc9e2xvYWRpbmd9PlxyXG4gICAgICA8Q29udGFpbmVySG9tZURlZmF1bHQgdGl0bGU9XCJCaWcgQmFza2V0XCI+XHJcbiAgICAgICAgPEhvbWVEZWZhdWx0QmFubmVyIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSBsb2FkaW5nPXtsb2FkaW5nfSAvPlxyXG4gICAgICAgIHsvKiA8TWFya2V0UGxhY2UzU2VhcmNoVHJlbmRpbmcgLz4gKi99XHJcbiAgICAgICAgey8qIDxTaXRlRmVhdHVyZXMgLz4gKi99XHJcbiAgICAgICAgIHshbG9hZGluZyAmJiBob21laXRlbXMgJiYgaG9tZWl0ZW1zPy5jYXRlZ29yeT8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8U2hvcEJ5Q2F0ZWdvcnlcclxuICAgICAgICAgICAgY29sbGVjdGlvblNsdWc9XCJkZWFsLW9mLXRoZS1kYXlcIlxyXG4gICAgICAgICAgICBob21laXRlbXM9e2hvbWVpdGVtc31cclxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8VHJlbmRpbmdOb3cgaG9tZWl0ZW1zPXtob21laXRlbXN9Lz5cclxuICAgICAgICB7LyogPEhvbWVjYXRlZ29yaWVzIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSBsb2FkaW5nPXtsb2FkaW5nfSAvPiAqL31cclxuICAgICAgICB7IWxvYWRpbmcgJiYgaG9tZWl0ZW1zICYmIGhvbWVpdGVtcz8uc2hvY2tpbmdfc2FsZT8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8U2hvY2tpbmdzYWxlXHJcbiAgICAgICAgICAgIGNvbGxlY3Rpb25TbHVnPVwiZGVhbC1vZi10aGUtZGF5XCJcclxuICAgICAgICAgICAgaG9tZWl0ZW1zPXtob21laXRlbXN9XHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICBcclxuXHJcbiAgICAgIFxyXG4gICAgICAgICAgIDxBZHZlcnQgIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSBsb2FkaW5nPXtsb2FkaW5nfS8+XHJcblxyXG4gICAgICAgICAgIHshbG9hZGluZyAmJiBob21laXRlbXMgJiYgaG9tZWl0ZW1zPy5uZXdfYXJyaXZhbHM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgPE5ld0RlYWxzRGFpbHlcclxuICAgICAgICAgICAgY29sbGVjdGlvblNsdWc9XCJkZWFsLW9mLXRoZS1kYXlcIlxyXG4gICAgICAgICAgICBob21laXRlbXM9e2dldE5ld0FyckRhdGF9XHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgey8qIHshbG9hZGluZyAmJiBob21laXRlbXMgJiYgaG9tZWl0ZW1zPy5mZWF0dXJlZF9wcm9kdWN0cz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8RmVhdHVyZXByb2R1Y3RzXHJcbiAgICAgICAgICAgIGNvbGxlY3Rpb25TbHVnPVwiY29uc3VtZXItZWxlY3Ryb25pY3NcIlxyXG4gICAgICAgICAgICB0aXRsZT1cIkZlYXR1cmUgcHJvZHVjdHNcIlxyXG4gICAgICAgICAgICBob21laXRlbXM9e2hvbWVpdGVtc31cclxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX0gKi99XHJcbiAgICAgICAgPEZlYXR1cmVBbmRSZWNlbnQgaG9tZWl0ZW1zPXtob21laXRlbXN9IGdldEZlYXR1cmVQcm9kdWN0PXtnZXRGZWF0dXJlUHJvZHVjdH0gbG9hZGluZz17bG9hZGluZ30vPlxyXG4gICAgICAgIDxEaXNjb3VudCBnZXRPZmZlckRhdGE9e2dldE9mZmVyRGF0YX0gbG9hZGluZz17bG9hZGluZ30vPlxyXG4gICAgICAgIDxCb3R0b21DYXRlZ29yeSBob21laXRlbXM9e2hvbWVpdGVtc30gbG9hZGluZz17bG9hZGluZ30vPlxyXG4gICAgICAgIDxCcmFuZCBob21laXRlbXM9e2hvbWVpdGVtc30gbG9hZGluZz17bG9hZGluZ30vPlxyXG4gICAgICAgIHsvKiB7IWxvYWRpbmcgJiYgaG9tZWl0ZW1zICYmIGhvbWVpdGVtcz8uYXVjdGlvbj8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8SG9tZWF1Y3Rpb24gaG9tZWl0ZW1zPXtob21laXRlbXN9IC8+XHJcbiAgICAgICAgKX0gKi99XHJcbiAgICAgICAgey8qIDxCZXN0c2VsbGVyIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSAvPiAqL31cclxuICAgICAgICB7LyogPERvd25Mb2FkQXBwIC8+ICovfVxyXG4gICAgICAgIHsvKiA8TmV3bGV0dGVycyAvPiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC1zdG9yaWVzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8Rm9vdGVyTGlua3MgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0NvbnRhaW5lckhvbWVEZWZhdWx0PlxyXG4gICAgPC9TcGluPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb21lcGFnZURlZmF1bHRQYWdlO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9