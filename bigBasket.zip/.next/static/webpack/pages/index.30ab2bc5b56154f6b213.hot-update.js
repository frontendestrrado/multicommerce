webpackHotUpdate_N_E("pages/index",{

/***/ "./components/elements/detail/modules/ModuleDetailActionsMobile.jsx":
/*!**************************************************************************!*\
  !*** ./components/elements/detail/modules/ModuleDetailActionsMobile.jsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");



var _jsxFileName = "E:\\bigBasket\\components\\elements\\detail\\modules\\ModuleDetailActionsMobile.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }









const ModuleDetailActionsMobile = ({
  product
}) => {
  _s();

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"])();
  const Router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();
  const {
    0: loading1,
    1: setLoading1
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading2,
    1: setLoading2
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading3,
    1: setLoading3
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"])(state => state.auth);
  const {
    productQuantity,
    productIdOfConfig,
    out_of_stock_selling,
    stock
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"])(state => state.product);

  const handleAddItemToCart = async e => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please login first");
      return false;
    } else if (product.product.product_type == "config" && (productIdOfConfig == 0 || productIdOfConfig == null || productIdOfConfig == undefined)) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please Select Varient");
      return false;
    } else {
      var _payload;

      setLoading1(true);
      let payload = {
        user_id: 1,
        quantity: productQuantity || 1,
        cart_type: "web",
        access_token: token
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: productIdOfConfig
        });

        if (out_of_stock_selling === false && stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      }

      const responseData = ((_payload = payload) === null || _payload === void 0 ? void 0 : _payload.access_token) && (await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToCart(payload));

      if (responseData && responseData.httpcode == "200") {
        dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_3__["getCart"])());
        setLoading1(false);
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])(responseData.status, responseData.status, responseData.response);
      } else if (responseData && responseData.httpcode == 400) {
        let error = responseData.errors;

        for (const [key, value] of Object.entries(error)) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "", value, 2);
        }
      } else {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", responseData.message);
        setLoading1(false);
      }
    }

    return false;
  };

  const handleBuynow = async e => {
    if (auth.isLoggedIn !== true) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please login first");
      return false;
    } else if (product.product.product_type == "config" && (productIdOfConfig == 0 || productIdOfConfig == null || productIdOfConfig == undefined)) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please Select Varient");
      return false;
    } else {
      setLoading2(true);
      let payload = {
        user_id: 1,
        quantity: productQuantity || 1,
        access_token: auth.access_token,
        cart_type: "web"
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: productIdOfConfig
        });

        if (out_of_stock_selling === false && stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      }

      const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToCart(payload);

      if (responseData.httpcode == 200) {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])(responseData.status, responseData.status, responseData.response);
        setTimeout(function () {
          Router.push("/account/checkout");
        }, 1000);
        setLoading2(false);
        return false;
      } else {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", responseData.message);
        setLoading2(false);
        return false;
      }
    }

    return false;
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product__actions-mobile",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "ps-btn ps-btn--black",
      onClick: e => handleAddItemToCart(e),
      children: "Add to cart1"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 175,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "ps-btn",
      onClick: e => handleBuynow(e),
      children: "Buy Now"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 181,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 174,
    columnNumber: 5
  }, undefined);
};

_s(ModuleDetailActionsMobile, "JBJhYokuiu19kou1mDKh33i5BTM=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"], next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"]];
});

_c = ModuleDetailActionsMobile;
/* harmony default export */ __webpack_exports__["default"] = (ModuleDetailActionsMobile);

var _c;

$RefreshReg$(_c, "ModuleDetailActionsMobile");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9kZXRhaWwvbW9kdWxlcy9Nb2R1bGVEZXRhaWxBY3Rpb25zTW9iaWxlLmpzeCJdLCJuYW1lcyI6WyJNb2R1bGVEZXRhaWxBY3Rpb25zTW9iaWxlIiwicHJvZHVjdCIsImRpc3BhdGNoIiwidXNlRGlzcGF0Y2giLCJSb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJsb2FkaW5nMSIsInNldExvYWRpbmcxIiwidXNlU3RhdGUiLCJsb2FkaW5nMiIsInNldExvYWRpbmcyIiwibG9hZGluZzMiLCJzZXRMb2FkaW5nMyIsImF1dGgiLCJ1c2VTZWxlY3RvciIsInN0YXRlIiwicHJvZHVjdFF1YW50aXR5IiwicHJvZHVjdElkT2ZDb25maWciLCJvdXRfb2Zfc3RvY2tfc2VsbGluZyIsInN0b2NrIiwiaGFuZGxlQWRkSXRlbVRvQ2FydCIsImUiLCJ1c2VyZGF0YSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJwYXJzZWRhdGEiLCJKU09OIiwicGFyc2UiLCJ0b2tlbiIsImFjY2Vzc190b2tlbiIsInVuZGVmaW5lZCIsImRpc3BsYXlOb3RpZmljYXRpb24iLCJwcm9kdWN0X3R5cGUiLCJwYXlsb2FkIiwidXNlcl9pZCIsInF1YW50aXR5IiwiY2FydF90eXBlIiwicHJvZHVjdF9pZCIsInJlc3BvbnNlRGF0YSIsIlByb2R1Y3RSZXBvc2l0b3J5IiwiYWRkUHJvZHVjdFRvQ2FydCIsImh0dHBjb2RlIiwiZ2V0Q2FydCIsInN0YXR1cyIsInJlc3BvbnNlIiwiZXJyb3IiLCJlcnJvcnMiLCJrZXkiLCJ2YWx1ZSIsIk9iamVjdCIsImVudHJpZXMiLCJtZXNzYWdlIiwiaGFuZGxlQnV5bm93IiwiaXNMb2dnZWRJbiIsInNldFRpbWVvdXQiLCJwdXNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1BLHlCQUF5QixHQUFHLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWlCO0FBQUE7O0FBQ2pELFFBQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7QUFDQSxRQUFNQyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCQyxzREFBUSxDQUFDLEtBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJGLHNEQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDRyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQkosc0RBQVEsQ0FBQyxLQUFELENBQXhDO0FBRUEsUUFBTUssSUFBSSxHQUFHQywrREFBVyxDQUFFQyxLQUFELElBQVdBLEtBQUssQ0FBQ0YsSUFBbEIsQ0FBeEI7QUFDQSxRQUFNO0FBQUVHLG1CQUFGO0FBQW1CQyxxQkFBbkI7QUFBc0NDLHdCQUF0QztBQUE0REM7QUFBNUQsTUFDSkwsK0RBQVcsQ0FBRUMsS0FBRCxJQUFXQSxLQUFLLENBQUNkLE9BQWxCLENBRGI7O0FBR0EsUUFBTW1CLG1CQUFtQixHQUFHLE1BQU9DLENBQVAsSUFBYTtBQUN2QyxRQUFJQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0wsUUFBWCxDQUFoQjtBQUNBLFFBQUlNLEtBQUssR0FBR0gsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQXZCOztBQUVBLFFBQUlQLFFBQVEsS0FBS1EsU0FBYixJQUEwQlIsUUFBUSxLQUFLLElBQTNDLEVBQWlEO0FBQy9DUywyRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQixvQkFBbkIsQ0FBbkI7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQUhELE1BR08sSUFDTDlCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQitCLFlBQWhCLElBQWdDLFFBQWhDLEtBQ0NmLGlCQUFpQixJQUFJLENBQXJCLElBQ0NBLGlCQUFpQixJQUFJLElBRHRCLElBRUNBLGlCQUFpQixJQUFJYSxTQUh2QixDQURLLEVBS0w7QUFDQUMsMkZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsdUJBQW5CLENBQW5CO0FBQ0EsYUFBTyxLQUFQO0FBQ0QsS0FSTSxNQVFBO0FBQUE7O0FBQ0x4QixpQkFBVyxDQUFDLElBQUQsQ0FBWDtBQUNBLFVBQUkwQixPQUFPLEdBQUc7QUFDWkMsZUFBTyxFQUFFLENBREc7QUFFWkMsZ0JBQVEsRUFBRW5CLGVBQWUsSUFBSSxDQUZqQjtBQUdab0IsaUJBQVMsRUFBRSxLQUhDO0FBSVpQLG9CQUFZLEVBQUVEO0FBSkYsT0FBZDs7QUFPQSxVQUFJM0IsT0FBTyxDQUFDQSxPQUFSLENBQWdCK0IsWUFBaEIsSUFBZ0MsUUFBcEMsRUFBOEM7QUFDNUNDLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEksb0JBQVUsRUFBRXBCO0FBRlAsVUFBUDs7QUFJQSxZQUFJQyxvQkFBb0IsS0FBSyxLQUF6QixJQUFrQ0MsS0FBSyxJQUFJLENBQS9DLEVBQWtEO0FBQ2hEWSwrRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix1QkFBbkIsQ0FBbkI7QUFFQXJCLHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBRUEsaUJBQU8sS0FBUDtBQUNEO0FBQ0YsT0FaRCxNQVlPO0FBQ0x1QixlQUFPLG1DQUNGQSxPQURFO0FBRUxJLG9CQUFVLEVBQUVwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQztBQUZ2QixVQUFQOztBQUlBLFlBQ0VwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JpQixvQkFBaEIsS0FBeUMsS0FBekMsSUFDQWpCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmtCLEtBQWhCLElBQXlCLENBRjNCLEVBR0U7QUFDQVksK0ZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsdUJBQW5CLENBQW5CO0FBRUFyQixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFlBQU00QixZQUFZLEdBQ2hCLGFBQUFMLE9BQU8sVUFBUCw0Q0FBU0osWUFBVCxNQUNDLE1BQU1VLHVFQUFpQixDQUFDQyxnQkFBbEIsQ0FBbUNQLE9BQW5DLENBRFAsQ0FERjs7QUFJQSxVQUFJSyxZQUFZLElBQUlBLFlBQVksQ0FBQ0csUUFBYixJQUF5QixLQUE3QyxFQUFvRDtBQUNsRHZDLGdCQUFRLENBQUN3QyxrRUFBTyxFQUFSLENBQVI7QUFFQW5DLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0F3Qiw2RkFBbUIsQ0FDakJPLFlBQVksQ0FBQ0ssTUFESSxFQUVqQkwsWUFBWSxDQUFDSyxNQUZJLEVBR2pCTCxZQUFZLENBQUNNLFFBSEksQ0FBbkI7QUFLRCxPQVRELE1BU08sSUFBSU4sWUFBWSxJQUFJQSxZQUFZLENBQUNHLFFBQWIsSUFBeUIsR0FBN0MsRUFBa0Q7QUFDdkQsWUFBSUksS0FBSyxHQUFHUCxZQUFZLENBQUNRLE1BQXpCOztBQUNBLGFBQUssTUFBTSxDQUFDQyxHQUFELEVBQU1DLEtBQU4sQ0FBWCxJQUEyQkMsTUFBTSxDQUFDQyxPQUFQLENBQWVMLEtBQWYsQ0FBM0IsRUFBa0Q7QUFDaERkLCtGQUFtQixDQUFDLE9BQUQsRUFBVSxFQUFWLEVBQWNpQixLQUFkLEVBQXFCLENBQXJCLENBQW5CO0FBQ0Q7QUFDRixPQUxNLE1BS0E7QUFDTGpCLDZGQUFtQixDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CTyxZQUFZLENBQUNhLE9BQWhDLENBQW5CO0FBQ0E1QyxtQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNEO0FBQ0Y7O0FBQ0QsV0FBTyxLQUFQO0FBQ0QsR0E5RUQ7O0FBZ0ZBLFFBQU02QyxZQUFZLEdBQUcsTUFBTy9CLENBQVAsSUFBYTtBQUNoQyxRQUFJUixJQUFJLENBQUN3QyxVQUFMLEtBQW9CLElBQXhCLEVBQThCO0FBQzVCdEIsMkZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsb0JBQW5CLENBQW5CO0FBQ0EsYUFBTyxLQUFQO0FBQ0QsS0FIRCxNQUdPLElBQ0w5QixPQUFPLENBQUNBLE9BQVIsQ0FBZ0IrQixZQUFoQixJQUFnQyxRQUFoQyxLQUNDZixpQkFBaUIsSUFBSSxDQUFyQixJQUNDQSxpQkFBaUIsSUFBSSxJQUR0QixJQUVDQSxpQkFBaUIsSUFBSWEsU0FIdkIsQ0FESyxFQUtMO0FBQ0FDLDJGQUFtQixDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLHVCQUFuQixDQUFuQjtBQUNBLGFBQU8sS0FBUDtBQUNELEtBUk0sTUFRQTtBQUNMckIsaUJBQVcsQ0FBQyxJQUFELENBQVg7QUFDQSxVQUFJdUIsT0FBTyxHQUFHO0FBQ1pDLGVBQU8sRUFBRSxDQURHO0FBRVpDLGdCQUFRLEVBQUVuQixlQUFlLElBQUksQ0FGakI7QUFHWmEsb0JBQVksRUFBRWhCLElBQUksQ0FBQ2dCLFlBSFA7QUFJWk8saUJBQVMsRUFBRTtBQUpDLE9BQWQ7O0FBT0EsVUFBSW5DLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQitCLFlBQWhCLElBQWdDLFFBQXBDLEVBQThDO0FBQzVDQyxlQUFPLG1DQUNGQSxPQURFO0FBRUxJLG9CQUFVLEVBQUVwQjtBQUZQLFVBQVA7O0FBSUEsWUFBSUMsb0JBQW9CLEtBQUssS0FBekIsSUFBa0NDLEtBQUssSUFBSSxDQUEvQyxFQUFrRDtBQUNoRFksK0ZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsdUJBQW5CLENBQW5CO0FBRUFyQixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGLE9BWkQsTUFZTztBQUNMdUIsZUFBTyxtQ0FDRkEsT0FERTtBQUVMSSxvQkFBVSxFQUFFcEMsT0FBTyxDQUFDQSxPQUFSLENBQWdCb0M7QUFGdkIsVUFBUDs7QUFLQSxZQUNFcEMsT0FBTyxDQUFDQSxPQUFSLENBQWdCaUIsb0JBQWhCLEtBQXlDLEtBQXpDLElBQ0FqQixPQUFPLENBQUNBLE9BQVIsQ0FBZ0JrQixLQUFoQixJQUF5QixDQUYzQixFQUdFO0FBQ0FZLCtGQUFtQixDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLHVCQUFuQixDQUFuQjtBQUVBckIscUJBQVcsQ0FBQyxLQUFELENBQVg7QUFFQSxpQkFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFFRCxZQUFNNEIsWUFBWSxHQUFHLE1BQU1DLHVFQUFpQixDQUFDQyxnQkFBbEIsQ0FBbUNQLE9BQW5DLENBQTNCOztBQUVBLFVBQUlLLFlBQVksQ0FBQ0csUUFBYixJQUF5QixHQUE3QixFQUFrQztBQUNoQ1YsNkZBQW1CLENBQ2pCTyxZQUFZLENBQUNLLE1BREksRUFFakJMLFlBQVksQ0FBQ0ssTUFGSSxFQUdqQkwsWUFBWSxDQUFDTSxRQUhJLENBQW5CO0FBS0FVLGtCQUFVLENBQUMsWUFBWTtBQUNyQmxELGdCQUFNLENBQUNtRCxJQUFQLENBQVksbUJBQVo7QUFDRCxTQUZTLEVBRVAsSUFGTyxDQUFWO0FBR0E3QyxtQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBLGVBQU8sS0FBUDtBQUNELE9BWEQsTUFXTztBQUNMcUIsNkZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUJPLFlBQVksQ0FBQ2EsT0FBaEMsQ0FBbkI7QUFDQXpDLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0EsZUFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPLEtBQVA7QUFDRCxHQXZFRDs7QUF5RUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsNEJBQWY7QUFBQSw0QkFDRTtBQUNFLGVBQVMsRUFBQyxzQkFEWjtBQUVFLGFBQU8sRUFBR1csQ0FBRCxJQUFPRCxtQkFBbUIsQ0FBQ0MsQ0FBRCxDQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQU9FO0FBQUcsZUFBUyxFQUFDLFFBQWI7QUFBc0IsYUFBTyxFQUFHQSxDQUFELElBQU8rQixZQUFZLENBQUMvQixDQUFELENBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBYUQsQ0FqTEQ7O0dBQU1yQix5QjtVQUNhRyx1RCxFQUNGRSxxRCxFQUtGUyx1RCxFQUVYQSx1RDs7O0tBVEVkLHlCO0FBbUxTQSx3RkFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4zMGFiMmJjNWI1NjE1NGY2YjIxMy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgYWRkSXRlbSwgZ2V0Q2FydCB9IGZyb20gXCJ+L3N0b3JlL2NhcnQvYWN0aW9uXCI7XHJcbmltcG9ydCB7IHVzZURpc3BhdGNoIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgUHJvZHVjdFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1Byb2R1Y3RSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IGRpc3BsYXlOb3RpZmljYXRpb24gfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuXHJcbmNvbnN0IE1vZHVsZURldGFpbEFjdGlvbnNNb2JpbGUgPSAoeyBwcm9kdWN0IH0pID0+IHtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcbiAgY29uc3QgUm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgW2xvYWRpbmcxLCBzZXRMb2FkaW5nMV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcyLCBzZXRMb2FkaW5nMl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmczLCBzZXRMb2FkaW5nM10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGF1dGggPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLmF1dGgpO1xyXG4gIGNvbnN0IHsgcHJvZHVjdFF1YW50aXR5LCBwcm9kdWN0SWRPZkNvbmZpZywgb3V0X29mX3N0b2NrX3NlbGxpbmcsIHN0b2NrIH0gPVxyXG4gICAgdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5wcm9kdWN0KTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkSXRlbVRvQ2FydCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuXHJcbiAgICBpZiAodXNlcmRhdGEgPT09IHVuZGVmaW5lZCB8fCB1c2VyZGF0YSA9PT0gbnVsbCkge1xyXG4gICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIlBsZWFzZSBsb2dpbiBmaXJzdFwiKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgcHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiICYmXHJcbiAgICAgIChwcm9kdWN0SWRPZkNvbmZpZyA9PSAwIHx8XHJcbiAgICAgICAgcHJvZHVjdElkT2ZDb25maWcgPT0gbnVsbCB8fFxyXG4gICAgICAgIHByb2R1Y3RJZE9mQ29uZmlnID09IHVuZGVmaW5lZClcclxuICAgICkge1xyXG4gICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIlBsZWFzZSBTZWxlY3QgVmFyaWVudFwiKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TG9hZGluZzEodHJ1ZSk7XHJcbiAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHVzZXJfaWQ6IDEsXHJcbiAgICAgICAgcXVhbnRpdHk6IHByb2R1Y3RRdWFudGl0eSB8fCAxLFxyXG4gICAgICAgIGNhcnRfdHlwZTogXCJ3ZWJcIixcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IHRva2VuLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgaWYgKHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X3R5cGUgPT0gXCJjb25maWdcIikge1xyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkT2ZDb25maWcsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAob3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmIHN0b2NrIDw9IDApIHtcclxuICAgICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUHJvZHVjdCBPdXQgb2YgU3RvY2shXCIpO1xyXG5cclxuICAgICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfaWQsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Qub3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmXHJcbiAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Quc3RvY2sgPD0gMFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIik7XHJcblxyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XHJcbiAgICAgICAgcGF5bG9hZD8uYWNjZXNzX3Rva2VuICYmXHJcbiAgICAgICAgKGF3YWl0IFByb2R1Y3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb0NhcnQocGF5bG9hZCkpO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlRGF0YSAmJiByZXNwb25zZURhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgIGRpc3BhdGNoKGdldENhcnQoKSk7XHJcblxyXG4gICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFxyXG4gICAgICAgICAgcmVzcG9uc2VEYXRhLnN0YXR1cyxcclxuICAgICAgICAgIHJlc3BvbnNlRGF0YS5zdGF0dXMsXHJcbiAgICAgICAgICByZXNwb25zZURhdGEucmVzcG9uc2VcclxuICAgICAgICApO1xyXG4gICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlRGF0YSAmJiByZXNwb25zZURhdGEuaHR0cGNvZGUgPT0gNDAwKSB7XHJcbiAgICAgICAgbGV0IGVycm9yID0gcmVzcG9uc2VEYXRhLmVycm9ycztcclxuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhlcnJvcikpIHtcclxuICAgICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIlwiLCB2YWx1ZSwgMik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIHJlc3BvbnNlRGF0YS5tZXNzYWdlKTtcclxuICAgICAgICBzZXRMb2FkaW5nMShmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVCdXlub3cgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgaWYgKGF1dGguaXNMb2dnZWRJbiAhPT0gdHJ1ZSkge1xyXG4gICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIlBsZWFzZSBsb2dpbiBmaXJzdFwiKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgcHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiICYmXHJcbiAgICAgIChwcm9kdWN0SWRPZkNvbmZpZyA9PSAwIHx8XHJcbiAgICAgICAgcHJvZHVjdElkT2ZDb25maWcgPT0gbnVsbCB8fFxyXG4gICAgICAgIHByb2R1Y3RJZE9mQ29uZmlnID09IHVuZGVmaW5lZClcclxuICAgICkge1xyXG4gICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIlBsZWFzZSBTZWxlY3QgVmFyaWVudFwiKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TG9hZGluZzIodHJ1ZSk7XHJcbiAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHVzZXJfaWQ6IDEsXHJcbiAgICAgICAgcXVhbnRpdHk6IHByb2R1Y3RRdWFudGl0eSB8fCAxLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjogYXV0aC5hY2Nlc3NfdG9rZW4sXHJcbiAgICAgICAgY2FydF90eXBlOiBcIndlYlwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgaWYgKHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X3R5cGUgPT0gXCJjb25maWdcIikge1xyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkT2ZDb25maWcsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAob3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmIHN0b2NrIDw9IDApIHtcclxuICAgICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUHJvZHVjdCBPdXQgb2YgU3RvY2shXCIpO1xyXG5cclxuICAgICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfaWQsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgcHJvZHVjdC5wcm9kdWN0Lm91dF9vZl9zdG9ja19zZWxsaW5nID09PSBmYWxzZSAmJlxyXG4gICAgICAgICAgcHJvZHVjdC5wcm9kdWN0LnN0b2NrIDw9IDBcclxuICAgICAgICApIHtcclxuICAgICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUHJvZHVjdCBPdXQgb2YgU3RvY2shXCIpO1xyXG5cclxuICAgICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSBhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5hZGRQcm9kdWN0VG9DYXJ0KHBheWxvYWQpO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlRGF0YS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFxyXG4gICAgICAgICAgcmVzcG9uc2VEYXRhLnN0YXR1cyxcclxuICAgICAgICAgIHJlc3BvbnNlRGF0YS5zdGF0dXMsXHJcbiAgICAgICAgICByZXNwb25zZURhdGEucmVzcG9uc2VcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgUm91dGVyLnB1c2goXCIvYWNjb3VudC9jaGVja291dFwiKTtcclxuICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICBzZXRMb2FkaW5nMihmYWxzZSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIHJlc3BvbnNlRGF0YS5tZXNzYWdlKTtcclxuICAgICAgICBzZXRMb2FkaW5nMihmYWxzZSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fYWN0aW9ucy1tb2JpbGVcIj5cclxuICAgICAgPGFcclxuICAgICAgICBjbGFzc05hbWU9XCJwcy1idG4gcHMtYnRuLS1ibGFja1wiXHJcbiAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZUFkZEl0ZW1Ub0NhcnQoZSl9XHJcbiAgICAgID5cclxuICAgICAgICBBZGQgdG8gY2FydDFcclxuICAgICAgPC9hPlxyXG4gICAgICA8YSBjbGFzc05hbWU9XCJwcy1idG5cIiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQnV5bm93KGUpfT5cclxuICAgICAgICBCdXkgTm93XHJcbiAgICAgIDwvYT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNb2R1bGVEZXRhaWxBY3Rpb25zTW9iaWxlO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9