webpackHotUpdate_N_E("pages/_app",{

/***/ "./repositories/AccountRepository.js":
/*!*******************************************!*\
  !*** ./repositories/AccountRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");





const modalOpen = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message,
    description
  });
};

class AccountRepository {
  async getUserPurchaseYears(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/year`, payload).then(response => {
      return response.data;
    }).catch(err => {
      modalOpen("error", "Error", "Error Fetching Years from Server");
    });
    return response;
  }

  async changePassword(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/password/change`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async registerNewUser(payload) {
    // alert("d")
    console.log("....555...", payload);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async editCustomerProfile(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(function (response) {
      return response.data;
    }).catch(function (response) {
      console.log(response);
      return response.data;
    });
    return response;
  }

  async getCountry() {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/country`).then(response => {
      if (response.data.httpcode == 200) {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getChatList(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/list`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getChatMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/message`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/send`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getState(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/state`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getCity(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/city`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getMyOrders(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/mypurchase`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async cancelOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/response/cancel/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getOrderDetails(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getCustomerProfileDetail({ access_token }) {


  async getCustomerProfileDetail() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/profile`, {
      access_token,
      lang_id: localStorage.getItem("langId")
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateCustomerProfileDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerRecentViews(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/recent/views`, {
      access_token,
      lang_id: localStorage.getItem("langId")
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerAddresses() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/address`, {
      access_token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async makeDefaultAddresses(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    userUpdateFormData.append("is_default", payload.default);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/default/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteAddress(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/remove/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/return/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnShipmentDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/return/shipment`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => response.error);
    return response;
  }

  async listSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/list-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async supportMessageByID(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/support-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async addTicketMessage(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-ticket-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getWalletDetails(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/wallet/amount`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionCartData(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getUserNotification(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/view/notifications`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionOrderList(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/order/list`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/send/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/verify/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyForgotOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/login/forgot/verify-otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new AccountRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/CartRepository.js":
/*!****************************************!*\
  !*** ./repositories/CartRepository.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");




class CartRepository {
  async addProductToCart({
    access_token,
    product,
    quantity,
    cart_type
  }) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/add-cart`, {
      access_token,
      product_id: product.product_id,
      quantity,
      cart_type
    }).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      }

      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCartItem(payload) {
    // alert("d")
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__["getDeviceId"]);
    console.log("....bbbbb...bbb...", payload);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: localStorage.getItem("langId"),
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_1__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }); // alert("3333")

    console.log("....bbbbb...bbb..444444444444.", response).then(response => {
      //   alert("44444444")
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async fetchPlatformVoucher() {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/platform`, {
      lang_id: ""
    }).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async checkPlatformVoucher(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/platform`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async checkSellerVoucher(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_2__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_2__["apibaseurl"]}/api/customer/coupon/seller`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data;
      } else {
        return response.data;
      }
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new CartRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Homeapi.js":
/*!*********************************!*\
  !*** ./repositories/Homeapi.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");




class Homeapi {
  async getHomedata(pathName) {
    let payload = {
      access_token: "",
      lang_id: localStorage.getItem("langId"),
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["getDeviceId"],
      page_url: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["makePageUrl"])("/"),
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["osType"])()
    };
    const CancelToken = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken;
    let source = CancelToken.source();
    source && source.cancel("Operation canceled due to new request."); // save the new request for cancellation

    source = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken.source();
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/home`, payload, {
      cancelToken: source.token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    })); // cancel the request (the message parameter is optional)

    source.cancel("Operation canceled by the user.");
    return reponse;
  }

  async submitReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-product-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async submitSellerReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-seller-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getHomedata() {
  //   const response = await axios
  //     .get(`https://estrradoweb.com/kangtao/api/customer/home`, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     })
  //     .then((response) => response.data)
  //     .catch((error) => error);
  //   return response;
  // }


}

/* harmony default export */ __webpack_exports__["default"] = (new Homeapi());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/ProductRepository.js":
/*!*******************************************!*\
  !*** ./repositories/ProductRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");



class ProductRepository {
  async getRecords(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(params)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getSearchedProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-search`, {
      lang_id: "",
      category_id: params.category_id,
      keyword: params.title_contains
    }).then(response => {
      console.log("...9999...", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.no_of_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list?page=` + params.page, {
      lang_id: localStorage.getItem("langId"),
      access_token: "",
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: "https://abc.com/products/us/img",
      os_type: "WEB"
    }).then(response => {
      console.log("...888...", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list-filter?page=` + payload.page, payload).then(response => {
      console.log("############", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getBrands() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/brand`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductCategories() {
    // const reponse = await Repository.get(`${baseUrl}/product-categories`)
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cat-subcat`, {
      lang_id: localStorage.getItem("langId")
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getTotalRecords() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products/count`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsById(id) {
    console.log("....dddddd..1..", id);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("....dddddd..1.userdata.", userdata);
    console.log("....dddddd..1..parsedata", parsedata);
    console.log("....dddddd..1.access_token.", access_token);
    console.log("....dddddd..1.getDeviceId.", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"]);
    console.log("....dddddd..1.access_token.", access_token);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-detail`, {
      access_token,
      id,
      lang_id: localStorage.getItem("langId"),
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["basePathUrl"]}/product/${id}`,
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["osType"])()
    }).then(response => {
      console.log("....dddddd....", response);
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getShockSaleByid(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getProductsByCategory(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/product-categories?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrand(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByPriceRange(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(payload)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addProductToCart(payload) {
    console.log(".....56565656565656...", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async changeQty(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart/change-qty`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeOrder(payload) {
    console.log("......3333333333.......", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/placeorder`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCart(payload) {
    console.log("....aaaa....", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteCart(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/delete-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getAuctionProductByAuctionId(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createBid(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-bid`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShopDetailById(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shop-detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCheckoutInfo(payload) {
    console.log("...getCheckoutInfo... apyload..", payload);
    console.log("...getCheckoutInfo... apibaseurl..", _Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/checkout-info`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeAuctionOrder(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/checkout`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new ProductRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Repository.js":
/*!************************************!*\
  !*** ./repositories/Repository.js ***!
  \************************************/
/*! exports provided: basePostUrl, baseStoreURL, apibaseurl, basePathUrl, customHeaders, baseUrl, default, serializeQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePostUrl", function() { return basePostUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseStoreURL", function() { return baseStoreURL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "apibaseurl", function() { return apibaseurl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePathUrl", function() { return basePathUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customHeaders", function() { return customHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "serializeQuery", function() { return serializeQuery; });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseDomain = "https://beta.apinouthemes.com"; // API for products

const basePostUrl = "https://beta.apinouthemes.com"; // API for post

const baseStoreURL = "https://beta.apinouthemes.com"; // API for vendor(store)

let apibaseurlCustom = "https://qa-bigbasket.estrradoweb.com";
let basePath = "https://dev-kangtao.vercel.app";

if (true) {
  if (window.location.hostname == "uat-kangtao.vercel.app") {
    apibaseurlCustom = "https://uat-kt.estrradoweb.com";
    basePath = "https://uat-kangtao.vercel.app";
  }

  if (window.location.hostname == "qa-kangtao.vercel.app") {
    apibaseurlCustom = "https://qa-kt.estrradoweb.com";
    basePath = "https://qa-kangtao.vercel.app";
  }
}

const apibaseurl = apibaseurlCustom;
const basePathUrl = basePath;
const customHeaders = {
  Accept: "application/json"
};
const baseUrl = `${baseDomain}`;
/* harmony default export */ __webpack_exports__["default"] = (axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseUrl,
  headers: customHeaders
}));
const serializeQuery = query => {
  return Object.keys(query).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`).join("&");
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/account/saga.js":
/*!*******************************!*\
  !*** ./store/account/saga.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/repositories/AccountRepository */ "./repositories/AccountRepository.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./action */ "./store/account/action.js");
/* harmony import */ var _auth_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth/action */ "./store/auth/action.js");








const modalSuccess = type => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message: "Wellcome",
    description: "You are logged in successfully!"
  });
};

const modalOpen = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message,
    description
  });
};

function* getMyOrdersSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getMyOrders, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(response.httpcode == 200 && Object(_action__WEBPACK_IMPORTED_MODULE_5__["getMyOrdersSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerProfile({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerProfileDetail, payload);

    if (response.httpcode == 401) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Invalid Access Token! Login Again");
      next_router__WEBPACK_IMPORTED_MODULE_4___default.a.push("/account/login");
      yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_auth_action__WEBPACK_IMPORTED_MODULE_6__["logOut"])());
    }

    if (response.httpcode == 200) {
      yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerProfileSuccess"])(response.data));
    }
  } catch (err) {
    console.log(err);
  }
}

function* updateCustomerProfile({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].updateCustomerProfileDetail, payload);

    if (response.httpcode == 401) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Invalid Access Token! Login Again");
    }

    if (response.httpcode == 200 && response.data.success) {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success("Profile updated successfully!");
    }

    if (response.error) {
      response.error.map(error => {
        antd__WEBPACK_IMPORTED_MODULE_3__["notification"]["error"]({
          message: error
        });
      });
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(getCustomerProfile());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["updateCustomerProfileSuccess"])(response));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerRecentViewsSlug({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerRecentViews, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerRecentViewsSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerAddressSlug() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCustomerAddresses);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddressSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* makeDefaultAddressSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].makeDefaultAddresses, payload);

    if (response.httpcode == "200") {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success(response.data.message);
    } else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error Updating Default Address!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* deleteAddressSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].deleteAddress, payload);

    if (response.httpcode == "200") {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].success(response.data.message);
    } else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error Deleting Address!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* addAddressSaga({
  payload
}) {
  try {
    // const response = yield call(AccountRepository.addAddress, payload);
    // if (response.httpcode == "200") {
    //   message.success(response.data.message);
    // } else {
    //   message.error("Error Updating Address!");
    // }
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerAddress"])());
  } catch (err) {
    console.log(err);
  }
}

function* getChatListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getChatList, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Fetching Chats!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerChatListSuccess"])(response.data.list));
  } catch (err) {
    console.log(err);
  }
}

function* getCustomerChatMessageSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getChatMessage, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Fetching Chats!");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCustomerChatMessageSuccess"])(response.data.messages));
  } catch (err) {
    console.log(err);
  }
}

function* sendMessageToSellerSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].sendMessage, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error("Error While Sending Message!");
    } // yield put(getCustomerChatMessageSuccess(response.data.messages));

  } catch (err) {
    console.log(err);
  }
}

function* getOrderDetailsSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getOrderDetails, payload);

    if (response.httpcode == "200") {} else {
      antd__WEBPACK_IMPORTED_MODULE_3__["message"].error(response.message);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getOrderDetailsSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* cancelOrderRequestSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].cancelOrderRequest, payload);
    let data_payload = {
      access_token: payload.access_token,
      lang_id: localStorage.getItem("langId")
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getMyOrders"])(data_payload));
  } catch (err) {
    console.log(err);
  }
}

function* getTokenListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].listSupportToken, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getTokenListSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getSupportMessageSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].supportMessageByID, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getSupportMessagefromSupportIdSuccess"])(response.data));
  } catch (err) {
    console.log(err);
  }
}

function* getUserWalletDetails({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getWalletDetails, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getWalletDetailsSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Wallet Data");
    console.log(err);
  }
}

function* getAuctionDataSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getAuctionCartData, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getAuctionCartDataSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Auction Data");
    console.log(err);
  }
}

function* getAuctionOrderListSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getAuctionOrderList, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getAuctionOrderListSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Auction Data");
    console.log(err);
  }
}

function* getCountryDataSaga() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getCountry);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getCountryDataSuccess"])(response));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Country Data");
    console.log(err);
  }
}

function* getUserNotificationSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getUserNotification, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_5__["getUserNotificationsSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Notifications");
  }
}

function* getPurchaseYear({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["call"])(_repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_2__["default"].getUserPurchaseYears, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["put"])(response.httpcode == 200 && Object(_action__WEBPACK_IMPORTED_MODULE_5__["getUserPurchaseYearSuccess"])(response.data));
  } catch (err) {
    modalOpen("error", "Error", "Error While Fetching Years!");
  }
}

function* rootSaga() {
  // yield all([
  //   takeEvery(actionTypes.GET_NEW_SELLER_CHATS, getNewSellerChatsSaga),
  // ]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_CHAT_MESSAGE, getCustomerChatMessageSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].SEND_MESSAGE_TO_SELLER, sendMessageToSellerSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_CHAT_LIST, getChatListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_MY_ORDERS, getMyOrdersSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_PROFILE, getCustomerProfile)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].UPDATE_CUSTOMER_PROFILE, updateCustomerProfile)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_RECENT_VIEWS, getCustomerRecentViewsSlug)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_CUSTOMER_ADDRESS, getCustomerAddressSlug)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].MAKE_DEFAULT_ADDRESS, makeDefaultAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].ADD_ADDRESS, addAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].DELETE_ADDRESS, deleteAddressSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_ORDER_DETAILS, getOrderDetailsSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].MAKE_CANCEL_ORDER_REQUEST, cancelOrderRequestSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_TOKEN_LIST, getTokenListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_SUPPORT_MESSAGE_BY_SUPPORT_ID, getSupportMessageSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_WALLET_DETAILS, getUserWalletDetails)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_AUCTION_CART_DATA, getAuctionDataSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_AUCTION_ORDER_LIST, getAuctionOrderListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_COUNTRY_DATA, getCountryDataSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_USER_NOTIFICATION, getUserNotificationSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_1__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_5__["actionTypes"].GET_USER_PURCHASE_YEARS, getPurchaseYear)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/action.js":
/*!******************************!*\
  !*** ./store/cart/action.js ***!
  \******************************/
/*! exports provided: actionTypes, removeProductFromCartNew, selectedPaymentOption, sellerWiseMessage, usedWalletAmount, sellerWiseDiscount, grandTotalWithDiscountValue, appliedSellerVoucher, appliedPlatformVoucher, totalDiscount, fetchPlatformVoucherAction, fetchPlatformVoucherActionSuccess, getCart, getCartSuccess, getCartError, updateSelectedAddress, addItem, removeItem, increaseItemQty, decreaseItemQty, updateCartSuccess, updateCartError, clearCart, clearCartSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "actionTypes", function() { return actionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeProductFromCartNew", function() { return removeProductFromCartNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedPaymentOption", function() { return selectedPaymentOption; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseMessage", function() { return sellerWiseMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "usedWalletAmount", function() { return usedWalletAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseDiscount", function() { return sellerWiseDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "grandTotalWithDiscountValue", function() { return grandTotalWithDiscountValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedSellerVoucher", function() { return appliedSellerVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedPlatformVoucher", function() { return appliedPlatformVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalDiscount", function() { return totalDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherAction", function() { return fetchPlatformVoucherAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherActionSuccess", function() { return fetchPlatformVoucherActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCart", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartSuccess", function() { return getCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartError", function() { return getCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSelectedAddress", function() { return updateSelectedAddress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addItem", function() { return addItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeItem", function() { return removeItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "increaseItemQty", function() { return increaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decreaseItemQty", function() { return decreaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartSuccess", function() { return updateCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartError", function() { return updateCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCart", function() { return clearCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCartSuccess", function() { return clearCartSuccess; });
const actionTypes = {
  GET_CART: "GET_CART",
  GET_CART_SUCCESS: "GET_CART_SUCCESS",
  GET_CART_ERROR: "GET_CART_ERROR",
  GET_CART_TOTAL_QUANTITY: "GET_CART_TOTAL_QUANTITY",
  GET_CART_TOTAL_QUANTITY_SUCCESS: "GET_CART_TOTAL_QUANTITY_SUCCESS",
  ADD_ITEM: "ADD_ITEM",
  REMOVE_ITEM: "REMOVE_ITEM",
  REMOVE_PRODUCT_FROM_CART_NEW: "REMOVE_PRODUCT_FROM_CART_NEW",
  CLEAR_CART: "CLEAR_CART",
  CLEAR_CART_SUCCESS: "CLEAR_CART_SUCCESS",
  CLEAR_CART_ERROR: "CLEAR_CART_ERROR",
  INCREASE_QTY: "INCREASE_QTY",
  INCREASE_QTY_SUCCESS: "INCREASE_QTY_SUCCESS",
  INCREASE_QTY_ERROR: "INCREASE_QTY_ERROR",
  DECREASE_QTY: "DECREASE_QTY",
  UPDATE_CART: "UPDATE_CART",
  UPDATE_CART_SUCCESS: "UPDATE_CART_SUCCESS",
  UPDATE_CART_ERROR: "UPDATE_CART_ERROR",
  UPDATE_SELECTED_ADDRESS: "UPDATE_SELECTED_ADDRESS",
  FETCH_PLATFORM_VOUCHER: "FETCH_PLATFORM_VOUCHER",
  FETCH_PLATFORM_VOUCHER_SUCCESS: "FETCH_PLATFORM_VOUCHER_SUCCESS",
  TOTAL_DISCOUNT: "TOTAL_DISCOUNT",
  APPLIED_SELLER_VOUCHER: "APPLIED_SELLER_VOUCHER",
  APPLIED_PLATFORM_VOUCHER: "APPLIED_PLATFORM_VOUCHER",
  GRAND_TOTAL_WITH_DISCOUNT_VALUE: "GRAND_TOTAL_WITH_DISCOUNT_VALUE",
  SELLER_WISE_DISCOUNT: "SELLER_WISE_DISCOUNT",
  SELLER_WISE_MESSAGES: "SELLER_WISEMESSAGES",
  USED_WALLET_AMOUNT: "USED_WALLET_AMOUNT",
  SELECTED_PAYMENT_OPTION_BY_USER: "SELECTED_PAYMENT_OPTION_BY_USER"
};
function removeProductFromCartNew(payload) {
  return {
    type: actionTypes.REMOVE_PRODUCT_FROM_CART_NEW,
    payload
  };
}
function selectedPaymentOption(payload) {
  return {
    type: actionTypes.SELECTED_PAYMENT_OPTION_BY_USER,
    payload
  };
}
function sellerWiseMessage(payload) {
  return {
    type: actionTypes.SELLER_WISE_MESSAGES,
    payload
  };
}
function usedWalletAmount(payload) {
  return {
    type: actionTypes.USED_WALLET_AMOUNT,
    payload
  };
}
function sellerWiseDiscount(payload) {
  return {
    type: actionTypes.SELLER_WISE_DISCOUNT,
    payload
  };
}
function grandTotalWithDiscountValue(payload) {
  return {
    type: actionTypes.GRAND_TOTAL_WITH_DISCOUNT_VALUE,
    payload
  };
}
function appliedSellerVoucher(payload) {
  return {
    type: actionTypes.APPLIED_SELLER_VOUCHER,
    payload
  };
}
function appliedPlatformVoucher(payload) {
  return {
    type: actionTypes.APPLIED_PLATFORM_VOUCHER,
    payload
  };
}
function totalDiscount(payload) {
  return {
    type: actionTypes.TOTAL_DISCOUNT,
    payload
  };
}
function fetchPlatformVoucherAction() {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER
  };
}
function fetchPlatformVoucherActionSuccess(payload) {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER_SUCCESS,
    payload
  };
}
function getCart() {
  // alert("getCart")
  return {
    type: actionTypes.GET_CART
  };
}
function getCartSuccess(payload) {
  return {
    type: actionTypes.GET_CART_SUCCESS,
    payload
  };
}
function getCartError(error) {
  return {
    type: actionTypes.GET_CART_ERROR,
    error
  };
}
function updateSelectedAddress(payload) {
  // alert("call")
  console.log("..555555....", payload);
  return {
    type: actionTypes.UPDATE_SELECTED_ADDRESS,
    payload
  };
}
function addItem(payload) {
  return {
    type: actionTypes.ADD_ITEM,
    payload
  };
}
function removeItem(product) {
  return {
    type: actionTypes.REMOVE_ITEM,
    product
  };
}
function increaseItemQty(product) {
  return {
    type: actionTypes.INCREASE_QTY,
    product
  };
}
function decreaseItemQty(product) {
  return {
    type: actionTypes.DECREASE_QTY,
    product
  };
}
function updateCartSuccess(payload) {
  return {
    type: actionTypes.UPDATE_CART_SUCCESS,
    payload
  };
}
function updateCartError(payload) {
  return {
    type: actionTypes.UPDATE_CART_ERROR,
    payload
  };
}
function clearCart() {
  return {
    type: actionTypes.CLEAR_CART
  };
}
function clearCartSuccess() {
  return {
    type: actionTypes.CLEAR_CART_SUCCESS
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/saga.js":
/*!****************************!*\
  !*** ./store/cart/saga.js ***!
  \****************************/
/*! exports provided: calculateAmount, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "calculateAmount", function() { return calculateAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./action */ "./store/cart/action.js");
/* harmony import */ var _repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/CartRepository */ "./repositories/CartRepository.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");







const modalSuccess = (type, message) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description: "This product has been added to your cart!",
    duration: 1
  });
};

const modalWarning = type => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Remove A Item",
    description: "This product has been removed from your cart!",
    duration: 1
  });
};

const calculateAmount = obj => Object.values(obj).reduce((acc, {
  quantity,
  price
}) => acc + quantity * price, 0).toFixed(2);

function* getCartSaga() {
  // alert("bbbbb")
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let lang_id = localStorage.getItem("langId");
    let payload = {
      access_token,
      lang_id
    };
    console.log("...getCartSaga..payload...", payload);
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].getCartItem, payload);
    console.log("...getCartSaga..payload...", payload);
    console.log("......abcd.....", response);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartSuccess"])(response.data));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* addItemSaga({
  payload
}) {
  //  alert("aaaaaaaaaaa")
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].addProductToCart, payload);
    modalSuccess(response.status, response.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCart"])(payload.access_token));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* removeItemSaga(payload) {
  try {
    const {
      product
    } = payload;
    let localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let index = localCart.cartItems.findIndex(item => item.id === product.id);
    localCart.cartTotal = localCart.cartTotal - product.quantity;
    localCart.cartItems.splice(index, 1);
    localCart.amount = calculateAmount(localCart.cartItems);

    if (localCart.cartItems.length === 0) {
      localCart.cartItems = [];
      localCart.amount = 0;
      localCart.cartTotal = 0;
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
    modalWarning("warning");
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* increaseQtySaga(payload) {
  try {
    const {
      product
    } = payload;
    let localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let selectedItem = localCart.cartItems.find(item => item.id === product.id);

    if (selectedItem) {
      selectedItem.quantity++;
      localCart.cartTotal++;
      localCart.amount = calculateAmount(localCart.cartItems);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* decreaseItemQtySaga(payload) {
  try {
    const {
      product
    } = payload;
    const localCart = JSON.parse(JSON.parse(localStorage.getItem("persist:Kangtao")).cart);
    let selectedItem = localCart.cartItems.find(item => item.id === product.id);

    if (selectedItem) {
      selectedItem.quantity--;
      localCart.cartTotal--;
      localCart.amount = calculateAmount(localCart.cartItems);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartSuccess"])(localCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCartError"])(err));
  }
}

function* clearCartSaga() {
  try {
    const emptyCart = {
      cartItems: [],
      amount: 0,
      cartTotal: 0,
      cart: []
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["clearCartSuccess"])(emptyCart));
  } catch (err) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateCartError"])(err));
  }
}

function* fetchPlatformVoucherSaga() {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_CartRepository__WEBPACK_IMPORTED_MODULE_3__["default"].fetchPlatformVoucher);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["fetchPlatformVoucherActionSuccess"])(response.data.coupon));
  } catch (err) {}
}

function* removeFromCartNewSaga({
  payload
}) {
  try {
    const response = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_4__["default"].deleteCart, payload);

    if (response && response.httpcode == 200) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__["displayNotification"])("success", "Success", "Product Removed");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getCart"])());
  } catch (err) {
    Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_5__["displayNotification"])("error", "Error", "Error in removing Item");
  }
}

function* rootSaga() {
  // alert("cccc")
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].GET_CART, getCartSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_ITEM, addItemSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_ITEM, removeItemSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].INCREASE_QTY, increaseQtySaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].DECREASE_QTY, decreaseItemQtySaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].CLEAR_CART, clearCartSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].FETCH_PLATFORM_VOUCHER, fetchPlatformVoucherSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_PRODUCT_FROM_CART_NEW, removeFromCartNewSaga)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/wishlist/saga.js":
/*!********************************!*\
  !*** ./store/wishlist/saga.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return rootSaga; });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-saga/effects */ "./node_modules/redux-saga/dist/redux-saga-effects-npm-proxy.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./action */ "./store/wishlist/action.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/repositories/WishlistRepository */ "./repositories/WishlistRepository.js");
/* harmony import */ var _product_action__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../product/action */ "./store/product/action.js");









const modalSuccess = type => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Added to wishlisht!",
    description: "This product has been added to wishlist!"
  });
};

const modalWarning = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message: "Removed from wishlist",
    description: "This product has been removed from wishlist!"
  });
};

const modalRemoveWarning = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description
  });
};

const modalShow = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_1__["notification"][type]({
    message,
    description
  });
};

function* getWishlistListSaga() {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let lang_id = localStorage.getItem("langId");
    let payload = {
      access_token,
      lang_id
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].getProductToWishlist, payload);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])((responseData === null || responseData === void 0 ? void 0 : responseData.httpcode) == "200" && Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistListSuccess"])(responseData.data));
  } catch (err) {
    console.log(err);
  }
}

function* addItemToWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product,
      type: "web"
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToWishList, payload);
    modalShow(responseData.status, responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["getProductsById"])(product));
  } catch (err) {
    console.log(err);
  }
}

function* removeItemWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].removeProductFromWishList, payload);
    modalRemoveWarning("warning", responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["getProductsById"])(product));
  } catch (err) {
    console.log(err);
  }
}

function* clearWishlistListSaga() {
  try {
    const emptyCart = {
      wishlistItems: [],
      wishlistTotal: 0
    };
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["updateWishlistListSuccess"])(emptyCart));
  } catch (err) {
    console.log(err);
  }
}

function* addShockingSaleItemToWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product,
      type: "web"
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToWishList, payload);
    modalShow(responseData.status, responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["updateShockingsaleWishlist"])(true));
  } catch (err) {
    console.log(err);
  }
}

function* removeShockingSaleItemFromWishlistSaga({
  product
}) {
  try {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    let payload = {
      access_token,
      product_id: product
    };
    const responseData = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["call"])(_repositories_WishlistRepository__WEBPACK_IMPORTED_MODULE_6__["default"].removeProductFromWishList, payload);
    modalRemoveWarning("warning", responseData.message, responseData.data.message);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_action__WEBPACK_IMPORTED_MODULE_2__["getWishlistList"])());
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["put"])(Object(_product_action__WEBPACK_IMPORTED_MODULE_7__["updateShockingsaleWishlist"])(false));
  } catch (err) {
    console.log(err);
  }
}

function* rootSaga() {
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].GET_WISHLIST_LIST, getWishlistListSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_ITEM_WISHLISH, addItemToWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_ITEM_WISHLISH, removeItemWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].ADD_SHOCKING_SALE_ITEM_TO_WISHLIST, addShockingSaleItemToWishlistSaga)]);
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["takeEvery"])(_action__WEBPACK_IMPORTED_MODULE_2__["actionTypes"].REMOVE_SHOCKING_SALE_ITEM_FROM_WISHLIST, removeShockingSaleItemFromWishlistSaga)]);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./utilities/product-helper.js":
/*!*************************************!*\
  !*** ./utilities/product-helper.js ***!
  \*************************************/
/*! exports provided: routeWithoutRefresh, homePageProductPriceHelper, returnTotalOfCartValue, returnTotalCommission, returnTotalOfCartTaxValue, priceHelper, currencyHelperConvertToRinggit, mathFormula, divCurrency, mulCurrency, addCurrency, subCurrency, formatCurrency, getColletionBySlug, getItemBySlug, convertSlugsQueryString, StrapiProductBadge, StrapiProductPrice, StrapiProductPrice_New, featureproductprice, StrapiProductPriceExpanded, StrapiProductPriceExpandedOther, StrapiProductPriceExpandedOther1, StrapiProductThumbnail, StrapiProductThumbnailOther, StrapiProductThumbnailDetail, Shockingproductthumbnail, colorHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routeWithoutRefresh", function() { return routeWithoutRefresh; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "homePageProductPriceHelper", function() { return homePageProductPriceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartValue", function() { return returnTotalOfCartValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalCommission", function() { return returnTotalCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartTaxValue", function() { return returnTotalOfCartTaxValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "priceHelper", function() { return priceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currencyHelperConvertToRinggit", function() { return currencyHelperConvertToRinggit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mathFormula", function() { return mathFormula; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "divCurrency", function() { return divCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mulCurrency", function() { return mulCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addCurrency", function() { return addCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subCurrency", function() { return subCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatCurrency", function() { return formatCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColletionBySlug", function() { return getColletionBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getItemBySlug", function() { return getItemBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertSlugsQueryString", function() { return convertSlugsQueryString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductBadge", function() { return StrapiProductBadge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice", function() { return StrapiProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice_New", function() { return StrapiProductPrice_New; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "featureproductprice", function() { return featureproductprice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpanded", function() { return StrapiProductPriceExpanded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther", function() { return StrapiProductPriceExpandedOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther1", function() { return StrapiProductPriceExpandedOther1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnail", function() { return StrapiProductThumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailOther", function() { return StrapiProductThumbnailOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailDetail", function() { return StrapiProductThumbnailDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Shockingproductthumbnail", function() { return Shockingproductthumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorHelper", function() { return colorHelper; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "E:\\bigBasket\\utilities\\product-helper.js";

/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */






const exactMath = __webpack_require__(/*! exact-math */ "./node_modules/exact-math/dist/exact-math.node.js");

function routeWithoutRefresh(routeLink) {
  next_router__WEBPACK_IMPORTED_MODULE_5___default.a.replace(routeLink, undefined, {
    shallow: true
  });
}
function homePageProductPriceHelper(product) {
  if (product.offer_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["SAR ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this);
  }

  if (product.shock_sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["SAR ", product.shock_sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this);
  }

  if (product.sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["SAR ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["SAR ", product.actual_price ? product.actual_price : 0]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
function returnTotalOfCartValue(products) {
  let cart_total_price = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_discount_price == 0 ? next.total_actual_price : next.total_discount_price));
  }, 0);
  return cart_total_price;
}
function returnTotalCommission(products) {
  let cart_total_commission = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.commission));
  }, 0);
  return cart_total_commission;
}
function returnTotalOfCartTaxValue(products) {
  let cart_total_tax = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_tax_value));
  }, 0);
  return cart_total_tax;
}
function priceHelper(num) {
  let numberArray = num === null || num === void 0 ? void 0 : num.toString().split(",");

  if (numberArray && (numberArray === null || numberArray === void 0 ? void 0 : numberArray.length) > 0) {
    return numberArray.reduce((prev, next) => prev + next);
  } else {
    return 0;
  }
}
function currencyHelperConvertToRinggit(currencyVal) {
  return new Intl.NumberFormat("ms-MY", {
    style: "currency",
    currency: "MYR"
  }).format(priceHelper(currencyVal));
}
function mathFormula(formulaText) {
  let result = exactMath.formula(formulaText);
}
function divCurrency(firstVal, secondVal) {
  let divData = exactMath.div(priceHelper(firstVal || 0), priceHelper(secondVal || 1));
  return divData;
}
function mulCurrency(firstVal, secondVal) {
  let mulData = exactMath.mul(priceHelper(firstVal || 1), priceHelper(secondVal || 1));
  return mulData;
}
function addCurrency(currencyValFirst, currencyValSecond) {
  let addData = exactMath.add(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return addData;
}
function subCurrency(currencyValFirst, currencyValSecond) {
  let subData = exactMath.sub(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return subData;
}
function formatCurrency(num) {
  if (num !== undefined) {
    return parseFloat(num).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
  } else {}
}
function getColletionBySlug(collections, slug) {
  if (collections.length > 0) {
    const result = collections.find(item => item.slug === slug.toString());

    if (result !== undefined) {
      return result.products;
    } else {
      return [];
    }
  } else {
    return [];
  }
}
function getItemBySlug(banners, slug) {
  if (banners.length > 0) {
    const banner = banners.find(item => item.slug === slug.toString());

    if (banner !== undefined) {
      return banner;
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function convertSlugsQueryString(payload) {
  let query = "";

  if (payload.length > 0) {
    payload.forEach(item => {
      if (query === "") {
        query = `slug_in=${item}`;
      } else {
        query = query + `&slug_in=${item}`;
      }
    });
  }

  return query;
}
function StrapiProductBadge(product) {
  let view;

  if (product.badge && product.badge !== null) {
    view = product.badge.map(badge => {
      if (badge.type === "sale") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 16
        }, this);
      } else if (badge.type === "outStock") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge out-stock",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 16
        }, this);
      } else {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge hot",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 16
        }, this);
      }
    });
  }

  return view;
}
_c = StrapiProductBadge;
function StrapiProductPrice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["SAR ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 216,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["SAR ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 223,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c2 = StrapiProductPrice;
function StrapiProductPrice_New(product) {
  let view;

  if (product.sale_price !== false) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["SAR ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 235,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["SAR ", product.actual_price]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 239,
      columnNumber: 12
    }, this);
  }

  return view;
}
_c3 = StrapiProductPrice_New;
function featureproductprice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["SAR ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["SAR ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["SAR ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["SAR ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 259,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 7
    }, this);
  }

  return view;
}
function StrapiProductPriceExpanded(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["SAR ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["SAR ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 274,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
        children: "18% off"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 275,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 272,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["SAR ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 280,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c4 = StrapiProductPriceExpanded;
function StrapiProductPriceExpandedOther(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["SAR ", formatCurrency(product.offer_price ? product.offer_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["SAR ", formatCurrency(product.actual_price ? product.actual_price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 292,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 295,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 290,
    columnNumber: 5
  }, this);
  return view;
}
_c5 = StrapiProductPriceExpandedOther;
function StrapiProductPriceExpandedOther1(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["SAR ", formatCurrency(product.sale_price ? product.sale_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["SAR ", formatCurrency(product.price ? product.price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 307,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 310,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 305,
    columnNumber: 5
  }, this);
  return view;
}
_c6 = StrapiProductPriceExpandedOther1;
function StrapiProductThumbnail(product) {
  let view;

  if (product.thumbnail) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: `${_repositories_Repository__WEBPACK_IMPORTED_MODULE_3__["baseUrl"]}${product.thumbnail.url}`,
            alt: product.title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 323,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 322,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 338,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 337,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 336,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 335,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c7 = StrapiProductThumbnail;
function StrapiProductThumbnailOther(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 356,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 355,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 353,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 371,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 370,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 368,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c8 = StrapiProductThumbnailOther;
function StrapiProductThumbnailDetail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$2;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
            alt: product.product_name,
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 393,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 392,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 391,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 409,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 408,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 407,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 406,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c9 = StrapiProductThumbnailDetail;
function Shockingproductthumbnail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$3;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$3 = product.image[0]) === null || _product$image$3 === void 0 ? void 0 : _product$image$3.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 432,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 431,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 430,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 429,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 447,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 446,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 445,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 444,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c10 = Shockingproductthumbnail;
function colorHelper() {
  console.log("hello");
}

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;

$RefreshReg$(_c, "StrapiProductBadge");
$RefreshReg$(_c2, "StrapiProductPrice");
$RefreshReg$(_c3, "StrapiProductPrice_New");
$RefreshReg$(_c4, "StrapiProductPriceExpanded");
$RefreshReg$(_c5, "StrapiProductPriceExpandedOther");
$RefreshReg$(_c6, "StrapiProductPriceExpandedOther1");
$RefreshReg$(_c7, "StrapiProductThumbnail");
$RefreshReg$(_c8, "StrapiProductThumbnailOther");
$RefreshReg$(_c9, "StrapiProductThumbnailDetail");
$RefreshReg$(_c10, "Shockingproductthumbnail");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVwb3NpdG9yaWVzL0FjY291bnRSZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvQ2FydFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9Ib21lYXBpLmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9zdG9yZS9hY2NvdW50L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3N0b3JlL2NhcnQvYWN0aW9uLmpzIiwid2VicGFjazovL19OX0UvLi9zdG9yZS9jYXJ0L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3N0b3JlL3dpc2hsaXN0L3NhZ2EuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlci5qcyJdLCJuYW1lcyI6WyJtb2RhbE9wZW4iLCJ0eXBlIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwibm90aWZpY2F0aW9uIiwiQWNjb3VudFJlcG9zaXRvcnkiLCJnZXRVc2VyUHVyY2hhc2VZZWFycyIsInBheWxvYWQiLCJyZXNwb25zZSIsIlJlcG9zaXRvcnkiLCJwb3N0IiwiYXBpYmFzZXVybCIsInRoZW4iLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJjaGFuZ2VQYXNzd29yZCIsImh0dHBjb2RlIiwiY29uc29sZSIsImxvZyIsInJlZ2lzdGVyTmV3VXNlciIsImVkaXRDdXN0b21lclByb2ZpbGUiLCJnZXRDb3VudHJ5IiwiZ2V0Q2hhdExpc3QiLCJBeGlvcyIsIm1ldGhvZCIsInVybCIsImhlYWRlcnMiLCJlcnJvciIsIkpTT04iLCJzdHJpbmdpZnkiLCJnZXRDaGF0TWVzc2FnZSIsInNlbmRNZXNzYWdlIiwiZ2V0U3RhdGUiLCJnZXRDaXR5IiwiZ2V0TXlPcmRlcnMiLCJyZXBvbnNlIiwiY2FuY2VsT3JkZXJSZXF1ZXN0IiwiZ2V0T3JkZXJEZXRhaWxzIiwiZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsIiwidXNlcmRhdGEiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicGFyc2VkYXRhIiwicGFyc2UiLCJhY2Nlc3NfdG9rZW4iLCJsYW5nX2lkIiwidXBkYXRlQ3VzdG9tZXJQcm9maWxlRGV0YWlsIiwiZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3cyIsImdldEN1c3RvbWVyQWRkcmVzc2VzIiwibWFrZURlZmF1bHRBZGRyZXNzZXMiLCJ1c2VyVXBkYXRlRm9ybURhdGEiLCJGb3JtRGF0YSIsImFwcGVuZCIsImFkZHJlc3NfaWQiLCJkZWZhdWx0IiwiZGVsZXRlQWRkcmVzcyIsImFkZEFkZHJlc3MiLCJ1cGRhdGVBZGRyZXNzIiwicmV0dXJuT3JkZXJSZXF1ZXN0IiwicmV0dXJuU2hpcG1lbnREZXRhaWwiLCJjcmVhdGVTdXBwb3J0VG9rZW4iLCJsaXN0U3VwcG9ydFRva2VuIiwic3VwcG9ydE1lc3NhZ2VCeUlEIiwiYWRkVGlja2V0TWVzc2FnZSIsImdldFdhbGxldERldGFpbHMiLCJnZXRBdWN0aW9uQ2FydERhdGEiLCJnZXRVc2VyTm90aWZpY2F0aW9uIiwiZ2V0QXVjdGlvbk9yZGVyTGlzdCIsInNlbmRSZWdpc3Rlck1vYmlsZU9UUCIsInZlcmlmeVJlZ2lzdGVyTW9iaWxlT1RQIiwidmVyaWZ5Rm9yZ290T1RQIiwiQ2FydFJlcG9zaXRvcnkiLCJhZGRQcm9kdWN0VG9DYXJ0IiwicHJvZHVjdCIsInF1YW50aXR5IiwiY2FydF90eXBlIiwicHJvZHVjdF9pZCIsImdldENhcnRJdGVtIiwiZ2V0RGV2aWNlSWQiLCJ1c2VyX3Rva2VuIiwiZGV2aWNlX2lkIiwicGFnZV91cmwiLCJvc190eXBlIiwiZmV0Y2hQbGF0Zm9ybVZvdWNoZXIiLCJjaGVja1BsYXRmb3JtVm91Y2hlciIsImNoZWNrU2VsbGVyVm91Y2hlciIsIkhvbWVhcGkiLCJnZXRIb21lZGF0YSIsInBhdGhOYW1lIiwibWFrZVBhZ2VVcmwiLCJvc1R5cGUiLCJDYW5jZWxUb2tlbiIsImF4aW9zIiwic291cmNlIiwiY2FuY2VsIiwiY2FuY2VsVG9rZW4iLCJ0b2tlbiIsInN1Ym1pdFJldmlldyIsInN1Ym1pdFNlbGxlclJldmlldyIsIlByb2R1Y3RSZXBvc2l0b3J5IiwiZ2V0UmVjb3JkcyIsInBhcmFtcyIsImdldCIsImJhc2VVcmwiLCJzZXJpYWxpemVRdWVyeSIsImdldFNlYXJjaGVkUHJvZHVjdHMiLCJjYXRlZ29yeV9pZCIsImtleXdvcmQiLCJ0aXRsZV9jb250YWlucyIsIml0ZW1zIiwicHJvZHVjdHMiLCJ0b3RhbEl0ZW1zIiwibm9fb2ZfcHJvZHVjdHMiLCJnZXRQcm9kdWN0cyIsInBhZ2UiLCJ0b3RhbF9wcm9kdWN0cyIsImdldE5ld0RlYWxzUHJvZHVjdHMiLCJnZXRTaG9ja2luZ1NhbGVQcm9kdWN0cyIsInNob2NrX3NhbGUiLCJnZXRGZWF0dXJlZFByb2R1Y3RzIiwiZ2V0UHJvZHVjdHNieUZpbHRlciIsImdldE5ld0RlYWxzUHJvZHVjdHNieUZpbHRlciIsImdldFNob2NraW5nU2FsZVByb2R1Y3RzYnlGaWx0ZXIiLCJnZXRGZWF0dXJlZFByb2R1Y3RzYnlGaWx0ZXIiLCJnZXRTaG9ja2luZ1Byb2R1Y3RzIiwiZ2V0QnJhbmRzIiwiZ2V0UHJvZHVjdENhdGVnb3JpZXMiLCJnZXRUb3RhbFJlY29yZHMiLCJnZXRQcm9kdWN0c0J5SWQiLCJpZCIsImJhc2VQYXRoVXJsIiwiZ2V0U2hvY2tTYWxlQnlpZCIsImdldFByb2R1Y3RzQnlDYXRlZ29yeSIsImxlbmd0aCIsImdldFByb2R1Y3RzQnlCcmFuZCIsImdldFByb2R1Y3RzQnlCcmFuZHMiLCJxdWVyeSIsImZvckVhY2giLCJpdGVtIiwiZ2V0UHJvZHVjdHNCeVByaWNlUmFuZ2UiLCJjaGFuZ2VRdHkiLCJwbGFjZU9yZGVyIiwiZ2V0Q2FydCIsImRlbGV0ZUNhcnQiLCJnZXRBdWN0aW9uUHJvZHVjdEJ5QXVjdGlvbklkIiwiY3JlYXRlQmlkIiwiZ2V0U2hvcERldGFpbEJ5SWQiLCJnZXRDaGVja291dEluZm8iLCJwbGFjZUF1Y3Rpb25PcmRlciIsImJhc2VEb21haW4iLCJiYXNlUG9zdFVybCIsImJhc2VTdG9yZVVSTCIsImFwaWJhc2V1cmxDdXN0b20iLCJiYXNlUGF0aCIsIndpbmRvdyIsImxvY2F0aW9uIiwiaG9zdG5hbWUiLCJjdXN0b21IZWFkZXJzIiwiQWNjZXB0IiwiY3JlYXRlIiwiT2JqZWN0Iiwia2V5cyIsIm1hcCIsImtleSIsImVuY29kZVVSSUNvbXBvbmVudCIsImpvaW4iLCJtb2RhbFN1Y2Nlc3MiLCJnZXRNeU9yZGVyc1NhZ2EiLCJjYWxsIiwicHV0IiwiZ2V0TXlPcmRlcnNTdWNjZXNzIiwiZ2V0Q3VzdG9tZXJQcm9maWxlIiwicm91dGVyIiwicHVzaCIsImxvZ091dCIsImdldEN1c3RvbWVyUHJvZmlsZVN1Y2Nlc3MiLCJ1cGRhdGVDdXN0b21lclByb2ZpbGUiLCJzdWNjZXNzIiwidXBkYXRlQ3VzdG9tZXJQcm9maWxlU3VjY2VzcyIsImdldEN1c3RvbWVyUmVjZW50Vmlld3NTbHVnIiwiZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3c1N1Y2Nlc3MiLCJnZXRDdXN0b21lckFkZHJlc3NTbHVnIiwiZ2V0Q3VzdG9tZXJBZGRyZXNzU3VjY2VzcyIsIm1ha2VEZWZhdWx0QWRkcmVzc1NhZ2EiLCJnZXRDdXN0b21lckFkZHJlc3MiLCJkZWxldGVBZGRyZXNzU2FnYSIsImFkZEFkZHJlc3NTYWdhIiwiZ2V0Q2hhdExpc3RTYWdhIiwiZ2V0Q3VzdG9tZXJDaGF0TGlzdFN1Y2Nlc3MiLCJsaXN0IiwiZ2V0Q3VzdG9tZXJDaGF0TWVzc2FnZVNhZ2EiLCJnZXRDdXN0b21lckNoYXRNZXNzYWdlU3VjY2VzcyIsIm1lc3NhZ2VzIiwic2VuZE1lc3NhZ2VUb1NlbGxlclNhZ2EiLCJnZXRPcmRlckRldGFpbHNTYWdhIiwiZ2V0T3JkZXJEZXRhaWxzU3VjY2VzcyIsImNhbmNlbE9yZGVyUmVxdWVzdFNhZ2EiLCJkYXRhX3BheWxvYWQiLCJnZXRUb2tlbkxpc3RTYWdhIiwiZ2V0VG9rZW5MaXN0U3VjY2VzcyIsImdldFN1cHBvcnRNZXNzYWdlU2FnYSIsImdldFN1cHBvcnRNZXNzYWdlZnJvbVN1cHBvcnRJZFN1Y2Nlc3MiLCJnZXRVc2VyV2FsbGV0RGV0YWlscyIsImdldFdhbGxldERldGFpbHNTdWNjZXNzIiwiZ2V0QXVjdGlvbkRhdGFTYWdhIiwiZ2V0QXVjdGlvbkNhcnREYXRhU3VjY2VzcyIsImdldEF1Y3Rpb25PcmRlckxpc3RTYWdhIiwiZ2V0QXVjdGlvbk9yZGVyTGlzdFN1Y2Nlc3MiLCJnZXRDb3VudHJ5RGF0YVNhZ2EiLCJnZXRDb3VudHJ5RGF0YVN1Y2Nlc3MiLCJnZXRVc2VyTm90aWZpY2F0aW9uU2FnYSIsImdldFVzZXJOb3RpZmljYXRpb25zU3VjY2VzcyIsImdldFB1cmNoYXNlWWVhciIsImdldFVzZXJQdXJjaGFzZVllYXJTdWNjZXNzIiwicm9vdFNhZ2EiLCJhbGwiLCJ0YWtlRXZlcnkiLCJhY3Rpb25UeXBlcyIsIkdFVF9DVVNUT01FUl9DSEFUX01FU1NBR0UiLCJTRU5EX01FU1NBR0VfVE9fU0VMTEVSIiwiR0VUX0NVU1RPTUVSX0NIQVRfTElTVCIsIkdFVF9NWV9PUkRFUlMiLCJHRVRfQ1VTVE9NRVJfUFJPRklMRSIsIlVQREFURV9DVVNUT01FUl9QUk9GSUxFIiwiR0VUX0NVU1RPTUVSX1JFQ0VOVF9WSUVXUyIsIkdFVF9DVVNUT01FUl9BRERSRVNTIiwiTUFLRV9ERUZBVUxUX0FERFJFU1MiLCJBRERfQUREUkVTUyIsIkRFTEVURV9BRERSRVNTIiwiR0VUX09SREVSX0RFVEFJTFMiLCJNQUtFX0NBTkNFTF9PUkRFUl9SRVFVRVNUIiwiR0VUX1RPS0VOX0xJU1QiLCJHRVRfU1VQUE9SVF9NRVNTQUdFX0JZX1NVUFBPUlRfSUQiLCJHRVRfV0FMTEVUX0RFVEFJTFMiLCJHRVRfQVVDVElPTl9DQVJUX0RBVEEiLCJHRVRfQVVDVElPTl9PUkRFUl9MSVNUIiwiR0VUX0NPVU5UUllfREFUQSIsIkdFVF9VU0VSX05PVElGSUNBVElPTiIsIkdFVF9VU0VSX1BVUkNIQVNFX1lFQVJTIiwiR0VUX0NBUlQiLCJHRVRfQ0FSVF9TVUNDRVNTIiwiR0VUX0NBUlRfRVJST1IiLCJHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWSIsIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZX1NVQ0NFU1MiLCJBRERfSVRFTSIsIlJFTU9WRV9JVEVNIiwiUkVNT1ZFX1BST0RVQ1RfRlJPTV9DQVJUX05FVyIsIkNMRUFSX0NBUlQiLCJDTEVBUl9DQVJUX1NVQ0NFU1MiLCJDTEVBUl9DQVJUX0VSUk9SIiwiSU5DUkVBU0VfUVRZIiwiSU5DUkVBU0VfUVRZX1NVQ0NFU1MiLCJJTkNSRUFTRV9RVFlfRVJST1IiLCJERUNSRUFTRV9RVFkiLCJVUERBVEVfQ0FSVCIsIlVQREFURV9DQVJUX1NVQ0NFU1MiLCJVUERBVEVfQ0FSVF9FUlJPUiIsIlVQREFURV9TRUxFQ1RFRF9BRERSRVNTIiwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUiIsIkZFVENIX1BMQVRGT1JNX1ZPVUNIRVJfU1VDQ0VTUyIsIlRPVEFMX0RJU0NPVU5UIiwiQVBQTElFRF9TRUxMRVJfVk9VQ0hFUiIsIkFQUExJRURfUExBVEZPUk1fVk9VQ0hFUiIsIkdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUUiLCJTRUxMRVJfV0lTRV9ESVNDT1VOVCIsIlNFTExFUl9XSVNFX01FU1NBR0VTIiwiVVNFRF9XQUxMRVRfQU1PVU5UIiwiU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUiIsInJlbW92ZVByb2R1Y3RGcm9tQ2FydE5ldyIsInNlbGVjdGVkUGF5bWVudE9wdGlvbiIsInNlbGxlcldpc2VNZXNzYWdlIiwidXNlZFdhbGxldEFtb3VudCIsInNlbGxlcldpc2VEaXNjb3VudCIsImdyYW5kVG90YWxXaXRoRGlzY291bnRWYWx1ZSIsImFwcGxpZWRTZWxsZXJWb3VjaGVyIiwiYXBwbGllZFBsYXRmb3JtVm91Y2hlciIsInRvdGFsRGlzY291bnQiLCJmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbiIsImZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uU3VjY2VzcyIsImdldENhcnRTdWNjZXNzIiwiZ2V0Q2FydEVycm9yIiwidXBkYXRlU2VsZWN0ZWRBZGRyZXNzIiwiYWRkSXRlbSIsInJlbW92ZUl0ZW0iLCJpbmNyZWFzZUl0ZW1RdHkiLCJkZWNyZWFzZUl0ZW1RdHkiLCJ1cGRhdGVDYXJ0U3VjY2VzcyIsInVwZGF0ZUNhcnRFcnJvciIsImNsZWFyQ2FydCIsImNsZWFyQ2FydFN1Y2Nlc3MiLCJkdXJhdGlvbiIsIm1vZGFsV2FybmluZyIsImNhbGN1bGF0ZUFtb3VudCIsIm9iaiIsInZhbHVlcyIsInJlZHVjZSIsImFjYyIsInByaWNlIiwidG9GaXhlZCIsImdldENhcnRTYWdhIiwiYWRkSXRlbVNhZ2EiLCJzdGF0dXMiLCJyZW1vdmVJdGVtU2FnYSIsImxvY2FsQ2FydCIsImNhcnQiLCJpbmRleCIsImNhcnRJdGVtcyIsImZpbmRJbmRleCIsImNhcnRUb3RhbCIsInNwbGljZSIsImFtb3VudCIsImluY3JlYXNlUXR5U2FnYSIsInNlbGVjdGVkSXRlbSIsImZpbmQiLCJkZWNyZWFzZUl0ZW1RdHlTYWdhIiwiY2xlYXJDYXJ0U2FnYSIsImVtcHR5Q2FydCIsImZldGNoUGxhdGZvcm1Wb3VjaGVyU2FnYSIsImNvdXBvbiIsInJlbW92ZUZyb21DYXJ0TmV3U2FnYSIsImRpc3BsYXlOb3RpZmljYXRpb24iLCJtb2RhbFJlbW92ZVdhcm5pbmciLCJtb2RhbFNob3ciLCJnZXRXaXNobGlzdExpc3RTYWdhIiwicmVzcG9uc2VEYXRhIiwiV2lzaGxpc3RSZXBvc2l0b3J5IiwiZ2V0UHJvZHVjdFRvV2lzaGxpc3QiLCJnZXRXaXNobGlzdExpc3RTdWNjZXNzIiwiYWRkSXRlbVRvV2lzaGxpc3RTYWdhIiwiYWRkUHJvZHVjdFRvV2lzaExpc3QiLCJnZXRXaXNobGlzdExpc3QiLCJyZW1vdmVJdGVtV2lzaGxpc3RTYWdhIiwicmVtb3ZlUHJvZHVjdEZyb21XaXNoTGlzdCIsImNsZWFyV2lzaGxpc3RMaXN0U2FnYSIsIndpc2hsaXN0SXRlbXMiLCJ3aXNobGlzdFRvdGFsIiwidXBkYXRlV2lzaGxpc3RMaXN0U3VjY2VzcyIsImFkZFNob2NraW5nU2FsZUl0ZW1Ub1dpc2hsaXN0U2FnYSIsInVwZGF0ZVNob2NraW5nc2FsZVdpc2hsaXN0IiwicmVtb3ZlU2hvY2tpbmdTYWxlSXRlbUZyb21XaXNobGlzdFNhZ2EiLCJHRVRfV0lTSExJU1RfTElTVCIsIkFERF9JVEVNX1dJU0hMSVNIIiwiUkVNT1ZFX0lURU1fV0lTSExJU0giLCJBRERfU0hPQ0tJTkdfU0FMRV9JVEVNX1RPX1dJU0hMSVNUIiwiUkVNT1ZFX1NIT0NLSU5HX1NBTEVfSVRFTV9GUk9NX1dJU0hMSVNUIiwiZXhhY3RNYXRoIiwicmVxdWlyZSIsInJvdXRlV2l0aG91dFJlZnJlc2giLCJyb3V0ZUxpbmsiLCJSb3V0ZXIiLCJyZXBsYWNlIiwidW5kZWZpbmVkIiwic2hhbGxvdyIsImhvbWVQYWdlUHJvZHVjdFByaWNlSGVscGVyIiwib2ZmZXJfcHJpY2UiLCJhY3R1YWxfcHJpY2UiLCJzaG9ja19zYWxlX3ByaWNlIiwic2FsZV9wcmljZSIsInJldHVyblRvdGFsT2ZDYXJ0VmFsdWUiLCJjYXJ0X3RvdGFsX3ByaWNlIiwicHJldiIsIm5leHQiLCJOdW1iZXIiLCJwcmljZUhlbHBlciIsInRvdGFsX2Rpc2NvdW50X3ByaWNlIiwidG90YWxfYWN0dWFsX3ByaWNlIiwicmV0dXJuVG90YWxDb21taXNzaW9uIiwiY2FydF90b3RhbF9jb21taXNzaW9uIiwiY29tbWlzc2lvbiIsInJldHVyblRvdGFsT2ZDYXJ0VGF4VmFsdWUiLCJjYXJ0X3RvdGFsX3RheCIsInRvdGFsX3RheF92YWx1ZSIsIm51bSIsIm51bWJlckFycmF5IiwidG9TdHJpbmciLCJzcGxpdCIsImN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdCIsImN1cnJlbmN5VmFsIiwiSW50bCIsIk51bWJlckZvcm1hdCIsInN0eWxlIiwiY3VycmVuY3kiLCJmb3JtYXQiLCJtYXRoRm9ybXVsYSIsImZvcm11bGFUZXh0IiwicmVzdWx0IiwiZm9ybXVsYSIsImRpdkN1cnJlbmN5IiwiZmlyc3RWYWwiLCJzZWNvbmRWYWwiLCJkaXZEYXRhIiwiZGl2IiwibXVsQ3VycmVuY3kiLCJtdWxEYXRhIiwibXVsIiwiYWRkQ3VycmVuY3kiLCJjdXJyZW5jeVZhbEZpcnN0IiwiY3VycmVuY3lWYWxTZWNvbmQiLCJhZGREYXRhIiwiYWRkIiwic3ViQ3VycmVuY3kiLCJzdWJEYXRhIiwic3ViIiwiZm9ybWF0Q3VycmVuY3kiLCJwYXJzZUZsb2F0IiwiZ2V0Q29sbGV0aW9uQnlTbHVnIiwiY29sbGVjdGlvbnMiLCJzbHVnIiwiZ2V0SXRlbUJ5U2x1ZyIsImJhbm5lcnMiLCJiYW5uZXIiLCJjb252ZXJ0U2x1Z3NRdWVyeVN0cmluZyIsIlN0cmFwaVByb2R1Y3RCYWRnZSIsInZpZXciLCJiYWRnZSIsInZhbHVlIiwiU3RyYXBpUHJvZHVjdFByaWNlIiwiaXNfc2FsZSIsIlN0cmFwaVByb2R1Y3RQcmljZV9OZXciLCJmZWF0dXJlcHJvZHVjdHByaWNlIiwiU3RyYXBpUHJvZHVjdFByaWNlRXhwYW5kZWQiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZE90aGVyIiwib2ZmZXIiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZE90aGVyMSIsIlN0cmFwaVByb2R1Y3RUaHVtYm5haWwiLCJ0aHVtYm5haWwiLCJ0aXRsZSIsIlN0cmFwaVByb2R1Y3RUaHVtYm5haWxPdGhlciIsImltYWdlIiwicHJvZHVjdF9uYW1lIiwiU3RyYXBpUHJvZHVjdFRodW1ibmFpbERldGFpbCIsIlNob2NraW5ncHJvZHVjdHRodW1ibmFpbCIsImNvbG9ySGVscGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUEsU0FBUyxHQUFHLENBQUNDLElBQUQsRUFBT0MsT0FBUCxFQUFnQkMsV0FBaEIsS0FBZ0M7QUFDaERDLG1EQUFZLENBQUNILElBQUQsQ0FBWixDQUFtQjtBQUNqQkMsV0FEaUI7QUFFakJDO0FBRmlCLEdBQW5CO0FBSUQsQ0FMRDs7QUFPQSxNQUFNRSxpQkFBTixDQUF3QjtBQUN0QixRQUFNQyxvQkFBTixDQUEyQkMsT0FBM0IsRUFBb0M7QUFDbEMsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsMEJBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm9CLEVBT3BCQyxLQVBvQixDQU9iQyxHQUFELElBQVM7QUFDZGYsZUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLGtDQUFuQixDQUFUO0FBQ0QsS0FUb0IsQ0FBdkI7QUFVQSxXQUFPUSxRQUFQO0FBQ0Q7O0FBR0QsUUFBTVEsY0FBTixDQUFxQlQsT0FBckIsRUFBOEI7QUFDNUIsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsK0JBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsVUFBSUEsUUFBUSxDQUFDSyxJQUFULENBQWNJLFFBQWQsSUFBMEIsR0FBOUIsRUFBbUM7QUFDakMsZUFBT1QsUUFBUSxDQUFDSyxJQUFoQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU1ZLGVBQU4sQ0FBc0JiLE9BQXRCLEVBQStCO0FBQzlCO0FBQ0NXLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJaLE9BQXpCO0FBQ0EsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsd0JBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsVUFBSUEsUUFBUSxDQUFDSyxJQUFULENBQWNJLFFBQWQsSUFBMEIsR0FBOUIsRUFBbUM7QUFDakMsZUFBT1QsUUFBUSxDQUFDSyxJQUFoQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU1hLG1CQUFOLENBQTBCZCxPQUExQixFQUFtQztBQUNqQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw0QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWYsVUFBVUosUUFBVixFQUFvQjtBQUN4QixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2QsVUFBVU4sUUFBVixFQUFvQjtBQUN6QlUsYUFBTyxDQUFDQyxHQUFSLENBQVlYLFFBQVo7QUFDQSxhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FWb0IsQ0FBdkI7QUFXQSxXQUFPTCxRQUFQO0FBQ0Q7O0FBRUQsUUFBTWMsVUFBTixHQUFtQjtBQUNqQixVQUFNZCxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUFpQixHQUFFQyxzREFBVyx1QkFBOUIsRUFDcEJDLElBRG9CLENBQ2RKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixHQUE5QixFQUFtQztBQUNqQyxlQUFPVCxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBckI7QUFDRDs7QUFDRCxhQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JDLEdBQUQsSUFBU0csT0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVosQ0FQSyxDQUF2QjtBQVFBLFdBQU9QLFFBQVA7QUFDRDs7QUFFRCxRQUFNZSxXQUFOLENBQWtCaEIsT0FBbEIsRUFBMkI7QUFDekIsVUFBTUMsUUFBUSxHQUFHLE1BQU1nQiw0Q0FBSyxDQUFDO0FBQzNCQyxZQUFNLEVBQUUsTUFEbUI7QUFFM0JDLFNBQUcsRUFBRyxHQUFFZixzREFBVyx5QkFGUTtBQUczQkUsVUFBSSxFQUFFTixPQUhxQjtBQUkzQm9CLGFBQU8sRUFBRTtBQUFFLHdCQUFnQjtBQUFsQjtBQUprQixLQUFELENBQUwsQ0FNcEJmLElBTm9CLENBTWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FSb0IsRUFTcEJDLEtBVG9CLENBU2JjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVRjLENBQXZCO0FBV0EsV0FBT3BCLFFBQVA7QUFDRDs7QUFFRCxRQUFNdUIsY0FBTixDQUFxQnhCLE9BQXJCLEVBQThCO0FBQzVCLFVBQU1DLFFBQVEsR0FBRyxNQUFNZ0IsNENBQUssQ0FBQztBQUMzQkMsWUFBTSxFQUFFLE1BRG1CO0FBRTNCQyxTQUFHLEVBQUcsR0FBRWYsc0RBQVcsNEJBRlE7QUFHM0JFLFVBQUksRUFBRU4sT0FIcUI7QUFJM0JvQixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBRCxDQUFMLENBTXBCZixJQU5vQixDQU1kSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBUm9CLEVBU3BCQyxLQVRvQixDQVNiYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FUYyxDQUF2QjtBQVdBLFdBQU9wQixRQUFQO0FBQ0Q7O0FBRUQsUUFBTXdCLFdBQU4sQ0FBa0J6QixPQUFsQixFQUEyQjtBQUN6QixVQUFNQyxRQUFRLEdBQUcsTUFBTWdCLDRDQUFLLENBQUM7QUFDM0JDLFlBQU0sRUFBRSxNQURtQjtBQUUzQkMsU0FBRyxFQUFHLEdBQUVmLHNEQUFXLHlCQUZRO0FBRzNCRSxVQUFJLEVBQUVOLE9BSHFCO0FBSTNCb0IsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmtCLEtBQUQsQ0FBTCxDQU1wQmYsSUFOb0IsQ0FNZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJvQixFQVNwQkMsS0FUb0IsQ0FTYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGMsQ0FBdkI7QUFXQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU15QixRQUFOLENBQWUxQixPQUFmLEVBQXdCO0FBQ3RCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLHFCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU0wQixPQUFOLENBQWMzQixPQUFkLEVBQXVCO0FBQ3JCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLG9CQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9MLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVRvQixFQVVwQkMsS0FWb0IsQ0FVYkMsR0FBRCxJQUFTRyxPQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBT1AsUUFBUDtBQUNEOztBQUVELFFBQU0yQixXQUFOLENBQWtCNUIsT0FBbEIsRUFBMkI7QUFDekIsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywwQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1DLGtCQUFOLENBQXlCOUIsT0FBekIsRUFBa0M7QUFDaEMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1Q0FETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1FLGVBQU4sQ0FBc0IvQixPQUF0QixFQUErQjtBQUM3QixVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDRCQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0QsR0F4THFCLENBMEx0Qjs7O0FBQ0EsUUFBTUcsd0JBQU4sR0FBaUM7QUFDL0IsUUFBSUMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFVBQU1ULE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQjtBQUFFa0Msa0JBQUY7QUFBZ0JDLGFBQU8sRUFBRUwsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCO0FBQXpCLEtBRm9CLEVBSW5COUIsSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTVcsMkJBQU4sQ0FBa0N4QyxPQUFsQyxFQUEyQztBQUN6QyxVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDRCQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTVksc0JBQU4sQ0FBNkJ6QyxPQUE3QixFQUFzQztBQUNwQyxRQUFJaUMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFVBQU1ULE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyw0QkFETSxFQUVwQjtBQUFFa0Msa0JBQUY7QUFBZ0JDLGFBQU8sRUFBRUwsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCO0FBQXpCLEtBRm9CLEVBSW5COUIsSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWEsb0JBQU4sR0FBNkI7QUFDM0IsUUFBSVQsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUVBLFVBQU1ULE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQjtBQUFFa0M7QUFBRixLQUZvQixFQUluQmpDLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUNELFFBQU1jLG9CQUFOLENBQTJCM0MsT0FBM0IsRUFBb0M7QUFDbEMsUUFBSWlDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFFQSxRQUFJTSxrQkFBa0IsR0FBRyxJQUFJQyxRQUFKLEVBQXpCO0FBRUFELHNCQUFrQixDQUFDRSxNQUFuQixDQUEwQixjQUExQixFQUEwQ1IsWUFBMUM7QUFDQU0sc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLFlBQTFCLEVBQXdDOUMsT0FBTyxDQUFDK0MsVUFBaEQ7QUFDQUgsc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLFlBQTFCLEVBQXdDOUMsT0FBTyxDQUFDZ0QsT0FBaEQ7QUFFQSxVQUFNbkIsT0FBTyxHQUFHLE1BQU1aLDRDQUFLLENBQUM7QUFDMUJDLFlBQU0sRUFBRSxNQURrQjtBQUUxQkMsU0FBRyxFQUFHLEdBQUVmLHNEQUFXLCtCQUZPO0FBRzFCRSxVQUFJLEVBQUVzQyxrQkFIb0I7QUFJMUJ4QixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKaUIsS0FBRCxDQUFMLENBTW5CZixJQU5tQixDQU1iSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBUm1CLEVBU25CQyxLQVRtQixDQVNaYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FUYSxDQUF0QjtBQVVBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNb0IsYUFBTixDQUFvQmpELE9BQXBCLEVBQTZCO0FBQzNCLFFBQUlpQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBRUEsUUFBSU0sa0JBQWtCLEdBQUcsSUFBSUMsUUFBSixFQUF6QjtBQUVBRCxzQkFBa0IsQ0FBQ0UsTUFBbkIsQ0FBMEIsY0FBMUIsRUFBMENSLFlBQTFDO0FBQ0FNLHNCQUFrQixDQUFDRSxNQUFuQixDQUEwQixZQUExQixFQUF3QzlDLE9BQU8sQ0FBQytDLFVBQWhEO0FBRUEsVUFBTWxCLE9BQU8sR0FBRyxNQUFNWiw0Q0FBSyxDQUFDO0FBQzFCQyxZQUFNLEVBQUUsTUFEa0I7QUFFMUJDLFNBQUcsRUFBRyxHQUFFZixzREFBVyw4QkFGTztBQUcxQkUsVUFBSSxFQUFFc0Msa0JBSG9CO0FBSTFCeEIsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmlCLEtBQUQsQ0FBTCxDQU1uQmYsSUFObUIsQ0FNYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJtQixFQVNuQkMsS0FUbUIsQ0FTWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXFCLFVBQU4sQ0FBaUJsRCxPQUFqQixFQUEwQjtBQUN4QixVQUFNNkIsT0FBTyxHQUFHLE1BQU1aLDRDQUFLLENBQUM7QUFDMUJDLFlBQU0sRUFBRSxNQURrQjtBQUUxQkMsU0FBRyxFQUFHLEdBQUVmLHNEQUFXLDJCQUZPO0FBRzFCRSxVQUFJLEVBQUVOLE9BSG9CO0FBSTFCb0IsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmlCLEtBQUQsQ0FBTCxDQU1uQmYsSUFObUIsQ0FNYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJtQixFQVNuQkMsS0FUbUIsQ0FTWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXNCLGFBQU4sQ0FBb0JuRCxPQUFwQixFQUE2QjtBQUMzQixVQUFNNkIsT0FBTyxHQUFHLE1BQU1aLDRDQUFLLENBQUM7QUFDMUJDLFlBQU0sRUFBRSxNQURrQjtBQUUxQkMsU0FBRyxFQUFHLEdBQUVmLHNEQUFXLDRCQUZPO0FBRzFCRSxVQUFJLEVBQUVOLE9BSG9CO0FBSTFCb0IsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmlCLEtBQUQsQ0FBTCxDQU1uQmYsSUFObUIsQ0FNYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVJtQixFQVNuQkMsS0FUbUIsQ0FTWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXVCLGtCQUFOLENBQXlCcEQsT0FBekIsRUFBa0M7QUFDaEMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyw4QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU13QixvQkFBTixDQUEyQnJELE9BQTNCLEVBQW9DO0FBQ2xDLFVBQU02QixPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcscUNBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNeUIsa0JBQU4sQ0FBeUJ0RCxPQUF6QixFQUFrQztBQUNoQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw2QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJDLEtBUG9CLENBT2JjLEtBQUQsSUFBV3BCLFFBQVEsQ0FBQ29CLEtBUE4sQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU1zRCxnQkFBTixDQUF1QnZELE9BQXZCLEVBQWdDO0FBQzlCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDJCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU11RCxrQkFBTixDQUF5QnhELE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLCtCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU13RCxnQkFBTixDQUF1QnpELE9BQXZCLEVBQWdDO0FBQzlCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLGtDQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU15RCxnQkFBTixDQUF1QjFELE9BQXZCLEVBQWdDO0FBQzlCLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDZCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU0wRCxrQkFBTixDQUF5QjNELE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLDhCQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU0yRCxtQkFBTixDQUEwQjVELE9BQTFCLEVBQW1DO0FBQ2pDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLGtDQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU00RCxtQkFBTixDQUEwQjdELE9BQTFCLEVBQW1DO0FBQ2pDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLGtDQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU02RCxxQkFBTixDQUE0QjlELE9BQTVCLEVBQXFDO0FBQ25DLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLGlDQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU04RCx1QkFBTixDQUE4Qi9ELE9BQTlCLEVBQXVDO0FBQ3JDLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLG1DQURPLEVBRXJCSixPQUZxQixFQUlwQkssSUFKb0IsQ0FJZEosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5vQixFQU9wQkMsS0FQb0IsQ0FPYmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcEIsUUFBUDtBQUNEOztBQUVELFFBQU0rRCxlQUFOLENBQXNCaEUsT0FBdEIsRUFBK0I7QUFDN0IsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsdUNBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm9CLEVBT3BCQyxLQVBvQixDQU9iYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYyxDQUF2QjtBQVFBLFdBQU9wQixRQUFQO0FBQ0Q7O0FBM2RxQjs7QUFnZVQsbUVBQUlILGlCQUFKLEVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVlQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNbUUsY0FBTixDQUFxQjtBQUNuQixRQUFNQyxnQkFBTixDQUF1QjtBQUFFNUIsZ0JBQUY7QUFBZ0I2QixXQUFoQjtBQUF5QkMsWUFBekI7QUFBbUNDO0FBQW5DLEdBQXZCLEVBQXVFO0FBQ3JFLFVBQU14QyxPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsd0JBRE0sRUFFcEI7QUFBRWtDLGtCQUFGO0FBQWdCZ0MsZ0JBQVUsRUFBRUgsT0FBTyxDQUFDRyxVQUFwQztBQUFnREYsY0FBaEQ7QUFBMERDO0FBQTFELEtBRm9CLEVBSW5CaEUsSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjSSxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU9ULFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRDs7QUFDRCxhQUFPTCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FUbUIsRUFVbkJDLEtBVm1CLENBVVpjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVZhLENBQXRCO0FBV0EsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0wQyxXQUFOLENBQWtCdkUsT0FBbEIsRUFBMkI7QUFDMUI7QUFDRVcsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0M0RCxxRUFBdEM7QUFDRDdELFdBQU8sQ0FBQ0MsR0FBUixDQUFZLG9CQUFaLEVBQWlDWixPQUFqQztBQUNBLFFBQUlpQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBQ0EsVUFBTW1DLFVBQVUsR0FBR25DLFlBQW5CO0FBRUEsVUFBTXJDLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQWlCLEdBQUVDLHNEQUFXLG9CQUE5QixFQUFtRDtBQUN4RWtDLGtCQUFZLEVBQUVtQyxVQUQwRDtBQUV4RWxDLGFBQU8sRUFBQ0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCLENBRmdFO0FBR3hFdUMsZUFBUyxFQUFFRixxRUFINkQ7QUFJeEVHLGNBQVEsRUFBRSxpQ0FKOEQ7QUFLeEVDLGFBQU8sRUFBRTtBQUwrRCxLQUFuRCxDQUF2QixDQVR5QixDQWdCMUI7O0FBQ0NqRSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWixFQUE2Q1gsUUFBN0MsRUFDQ0ksSUFERCxDQUNPSixRQUFELElBQWM7QUFDckI7QUFDRyxVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUVuQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsT0FIRCxNQUdPO0FBQ0wsZUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNEO0FBQ0YsS0FURCxFQVVHQyxLQVZILENBVVVjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVZUO0FBV0EsV0FBT3BCLFFBQVA7QUFDRDs7QUFFRCxRQUFNNEUsb0JBQU4sR0FBNkI7QUFDM0IsVUFBTTVFLFFBQVEsR0FBRyxNQUFNQyxtREFBVSxDQUFDQyxJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLCtCQURPLEVBRXJCO0FBQ0VtQyxhQUFPLEVBQUU7QUFEWCxLQUZxQixFQU1wQmxDLElBTm9CLENBTWRKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUNuQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNEO0FBQ0YsS0Fab0IsRUFhcEJDLEtBYm9CLENBYWJjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWJjLENBQXZCO0FBY0EsV0FBT3BCLFFBQVA7QUFDRDs7QUFFRCxRQUFNNkUsb0JBQU4sQ0FBMkI5RSxPQUEzQixFQUFvQztBQUNsQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVywrQkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUNuQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNEO0FBQ0YsS0FWb0IsRUFXcEJDLEtBWG9CLENBV2JjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVhjLENBQXZCO0FBWUEsV0FBT3BCLFFBQVA7QUFDRDs7QUFFRCxRQUFNOEUsa0JBQU4sQ0FBeUIvRSxPQUF6QixFQUFrQztBQUNoQyxVQUFNQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw2QkFETyxFQUVyQkosT0FGcUIsRUFJcEJLLElBSm9CLENBSWRKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQVQsQ0FBY0ksUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUNuQyxlQUFPVCxRQUFRLENBQUNLLElBQWhCO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsZUFBT0wsUUFBUSxDQUFDSyxJQUFoQjtBQUNEO0FBQ0YsS0FWb0IsRUFXcEJDLEtBWG9CLENBV2JjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVhjLENBQXZCO0FBWUEsV0FBT3BCLFFBQVA7QUFDRDs7QUEvRmtCOztBQWtHTixtRUFBSWdFLGNBQUosRUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTWUsT0FBTixDQUFjO0FBQ1osUUFBTUMsV0FBTixDQUFrQkMsUUFBbEIsRUFBNEI7QUFDMUIsUUFBSWxGLE9BQU8sR0FBRztBQUNac0Msa0JBQVksRUFBRSxFQURGO0FBRVpDLGFBQU8sRUFBQ0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCLENBRkk7QUFHWnVDLGVBQVMsRUFBRUYscUVBSEM7QUFJWkcsY0FBUSxFQUFFUSw2RUFBVyxDQUFDLEdBQUQsQ0FKVDtBQUtaUCxhQUFPLEVBQUVRLHdFQUFNO0FBTEgsS0FBZDtBQVFBLFVBQU1DLFdBQVcsR0FBR0MsNENBQUssQ0FBQ0QsV0FBMUI7QUFDQSxRQUFJRSxNQUFNLEdBQUdGLFdBQVcsQ0FBQ0UsTUFBWixFQUFiO0FBRUFBLFVBQU0sSUFBSUEsTUFBTSxDQUFDQyxNQUFQLENBQWMsd0NBQWQsQ0FBVixDQVowQixDQWExQjs7QUFDQUQsVUFBTSxHQUFHRCw0Q0FBSyxDQUFDRCxXQUFOLENBQWtCRSxNQUFsQixFQUFUO0FBRUEsVUFBTTFELE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxvQkFETSxFQUVwQkosT0FGb0IsRUFHcEI7QUFDRXlGLGlCQUFXLEVBQUVGLE1BQU0sQ0FBQ0c7QUFEdEIsS0FIb0IsRUFPbkJyRixJQVBtQixDQU9iSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBVG1CLEVBVW5CQyxLQVZtQixDQVVaYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FWYSxDQUF0QixDQWhCMEIsQ0EyQjFCOztBQUNBa0UsVUFBTSxDQUFDQyxNQUFQLENBQWMsaUNBQWQ7QUFDQSxXQUFPM0QsT0FBUDtBQUNEOztBQUVELFFBQU04RCxZQUFOLENBQW1CM0YsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxtQ0FETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0rRCxrQkFBTixDQUF5QjVGLE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU02QixPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsa0NBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRCxHQXZEVyxDQXdEWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFsRVk7O0FBcUVDLG1FQUFJbUQsT0FBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6RUE7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFPQSxNQUFNYSxpQkFBTixDQUF3QjtBQUN0QixRQUFNQyxVQUFOLENBQWlCQyxNQUFqQixFQUF5QjtBQUN2QixVQUFNbEUsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDOEYsR0FBWCxDQUNuQixHQUFFQyxtREFBUSxhQUFZQyxrRUFBYyxDQUFDSCxNQUFELENBQVMsRUFEMUIsRUFHbkIxRixJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTG1CLEVBTW5CQyxLQU5tQixDQU1aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNc0UsbUJBQU4sQ0FBMEJKLE1BQTFCLEVBQWtDO0FBQ2hDLFVBQU1sRSxPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsOEJBRE0sRUFFcEI7QUFDRW1DLGFBQU8sRUFBRSxFQURYO0FBRUU2RCxpQkFBVyxFQUFFTCxNQUFNLENBQUNLLFdBRnRCO0FBR0VDLGFBQU8sRUFBRU4sTUFBTSxDQUFDTztBQUhsQixLQUZvQixFQVFuQmpHLElBUm1CLENBUWJKLFFBQUQsSUFBYztBQUNsQlUsYUFBTyxDQUFDQyxHQUFSLENBQVksWUFBWixFQUF5QlgsUUFBekI7QUFDQSxhQUFPO0FBQ0xzRyxhQUFLLEVBQUV0RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmtHLFFBRHJCO0FBRUxDLGtCQUFVLEVBQUV4RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQm9HO0FBRjFCLE9BQVA7QUFJRCxLQWRtQixFQWdCbkJuRyxLQWhCbUIsQ0FnQlpjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWhCYSxDQUF0QjtBQWlCQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTThFLFdBQU4sQ0FBa0JaLE1BQWxCLEVBQTBCO0FBQ3hCLFVBQU1sRSxPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsa0NBQWQsR0FBa0QyRixNQUFNLENBQUNhLElBRHJDLEVBRXBCO0FBQ0VyRSxhQUFPLEVBQUVMLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixDQURYO0FBRUVHLGtCQUFZLEVBQUUsRUFGaEI7QUFHRW9DLGVBQVMsRUFBRUYscUVBSGI7QUFJRUcsY0FBUSxFQUFFLGlDQUpaO0FBS0VDLGFBQU8sRUFBRTtBQUxYLEtBRm9CLEVBVW5CdkUsSUFWbUIsQ0FVYkosUUFBRCxJQUFjO0FBQ2xCVSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCWCxRQUF4QjtBQUNBLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0csUUFEckI7QUFFTEMsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBaEJtQixFQWtCbkJ0RyxLQWxCbUIsQ0FrQlpjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWxCYSxDQUF0QjtBQW1CQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWlGLG1CQUFOLENBQTBCOUcsT0FBMUIsRUFBbUMrRixNQUFuQyxFQUEyQztBQUN6QyxVQUFNbEUsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG1DQUFkLEdBQW1EMkYsTUFBTSxDQUFDYSxJQUR0QyxFQUVwQjVHLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMc0csYUFBSyxFQUFFdEcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJrRyxRQURyQjtBQUVMQyxrQkFBVSxFQUFFeEcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ1RztBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkJ0RyxLQVhtQixDQVdaYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNa0YsdUJBQU4sQ0FBOEIvRyxPQUE5QixFQUF1QytGLE1BQXZDLEVBQStDO0FBQzdDLFVBQU1sRSxPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcseUNBQWQsR0FBeUQyRixNQUFNLENBQUNhLElBRDVDLEVBRXBCNUcsT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0xzRyxhQUFLLEVBQUV0RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQjBHLFVBRHJCO0FBRUxQLGtCQUFVLEVBQUV4RyxRQUFRLENBQUNLLElBQVQsQ0FBY0EsSUFBZCxDQUFtQnVHO0FBRjFCLE9BQVA7QUFJRCxLQVRtQixFQVduQnRHLEtBWG1CLENBV1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1vRixtQkFBTixDQUEwQmpILE9BQTFCLEVBQW1DK0YsTUFBbkMsRUFBMkM7QUFDekMsVUFBTWxFLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxzQ0FBZCxHQUFzRDJGLE1BQU0sQ0FBQ2EsSUFEekMsRUFFcEI1RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0csUUFEckI7QUFFTEMsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CdEcsS0FYbUIsQ0FXWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXFGLG1CQUFOLENBQTBCbEgsT0FBMUIsRUFBbUM7QUFDakMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx5Q0FBZCxHQUF5REosT0FBTyxDQUFDNEcsSUFEN0MsRUFFcEI1RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCVSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTJCWCxRQUEzQjtBQUNBLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0csUUFEckI7QUFFTEMsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBVm1CLEVBWW5CdEcsS0FabUIsQ0FZWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWmEsQ0FBdEI7QUFhQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXNGLDJCQUFOLENBQWtDbkgsT0FBbEMsRUFBMkM7QUFDekMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxtQ0FBZCxHQUFtREosT0FBTyxDQUFDNEcsSUFEdkMsRUFFcEI1RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0csUUFEckI7QUFFTEMsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CdEcsS0FYbUIsQ0FXWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXVGLCtCQUFOLENBQXNDcEgsT0FBdEMsRUFBK0M7QUFDN0MsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx5Q0FBZCxHQUF5REosT0FBTyxDQUFDNEcsSUFEN0MsRUFFcEI1RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CMEcsVUFEckI7QUFFTFAsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CdEcsS0FYbUIsQ0FXWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXdGLDJCQUFOLENBQWtDckgsT0FBbEMsRUFBMkM7QUFDekMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyxzQ0FBZCxHQUFzREosT0FBTyxDQUFDNEcsSUFEMUMsRUFFcEI1RyxPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTHNHLGFBQUssRUFBRXRHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0csUUFEckI7QUFFTEMsa0JBQVUsRUFBRXhHLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjQSxJQUFkLENBQW1CdUc7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CdEcsS0FYbUIsQ0FXWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXlGLG1CQUFOLENBQTBCdkIsTUFBMUIsRUFBa0M7QUFDaEMsVUFBTWxFLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx5Q0FBZCxHQUF5RDJGLE1BQU0sQ0FBQ2EsSUFENUMsRUFHbkJ2RyxJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMc0csYUFBSyxFQUFFdEcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUIwRyxVQURyQjtBQUVMUCxrQkFBVSxFQUFFeEcsUUFBUSxDQUFDSyxJQUFULENBQWNBLElBQWQsQ0FBbUJ1RztBQUYxQixPQUFQO0FBSUQsS0FSbUIsRUFVbkJ0RyxLQVZtQixDQVVaYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FWYSxDQUF0QjtBQVdBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNMEYsU0FBTixHQUFrQjtBQUNoQixVQUFNMUYsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQWlCLEdBQUVDLHNEQUFXLHFCQUE5QixFQUNuQkMsSUFEbUIsQ0FDYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQUhtQixFQUluQkMsS0FKbUIsQ0FJWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTJGLG9CQUFOLEdBQTZCO0FBQzNCO0FBQ0EsVUFBTTNGLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywwQkFETSxFQUNvQjtBQUN4Q21DLGFBQU8sRUFBQ0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCO0FBRGdDLEtBRHBCLEVBS25COUIsSUFMbUIsQ0FLYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQVBtQixFQVFuQkMsS0FSbUIsQ0FRWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUmEsQ0FBdEI7QUFTQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTRGLGVBQU4sR0FBd0I7QUFDdEIsVUFBTTVGLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQzhGLEdBQVgsQ0FBZ0IsR0FBRUMsbURBQVEsaUJBQTFCLEVBQ25CNUYsSUFEbUIsQ0FDYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQUhtQixFQUluQkMsS0FKbUIsQ0FJWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTZGLGVBQU4sQ0FBc0JDLEVBQXRCLEVBQTBCO0FBQ3hCaEgsV0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQVosRUFBOEIrRyxFQUE5QjtBQUNBLFFBQUkxRixRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBQ0EzQixXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQ3FCLFFBQXRDO0FBQ0F0QixXQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWixFQUF1Q3dCLFNBQXZDO0FBQ0F6QixXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEwQzBCLFlBQTFDO0FBQ0EzQixXQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWixFQUF5QzRELHFFQUF6QztBQUNBN0QsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQVosRUFBMEMwQixZQUExQztBQUNBLFVBQU1yQyxRQUFRLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ0MsSUFBWCxDQUNwQixHQUFFQyxzREFBVyw4QkFETyxFQUVyQjtBQUNFa0Msa0JBREY7QUFFRXFGLFFBRkY7QUFHRXBGLGFBQU8sRUFBQ0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCLENBSFY7QUFJRXVDLGVBQVMsRUFBRUYscUVBSmI7QUFLRUcsY0FBUSxFQUFHLEdBQUVpRCx1REFBWSxZQUFXRCxFQUFHLEVBTHpDO0FBTUUvQyxhQUFPLEVBQUVRLHdFQUFNO0FBTmpCLEtBRnFCLEVBV3BCL0UsSUFYb0IsQ0FXZEosUUFBRCxJQUFjO0FBQ2xCVSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWixFQUE2QlgsUUFBN0I7QUFDQSxhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0Fkb0IsRUFlcEJDLEtBZm9CLENBZWJjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQWZjLENBQXZCO0FBZ0JBLFdBQU9wQixRQUFQO0FBQ0Q7O0FBRUQsUUFBTTRILGdCQUFOLENBQXVCN0gsT0FBdkIsRUFBZ0M7QUFDOUIsVUFBTUMsUUFBUSxHQUFHLE1BQU1DLG1EQUFVLENBQUNDLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsMEJBRE8sRUFFckJKLE9BRnFCLEVBSXBCSyxJQUpvQixDQUlkSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm9CLEVBT3BCQyxLQVBvQixDQU9iYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYyxDQUF2QjtBQVFBLFdBQU9wQixRQUFQO0FBQ0Q7O0FBRUQsUUFBTTZILHFCQUFOLENBQTRCOUgsT0FBNUIsRUFBcUM7QUFDbkMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQzhGLEdBQVgsQ0FDbkIsR0FBRUMsbURBQVEsNEJBQTJCakcsT0FBUSxFQUQxQixFQUduQkssSUFIbUIsQ0FHYkosUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ0ssSUFBYixFQUFtQjtBQUNqQixZQUFJTCxRQUFRLENBQUNLLElBQVQsQ0FBY3lILE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUIsaUJBQU85SCxRQUFRLENBQUNLLElBQVQsQ0FBYyxDQUFkLENBQVA7QUFDRDtBQUNGLE9BSkQsTUFJTztBQUNMLGVBQU8sSUFBUDtBQUNEO0FBQ0YsS0FYbUIsRUFZbkJDLEtBWm1CLENBWWIsTUFBTTtBQUNYLGFBQU8sSUFBUDtBQUNELEtBZG1CLENBQXRCO0FBZUEsV0FBT3NCLE9BQVA7QUFDRDs7QUFDRCxRQUFNbUcsa0JBQU4sQ0FBeUJoSSxPQUF6QixFQUFrQztBQUNoQyxVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDOEYsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxnQkFBZWpHLE9BQVEsRUFBakQsRUFDbkJLLElBRG1CLENBQ2JKLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNLLElBQWIsRUFBbUI7QUFDakIsWUFBSUwsUUFBUSxDQUFDSyxJQUFULENBQWN5SCxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQzVCLGlCQUFPOUgsUUFBUSxDQUFDSyxJQUFULENBQWMsQ0FBZCxDQUFQO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTCxlQUFPLElBQVA7QUFDRDtBQUNGLEtBVG1CLEVBVW5CQyxLQVZtQixDQVViLE1BQU07QUFDWCxhQUFPLElBQVA7QUFDRCxLQVptQixDQUF0QjtBQWFBLFdBQU9zQixPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9HLG1CQUFOLENBQTBCakksT0FBMUIsRUFBbUM7QUFDakMsUUFBSWtJLEtBQUssR0FBRyxFQUFaO0FBQ0FsSSxXQUFPLENBQUNtSSxPQUFSLENBQWlCQyxJQUFELElBQVU7QUFDeEIsVUFBSUYsS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDaEJBLGFBQUssR0FBSSxTQUFRRSxJQUFLLEVBQXRCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xGLGFBQUssR0FBR0EsS0FBSyxHQUFJLFVBQVNFLElBQUssRUFBL0I7QUFDRDtBQUNGLEtBTkQ7QUFPQSxVQUFNdkcsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDOEYsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxXQUFVaUMsS0FBTSxFQUExQyxFQUNuQjdILElBRG1CLENBQ2JKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FIbUIsRUFJbkJDLEtBSm1CLENBSVpjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQUphLENBQXRCO0FBS0EsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU1vRyxtQkFBTixDQUEwQmpJLE9BQTFCLEVBQW1DO0FBQ2pDLFFBQUlrSSxLQUFLLEdBQUcsRUFBWjtBQUNBbEksV0FBTyxDQUFDbUksT0FBUixDQUFpQkMsSUFBRCxJQUFVO0FBQ3hCLFVBQUlGLEtBQUssS0FBSyxFQUFkLEVBQWtCO0FBQ2hCQSxhQUFLLEdBQUksU0FBUUUsSUFBSyxFQUF0QjtBQUNELE9BRkQsTUFFTztBQUNMRixhQUFLLEdBQUdBLEtBQUssR0FBSSxVQUFTRSxJQUFLLEVBQS9CO0FBQ0Q7QUFDRixLQU5EO0FBT0EsVUFBTXZHLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQzhGLEdBQVgsQ0FBZ0IsR0FBRUMsbURBQVEsV0FBVWlDLEtBQU0sRUFBMUMsRUFDbkI3SCxJQURtQixDQUNiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBSG1CLEVBSW5CQyxLQUptQixDQUlaYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FKYSxDQUF0QjtBQUtBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNd0csdUJBQU4sQ0FBOEJySSxPQUE5QixFQUF1QztBQUNyQyxVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDOEYsR0FBWCxDQUNuQixHQUFFQyxtREFBUSxhQUFZQyxrRUFBYyxDQUFDbEcsT0FBRCxDQUFVLEVBRDNCLEVBR25CSyxJQUhtQixDQUdiSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTG1CLEVBTW5CQyxLQU5tQixDQU1aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNcUMsZ0JBQU4sQ0FBdUJsRSxPQUF2QixFQUFnQztBQUM5QlcsV0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBcUNaLE9BQXJDO0FBQ0EsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx3QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUNELFFBQU15RyxTQUFOLENBQWdCdEksT0FBaEIsRUFBeUI7QUFDdkIsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywrQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0wRyxVQUFOLENBQWlCdkksT0FBakIsRUFBMEI7QUFDeEJXLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDWixPQUF0QztBQUNBLFVBQU02QixPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsZ0NBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNMkcsT0FBTixDQUFjeEksT0FBZCxFQUF1QjtBQUNyQlcsV0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQlosT0FBM0I7QUFDQSxVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG9CQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTRHLFVBQU4sQ0FBaUJ6SSxPQUFqQixFQUEwQjtBQUN4QixVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDJCQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTZHLDRCQUFOLENBQW1DMUksT0FBbkMsRUFBNEM7QUFDMUMsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU04RyxTQUFOLENBQWdCM0ksT0FBaEIsRUFBeUI7QUFDdkIsVUFBTTZCLE9BQU8sR0FBRyxNQUFNM0IsbURBQVUsQ0FBQ0MsSUFBWCxDQUNuQixHQUFFQyxzREFBVywwQkFETSxFQUVwQkosT0FGb0IsRUFJbkJLLElBSm1CLENBSWJKLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNLLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJDLEtBUG1CLENBT1pjLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBT1EsT0FBUDtBQUNEOztBQUVELFFBQU0rRyxpQkFBTixDQUF3QjVJLE9BQXhCLEVBQWlDO0FBQy9CLFVBQU02QixPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsMkJBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNZ0gsZUFBTixDQUFzQjdJLE9BQXRCLEVBQStCO0FBQzdCVyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUE4Q1osT0FBOUM7QUFDQVcsV0FBTyxDQUFDQyxHQUFSLENBQVksb0NBQVosRUFBaURSLHNEQUFqRDtBQUNBLFVBQU15QixPQUFPLEdBQUcsTUFBTTNCLG1EQUFVLENBQUNDLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsbUNBRE0sRUFFcEJKLE9BRm9CLEVBSW5CSyxJQUptQixDQUliSixRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDSyxJQUFoQjtBQUNELEtBTm1CLEVBT25CQyxLQVBtQixDQU9aYyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUYsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU9RLE9BQVA7QUFDRDs7QUFFRCxRQUFNaUgsaUJBQU4sQ0FBd0I5SSxPQUF4QixFQUFpQztBQUMvQixVQUFNNkIsT0FBTyxHQUFHLE1BQU0zQixtREFBVSxDQUFDQyxJQUFYLENBQ25CLEdBQUVDLHNEQUFXLGdDQURNLEVBRXBCSixPQUZvQixFQUluQkssSUFKbUIsQ0FJYkosUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ0ssSUFBaEI7QUFDRCxLQU5tQixFQU9uQkMsS0FQbUIsQ0FPWmMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWVGLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPUSxPQUFQO0FBQ0Q7O0FBM2NxQjs7QUE4Y1QsbUVBQUlnRSxpQkFBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0ZEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE1BQU1rRCxVQUFVLEdBQUcsK0JBQW5CLEMsQ0FBb0Q7O0FBQzdDLE1BQU1DLFdBQVcsR0FBRywrQkFBcEIsQyxDQUFxRDs7QUFDckQsTUFBTUMsWUFBWSxHQUFHLCtCQUFyQixDLENBQXNEOztBQUU3RCxJQUFJQyxnQkFBZ0IsR0FBRyxzQ0FBdkI7QUFDQSxJQUFJQyxRQUFRLEdBQUcsZ0NBQWY7O0FBQ0EsVUFBbUM7QUFDakMsTUFBSUMsTUFBTSxDQUFDQyxRQUFQLENBQWdCQyxRQUFoQixJQUE0Qix3QkFBaEMsRUFBMEQ7QUFDeERKLG9CQUFnQixHQUFHLGdDQUFuQjtBQUNBQyxZQUFRLEdBQUcsZ0NBQVg7QUFDRDs7QUFDRCxNQUFJQyxNQUFNLENBQUNDLFFBQVAsQ0FBZ0JDLFFBQWhCLElBQTRCLHVCQUFoQyxFQUF5RDtBQUN2REosb0JBQWdCLEdBQUcsK0JBQW5CO0FBQ0FDLFlBQVEsR0FBRywrQkFBWDtBQUNEO0FBQ0Y7O0FBRU0sTUFBTS9JLFVBQVUsR0FBRzhJLGdCQUFuQjtBQUNBLE1BQU10QixXQUFXLEdBQUd1QixRQUFwQjtBQUVBLE1BQU1JLGFBQWEsR0FBRztBQUMzQkMsUUFBTSxFQUFFO0FBRG1CLENBQXRCO0FBSUEsTUFBTXZELE9BQU8sR0FBSSxHQUFFOEMsVUFBVyxFQUE5QjtBQUVRekQsMkdBQUssQ0FBQ21FLE1BQU4sQ0FBYTtBQUMxQnhELFNBRDBCO0FBRTFCN0UsU0FBTyxFQUFFbUk7QUFGaUIsQ0FBYixDQUFmO0FBS08sTUFBTXJELGNBQWMsR0FBSWdDLEtBQUQsSUFBVztBQUN2QyxTQUFPd0IsTUFBTSxDQUFDQyxJQUFQLENBQVl6QixLQUFaLEVBQ0owQixHQURJLENBRUZDLEdBQUQsSUFBVSxHQUFFQyxrQkFBa0IsQ0FBQ0QsR0FBRCxDQUFNLElBQUdDLGtCQUFrQixDQUFDNUIsS0FBSyxDQUFDMkIsR0FBRCxDQUFOLENBQWEsRUFGbkUsRUFJSkUsSUFKSSxDQUlDLEdBSkQsQ0FBUDtBQUtELENBTk07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQXNCQTs7QUFFQSxNQUFNQyxZQUFZLEdBQUl0SyxJQUFELElBQVU7QUFDN0JHLG1EQUFZLENBQUNILElBQUQsQ0FBWixDQUFtQjtBQUNqQkMsV0FBTyxFQUFFLFVBRFE7QUFFakJDLGVBQVcsRUFBRTtBQUZJLEdBQW5CO0FBSUQsQ0FMRDs7QUFNQSxNQUFNSCxTQUFTLEdBQUcsQ0FBQ0MsSUFBRCxFQUFPQyxPQUFQLEVBQWdCQyxXQUFoQixLQUFnQztBQUNoREMsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLFVBQVVxSyxlQUFWLENBQTBCO0FBQUVqSztBQUFGLENBQTFCLEVBQXVDO0FBQ3JDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQzhCLFdBQW5CLEVBQWdDNUIsT0FBaEMsQ0FBM0I7QUFDQSxVQUFNbUssOERBQUcsQ0FBQ2xLLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixHQUFyQixJQUE0QjBKLGtFQUFrQixDQUFDbkssUUFBUSxDQUFDSyxJQUFWLENBQS9DLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVNkosa0JBQVYsQ0FBNkI7QUFBRXJLO0FBQUYsQ0FBN0IsRUFBMEM7QUFDeEMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FDekJwSyx1RUFBaUIsQ0FBQ2tDLHdCQURPLEVBRXpCaEMsT0FGeUIsQ0FBM0I7O0FBS0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCZixrREFBTyxDQUFDMEIsS0FBUixDQUFjLG1DQUFkO0FBQ0FpSix3REFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVo7QUFDQSxZQUFNSiw4REFBRyxDQUFDSywyREFBTSxFQUFQLENBQVQ7QUFDRDs7QUFDRCxRQUFJdkssUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCLFlBQU15Siw4REFBRyxDQUFDTSx5RUFBeUIsQ0FBQ3hLLFFBQVEsQ0FBQ0ssSUFBVixDQUExQixDQUFUO0FBQ0Q7QUFDRixHQWRELENBY0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVa0sscUJBQVYsQ0FBZ0M7QUFBRTFLO0FBQUYsQ0FBaEMsRUFBNkM7QUFDM0MsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FDekJwSyx1RUFBaUIsQ0FBQzBDLDJCQURPLEVBRXpCeEMsT0FGeUIsQ0FBM0I7O0FBS0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXpCLEVBQThCO0FBQzVCZixrREFBTyxDQUFDMEIsS0FBUixDQUFjLG1DQUFkO0FBQ0Q7O0FBRUQsUUFBSXBCLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixHQUFyQixJQUE0QlQsUUFBUSxDQUFDSyxJQUFULENBQWNxSyxPQUE5QyxFQUF1RDtBQUNyRGhMLGtEQUFPLENBQUNnTCxPQUFSLENBQWdCLCtCQUFoQjtBQUNEOztBQUVELFFBQUkxSyxRQUFRLENBQUNvQixLQUFiLEVBQW9CO0FBQ2xCcEIsY0FBUSxDQUFDb0IsS0FBVCxDQUFldUksR0FBZixDQUFvQnZJLEtBQUQsSUFBVztBQUM1QnhCLHlEQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCRixpQkFBTyxFQUFFMEI7QUFEVyxTQUF0QjtBQUdELE9BSkQ7QUFLRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ0Usa0JBQWtCLEVBQW5CLENBQVQ7QUFDQSxVQUFNRiw4REFBRyxDQUFDUyw0RUFBNEIsQ0FBQzNLLFFBQUQsQ0FBN0IsQ0FBVDtBQUNELEdBdkJELENBdUJFLE9BQU9PLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVXFLLDBCQUFWLENBQXFDO0FBQUU3SztBQUFGLENBQXJDLEVBQWtEO0FBQ2hELE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQ3pCcEssdUVBQWlCLENBQUMyQyxzQkFETyxFQUV6QnpDLE9BRnlCLENBQTNCO0FBSUEsVUFBTW1LLDhEQUFHLENBQUNXLDZFQUE2QixDQUFDN0ssUUFBUSxDQUFDSyxJQUFWLENBQTlCLENBQVQ7QUFDRCxHQU5ELENBTUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVdUssc0JBQVYsR0FBbUM7QUFDakMsTUFBSTtBQUNGLFVBQU05SyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQzRDLG9CQUFuQixDQUEzQjtBQUNBLFVBQU15SCw4REFBRyxDQUFDYSx5RUFBeUIsQ0FBQy9LLFFBQVEsQ0FBQ0ssSUFBVixDQUExQixDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVXlLLHNCQUFWLENBQWlDO0FBQUVqTDtBQUFGLENBQWpDLEVBQThDO0FBQzVDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQ3pCcEssdUVBQWlCLENBQUM2QyxvQkFETyxFQUV6QjNDLE9BRnlCLENBQTNCOztBQUlBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQztBQUM5QmYsa0RBQU8sQ0FBQ2dMLE9BQVIsQ0FBZ0IxSyxRQUFRLENBQUNLLElBQVQsQ0FBY1gsT0FBOUI7QUFDRCxLQUZELE1BRU87QUFDTEEsa0RBQU8sQ0FBQzBCLEtBQVIsQ0FBYyxpQ0FBZDtBQUNEOztBQUNELFVBQU04SSw4REFBRyxDQUFDZSxrRUFBa0IsRUFBbkIsQ0FBVDtBQUNELEdBWEQsQ0FXRSxPQUFPMUssR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVMkssaUJBQVYsQ0FBNEI7QUFBRW5MO0FBQUYsQ0FBNUIsRUFBeUM7QUFDdkMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDbUQsYUFBbkIsRUFBa0NqRCxPQUFsQyxDQUEzQjs7QUFDQSxRQUFJQyxRQUFRLENBQUNTLFFBQVQsSUFBcUIsS0FBekIsRUFBZ0M7QUFDOUJmLGtEQUFPLENBQUNnTCxPQUFSLENBQWdCMUssUUFBUSxDQUFDSyxJQUFULENBQWNYLE9BQTlCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLGtEQUFPLENBQUMwQixLQUFSLENBQWMseUJBQWQ7QUFDRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ2Usa0VBQWtCLEVBQW5CLENBQVQ7QUFDRCxHQVJELENBUUUsT0FBTzFLLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTRLLGNBQVYsQ0FBeUI7QUFBRXBMO0FBQUYsQ0FBekIsRUFBc0M7QUFDcEMsTUFBSTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQU1tSyw4REFBRyxDQUFDZSxrRUFBa0IsRUFBbkIsQ0FBVDtBQUNELEdBUkQsQ0FRRSxPQUFPMUssR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVNkssZUFBVixDQUEwQjtBQUFFckw7QUFBRixDQUExQixFQUF1QztBQUNyQyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1pSywrREFBSSxDQUFDcEssdUVBQWlCLENBQUNrQixXQUFuQixFQUFnQ2hCLE9BQWhDLENBQTNCOztBQUNBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQyxDQUMvQixDQURELE1BQ087QUFDTGYsa0RBQU8sQ0FBQzBCLEtBQVIsQ0FBYyw2QkFBZDtBQUNEOztBQUVELFVBQU04SSw4REFBRyxDQUFDbUIsMEVBQTBCLENBQUNyTCxRQUFRLENBQUNLLElBQVQsQ0FBY2lMLElBQWYsQ0FBM0IsQ0FBVDtBQUNELEdBUkQsQ0FRRSxPQUFPL0ssR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVZ0wsMEJBQVYsQ0FBcUM7QUFBRXhMO0FBQUYsQ0FBckMsRUFBa0Q7QUFDaEQsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDMEIsY0FBbkIsRUFBbUN4QixPQUFuQyxDQUEzQjs7QUFDQSxRQUFJQyxRQUFRLENBQUNTLFFBQVQsSUFBcUIsS0FBekIsRUFBZ0MsQ0FDL0IsQ0FERCxNQUNPO0FBQ0xmLGtEQUFPLENBQUMwQixLQUFSLENBQWMsNkJBQWQ7QUFDRDs7QUFDRCxVQUFNOEksOERBQUcsQ0FBQ3NCLDZFQUE2QixDQUFDeEwsUUFBUSxDQUFDSyxJQUFULENBQWNvTCxRQUFmLENBQTlCLENBQVQ7QUFDRCxHQVBELENBT0UsT0FBT2xMLEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVW1MLHVCQUFWLENBQWtDO0FBQUUzTDtBQUFGLENBQWxDLEVBQStDO0FBQzdDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQzJCLFdBQW5CLEVBQWdDekIsT0FBaEMsQ0FBM0I7O0FBQ0EsUUFBSUMsUUFBUSxDQUFDUyxRQUFULElBQXFCLEtBQXpCLEVBQWdDLENBQy9CLENBREQsTUFDTztBQUNMZixrREFBTyxDQUFDMEIsS0FBUixDQUFjLDhCQUFkO0FBQ0QsS0FMQyxDQU1GOztBQUNELEdBUEQsQ0FPRSxPQUFPYixHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVVvTCxtQkFBVixDQUE4QjtBQUFFNUw7QUFBRixDQUE5QixFQUEyQztBQUN6QyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1pSywrREFBSSxDQUFDcEssdUVBQWlCLENBQUNpQyxlQUFuQixFQUFvQy9CLE9BQXBDLENBQTNCOztBQUNBLFFBQUlDLFFBQVEsQ0FBQ1MsUUFBVCxJQUFxQixLQUF6QixFQUFnQyxDQUMvQixDQURELE1BQ087QUFDTGYsa0RBQU8sQ0FBQzBCLEtBQVIsQ0FBY3BCLFFBQVEsQ0FBQ04sT0FBdkI7QUFDRDs7QUFDRCxVQUFNd0ssOERBQUcsQ0FBQzBCLHNFQUFzQixDQUFDNUwsUUFBUSxDQUFDSyxJQUFWLENBQXZCLENBQVQ7QUFDRCxHQVBELENBT0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVc0wsc0JBQVYsQ0FBaUM7QUFBRTlMO0FBQUYsQ0FBakMsRUFBOEM7QUFDNUMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDZ0Msa0JBQW5CLEVBQXVDOUIsT0FBdkMsQ0FBM0I7QUFDQSxRQUFJK0wsWUFBWSxHQUFHO0FBQ2pCekosa0JBQVksRUFBRXRDLE9BQU8sQ0FBQ3NDLFlBREw7QUFFakJDLGFBQU8sRUFBQ0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCO0FBRlMsS0FBbkI7QUFJQSxVQUFNZ0ksOERBQUcsQ0FBQ3ZJLDJEQUFXLENBQUNtSyxZQUFELENBQVosQ0FBVDtBQUNELEdBUEQsQ0FPRSxPQUFPdkwsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVd0wsZ0JBQVYsQ0FBMkI7QUFBRWhNO0FBQUYsQ0FBM0IsRUFBd0M7QUFDdEMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDeUQsZ0JBQW5CLEVBQXFDdkQsT0FBckMsQ0FBM0I7QUFDQSxVQUFNbUssOERBQUcsQ0FBQzhCLG1FQUFtQixDQUFDaE0sUUFBUSxDQUFDSyxJQUFWLENBQXBCLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVMEwscUJBQVYsQ0FBZ0M7QUFBRWxNO0FBQUYsQ0FBaEMsRUFBNkM7QUFDM0MsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDMEQsa0JBQW5CLEVBQXVDeEQsT0FBdkMsQ0FBM0I7QUFDQSxVQUFNbUssOERBQUcsQ0FBQ2dDLHFGQUFxQyxDQUFDbE0sUUFBUSxDQUFDSyxJQUFWLENBQXRDLENBQVQ7QUFDRCxHQUhELENBR0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVNEwsb0JBQVYsQ0FBK0I7QUFBRXBNO0FBQUYsQ0FBL0IsRUFBNEM7QUFDMUMsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ3BLLHVFQUFpQixDQUFDNEQsZ0JBQW5CLEVBQXFDMUQsT0FBckMsQ0FBM0I7QUFFQSxVQUFNbUssOERBQUcsQ0FBQ2tDLHVFQUF1QixDQUFDcE0sUUFBUSxDQUFDSyxJQUFWLENBQXhCLENBQVQ7QUFDRCxHQUpELENBSUUsT0FBT0UsR0FBUCxFQUFZO0FBQ1pmLGFBQVMsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQixrQ0FBbkIsQ0FBVDtBQUNBa0IsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVU4TCxrQkFBVixDQUE2QjtBQUFFdE07QUFBRixDQUE3QixFQUEwQztBQUN4QyxNQUFJO0FBQ0YsVUFBTUMsUUFBUSxHQUFHLE1BQU1pSywrREFBSSxDQUFDcEssdUVBQWlCLENBQUM2RCxrQkFBbkIsRUFBdUMzRCxPQUF2QyxDQUEzQjtBQUNBLFVBQU1tSyw4REFBRyxDQUFDb0MseUVBQXlCLENBQUN0TSxRQUFRLENBQUNLLElBQVYsQ0FBMUIsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPRSxHQUFQLEVBQVk7QUFDWmYsYUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG1DQUFuQixDQUFUO0FBQ0FrQixXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVWdNLHVCQUFWLENBQWtDO0FBQUV4TTtBQUFGLENBQWxDLEVBQStDO0FBQzdDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQytELG1CQUFuQixFQUF3QzdELE9BQXhDLENBQTNCO0FBQ0EsVUFBTW1LLDhEQUFHLENBQUNzQywwRUFBMEIsQ0FBQ3hNLFFBQVEsQ0FBQ0ssSUFBVixDQUEzQixDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaZixhQUFTLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsbUNBQW5CLENBQVQ7QUFDQWtCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVa00sa0JBQVYsR0FBK0I7QUFDN0IsTUFBSTtBQUNGLFVBQU16TSxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQ2lCLFVBQW5CLENBQTNCO0FBQ0EsVUFBTW9KLDhEQUFHLENBQUN3QyxxRUFBcUIsQ0FBQzFNLFFBQUQsQ0FBdEIsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPTyxHQUFQLEVBQVk7QUFDWmYsYUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG1DQUFuQixDQUFUO0FBQ0FrQixXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVW9NLHVCQUFWLENBQWtDO0FBQUU1TTtBQUFGLENBQWxDLEVBQStDO0FBQzdDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNwSyx1RUFBaUIsQ0FBQzhELG1CQUFuQixFQUF3QzVELE9BQXhDLENBQTNCO0FBQ0EsVUFBTW1LLDhEQUFHLENBQUMwQywyRUFBMkIsQ0FBQzVNLFFBQVEsQ0FBQ0ssSUFBVixDQUE1QixDQUFUO0FBQ0QsR0FIRCxDQUdFLE9BQU9FLEdBQVAsRUFBWTtBQUNaZixhQUFTLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsb0NBQW5CLENBQVQ7QUFDRDtBQUNGOztBQUVELFVBQVVxTixlQUFWLENBQTBCO0FBQUU5TTtBQUFGLENBQTFCLEVBQXVDO0FBQ3JDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQ3pCcEssdUVBQWlCLENBQUNDLG9CQURPLEVBRXpCQyxPQUZ5QixDQUEzQjtBQUlBLFVBQU1tSyw4REFBRyxDQUNQbEssUUFBUSxDQUFDUyxRQUFULElBQXFCLEdBQXJCLElBQTRCcU0sMEVBQTBCLENBQUM5TSxRQUFRLENBQUNLLElBQVYsQ0FEL0MsQ0FBVDtBQUdELEdBUkQsQ0FRRSxPQUFPRSxHQUFQLEVBQVk7QUFDWmYsYUFBUyxDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLDZCQUFuQixDQUFUO0FBQ0Q7QUFDRjs7QUFFYyxVQUFVdU4sUUFBVixHQUFxQjtBQUNsQztBQUNBO0FBQ0E7QUFDQSxRQUFNQyw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQ1BDLG1EQUFXLENBQUNDLHlCQURMLEVBRVA1QiwwQkFGTyxDQURELENBQUQsQ0FBVDtBQU1BLFFBQU15Qiw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNFLHNCQUFiLEVBQXFDMUIsdUJBQXJDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTXNCLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ0csc0JBQWIsRUFBcUNqQyxlQUFyQyxDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU00Qiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNJLGFBQWIsRUFBNEJ0RCxlQUE1QixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1nRCw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNLLG9CQUFiLEVBQW1DbkQsa0JBQW5DLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTTRDLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ00sdUJBQWIsRUFBc0MvQyxxQkFBdEMsQ0FERCxDQUFELENBQVQ7QUFHQSxRQUFNdUMsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUNQQyxtREFBVyxDQUFDTyx5QkFETCxFQUVQN0MsMEJBRk8sQ0FERCxDQUFELENBQVQ7QUFNQSxRQUFNb0MsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDUSxvQkFBYixFQUFtQzVDLHNCQUFuQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1rQyw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNTLG9CQUFiLEVBQW1DM0Msc0JBQW5DLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTWdDLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ1UsV0FBYixFQUEwQnpDLGNBQTFCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTTZCLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ1csY0FBYixFQUE2QjNDLGlCQUE3QixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU04Qiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNZLGlCQUFiLEVBQWdDbkMsbUJBQWhDLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTXFCLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ2EseUJBQWIsRUFBd0NsQyxzQkFBeEMsQ0FERCxDQUFELENBQVQ7QUFHQSxRQUFNbUIsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDYyxjQUFiLEVBQTZCakMsZ0JBQTdCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTWlCLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FDUEMsbURBQVcsQ0FBQ2UsaUNBREwsRUFFUGhDLHFCQUZPLENBREQsQ0FBRCxDQUFUO0FBTUEsUUFBTWUsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDZ0Isa0JBQWIsRUFBaUMvQixvQkFBakMsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNYSw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNpQixxQkFBYixFQUFvQzlCLGtCQUFwQyxDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1XLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ2tCLHNCQUFiLEVBQXFDN0IsdUJBQXJDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTVMsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDbUIsZ0JBQWIsRUFBK0I1QixrQkFBL0IsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNTyw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQUNDLG1EQUFXLENBQUNvQixxQkFBYixFQUFvQzNCLHVCQUFwQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1LLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ3FCLHVCQUFiLEVBQXNDMUIsZUFBdEMsQ0FBVixDQUFELENBQVQ7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDalhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU8sTUFBTUssV0FBVyxHQUFHO0FBQ3pCc0IsVUFBUSxFQUFFLFVBRGU7QUFFekJDLGtCQUFnQixFQUFFLGtCQUZPO0FBR3pCQyxnQkFBYyxFQUFFLGdCQUhTO0FBS3pCQyx5QkFBdUIsRUFBRSx5QkFMQTtBQU16QkMsaUNBQStCLEVBQUUsaUNBTlI7QUFRekJDLFVBQVEsRUFBRSxVQVJlO0FBU3pCQyxhQUFXLEVBQUUsYUFUWTtBQVV6QkMsOEJBQTRCLEVBQUUsOEJBVkw7QUFZekJDLFlBQVUsRUFBRSxZQVphO0FBYXpCQyxvQkFBa0IsRUFBRSxvQkFiSztBQWN6QkMsa0JBQWdCLEVBQUUsa0JBZE87QUFnQnpCQyxjQUFZLEVBQUUsY0FoQlc7QUFpQnpCQyxzQkFBb0IsRUFBRSxzQkFqQkc7QUFrQnpCQyxvQkFBa0IsRUFBRSxvQkFsQks7QUFvQnpCQyxjQUFZLEVBQUUsY0FwQlc7QUFxQnpCQyxhQUFXLEVBQUUsYUFyQlk7QUF1QnpCQyxxQkFBbUIsRUFBRSxxQkF2Qkk7QUF3QnpCQyxtQkFBaUIsRUFBRSxtQkF4Qk07QUEwQnpCQyx5QkFBdUIsRUFBRSx5QkExQkE7QUE0QnpCQyx3QkFBc0IsRUFBRSx3QkE1QkM7QUE2QnpCQyxnQ0FBOEIsRUFBRSxnQ0E3QlA7QUErQnpCQyxnQkFBYyxFQUFFLGdCQS9CUztBQWlDekJDLHdCQUFzQixFQUFFLHdCQWpDQztBQW1DekJDLDBCQUF3QixFQUFFLDBCQW5DRDtBQXFDekJDLGlDQUErQixFQUFFLGlDQXJDUjtBQXVDekJDLHNCQUFvQixFQUFFLHNCQXZDRztBQXlDekJDLHNCQUFvQixFQUFFLHFCQXpDRztBQTJDekJDLG9CQUFrQixFQUFFLG9CQTNDSztBQTZDekJDLGlDQUErQixFQUFFO0FBN0NSLENBQXBCO0FBZ0RBLFNBQVNDLHdCQUFULENBQWtDdFEsT0FBbEMsRUFBMkM7QUFDaEQsU0FBTztBQUFFTixRQUFJLEVBQUV5TixXQUFXLENBQUM2Qiw0QkFBcEI7QUFBa0RoUDtBQUFsRCxHQUFQO0FBQ0Q7QUFFTSxTQUFTdVEscUJBQVQsQ0FBK0J2USxPQUEvQixFQUF3QztBQUM3QyxTQUFPO0FBQUVOLFFBQUksRUFBRXlOLFdBQVcsQ0FBQ2tELCtCQUFwQjtBQUFxRHJRO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVN3USxpQkFBVCxDQUEyQnhRLE9BQTNCLEVBQW9DO0FBQ3pDLFNBQU87QUFBRU4sUUFBSSxFQUFFeU4sV0FBVyxDQUFDZ0Qsb0JBQXBCO0FBQTBDblE7QUFBMUMsR0FBUDtBQUNEO0FBRU0sU0FBU3lRLGdCQUFULENBQTBCelEsT0FBMUIsRUFBbUM7QUFDeEMsU0FBTztBQUFFTixRQUFJLEVBQUV5TixXQUFXLENBQUNpRCxrQkFBcEI7QUFBd0NwUTtBQUF4QyxHQUFQO0FBQ0Q7QUFFTSxTQUFTMFEsa0JBQVQsQ0FBNEIxUSxPQUE1QixFQUFxQztBQUMxQyxTQUFPO0FBQUVOLFFBQUksRUFBRXlOLFdBQVcsQ0FBQytDLG9CQUFwQjtBQUEwQ2xRO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVMyUSwyQkFBVCxDQUFxQzNRLE9BQXJDLEVBQThDO0FBQ25ELFNBQU87QUFBRU4sUUFBSSxFQUFFeU4sV0FBVyxDQUFDOEMsK0JBQXBCO0FBQXFEalE7QUFBckQsR0FBUDtBQUNEO0FBRU0sU0FBUzRRLG9CQUFULENBQThCNVEsT0FBOUIsRUFBdUM7QUFDNUMsU0FBTztBQUFFTixRQUFJLEVBQUV5TixXQUFXLENBQUM0QyxzQkFBcEI7QUFBNEMvUDtBQUE1QyxHQUFQO0FBQ0Q7QUFFTSxTQUFTNlEsc0JBQVQsQ0FBZ0M3USxPQUFoQyxFQUF5QztBQUM5QyxTQUFPO0FBQUVOLFFBQUksRUFBRXlOLFdBQVcsQ0FBQzZDLHdCQUFwQjtBQUE4Q2hRO0FBQTlDLEdBQVA7QUFDRDtBQUVNLFNBQVM4USxhQUFULENBQXVCOVEsT0FBdkIsRUFBZ0M7QUFDckMsU0FBTztBQUFFTixRQUFJLEVBQUV5TixXQUFXLENBQUMyQyxjQUFwQjtBQUFvQzlQO0FBQXBDLEdBQVA7QUFDRDtBQUVNLFNBQVMrUSwwQkFBVCxHQUFzQztBQUMzQyxTQUFPO0FBQ0xyUixRQUFJLEVBQUV5TixXQUFXLENBQUN5QztBQURiLEdBQVA7QUFHRDtBQUVNLFNBQVNvQixpQ0FBVCxDQUEyQ2hSLE9BQTNDLEVBQW9EO0FBQ3pELFNBQU87QUFDTE4sUUFBSSxFQUFFeU4sV0FBVyxDQUFDMEMsOEJBRGI7QUFFTDdQO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBU3dJLE9BQVQsR0FBbUI7QUFDekI7QUFDQyxTQUFPO0FBQUU5SSxRQUFJLEVBQUV5TixXQUFXLENBQUNzQjtBQUFwQixHQUFQO0FBQ0Q7QUFFTSxTQUFTd0MsY0FBVCxDQUF3QmpSLE9BQXhCLEVBQWlDO0FBQ3RDLFNBQU87QUFDTE4sUUFBSSxFQUFFeU4sV0FBVyxDQUFDdUIsZ0JBRGI7QUFFTDFPO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBU2tSLFlBQVQsQ0FBc0I3UCxLQUF0QixFQUE2QjtBQUNsQyxTQUFPO0FBQ0wzQixRQUFJLEVBQUV5TixXQUFXLENBQUN3QixjQURiO0FBRUx0TjtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVM4UCxxQkFBVCxDQUErQm5SLE9BQS9CLEVBQXdDO0FBQzlDO0FBQ0NXLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBMkJaLE9BQTNCO0FBRUEsU0FBTztBQUNMTixRQUFJLEVBQUV5TixXQUFXLENBQUN3Qyx1QkFEYjtBQUVMM1A7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTb1IsT0FBVCxDQUFpQnBSLE9BQWpCLEVBQTBCO0FBQy9CLFNBQU87QUFBRU4sUUFBSSxFQUFFeU4sV0FBVyxDQUFDMkIsUUFBcEI7QUFBOEI5TztBQUE5QixHQUFQO0FBQ0Q7QUFFTSxTQUFTcVIsVUFBVCxDQUFvQmxOLE9BQXBCLEVBQTZCO0FBQ2xDLFNBQU87QUFBRXpFLFFBQUksRUFBRXlOLFdBQVcsQ0FBQzRCLFdBQXBCO0FBQWlDNUs7QUFBakMsR0FBUDtBQUNEO0FBRU0sU0FBU21OLGVBQVQsQ0FBeUJuTixPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQUV6RSxRQUFJLEVBQUV5TixXQUFXLENBQUNpQyxZQUFwQjtBQUFrQ2pMO0FBQWxDLEdBQVA7QUFDRDtBQUVNLFNBQVNvTixlQUFULENBQXlCcE4sT0FBekIsRUFBa0M7QUFDdkMsU0FBTztBQUFFekUsUUFBSSxFQUFFeU4sV0FBVyxDQUFDb0MsWUFBcEI7QUFBa0NwTDtBQUFsQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTcU4saUJBQVQsQ0FBMkJ4UixPQUEzQixFQUFvQztBQUN6QyxTQUFPO0FBQ0xOLFFBQUksRUFBRXlOLFdBQVcsQ0FBQ3NDLG1CQURiO0FBRUx6UDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVN5UixlQUFULENBQXlCelIsT0FBekIsRUFBa0M7QUFDdkMsU0FBTztBQUNMTixRQUFJLEVBQUV5TixXQUFXLENBQUN1QyxpQkFEYjtBQUVMMVA7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTMFIsU0FBVCxHQUFxQjtBQUMxQixTQUFPO0FBQUVoUyxRQUFJLEVBQUV5TixXQUFXLENBQUM4QjtBQUFwQixHQUFQO0FBQ0Q7QUFFTSxTQUFTMEMsZ0JBQVQsR0FBNEI7QUFDakMsU0FBTztBQUFFalMsUUFBSSxFQUFFeU4sV0FBVyxDQUFDK0I7QUFBcEIsR0FBUDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsS0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBO0FBVUE7QUFDQTtBQUNBOztBQUVBLE1BQU1sRixZQUFZLEdBQUcsQ0FBQ3RLLElBQUQsRUFBT0MsT0FBUCxLQUFtQjtBQUN0Q0UsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkMsZUFBVyxFQUFFLDJDQUZJO0FBR2pCZ1MsWUFBUSxFQUFFO0FBSE8sR0FBbkI7QUFLRCxDQU5EOztBQU9BLE1BQU1DLFlBQVksR0FBSW5TLElBQUQsSUFBVTtBQUM3QkcsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQUFPLEVBQUUsZUFEUTtBQUVqQkMsZUFBVyxFQUFFLCtDQUZJO0FBR2pCZ1MsWUFBUSxFQUFFO0FBSE8sR0FBbkI7QUFLRCxDQU5EOztBQVFPLE1BQU1FLGVBQWUsR0FBSUMsR0FBRCxJQUM3QnJJLE1BQU0sQ0FBQ3NJLE1BQVAsQ0FBY0QsR0FBZCxFQUNHRSxNQURILENBQ1UsQ0FBQ0MsR0FBRCxFQUFNO0FBQUU5TixVQUFGO0FBQVkrTjtBQUFaLENBQU4sS0FBOEJELEdBQUcsR0FBRzlOLFFBQVEsR0FBRytOLEtBRHpELEVBQ2dFLENBRGhFLEVBRUdDLE9BRkgsQ0FFVyxDQUZYLENBREs7O0FBS1AsVUFBVUMsV0FBVixHQUF3QjtBQUN2QjtBQUNDLE1BQUk7QUFDRixRQUFJcFEsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUNBLFFBQUlDLE9BQU8sR0FBSUwsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCLENBQWY7QUFDQSxRQUFJbkMsT0FBTyxHQUFHO0FBQ1pzQyxrQkFEWTtBQUVaQztBQUZZLEtBQWQ7QUFJSjVCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQXlDWixPQUF6QztBQUNJLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ2pHLG9FQUFjLENBQUNNLFdBQWhCLEVBQTZCdkUsT0FBN0IsQ0FBM0I7QUFDQVcsV0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBeUNaLE9BQXpDO0FBQ0FXLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaLEVBQThCWCxRQUE5QjtBQUNBLFVBQU1rSyw4REFBRyxDQUFDOEcsOERBQWMsQ0FBQ2hSLFFBQVEsQ0FBQ0ssSUFBVixDQUFmLENBQVQ7QUFDRCxHQWRELENBY0UsT0FBT0UsR0FBUCxFQUFZO0FBQ1osVUFBTTJKLDhEQUFHLENBQUMrRyw0REFBWSxDQUFDMVEsR0FBRCxDQUFiLENBQVQ7QUFDRDtBQUNGOztBQUVELFVBQVU4UixXQUFWLENBQXNCO0FBQUV0UztBQUFGLENBQXRCLEVBQW1DO0FBQ25DO0FBQ0UsTUFBSTtBQUNGLFVBQU1DLFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ2pHLG9FQUFjLENBQUNDLGdCQUFoQixFQUFrQ2xFLE9BQWxDLENBQTNCO0FBRUFnSyxnQkFBWSxDQUFDL0osUUFBUSxDQUFDc1MsTUFBVixFQUFrQnRTLFFBQVEsQ0FBQ04sT0FBM0IsQ0FBWjtBQUNBLFVBQU13Syw4REFBRyxDQUFDM0IsdURBQU8sQ0FBQ3hJLE9BQU8sQ0FBQ3NDLFlBQVQsQ0FBUixDQUFUO0FBQ0QsR0FMRCxDQUtFLE9BQU85QixHQUFQLEVBQVk7QUFDWixVQUFNMkosOERBQUcsQ0FBQytHLDREQUFZLENBQUMxUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVWdTLGNBQVYsQ0FBeUJ4UyxPQUF6QixFQUFrQztBQUNoQyxNQUFJO0FBQ0YsVUFBTTtBQUFFbUU7QUFBRixRQUFjbkUsT0FBcEI7QUFDQSxRQUFJeVMsU0FBUyxHQUFHblIsSUFBSSxDQUFDZSxLQUFMLENBQ2RmLElBQUksQ0FBQ2UsS0FBTCxDQUFXSCxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsaUJBQXJCLENBQVgsRUFBb0R1USxJQUR0QyxDQUFoQjtBQUlBLFFBQUlDLEtBQUssR0FBR0YsU0FBUyxDQUFDRyxTQUFWLENBQW9CQyxTQUFwQixDQUErQnpLLElBQUQsSUFBVUEsSUFBSSxDQUFDVCxFQUFMLEtBQVl4RCxPQUFPLENBQUN3RCxFQUE1RCxDQUFaO0FBQ0E4SyxhQUFTLENBQUNLLFNBQVYsR0FBc0JMLFNBQVMsQ0FBQ0ssU0FBVixHQUFzQjNPLE9BQU8sQ0FBQ0MsUUFBcEQ7QUFDQXFPLGFBQVMsQ0FBQ0csU0FBVixDQUFvQkcsTUFBcEIsQ0FBMkJKLEtBQTNCLEVBQWtDLENBQWxDO0FBQ0FGLGFBQVMsQ0FBQ08sTUFBVixHQUFtQmxCLGVBQWUsQ0FBQ1csU0FBUyxDQUFDRyxTQUFYLENBQWxDOztBQUNBLFFBQUlILFNBQVMsQ0FBQ0csU0FBVixDQUFvQjdLLE1BQXBCLEtBQStCLENBQW5DLEVBQXNDO0FBQ3BDMEssZUFBUyxDQUFDRyxTQUFWLEdBQXNCLEVBQXRCO0FBQ0FILGVBQVMsQ0FBQ08sTUFBVixHQUFtQixDQUFuQjtBQUNBUCxlQUFTLENBQUNLLFNBQVYsR0FBc0IsQ0FBdEI7QUFDRDs7QUFDRCxVQUFNM0ksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0FaLGdCQUFZLENBQUMsU0FBRCxDQUFaO0FBQ0QsR0FqQkQsQ0FpQkUsT0FBT3JSLEdBQVAsRUFBWTtBQUNaLFVBQU0ySiw4REFBRyxDQUFDK0csNERBQVksQ0FBQzFRLEdBQUQsQ0FBYixDQUFUO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVeVMsZUFBVixDQUEwQmpULE9BQTFCLEVBQW1DO0FBQ2pDLE1BQUk7QUFDRixVQUFNO0FBQUVtRTtBQUFGLFFBQWNuRSxPQUFwQjtBQUNBLFFBQUl5UyxTQUFTLEdBQUduUixJQUFJLENBQUNlLEtBQUwsQ0FDZGYsSUFBSSxDQUFDZSxLQUFMLENBQVdILFlBQVksQ0FBQ0MsT0FBYixDQUFxQixpQkFBckIsQ0FBWCxFQUFvRHVRLElBRHRDLENBQWhCO0FBR0EsUUFBSVEsWUFBWSxHQUFHVCxTQUFTLENBQUNHLFNBQVYsQ0FBb0JPLElBQXBCLENBQ2hCL0ssSUFBRCxJQUFVQSxJQUFJLENBQUNULEVBQUwsS0FBWXhELE9BQU8sQ0FBQ3dELEVBRGIsQ0FBbkI7O0FBR0EsUUFBSXVMLFlBQUosRUFBa0I7QUFDaEJBLGtCQUFZLENBQUM5TyxRQUFiO0FBQ0FxTyxlQUFTLENBQUNLLFNBQVY7QUFDQUwsZUFBUyxDQUFDTyxNQUFWLEdBQW1CbEIsZUFBZSxDQUFDVyxTQUFTLENBQUNHLFNBQVgsQ0FBbEM7QUFDRDs7QUFDRCxVQUFNekksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0QsR0FkRCxDQWNFLE9BQU9qUyxHQUFQLEVBQVk7QUFDWixVQUFNMkosOERBQUcsQ0FBQytHLDREQUFZLENBQUMxUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTRTLG1CQUFWLENBQThCcFQsT0FBOUIsRUFBdUM7QUFDckMsTUFBSTtBQUNGLFVBQU07QUFBRW1FO0FBQUYsUUFBY25FLE9BQXBCO0FBQ0EsVUFBTXlTLFNBQVMsR0FBR25SLElBQUksQ0FBQ2UsS0FBTCxDQUNoQmYsSUFBSSxDQUFDZSxLQUFMLENBQVdILFlBQVksQ0FBQ0MsT0FBYixDQUFxQixpQkFBckIsQ0FBWCxFQUFvRHVRLElBRHBDLENBQWxCO0FBR0EsUUFBSVEsWUFBWSxHQUFHVCxTQUFTLENBQUNHLFNBQVYsQ0FBb0JPLElBQXBCLENBQ2hCL0ssSUFBRCxJQUFVQSxJQUFJLENBQUNULEVBQUwsS0FBWXhELE9BQU8sQ0FBQ3dELEVBRGIsQ0FBbkI7O0FBSUEsUUFBSXVMLFlBQUosRUFBa0I7QUFDaEJBLGtCQUFZLENBQUM5TyxRQUFiO0FBQ0FxTyxlQUFTLENBQUNLLFNBQVY7QUFDQUwsZUFBUyxDQUFDTyxNQUFWLEdBQW1CbEIsZUFBZSxDQUFDVyxTQUFTLENBQUNHLFNBQVgsQ0FBbEM7QUFDRDs7QUFDRCxVQUFNekksOERBQUcsQ0FBQ3FILGlFQUFpQixDQUFDaUIsU0FBRCxDQUFsQixDQUFUO0FBQ0QsR0FmRCxDQWVFLE9BQU9qUyxHQUFQLEVBQVk7QUFDWixVQUFNMkosOERBQUcsQ0FBQytHLDREQUFZLENBQUMxUSxHQUFELENBQWIsQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTZTLGFBQVYsR0FBMEI7QUFDeEIsTUFBSTtBQUNGLFVBQU1DLFNBQVMsR0FBRztBQUNoQlYsZUFBUyxFQUFFLEVBREs7QUFFaEJJLFlBQU0sRUFBRSxDQUZRO0FBR2hCRixlQUFTLEVBQUUsQ0FISztBQUloQkosVUFBSSxFQUFFO0FBSlUsS0FBbEI7QUFNQSxVQUFNdkksOERBQUcsQ0FBQ3dILGdFQUFnQixDQUFDMkIsU0FBRCxDQUFqQixDQUFUO0FBQ0QsR0FSRCxDQVFFLE9BQU85UyxHQUFQLEVBQVk7QUFDWixVQUFNMkosOERBQUcsQ0FBQ3NILCtEQUFlLENBQUNqUixHQUFELENBQWhCLENBQVQ7QUFDRDtBQUNGOztBQUVELFVBQVUrUyx3QkFBVixHQUFxQztBQUNuQyxNQUFJO0FBQ0YsVUFBTXRULFFBQVEsR0FBRyxNQUFNaUssK0RBQUksQ0FBQ2pHLG9FQUFjLENBQUNZLG9CQUFoQixDQUEzQjtBQUNBLFVBQU1zRiw4REFBRyxDQUFDNkcsaUZBQWlDLENBQUMvUSxRQUFRLENBQUNLLElBQVQsQ0FBY2tULE1BQWYsQ0FBbEMsQ0FBVDtBQUNELEdBSEQsQ0FHRSxPQUFPaFQsR0FBUCxFQUFZLENBQUU7QUFDakI7O0FBRUQsVUFBVWlULHFCQUFWLENBQWdDO0FBQUV6VDtBQUFGLENBQWhDLEVBQTZDO0FBQzNDLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcsTUFBTWlLLCtEQUFJLENBQUNyRSx1RUFBaUIsQ0FBQzRDLFVBQW5CLEVBQStCekksT0FBL0IsQ0FBM0I7O0FBQ0EsUUFBSUMsUUFBUSxJQUFJQSxRQUFRLENBQUNTLFFBQVQsSUFBcUIsR0FBckMsRUFBMEM7QUFDeENnVCwyRkFBbUIsQ0FBQyxTQUFELEVBQVksU0FBWixFQUF1QixpQkFBdkIsQ0FBbkI7QUFDRDs7QUFDRCxVQUFNdkosOERBQUcsQ0FBQzNCLHVEQUFPLEVBQVIsQ0FBVDtBQUNELEdBTkQsQ0FNRSxPQUFPaEksR0FBUCxFQUFZO0FBQ1prVCx5RkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix3QkFBbkIsQ0FBbkI7QUFDRDtBQUNGOztBQUVjLFVBQVUxRyxRQUFWLEdBQXFCO0FBQ25DO0FBQ0MsUUFBTUMsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDc0IsUUFBYixFQUF1QjRELFdBQXZCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTXBGLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzJCLFFBQWIsRUFBdUJ3RCxXQUF2QixDQUFWLENBQUQsQ0FBVDtBQUNBLFFBQU1yRiw4REFBRyxDQUFDLENBQUNDLG9FQUFTLENBQUNDLG1EQUFXLENBQUM0QixXQUFiLEVBQTBCeUQsY0FBMUIsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNdkYsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDaUMsWUFBYixFQUEyQjZELGVBQTNCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTWhHLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ29DLFlBQWIsRUFBMkI2RCxtQkFBM0IsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNbkcsOERBQUcsQ0FBQyxDQUFDQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDOEIsVUFBYixFQUF5Qm9FLGFBQXpCLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTXBHLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQ3lDLHNCQUFiLEVBQXFDMkQsd0JBQXJDLENBREQsQ0FBRCxDQUFUO0FBR0EsUUFBTXRHLDhEQUFHLENBQUMsQ0FDUkMsb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzZCLDRCQUFiLEVBQTJDeUUscUJBQTNDLENBREQsQ0FBRCxDQUFUO0FBR0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JMRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNekosWUFBWSxHQUFJdEssSUFBRCxJQUFVO0FBQzdCRyxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBQU8sRUFBRSxxQkFEUTtBQUVqQkMsZUFBVyxFQUFFO0FBRkksR0FBbkI7QUFJRCxDQUxEOztBQU9BLE1BQU1pUyxZQUFZLEdBQUcsQ0FBQ25TLElBQUQsRUFBT0MsT0FBUCxFQUFnQkMsV0FBaEIsS0FBZ0M7QUFDbkRDLG1EQUFZLENBQUNILElBQUQsQ0FBWixDQUFtQjtBQUNqQkMsV0FBTyxFQUFFLHVCQURRO0FBRWpCQyxlQUFXLEVBQUU7QUFGSSxHQUFuQjtBQUlELENBTEQ7O0FBT0EsTUFBTStULGtCQUFrQixHQUFHLENBQUNqVSxJQUFELEVBQU9DLE9BQVAsRUFBZ0JDLFdBQWhCLEtBQWdDO0FBQ3pEQyxtREFBWSxDQUFDSCxJQUFELENBQVosQ0FBbUI7QUFDakJDLFdBRGlCO0FBRWpCQztBQUZpQixHQUFuQjtBQUlELENBTEQ7O0FBT0EsTUFBTWdVLFNBQVMsR0FBRyxDQUFDbFUsSUFBRCxFQUFPQyxPQUFQLEVBQWdCQyxXQUFoQixLQUFnQztBQUNoREMsbURBQVksQ0FBQ0gsSUFBRCxDQUFaLENBQW1CO0FBQ2pCQyxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLFVBQVVpVSxtQkFBVixHQUFnQztBQUM5QixNQUFJO0FBQ0YsUUFBSTVSLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJQyxPQUFPLEdBQUdMLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixDQUFkO0FBQ0EsUUFBSW5DLE9BQU8sR0FBRztBQUNac0Msa0JBRFk7QUFFWkM7QUFGWSxLQUFkO0FBS0EsVUFBTXVSLFlBQVksR0FBRyxNQUFNNUosK0RBQUksQ0FDN0I2Six3RUFBa0IsQ0FBQ0Msb0JBRFUsRUFFN0JoVSxPQUY2QixDQUEvQjtBQUtBLFVBQU1tSyw4REFBRyxDQUNQLENBQUEySixZQUFZLFNBQVosSUFBQUEsWUFBWSxXQUFaLFlBQUFBLFlBQVksQ0FBRXBULFFBQWQsS0FBMEIsS0FBMUIsSUFDRXVULHNFQUFzQixDQUFDSCxZQUFZLENBQUN4VCxJQUFkLENBRmpCLENBQVQ7QUFJRCxHQW5CRCxDQW1CRSxPQUFPRSxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVELFVBQVUwVCxxQkFBVixDQUFnQztBQUFFL1A7QUFBRixDQUFoQyxFQUE2QztBQUMzQyxNQUFJO0FBQ0YsUUFBSWxDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJdEMsT0FBTyxHQUFHO0FBQ1pzQyxrQkFEWTtBQUVaZ0MsZ0JBQVUsRUFBRUgsT0FGQTtBQUdaekUsVUFBSSxFQUFFO0FBSE0sS0FBZDtBQU1BLFVBQU1vVSxZQUFZLEdBQUcsTUFBTTVKLCtEQUFJLENBQzdCNkosd0VBQWtCLENBQUNJLG9CQURVLEVBRTdCblUsT0FGNkIsQ0FBL0I7QUFJQTRULGFBQVMsQ0FDUEUsWUFBWSxDQUFDdkIsTUFETixFQUVQdUIsWUFBWSxDQUFDblUsT0FGTixFQUdQbVUsWUFBWSxDQUFDeFQsSUFBYixDQUFrQlgsT0FIWCxDQUFUO0FBS0EsVUFBTXdLLDhEQUFHLENBQUNpSywrREFBZSxFQUFoQixDQUFUO0FBQ0EsVUFBTWpLLDhEQUFHLENBQUN6Qyx1RUFBZSxDQUFDdkQsT0FBRCxDQUFoQixDQUFUO0FBQ0QsR0FyQkQsQ0FxQkUsT0FBTzNELEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVTZULHNCQUFWLENBQWlDO0FBQUVsUTtBQUFGLENBQWpDLEVBQThDO0FBQzVDLE1BQUk7QUFDRixRQUFJbEMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxLQUFMLENBQVdKLFFBQVgsQ0FBaEI7QUFDQSxRQUFJSyxZQUFZLEdBQUdGLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFRSxZQUE5QjtBQUNBLFFBQUl0QyxPQUFPLEdBQUc7QUFDWnNDLGtCQURZO0FBRVpnQyxnQkFBVSxFQUFFSDtBQUZBLEtBQWQ7QUFJQSxVQUFNMlAsWUFBWSxHQUFHLE1BQU01SiwrREFBSSxDQUM3QjZKLHdFQUFrQixDQUFDTyx5QkFEVSxFQUU3QnRVLE9BRjZCLENBQS9CO0FBSUEyVCxzQkFBa0IsQ0FDaEIsU0FEZ0IsRUFFaEJHLFlBQVksQ0FBQ25VLE9BRkcsRUFHaEJtVSxZQUFZLENBQUN4VCxJQUFiLENBQWtCWCxPQUhGLENBQWxCO0FBS0EsVUFBTXdLLDhEQUFHLENBQUNpSywrREFBZSxFQUFoQixDQUFUO0FBRUEsVUFBTWpLLDhEQUFHLENBQUN6Qyx1RUFBZSxDQUFDdkQsT0FBRCxDQUFoQixDQUFUO0FBQ0QsR0FwQkQsQ0FvQkUsT0FBTzNELEdBQVAsRUFBWTtBQUNaRyxXQUFPLENBQUNDLEdBQVIsQ0FBWUosR0FBWjtBQUNEO0FBQ0Y7O0FBRUQsVUFBVStULHFCQUFWLEdBQWtDO0FBQ2hDLE1BQUk7QUFDRixVQUFNakIsU0FBUyxHQUFHO0FBQ2hCa0IsbUJBQWEsRUFBRSxFQURDO0FBRWhCQyxtQkFBYSxFQUFFO0FBRkMsS0FBbEI7QUFJQSxVQUFNdEssOERBQUcsQ0FBQ3VLLHlFQUF5QixDQUFDcEIsU0FBRCxDQUExQixDQUFUO0FBQ0QsR0FORCxDQU1FLE9BQU85UyxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUNELFVBQVVtVSxpQ0FBVixDQUE0QztBQUFFeFE7QUFBRixDQUE1QyxFQUF5RDtBQUN2RCxNQUFJO0FBQ0YsUUFBSWxDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdkLElBQUksQ0FBQ2UsS0FBTCxDQUFXSixRQUFYLENBQWhCO0FBQ0EsUUFBSUssWUFBWSxHQUFHRixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUUsWUFBOUI7QUFDQSxRQUFJdEMsT0FBTyxHQUFHO0FBQ1pzQyxrQkFEWTtBQUVaZ0MsZ0JBQVUsRUFBRUgsT0FGQTtBQUdaekUsVUFBSSxFQUFFO0FBSE0sS0FBZDtBQU1BLFVBQU1vVSxZQUFZLEdBQUcsTUFBTTVKLCtEQUFJLENBQzdCNkosd0VBQWtCLENBQUNJLG9CQURVLEVBRTdCblUsT0FGNkIsQ0FBL0I7QUFJQTRULGFBQVMsQ0FDUEUsWUFBWSxDQUFDdkIsTUFETixFQUVQdUIsWUFBWSxDQUFDblUsT0FGTixFQUdQbVUsWUFBWSxDQUFDeFQsSUFBYixDQUFrQlgsT0FIWCxDQUFUO0FBS0EsVUFBTXdLLDhEQUFHLENBQUNpSywrREFBZSxFQUFoQixDQUFUO0FBQ0EsVUFBTWpLLDhEQUFHLENBQUN5SyxrRkFBMEIsQ0FBQyxJQUFELENBQTNCLENBQVQ7QUFDRCxHQXJCRCxDQXFCRSxPQUFPcFUsR0FBUCxFQUFZO0FBQ1pHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZSixHQUFaO0FBQ0Q7QUFDRjs7QUFFRCxVQUFVcVUsc0NBQVYsQ0FBaUQ7QUFBRTFRO0FBQUYsQ0FBakQsRUFBOEQ7QUFDNUQsTUFBSTtBQUNGLFFBQUlsQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHZCxJQUFJLENBQUNlLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0YsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVFLFlBQTlCO0FBQ0EsUUFBSXRDLE9BQU8sR0FBRztBQUNac0Msa0JBRFk7QUFFWmdDLGdCQUFVLEVBQUVIO0FBRkEsS0FBZDtBQUlBLFVBQU0yUCxZQUFZLEdBQUcsTUFBTTVKLCtEQUFJLENBQzdCNkosd0VBQWtCLENBQUNPLHlCQURVLEVBRTdCdFUsT0FGNkIsQ0FBL0I7QUFJQTJULHNCQUFrQixDQUNoQixTQURnQixFQUVoQkcsWUFBWSxDQUFDblUsT0FGRyxFQUdoQm1VLFlBQVksQ0FBQ3hULElBQWIsQ0FBa0JYLE9BSEYsQ0FBbEI7QUFLQSxVQUFNd0ssOERBQUcsQ0FBQ2lLLCtEQUFlLEVBQWhCLENBQVQ7QUFDQSxVQUFNakssOERBQUcsQ0FBQ3lLLGtGQUEwQixDQUFDLEtBQUQsQ0FBM0IsQ0FBVDtBQUNELEdBbkJELENBbUJFLE9BQU9wVSxHQUFQLEVBQVk7QUFDWkcsV0FBTyxDQUFDQyxHQUFSLENBQVlKLEdBQVo7QUFDRDtBQUNGOztBQUVjLFVBQVV3TSxRQUFWLEdBQXFCO0FBQ2xDLFFBQU1DLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzJILGlCQUFiLEVBQWdDakIsbUJBQWhDLENBQVYsQ0FBRCxDQUFUO0FBQ0EsUUFBTTVHLDhEQUFHLENBQUMsQ0FBQ0Msb0VBQVMsQ0FBQ0MsbURBQVcsQ0FBQzRILGlCQUFiLEVBQWdDYixxQkFBaEMsQ0FBVixDQUFELENBQVQ7QUFDQSxRQUFNakgsOERBQUcsQ0FBQyxDQUNSQyxvRUFBUyxDQUFDQyxtREFBVyxDQUFDNkgsb0JBQWIsRUFBbUNYLHNCQUFuQyxDQURELENBQUQsQ0FBVDtBQUdBLFFBQU1wSCw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQ1BDLG1EQUFXLENBQUM4SCxrQ0FETCxFQUVQTixpQ0FGTyxDQURELENBQUQsQ0FBVDtBQU1BLFFBQU0xSCw4REFBRyxDQUFDLENBQ1JDLG9FQUFTLENBQ1BDLG1EQUFXLENBQUMrSCx1Q0FETCxFQUVQTCxzQ0FGTyxDQURELENBQUQsQ0FBVDtBQU1EOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMU1EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1NLFNBQVMsR0FBR0MsbUJBQU8sQ0FBQyxxRUFBRCxDQUF6Qjs7QUFFTyxTQUFTQyxtQkFBVCxDQUE2QkMsU0FBN0IsRUFBd0M7QUFDN0NDLG9EQUFNLENBQUNDLE9BQVAsQ0FBZUYsU0FBZixFQUEwQkcsU0FBMUIsRUFBcUM7QUFDbkNDLFdBQU8sRUFBRTtBQUQwQixHQUFyQztBQUdEO0FBRU0sU0FBU0MsMEJBQVQsQ0FBb0N4UixPQUFwQyxFQUE2QztBQUNsRCxNQUFJQSxPQUFPLENBQUN5UixXQUFSLEtBQXdCLEtBQTVCLEVBQW1DO0FBQ2pDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEseUJBQ096UixPQUFPLENBQUN5UixXQUFSLEdBQXNCelIsT0FBTyxDQUFDeVIsV0FBOUIsR0FBNEMsQ0FEbkQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDJCQUNLelIsT0FBTyxDQUFDMFIsWUFBUixHQUF1QjFSLE9BQU8sQ0FBQzBSLFlBQS9CLEdBQThDLENBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0QsTUFBSTFSLE9BQU8sQ0FBQzJSLGdCQUFSLEtBQTZCLEtBQWpDLEVBQXdDO0FBQ3RDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEseUJBQ08zUixPQUFPLENBQUMyUixnQkFEZixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMkJBQ0szUixPQUFPLENBQUMwUixZQUFSLEdBQXVCMVIsT0FBTyxDQUFDMFIsWUFBL0IsR0FBOEMsQ0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxNQUFJMVIsT0FBTyxDQUFDNFIsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQyx3QkFDRTtBQUFHLGVBQVMsRUFBQyx5QkFBYjtBQUFBLHlCQUNPNVIsT0FBTyxDQUFDNFIsVUFEZixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMkJBQ0s1UixPQUFPLENBQUMwUixZQUFSLEdBQXVCMVIsT0FBTyxDQUFDMFIsWUFBL0IsR0FBOEMsQ0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxzQkFDRTtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHVCQUNPMVIsT0FBTyxDQUFDMFIsWUFBUixHQUF1QjFSLE9BQU8sQ0FBQzBSLFlBQS9CLEdBQThDLENBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBS0Q7QUFFTSxTQUFTRyxzQkFBVCxDQUFnQ3hQLFFBQWhDLEVBQTBDO0FBQy9DLE1BQUl5UCxnQkFBZ0IsR0FBR3pQLFFBQVEsQ0FBQ3lMLE1BQVQsQ0FBZ0IsQ0FBQ2lFLElBQUQsRUFBT0MsSUFBUCxLQUFnQjtBQUNyRCxXQUNFQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ0gsSUFBRCxDQUFaLENBQU4sR0FDQUUsTUFBTSxDQUNKQyxXQUFXLENBQ1RGLElBQUksQ0FBQ0csb0JBQUwsSUFBNkIsQ0FBN0IsR0FDSUgsSUFBSSxDQUFDSSxrQkFEVCxHQUVJSixJQUFJLENBQUNHLG9CQUhBLENBRFAsQ0FGUjtBQVVELEdBWHNCLEVBV3BCLENBWG9CLENBQXZCO0FBYUEsU0FBT0wsZ0JBQVA7QUFDRDtBQUVNLFNBQVNPLHFCQUFULENBQStCaFEsUUFBL0IsRUFBeUM7QUFDOUMsTUFBSWlRLHFCQUFxQixHQUFHalEsUUFBUSxDQUFDeUwsTUFBVCxDQUFnQixDQUFDaUUsSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQzFELFdBQU9DLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDSCxJQUFELENBQVosQ0FBTixHQUE0QkUsTUFBTSxDQUFDQyxXQUFXLENBQUNGLElBQUksQ0FBQ08sVUFBTixDQUFaLENBQXpDO0FBQ0QsR0FGMkIsRUFFekIsQ0FGeUIsQ0FBNUI7QUFJQSxTQUFPRCxxQkFBUDtBQUNEO0FBRU0sU0FBU0UseUJBQVQsQ0FBbUNuUSxRQUFuQyxFQUE2QztBQUNsRCxNQUFJb1EsY0FBYyxHQUFHcFEsUUFBUSxDQUFDeUwsTUFBVCxDQUFnQixDQUFDaUUsSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQ25ELFdBQ0VDLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDSCxJQUFELENBQVosQ0FBTixHQUE0QkUsTUFBTSxDQUFDQyxXQUFXLENBQUNGLElBQUksQ0FBQ1UsZUFBTixDQUFaLENBRHBDO0FBR0QsR0FKb0IsRUFJbEIsQ0FKa0IsQ0FBckI7QUFNQSxTQUFPRCxjQUFQO0FBQ0Q7QUFFTSxTQUFTUCxXQUFULENBQXFCUyxHQUFyQixFQUEwQjtBQUMvQixNQUFJQyxXQUFXLEdBQUdELEdBQUgsYUFBR0EsR0FBSCx1QkFBR0EsR0FBRyxDQUFFRSxRQUFMLEdBQWdCQyxLQUFoQixDQUFzQixHQUF0QixDQUFsQjs7QUFDQSxNQUFJRixXQUFXLElBQUksQ0FBQUEsV0FBVyxTQUFYLElBQUFBLFdBQVcsV0FBWCxZQUFBQSxXQUFXLENBQUVoUCxNQUFiLElBQXNCLENBQXpDLEVBQTRDO0FBQzFDLFdBQU9nUCxXQUFXLENBQUM5RSxNQUFaLENBQW1CLENBQUNpRSxJQUFELEVBQU9DLElBQVAsS0FBZ0JELElBQUksR0FBR0MsSUFBMUMsQ0FBUDtBQUNELEdBRkQsTUFFTztBQUNMLFdBQU8sQ0FBUDtBQUNEO0FBQ0Y7QUFFTSxTQUFTZSw4QkFBVCxDQUF3Q0MsV0FBeEMsRUFBcUQ7QUFDMUQsU0FBTyxJQUFJQyxJQUFJLENBQUNDLFlBQVQsQ0FBc0IsT0FBdEIsRUFBK0I7QUFDcENDLFNBQUssRUFBRSxVQUQ2QjtBQUVwQ0MsWUFBUSxFQUFFO0FBRjBCLEdBQS9CLEVBR0pDLE1BSEksQ0FHR25CLFdBQVcsQ0FBQ2MsV0FBRCxDQUhkLENBQVA7QUFJRDtBQUVNLFNBQVNNLFdBQVQsQ0FBcUJDLFdBQXJCLEVBQWtDO0FBQ3ZDLE1BQUlDLE1BQU0sR0FBR3hDLFNBQVMsQ0FBQ3lDLE9BQVYsQ0FBa0JGLFdBQWxCLENBQWI7QUFDRDtBQUVNLFNBQVNHLFdBQVQsQ0FBcUJDLFFBQXJCLEVBQStCQyxTQUEvQixFQUEwQztBQUMvQyxNQUFJQyxPQUFPLEdBQUc3QyxTQUFTLENBQUM4QyxHQUFWLENBQ1o1QixXQUFXLENBQUN5QixRQUFRLElBQUksQ0FBYixDQURDLEVBRVp6QixXQUFXLENBQUMwQixTQUFTLElBQUksQ0FBZCxDQUZDLENBQWQ7QUFJQSxTQUFPQyxPQUFQO0FBQ0Q7QUFFTSxTQUFTRSxXQUFULENBQXFCSixRQUFyQixFQUErQkMsU0FBL0IsRUFBMEM7QUFDL0MsTUFBSUksT0FBTyxHQUFHaEQsU0FBUyxDQUFDaUQsR0FBVixDQUNaL0IsV0FBVyxDQUFDeUIsUUFBUSxJQUFJLENBQWIsQ0FEQyxFQUVaekIsV0FBVyxDQUFDMEIsU0FBUyxJQUFJLENBQWQsQ0FGQyxDQUFkO0FBSUEsU0FBT0ksT0FBUDtBQUNEO0FBRU0sU0FBU0UsV0FBVCxDQUFxQkMsZ0JBQXJCLEVBQXVDQyxpQkFBdkMsRUFBMEQ7QUFDL0QsTUFBSUMsT0FBTyxHQUFHckQsU0FBUyxDQUFDc0QsR0FBVixDQUNacEMsV0FBVyxDQUFDaUMsZ0JBQWdCLElBQUksQ0FBckIsQ0FEQyxFQUVaakMsV0FBVyxDQUFDa0MsaUJBQWlCLElBQUksQ0FBdEIsQ0FGQyxDQUFkO0FBS0EsU0FBT0MsT0FBUDtBQUNEO0FBQ00sU0FBU0UsV0FBVCxDQUFxQkosZ0JBQXJCLEVBQXVDQyxpQkFBdkMsRUFBMEQ7QUFDL0QsTUFBSUksT0FBTyxHQUFHeEQsU0FBUyxDQUFDeUQsR0FBVixDQUNadkMsV0FBVyxDQUFDaUMsZ0JBQWdCLElBQUksQ0FBckIsQ0FEQyxFQUVaakMsV0FBVyxDQUFDa0MsaUJBQWlCLElBQUksQ0FBdEIsQ0FGQyxDQUFkO0FBS0EsU0FBT0ksT0FBUDtBQUNEO0FBRU0sU0FBU0UsY0FBVCxDQUF3Qi9CLEdBQXhCLEVBQTZCO0FBQ2xDLE1BQUlBLEdBQUcsS0FBS3JCLFNBQVosRUFBdUI7QUFDckIsV0FBT3FELFVBQVUsQ0FBQ2hDLEdBQUQsQ0FBVixDQUNKRSxRQURJLEdBRUp4QixPQUZJLENBRUkseUJBRkosRUFFK0IsS0FGL0IsQ0FBUDtBQUdELEdBSkQsTUFJTyxDQUNOO0FBQ0Y7QUFFTSxTQUFTdUQsa0JBQVQsQ0FBNEJDLFdBQTVCLEVBQXlDQyxJQUF6QyxFQUErQztBQUNwRCxNQUFJRCxXQUFXLENBQUNqUixNQUFaLEdBQXFCLENBQXpCLEVBQTRCO0FBQzFCLFVBQU00UCxNQUFNLEdBQUdxQixXQUFXLENBQUM3RixJQUFaLENBQWtCL0ssSUFBRCxJQUFVQSxJQUFJLENBQUM2USxJQUFMLEtBQWNBLElBQUksQ0FBQ2pDLFFBQUwsRUFBekMsQ0FBZjs7QUFDQSxRQUFJVyxNQUFNLEtBQUtsQyxTQUFmLEVBQTBCO0FBQ3hCLGFBQU9rQyxNQUFNLENBQUNuUixRQUFkO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxFQUFQO0FBQ0Q7QUFDRixHQVBELE1BT087QUFDTCxXQUFPLEVBQVA7QUFDRDtBQUNGO0FBRU0sU0FBUzBTLGFBQVQsQ0FBdUJDLE9BQXZCLEVBQWdDRixJQUFoQyxFQUFzQztBQUMzQyxNQUFJRSxPQUFPLENBQUNwUixNQUFSLEdBQWlCLENBQXJCLEVBQXdCO0FBQ3RCLFVBQU1xUixNQUFNLEdBQUdELE9BQU8sQ0FBQ2hHLElBQVIsQ0FBYy9LLElBQUQsSUFBVUEsSUFBSSxDQUFDNlEsSUFBTCxLQUFjQSxJQUFJLENBQUNqQyxRQUFMLEVBQXJDLENBQWY7O0FBQ0EsUUFBSW9DLE1BQU0sS0FBSzNELFNBQWYsRUFBMEI7QUFDeEIsYUFBTzJELE1BQVA7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPLElBQVA7QUFDRDtBQUNGLEdBUEQsTUFPTztBQUNMLFdBQU8sSUFBUDtBQUNEO0FBQ0Y7QUFFTSxTQUFTQyx1QkFBVCxDQUFpQ3JaLE9BQWpDLEVBQTBDO0FBQy9DLE1BQUlrSSxLQUFLLEdBQUcsRUFBWjs7QUFDQSxNQUFJbEksT0FBTyxDQUFDK0gsTUFBUixHQUFpQixDQUFyQixFQUF3QjtBQUN0Qi9ILFdBQU8sQ0FBQ21JLE9BQVIsQ0FBaUJDLElBQUQsSUFBVTtBQUN4QixVQUFJRixLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNoQkEsYUFBSyxHQUFJLFdBQVVFLElBQUssRUFBeEI7QUFDRCxPQUZELE1BRU87QUFDTEYsYUFBSyxHQUFHQSxLQUFLLEdBQUksWUFBV0UsSUFBSyxFQUFqQztBQUNEO0FBQ0YsS0FORDtBQU9EOztBQUNELFNBQU9GLEtBQVA7QUFDRDtBQUVNLFNBQVNvUixrQkFBVCxDQUE0Qm5WLE9BQTVCLEVBQXFDO0FBQzFDLE1BQUlvVixJQUFKOztBQUNBLE1BQUlwVixPQUFPLENBQUNxVixLQUFSLElBQWlCclYsT0FBTyxDQUFDcVYsS0FBUixLQUFrQixJQUF2QyxFQUE2QztBQUMzQ0QsUUFBSSxHQUFHcFYsT0FBTyxDQUFDcVYsS0FBUixDQUFjNVAsR0FBZCxDQUFtQjRQLEtBQUQsSUFBVztBQUNsQyxVQUFJQSxLQUFLLENBQUM5WixJQUFOLEtBQWUsTUFBbkIsRUFBMkI7QUFDekIsNEJBQU87QUFBSyxtQkFBUyxFQUFDLG1CQUFmO0FBQUEsb0JBQW9DOFosS0FBSyxDQUFDQztBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFQO0FBQ0QsT0FGRCxNQUVPLElBQUlELEtBQUssQ0FBQzlaLElBQU4sS0FBZSxVQUFuQixFQUErQjtBQUNwQyw0QkFBTztBQUFLLG1CQUFTLEVBQUMsNkJBQWY7QUFBQSxvQkFBOEM4WixLQUFLLENBQUNDO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQVA7QUFDRCxPQUZNLE1BRUE7QUFDTCw0QkFBTztBQUFLLG1CQUFTLEVBQUMsdUJBQWY7QUFBQSxvQkFBd0NELEtBQUssQ0FBQ0M7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBUDtBQUNEO0FBQ0YsS0FSTSxDQUFQO0FBU0Q7O0FBQ0QsU0FBT0YsSUFBUDtBQUNEO0tBZGVELGtCO0FBZ0JULFNBQVNJLGtCQUFULENBQTRCdlYsT0FBNUIsRUFBcUM7QUFDMUMsTUFBSW9WLElBQUo7O0FBQ0EsTUFBSXBWLE9BQU8sQ0FBQ3dWLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJKLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx5QkFDT1YsY0FBYyxDQUFDMVUsT0FBTyxDQUFDZ08sS0FBVCxDQURyQixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMkJBQTJCMEcsY0FBYyxDQUFDMVUsT0FBTyxDQUFDNFIsVUFBVCxDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQU1ELEdBUEQsTUFPTztBQUNMd0QsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHlCQUFzQ1YsY0FBYyxDQUFDMVUsT0FBTyxDQUFDZ08sS0FBVCxDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQUdEOztBQUNELFNBQU9vSCxJQUFQO0FBQ0Q7TUFmZUcsa0I7QUFpQlQsU0FBU0Usc0JBQVQsQ0FBZ0N6VixPQUFoQyxFQUF5QztBQUM5QyxNQUFJb1YsSUFBSjs7QUFDQSxNQUFJcFYsT0FBTyxDQUFDNFIsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQ3dELFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx5QkFDT3BWLE9BQU8sQ0FBQzRSLFVBRGYsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDJCQUEyQjVSLE9BQU8sQ0FBQzBSLFlBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBTUQsR0FQRCxNQU9PO0FBQ0wwRCxRQUFJLGdCQUFHO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEseUJBQXNDcFYsT0FBTyxDQUFDMFIsWUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQVA7QUFDRDs7QUFDRCxTQUFPMEQsSUFBUDtBQUNEO01BYmVLLHNCO0FBZVQsU0FBU0MsbUJBQVQsQ0FBNkIxVixPQUE3QixFQUFzQztBQUMzQyxNQUFJb1YsSUFBSjs7QUFDQSxNQUFJcFYsT0FBTyxDQUFDd1YsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkosUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHlCQUNPVixjQUFjLENBQUMxVSxPQUFPLENBQUM0UixVQUFULENBRHJCLEVBQzJDLEdBRDNDLGVBRUU7QUFBTSxpQkFBUyxFQUFDLFVBQWhCO0FBQUEsMkJBQ0s4QyxjQUFjLENBQUMxVSxPQUFPLENBQUMwUixZQUFULENBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQsR0FURCxNQVNPO0FBQ0wwRCxRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEseUJBQ09WLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQzRSLFVBQVQsQ0FEckIsRUFDMkMsR0FEM0MsZUFFRTtBQUFNLGlCQUFTLEVBQUMsVUFBaEI7QUFBQSwyQkFDSzhDLGNBQWMsQ0FBQzFVLE9BQU8sQ0FBQzBSLFlBQVQsQ0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxTQUFPMEQsSUFBUDtBQUNEO0FBRU0sU0FBU08sMEJBQVQsQ0FBb0MzVixPQUFwQyxFQUE2QztBQUNsRCxNQUFJb1YsSUFBSjs7QUFDQSxNQUFJcFYsT0FBTyxDQUFDd1YsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkosUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyx3QkFBYjtBQUFBLHlCQUNPVixjQUFjLENBQUMxVSxPQUFPLENBQUNnTyxLQUFULENBRHJCLGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwyQkFBMkIwRyxjQUFjLENBQUMxVSxPQUFPLENBQUM0UixVQUFULENBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQU9ELEdBUkQsTUFRTztBQUNMd0QsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHlCQUFzQ1YsY0FBYyxDQUFDMVUsT0FBTyxDQUFDZ08sS0FBVCxDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQUdEOztBQUNELFNBQU9vSCxJQUFQO0FBQ0Q7TUFoQmVPLDBCO0FBa0JULFNBQVNDLCtCQUFULENBQXlDNVYsT0FBekMsRUFBa0Q7QUFDdkQsTUFBSW9WLElBQUo7QUFFQUEsTUFBSSxnQkFDRjtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHVCQUNPVixjQUFjLENBQUMxVSxPQUFPLENBQUN5UixXQUFSLEdBQXNCelIsT0FBTyxDQUFDeVIsV0FBOUIsR0FBNEMsQ0FBN0MsQ0FEckIsZUFFRTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQUEseUJBQ0tpRCxjQUFjLENBQUMxVSxPQUFPLENBQUMwUixZQUFSLEdBQXVCMVIsT0FBTyxDQUFDMFIsWUFBL0IsR0FBOEMsQ0FBL0MsQ0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFLRTtBQUFBLGdCQUFRMVIsT0FBTyxDQUFDNlYsS0FBUixHQUFnQjdWLE9BQU8sQ0FBQzZWLEtBQXhCLEdBQWdDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVVBLFNBQU9ULElBQVA7QUFDRDtNQWRlUSwrQjtBQWVULFNBQVNFLGdDQUFULENBQTBDOVYsT0FBMUMsRUFBbUQ7QUFDeEQsTUFBSW9WLElBQUo7QUFFQUEsTUFBSSxnQkFDRjtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHVCQUNPVixjQUFjLENBQUMxVSxPQUFPLENBQUM0UixVQUFSLEdBQXFCNVIsT0FBTyxDQUFDNFIsVUFBN0IsR0FBMEMsQ0FBM0MsQ0FEckIsZUFFRTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQUEseUJBQ0s4QyxjQUFjLENBQUMxVSxPQUFPLENBQUNnTyxLQUFSLEdBQWdCaE8sT0FBTyxDQUFDZ08sS0FBeEIsR0FBZ0MsQ0FBakMsQ0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFLRTtBQUFBLGdCQUFRaE8sT0FBTyxDQUFDNlYsS0FBUixHQUFnQjdWLE9BQU8sQ0FBQzZWLEtBQXhCLEdBQWdDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVVBLFNBQU9ULElBQVA7QUFDRDtNQWRlVSxnQztBQWdCVCxTQUFTQyxzQkFBVCxDQUFnQy9WLE9BQWhDLEVBQXlDO0FBQzlDLE1BQUlvVixJQUFKOztBQUVBLE1BQUlwVixPQUFPLENBQUNnVyxTQUFaLEVBQXVCO0FBQ3JCWixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDd0QsRUFBRyxFQUF2RDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBRyxHQUFFMUIsZ0VBQVEsR0FBRTlCLE9BQU8sQ0FBQ2dXLFNBQVIsQ0FBa0JoWixHQUFJLEVBRDFDO0FBRUUsZUFBRyxFQUFFZ0QsT0FBTyxDQUFDaVc7QUFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFZRCxHQWJELE1BYU87QUFDTGIsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV3BWLE9BQU8sQ0FBQ3dELEVBQUcsRUFBdkQ7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFBSyxlQUFHLEVBQUMsMkJBQVQ7QUFBcUMsZUFBRyxFQUFDO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQVNEOztBQUVELFNBQU80UixJQUFQO0FBQ0Q7TUE3QmVXLHNCO0FBK0JULFNBQVNHLDJCQUFULENBQXFDbFcsT0FBckMsRUFBOEM7QUFDbkQsTUFBSW9WLElBQUo7O0FBRUEsTUFBSXBWLE9BQU8sQ0FBQ21XLEtBQVIsQ0FBY3ZTLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJ3UixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFFSCxPQUFGLGFBQUVBLE9BQUYsMENBQUVBLE9BQU8sQ0FBRW1XLEtBQVQsQ0FBZSxDQUFmLENBQUYsb0RBQUUsZ0JBQW1CQSxLQUQxQjtBQUVFLGVBQUcsRUFBRW5XLE9BQU8sQ0FBQ29XLFlBRmY7QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0QsR0FmRCxNQWVPO0FBQ0xoQixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXcFYsT0FBTyxDQUFDRyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFDLDJCQUROO0FBRUUsZUFBRyxFQUFDLFNBRk47QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0Q7O0FBRUQsU0FBT2lWLElBQVA7QUFDRDtNQXBDZWMsMkI7QUFzQ1QsU0FBU0csNEJBQVQsQ0FBc0NyVyxPQUF0QyxFQUErQztBQUNwRCxNQUFJb1YsSUFBSjs7QUFFQSxNQUFJcFYsT0FBTyxDQUFDbVcsS0FBUixDQUFjdlMsTUFBZCxHQUF1QixDQUEzQixFQUE4QjtBQUFBOztBQUM1QndSLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdwVixPQUFPLENBQUNHLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUVILE9BQUYsYUFBRUEsT0FBRiwyQ0FBRUEsT0FBTyxDQUFFbVcsS0FBVCxDQUFlLENBQWYsQ0FBRixxREFBRSxpQkFBbUJBLEtBRDFCO0FBRUUsZUFBRyxFQUFFblcsT0FBTyxDQUFDb1csWUFGZjtBQUdFLGlCQUFLLEVBQUMsTUFIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRCxHQWZELE1BZU87QUFDTGhCLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdwVixPQUFPLENBQUNHLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUMsMkJBRE47QUFFRSxlQUFHLEVBQUMsU0FGTjtBQUdFLGlCQUFLLEVBQUMsTUFIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRDs7QUFFRCxTQUFPaVYsSUFBUDtBQUNEO01BcENlaUIsNEI7QUFzQ1QsU0FBU0Msd0JBQVQsQ0FBa0N0VyxPQUFsQyxFQUEyQztBQUNoRCxNQUFJb1YsSUFBSjs7QUFFQSxNQUFJcFYsT0FBTyxDQUFDbVcsS0FBUixDQUFjdlMsTUFBZCxHQUF1QixDQUEzQixFQUE4QjtBQUFBOztBQUM1QndSLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdwVixPQUFPLENBQUNHLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUVILE9BQUYsYUFBRUEsT0FBRiwyQ0FBRUEsT0FBTyxDQUFFbVcsS0FBVCxDQUFlLENBQWYsQ0FBRixxREFBRSxpQkFBbUJBLEtBRDFCO0FBRUUsZUFBRyxFQUFFblcsT0FBTyxDQUFDb1csWUFGZjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRCxHQWZELE1BZU87QUFDTGhCLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdwVixPQUFPLENBQUNHLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUMsMkJBRE47QUFFRSxlQUFHLEVBQUMsU0FGTjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRDs7QUFFRCxTQUFPaVYsSUFBUDtBQUNEO09BcENla0Isd0I7QUFzQ1QsU0FBU0MsV0FBVCxHQUF1QjtBQUM1Qi9aLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDRCIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9fYXBwLmMyYzYxN2U4NjM1YTU1Yjk2OTMzLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyByZXNwb25zaXZlRm9udFNpemVzIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7IGJhc2VVcmwsIHNlcmlhbGl6ZVF1ZXJ5LCBhcGliYXNldXJsIH0gZnJvbSBcIi4vUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBtb2RhbE9wZW4gPSAodHlwZSwgbWVzc2FnZSwgZGVzY3JpcHRpb24pID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuY2xhc3MgQWNjb3VudFJlcG9zaXRvcnkge1xyXG4gIGFzeW5jIGdldFVzZXJQdXJjaGFzZVllYXJzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIveWVhcmAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgbW9kYWxPcGVuKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIkVycm9yIEZldGNoaW5nIFllYXJzIGZyb20gU2VydmVyXCIpO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG5cclxuICBhc3luYyBjaGFuZ2VQYXNzd29yZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Bhc3N3b3JkL2NoYW5nZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJlZ2lzdGVyTmV3VXNlcihwYXlsb2FkKSB7XHJcbiAgIC8vIGFsZXJ0KFwiZFwiKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uNTU1Li4uXCIscGF5bG9hZClcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVnaXN0ZXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBlZGl0Q3VzdG9tZXJQcm9maWxlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZWRpdC9wcm9maWxlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGZ1bmN0aW9uIChyZXNwb25zZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDb3VudHJ5KCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NvdW50cnlgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDaGF0TGlzdChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2hhdC9saXN0YCxcclxuICAgICAgZGF0YTogcGF5bG9hZCxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG5cclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENoYXRNZXNzYWdlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jaGF0L21lc3NhZ2VgLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc2VuZE1lc3NhZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NoYXQvc2VuZGAsXHJcbiAgICAgIGRhdGE6IHBheWxvYWQsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuXHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdGF0ZShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3N0YXRlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2l0eShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NpdHlgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRNeU9yZGVycyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvbXlwdXJjaGFzZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjYW5jZWxPcmRlclJlcXVlc3QocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Jlc3BvbnNlL2NhbmNlbC9yZXF1ZXN0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE9yZGVyRGV0YWlscyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIvZGV0YWlsYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIC8vIGFzeW5jIGdldEN1c3RvbWVyUHJvZmlsZURldGFpbCh7IGFjY2Vzc190b2tlbiB9KSB7XHJcbiAgYXN5bmMgZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsKCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9maWxlYCxcclxuICAgICAgeyBhY2Nlc3NfdG9rZW4sIGxhbmdfaWQ6IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ0lkXCIpfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZUN1c3RvbWVyUHJvZmlsZURldGFpbChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZWRpdC9wcm9maWxlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEN1c3RvbWVyUmVjZW50Vmlld3MocGF5bG9hZCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZWNlbnQvdmlld3NgLFxyXG4gICAgICB7IGFjY2Vzc190b2tlbiwgbGFuZ19pZDogbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nSWRcIikgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEN1c3RvbWVyQWRkcmVzc2VzKCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hZGRyZXNzYCxcclxuICAgICAgeyBhY2Nlc3NfdG9rZW4gfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbiAgYXN5bmMgbWFrZURlZmF1bHRBZGRyZXNzZXMocGF5bG9hZCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIHZhciB1c2VyVXBkYXRlRm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICB1c2VyVXBkYXRlRm9ybURhdGEuYXBwZW5kKFwiYWNjZXNzX3Rva2VuXCIsIGFjY2Vzc190b2tlbik7XHJcbiAgICB1c2VyVXBkYXRlRm9ybURhdGEuYXBwZW5kKFwiYWRkcmVzc19pZFwiLCBwYXlsb2FkLmFkZHJlc3NfaWQpO1xyXG4gICAgdXNlclVwZGF0ZUZvcm1EYXRhLmFwcGVuZChcImlzX2RlZmF1bHRcIiwgcGF5bG9hZC5kZWZhdWx0KTtcclxuXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9kZWZhdWx0L2FkZHJlc3NgLFxyXG4gICAgICBkYXRhOiB1c2VyVXBkYXRlRm9ybURhdGEsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZGVsZXRlQWRkcmVzcyhwYXlsb2FkKSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgdmFyIHVzZXJVcGRhdGVGb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgIHVzZXJVcGRhdGVGb3JtRGF0YS5hcHBlbmQoXCJhY2Nlc3NfdG9rZW5cIiwgYWNjZXNzX3Rva2VuKTtcclxuICAgIHVzZXJVcGRhdGVGb3JtRGF0YS5hcHBlbmQoXCJhZGRyZXNzX2lkXCIsIHBheWxvYWQuYWRkcmVzc19pZCk7XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVtb3ZlL2FkZHJlc3NgLFxyXG4gICAgICBkYXRhOiB1c2VyVXBkYXRlRm9ybURhdGEsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgYWRkQWRkcmVzcyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hZGQvYWRkcmVzc2AsXHJcbiAgICAgIGRhdGE6IHBheWxvYWQsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlQWRkcmVzcyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9lZGl0L2FkZHJlc3NgLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJldHVybk9yZGVyUmVxdWVzdChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmV0dXJuL3JlcXVlc3RgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcmV0dXJuU2hpcG1lbnREZXRhaWwocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL3JldHVybi9zaGlwbWVudGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjcmVhdGVTdXBwb3J0VG9rZW4ocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jcmVhdGUtdGlja2V0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gcmVzcG9uc2UuZXJyb3IpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgbGlzdFN1cHBvcnRUb2tlbihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2xpc3QtdGlja2V0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdXBwb3J0TWVzc2FnZUJ5SUQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zdXBwb3J0LW1lc3NhZ2VgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGFkZFRpY2tldE1lc3NhZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hZGQtdGlja2V0LW1lc3NhZ2VgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFdhbGxldERldGFpbHMocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci93YWxsZXQvYW1vdW50YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRBdWN0aW9uQ2FydERhdGEocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hdWN0aW9uL2RldGFpbGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0VXNlck5vdGlmaWNhdGlvbihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3ZpZXcvbm90aWZpY2F0aW9uc2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0QXVjdGlvbk9yZGVyTGlzdChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2F1Y3Rpb24vb3JkZXIvbGlzdGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc2VuZFJlZ2lzdGVyTW9iaWxlT1RQKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVnaXN0ZXIvc2VuZC9vdHBgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHZlcmlmeVJlZ2lzdGVyTW9iaWxlT1RQKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVnaXN0ZXIvdmVyaWZ5L290cGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdmVyaWZ5Rm9yZ290T1RQKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvbG9naW4vZm9yZ290L3ZlcmlmeS1vdHBgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcbn1cclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IEFjY291bnRSZXBvc2l0b3J5KCk7XHJcbiIsImltcG9ydCB7IHJlc3BvbnNpdmVGb250U2l6ZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgZ2V0RGV2aWNlSWQgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHsgYmFzZVVybCwgc2VyaWFsaXplUXVlcnksIGFwaWJhc2V1cmwgfSBmcm9tIFwiLi9SZXBvc2l0b3J5XCI7XHJcblxyXG5jbGFzcyBDYXJ0UmVwb3NpdG9yeSB7XHJcbiAgYXN5bmMgYWRkUHJvZHVjdFRvQ2FydCh7IGFjY2Vzc190b2tlbiwgcHJvZHVjdCwgcXVhbnRpdHksIGNhcnRfdHlwZSB9KSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkLWNhcnRgLFxyXG4gICAgICB7IGFjY2Vzc190b2tlbiwgcHJvZHVjdF9pZDogcHJvZHVjdC5wcm9kdWN0X2lkLCBxdWFudGl0eSwgY2FydF90eXBlIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2FydEl0ZW0ocGF5bG9hZCkge1xyXG4gICAvLyBhbGVydChcImRcIilcclxuICAgICBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi5jY2NjYy4uXCIsZ2V0RGV2aWNlSWQpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi4uLlwiLHBheWxvYWQpXHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXJ0YCwge1xyXG4gICAgICBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAgIGxhbmdfaWQ6bG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nSWRcIiksXHJcbiAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgICAgb3NfdHlwZTogXCJXRUJcIixcclxuICAgIH0pXHJcbiAgIC8vIGFsZXJ0KFwiMzMzM1wiKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuLjQ0NDQ0NDQ0NDQ0NC5cIixyZXNwb25zZSlcclxuICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAvLyAgIGFsZXJ0KFwiNDQ0NDQ0NDRcIilcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZmV0Y2hQbGF0Zm9ybVZvdWNoZXIoKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NvdXBvbi9wbGF0Zm9ybWAsXHJcbiAgICAgIHtcclxuICAgICAgICBsYW5nX2lkOiBcIlwiLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY2hlY2tQbGF0Zm9ybVZvdWNoZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jb3Vwb24vcGxhdGZvcm1gLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY2hlY2tTZWxsZXJWb3VjaGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY291cG9uL3NlbGxlcmAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgQ2FydFJlcG9zaXRvcnkoKTtcclxuIiwiaW1wb3J0IFJlcG9zaXRvcnksIHsgYXBpYmFzZXVybCB9IGZyb20gXCIuL1JlcG9zaXRvcnlcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXREZXZpY2VJZCwgbWFrZVBhZ2VVcmwsIG9zVHlwZSB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5cclxuY2xhc3MgSG9tZWFwaSB7XHJcbiAgYXN5bmMgZ2V0SG9tZWRhdGEocGF0aE5hbWUpIHtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBhY2Nlc3NfdG9rZW46IFwiXCIsXHJcbiAgICAgIGxhbmdfaWQ6bG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nSWRcIiksXHJcbiAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgIHBhZ2VfdXJsOiBtYWtlUGFnZVVybChcIi9cIiksXHJcbiAgICAgIG9zX3R5cGU6IG9zVHlwZSgpLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBDYW5jZWxUb2tlbiA9IGF4aW9zLkNhbmNlbFRva2VuO1xyXG4gICAgbGV0IHNvdXJjZSA9IENhbmNlbFRva2VuLnNvdXJjZSgpO1xyXG5cclxuICAgIHNvdXJjZSAmJiBzb3VyY2UuY2FuY2VsKFwiT3BlcmF0aW9uIGNhbmNlbGVkIGR1ZSB0byBuZXcgcmVxdWVzdC5cIik7XHJcbiAgICAvLyBzYXZlIHRoZSBuZXcgcmVxdWVzdCBmb3IgY2FuY2VsbGF0aW9uXHJcbiAgICBzb3VyY2UgPSBheGlvcy5DYW5jZWxUb2tlbi5zb3VyY2UoKTtcclxuXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvaG9tZWAsXHJcbiAgICAgIHBheWxvYWQsXHJcbiAgICAgIHtcclxuICAgICAgICBjYW5jZWxUb2tlbjogc291cmNlLnRva2VuLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIC8vIGNhbmNlbCB0aGUgcmVxdWVzdCAodGhlIG1lc3NhZ2UgcGFyYW1ldGVyIGlzIG9wdGlvbmFsKVxyXG4gICAgc291cmNlLmNhbmNlbChcIk9wZXJhdGlvbiBjYW5jZWxlZCBieSB0aGUgdXNlci5cIik7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdFJldmlldyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcG9zdC1wcm9kdWN0LXJldmlld2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdWJtaXRTZWxsZXJSZXZpZXcocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Bvc3Qtc2VsbGVyLXJldmlld2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG4gIC8vIGFzeW5jIGdldEhvbWVkYXRhKCkge1xyXG4gIC8vICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvc1xyXG4gIC8vICAgICAuZ2V0KGBodHRwczovL2VzdHJyYWRvd2ViLmNvbS9rYW5ndGFvL2FwaS9jdXN0b21lci9ob21lYCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gIC8vICAgICAgIH0sXHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YSlcclxuICAvLyAgICAgLmNhdGNoKChlcnJvcikgPT4gZXJyb3IpO1xyXG4gIC8vICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIC8vIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IEhvbWVhcGkoKTtcclxuIiwiaW1wb3J0IHsgZ2V0RGV2aWNlSWQsIG9zVHlwZSB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgUmVwb3NpdG9yeSwge1xyXG4gIGJhc2VVcmwsXHJcbiAgc2VyaWFsaXplUXVlcnksXHJcbiAgYXBpYmFzZXVybCxcclxuICBiYXNlUGF0aFVybCxcclxufSBmcm9tIFwiLi9SZXBvc2l0b3J5XCI7XHJcblxyXG5jbGFzcyBQcm9kdWN0UmVwb3NpdG9yeSB7XHJcbiAgYXN5bmMgZ2V0UmVjb3JkcyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChcclxuICAgICAgYCR7YmFzZVVybH0vcHJvZHVjdHM/JHtzZXJpYWxpemVRdWVyeShwYXJhbXMpfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTZWFyY2hlZFByb2R1Y3RzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3Qtc2VhcmNoYCxcclxuICAgICAge1xyXG4gICAgICAgIGxhbmdfaWQ6IFwiXCIsXHJcbiAgICAgICAgY2F0ZWdvcnlfaWQ6IHBhcmFtcy5jYXRlZ29yeV9pZCxcclxuICAgICAgICBrZXl3b3JkOiBwYXJhbXMudGl0bGVfY29udGFpbnMsXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi45OTk5Li4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEubm9fb2ZfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0cyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWxpc3Q/cGFnZT1gICsgcGFyYW1zLnBhZ2UsXHJcbiAgICAgIHtcclxuICAgICAgICBsYW5nX2lkOiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdJZFwiKSxcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IFwiXCIsXHJcbiAgICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgICBwYWdlX3VybDogXCJodHRwczovL2FiYy5jb20vcHJvZHVjdHMvdXMvaW1nXCIsXHJcbiAgICAgICAgb3NfdHlwZTogXCJXRUJcIixcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjg4OC4uLlwiLHJlc3BvbnNlKVxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0TmV3RGVhbHNQcm9kdWN0cyhwYXlsb2FkLCBwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWRlYWxzP3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvY2tpbmdTYWxlUHJvZHVjdHMocGF5bG9hZCwgcGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZS1wcm9kdWN0cz9wYWdlPWAgKyBwYXJhbXMucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0RmVhdHVyZWRQcm9kdWN0cyhwYXlsb2FkLCBwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWZlYXR1cmVkP3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1saXN0LWZpbHRlcj9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIjIyMjIyMjIyMjIyNcIixyZXNwb25zZSlcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE5ld0RlYWxzUHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1kZWFscz9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja2luZ1NhbGVQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9jay1zYWxlLXByb2R1Y3RzP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0RmVhdHVyZWRQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWZlYXR1cmVkP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob2NraW5nUHJvZHVjdHMocGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZS1wcm9kdWN0cz9wYWdlPWAgKyBwYXJhbXMucGFnZVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0QnJhbmRzKCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYnJhbmRgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RDYXRlZ29yaWVzKCkge1xyXG4gICAgLy8gY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L3Byb2R1Y3QtY2F0ZWdvcmllc2ApXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2F0LXN1YmNhdGAse1xyXG4gICAgICBsYW5nX2lkOmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ0lkXCIpfVxyXG4gICAgICBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRUb3RhbFJlY29yZHMoKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vcHJvZHVjdHMvY291bnRgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlJZChpZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLi5cIixpZClcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS51c2VyZGF0YS5cIix1c2VyZGF0YSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS4ucGFyc2VkYXRhXCIscGFyc2VkYXRhKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLmFjY2Vzc190b2tlbi5cIixhY2Nlc3NfdG9rZW4pXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuZ2V0RGV2aWNlSWQuXCIsZ2V0RGV2aWNlSWQpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuYWNjZXNzX3Rva2VuLlwiLGFjY2Vzc190b2tlbilcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1kZXRhaWxgLFxyXG4gICAgICB7XHJcbiAgICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIGxhbmdfaWQ6bG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nSWRcIiksXHJcbiAgICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgICBwYWdlX3VybDogYCR7YmFzZVBhdGhVcmx9L3Byb2R1Y3QvJHtpZH1gLFxyXG4gICAgICAgIG9zX3R5cGU6IG9zVHlwZSgpLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uLi5cIixyZXNwb25zZSlcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja1NhbGVCeWlkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUNhdGVnb3J5KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChcclxuICAgICAgYCR7YmFzZVVybH0vcHJvZHVjdC1jYXRlZ29yaWVzP3NsdWc9JHtwYXlsb2FkfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGFbMF07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUJyYW5kKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9icmFuZHM/c2x1Zz0ke3BheWxvYWR9YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGFbMF07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlCcmFuZHMocGF5bG9hZCkge1xyXG4gICAgbGV0IHF1ZXJ5ID0gXCJcIjtcclxuICAgIHBheWxvYWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAocXVlcnkgPT09IFwiXCIpIHtcclxuICAgICAgICBxdWVyeSA9IGBpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBxdWVyeSA9IHF1ZXJ5ICsgYCZpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vYnJhbmRzPyR7cXVlcnl9YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5QnJhbmRzKHBheWxvYWQpIHtcclxuICAgIGxldCBxdWVyeSA9IFwiXCI7XHJcbiAgICBwYXlsb2FkLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHF1ZXJ5ID09PSBcIlwiKSB7XHJcbiAgICAgICAgcXVlcnkgPSBgaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcXVlcnkgPSBxdWVyeSArIGAmaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L2JyYW5kcz8ke3F1ZXJ5fWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeVByaWNlUmFuZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KFxyXG4gICAgICBgJHtiYXNlVXJsfS9wcm9kdWN0cz8ke3NlcmlhbGl6ZVF1ZXJ5KHBheWxvYWQpfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBhZGRQcm9kdWN0VG9DYXJ0KHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLi41NjU2NTY1NjU2NTY1Ni4uLlwiLHBheWxvYWQpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkLWNhcnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuICBhc3luYyBjaGFuZ2VRdHkocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NhcnQvY2hhbmdlLXF0eWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBwbGFjZU9yZGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLi4uMzMzMzMzMzMzMy4uLi4uLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL3BsYWNlb3JkZXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2FydChwYXlsb2FkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5hYWFhLi4uLlwiLHBheWxvYWQpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBkZWxldGVDYXJ0KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9kZWxldGUtY2FydGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRBdWN0aW9uUHJvZHVjdEJ5QXVjdGlvbklkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hdWN0aW9uYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNyZWF0ZUJpZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY3JlYXRlLWJpZGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9wRGV0YWlsQnlJZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvcC1kZXRhaWxgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2hlY2tvdXRJbmZvKHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uZ2V0Q2hlY2tvdXRJbmZvLi4uIGFweWxvYWQuLlwiLHBheWxvYWQpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLmdldENoZWNrb3V0SW5mby4uLiBhcGliYXNldXJsLi5cIixhcGliYXNldXJsKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL2NoZWNrb3V0LWluZm9gLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGxhY2VBdWN0aW9uT3JkZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2F1Y3Rpb24vY2hlY2tvdXRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IFByb2R1Y3RSZXBvc2l0b3J5KCk7XHJcbiIsImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuY29uc3QgYmFzZURvbWFpbiA9IFwiaHR0cHM6Ly9iZXRhLmFwaW5vdXRoZW1lcy5jb21cIjsgLy8gQVBJIGZvciBwcm9kdWN0c1xyXG5leHBvcnQgY29uc3QgYmFzZVBvc3RVcmwgPSBcImh0dHBzOi8vYmV0YS5hcGlub3V0aGVtZXMuY29tXCI7IC8vIEFQSSBmb3IgcG9zdFxyXG5leHBvcnQgY29uc3QgYmFzZVN0b3JlVVJMID0gXCJodHRwczovL2JldGEuYXBpbm91dGhlbWVzLmNvbVwiOyAvLyBBUEkgZm9yIHZlbmRvcihzdG9yZSlcclxuXHJcbmxldCBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL3FhLWJpZ2Jhc2tldC5lc3RycmFkb3dlYi5jb21cIjtcclxubGV0IGJhc2VQYXRoID0gXCJodHRwczovL2Rldi1rYW5ndGFvLnZlcmNlbC5hcHBcIjtcclxuaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICBpZiAod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lID09IFwidWF0LWthbmd0YW8udmVyY2VsLmFwcFwiKSB7XHJcbiAgICBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL3VhdC1rdC5lc3RycmFkb3dlYi5jb21cIjtcclxuICAgIGJhc2VQYXRoID0gXCJodHRwczovL3VhdC1rYW5ndGFvLnZlcmNlbC5hcHBcIjtcclxuICB9XHJcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSA9PSBcInFhLWthbmd0YW8udmVyY2VsLmFwcFwiKSB7XHJcbiAgICBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL3FhLWt0LmVzdHJyYWRvd2ViLmNvbVwiO1xyXG4gICAgYmFzZVBhdGggPSBcImh0dHBzOi8vcWEta2FuZ3Rhby52ZXJjZWwuYXBwXCI7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgYXBpYmFzZXVybCA9IGFwaWJhc2V1cmxDdXN0b207XHJcbmV4cG9ydCBjb25zdCBiYXNlUGF0aFVybCA9IGJhc2VQYXRoO1xyXG5cclxuZXhwb3J0IGNvbnN0IGN1c3RvbUhlYWRlcnMgPSB7XHJcbiAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBiYXNlVXJsID0gYCR7YmFzZURvbWFpbn1gO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXhpb3MuY3JlYXRlKHtcclxuICBiYXNlVXJsLFxyXG4gIGhlYWRlcnM6IGN1c3RvbUhlYWRlcnMsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHNlcmlhbGl6ZVF1ZXJ5ID0gKHF1ZXJ5KSA9PiB7XHJcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHF1ZXJ5KVxyXG4gICAgLm1hcChcclxuICAgICAgKGtleSkgPT4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5W2tleV0pfWBcclxuICAgIClcclxuICAgIC5qb2luKFwiJlwiKTtcclxufTtcclxuIiwiaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgYWxsLCBwdXQsIHRha2VFdmVyeSwgY2FsbCB9IGZyb20gXCJyZWR1eC1zYWdhL2VmZmVjdHNcIjtcclxuaW1wb3J0IEFjY291bnRSZXBvc2l0b3J5IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9BY2NvdW50UmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24sIG1lc3NhZ2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgcm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBhY3Rpb25UeXBlcyxcclxuICBnZXRDdXN0b21lclByb2ZpbGVTdWNjZXNzLFxyXG4gIHVwZGF0ZUN1c3RvbWVyUHJvZmlsZVN1Y2Nlc3MsXHJcbiAgZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3c1N1Y2Nlc3MsXHJcbiAgZ2V0Q3VzdG9tZXJBZGRyZXNzU3VjY2VzcyxcclxuICBnZXRDdXN0b21lckFkZHJlc3MsXHJcbiAgZ2V0Q3VzdG9tZXJDaGF0TGlzdFN1Y2Nlc3MsXHJcbiAgZ2V0Q3VzdG9tZXJDaGF0TWVzc2FnZVN1Y2Nlc3MsXHJcbiAgZ2V0TXlPcmRlcnNTdWNjZXNzLFxyXG4gIGdldE9yZGVyRGV0YWlsc1N1Y2Nlc3MsXHJcbiAgZ2V0TXlPcmRlcnMsXHJcbiAgZ2V0VG9rZW5MaXN0U3VjY2VzcyxcclxuICBnZXRTdXBwb3J0TWVzc2FnZWZyb21TdXBwb3J0SWRTdWNjZXNzLFxyXG4gIGdldFdhbGxldERldGFpbHNTdWNjZXNzLFxyXG4gIGdldEF1Y3Rpb25DYXJ0RGF0YVN1Y2Nlc3MsXHJcbiAgZ2V0QXVjdGlvbk9yZGVyTGlzdFN1Y2Nlc3MsXHJcbiAgZ2V0Q291bnRyeURhdGFTdWNjZXNzLFxyXG4gIGdldFVzZXJOb3RpZmljYXRpb25zU3VjY2VzcyxcclxuICBnZXRDdXN0b21lckNoYXRNZXNzYWdlLFxyXG4gIGdldFVzZXJQdXJjaGFzZVllYXJTdWNjZXNzLFxyXG59IGZyb20gXCIuL2FjdGlvblwiO1xyXG5pbXBvcnQgeyBsb2dPdXQgfSBmcm9tIFwiLi4vYXV0aC9hY3Rpb25cIjtcclxuXHJcbmNvbnN0IG1vZGFsU3VjY2VzcyA9ICh0eXBlKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2U6IFwiV2VsbGNvbWVcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIllvdSBhcmUgbG9nZ2VkIGluIHN1Y2Nlc3NmdWxseSFcIixcclxuICB9KTtcclxufTtcclxuY29uc3QgbW9kYWxPcGVuID0gKHR5cGUsIG1lc3NhZ2UsIGRlc2NyaXB0aW9uKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2UsXHJcbiAgICBkZXNjcmlwdGlvbixcclxuICB9KTtcclxufTtcclxuXHJcbmZ1bmN0aW9uKiBnZXRNeU9yZGVyc1NhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldE15T3JkZXJzLCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChyZXNwb25zZS5odHRwY29kZSA9PSAyMDAgJiYgZ2V0TXlPcmRlcnNTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0Q3VzdG9tZXJQcm9maWxlKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChcclxuICAgICAgQWNjb3VudFJlcG9zaXRvcnkuZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG5cclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSA0MDEpIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkludmFsaWQgQWNjZXNzIFRva2VuISBMb2dpbiBBZ2FpblwiKTtcclxuICAgICAgcm91dGVyLnB1c2goXCIvYWNjb3VudC9sb2dpblwiKTtcclxuICAgICAgeWllbGQgcHV0KGxvZ091dCgpKTtcclxuICAgIH1cclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgeWllbGQgcHV0KGdldEN1c3RvbWVyUHJvZmlsZVN1Y2Nlc3MocmVzcG9uc2UuZGF0YSkpO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiB1cGRhdGVDdXN0b21lclByb2ZpbGUoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBBY2NvdW50UmVwb3NpdG9yeS51cGRhdGVDdXN0b21lclByb2ZpbGVEZXRhaWwsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IDQwMSkge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiSW52YWxpZCBBY2Nlc3MgVG9rZW4hIExvZ2luIEFnYWluXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSAyMDAgJiYgcmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlByb2ZpbGUgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChyZXNwb25zZS5lcnJvcikge1xyXG4gICAgICByZXNwb25zZS5lcnJvci5tYXAoKGVycm9yKSA9PiB7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3IsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgeWllbGQgcHV0KGdldEN1c3RvbWVyUHJvZmlsZSgpKTtcclxuICAgIHlpZWxkIHB1dCh1cGRhdGVDdXN0b21lclByb2ZpbGVTdWNjZXNzKHJlc3BvbnNlKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEN1c3RvbWVyUmVjZW50Vmlld3NTbHVnKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChcclxuICAgICAgQWNjb3VudFJlcG9zaXRvcnkuZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3cyxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKTtcclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lclJlY2VudFZpZXdzU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEN1c3RvbWVyQWRkcmVzc1NsdWcoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRDdXN0b21lckFkZHJlc3Nlcyk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJBZGRyZXNzU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIG1ha2VEZWZhdWx0QWRkcmVzc1NhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBBY2NvdW50UmVwb3NpdG9yeS5tYWtlRGVmYXVsdEFkZHJlc3NlcyxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKTtcclxuICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIFVwZGF0aW5nIERlZmF1bHQgQWRkcmVzcyFcIik7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJBZGRyZXNzKCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBkZWxldGVBZGRyZXNzU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuZGVsZXRlQWRkcmVzcywgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MocmVzcG9uc2UuZGF0YS5tZXNzYWdlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJFcnJvciBEZWxldGluZyBBZGRyZXNzIVwiKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lckFkZHJlc3MoKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGFkZEFkZHJlc3NTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIC8vIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5hZGRBZGRyZXNzLCBwYXlsb2FkKTtcclxuICAgIC8vIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAvLyAgIG1lc3NhZ2Uuc3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2UpO1xyXG4gICAgLy8gfSBlbHNlIHtcclxuICAgIC8vICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIFVwZGF0aW5nIEFkZHJlc3MhXCIpO1xyXG4gICAgLy8gfVxyXG4gICAgeWllbGQgcHV0KGdldEN1c3RvbWVyQWRkcmVzcygpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0Q2hhdExpc3RTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRDaGF0TGlzdCwgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIFdoaWxlIEZldGNoaW5nIENoYXRzIVwiKTtcclxuICAgIH1cclxuXHJcbiAgICB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJDaGF0TGlzdFN1Y2Nlc3MocmVzcG9uc2UuZGF0YS5saXN0KSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEN1c3RvbWVyQ2hhdE1lc3NhZ2VTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRDaGF0TWVzc2FnZSwgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIFdoaWxlIEZldGNoaW5nIENoYXRzIVwiKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dChnZXRDdXN0b21lckNoYXRNZXNzYWdlU3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2VzKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIHNlbmRNZXNzYWdlVG9TZWxsZXJTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5zZW5kTWVzc2FnZSwgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkVycm9yIFdoaWxlIFNlbmRpbmcgTWVzc2FnZSFcIik7XHJcbiAgICB9XHJcbiAgICAvLyB5aWVsZCBwdXQoZ2V0Q3VzdG9tZXJDaGF0TWVzc2FnZVN1Y2Nlc3MocmVzcG9uc2UuZGF0YS5tZXNzYWdlcykpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBnZXRPcmRlckRldGFpbHNTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRPcmRlckRldGFpbHMsIHBheWxvYWQpO1xyXG4gICAgaWYgKHJlc3BvbnNlLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IocmVzcG9uc2UubWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQoZ2V0T3JkZXJEZXRhaWxzU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGNhbmNlbE9yZGVyUmVxdWVzdFNhZ2EoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmNhbmNlbE9yZGVyUmVxdWVzdCwgcGF5bG9hZCk7XHJcbiAgICBsZXQgZGF0YV9wYXlsb2FkID0ge1xyXG4gICAgICBhY2Nlc3NfdG9rZW46IHBheWxvYWQuYWNjZXNzX3Rva2VuLFxyXG4gICAgICBsYW5nX2lkOmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ0lkXCIpLFxyXG4gICAgfTtcclxuICAgIHlpZWxkIHB1dChnZXRNeU9yZGVycyhkYXRhX3BheWxvYWQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0VG9rZW5MaXN0U2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkubGlzdFN1cHBvcnRUb2tlbiwgcGF5bG9hZCk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0VG9rZW5MaXN0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldFN1cHBvcnRNZXNzYWdlU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuc3VwcG9ydE1lc3NhZ2VCeUlELCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRTdXBwb3J0TWVzc2FnZWZyb21TdXBwb3J0SWRTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0VXNlcldhbGxldERldGFpbHMoeyBwYXlsb2FkIH0pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKEFjY291bnRSZXBvc2l0b3J5LmdldFdhbGxldERldGFpbHMsIHBheWxvYWQpO1xyXG5cclxuICAgIHlpZWxkIHB1dChnZXRXYWxsZXREZXRhaWxzU3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBtb2RhbE9wZW4oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgV2FsbGV0IERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEF1Y3Rpb25EYXRhU2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQWNjb3VudFJlcG9zaXRvcnkuZ2V0QXVjdGlvbkNhcnREYXRhLCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRBdWN0aW9uQ2FydERhdGFTdWNjZXNzKHJlc3BvbnNlLmRhdGEpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBBdWN0aW9uIERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldEF1Y3Rpb25PcmRlckxpc3RTYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRBdWN0aW9uT3JkZXJMaXN0LCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRBdWN0aW9uT3JkZXJMaXN0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBtb2RhbE9wZW4oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgV2hpbGUgRmV0Y2hpbmcgQXVjdGlvbiBEYXRhXCIpO1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBnZXRDb3VudHJ5RGF0YVNhZ2EoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRDb3VudHJ5KTtcclxuICAgIHlpZWxkIHB1dChnZXRDb3VudHJ5RGF0YVN1Y2Nlc3MocmVzcG9uc2UpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBDb3VudHJ5IERhdGFcIik7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGdldFVzZXJOb3RpZmljYXRpb25TYWdhKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChBY2NvdW50UmVwb3NpdG9yeS5nZXRVc2VyTm90aWZpY2F0aW9uLCBwYXlsb2FkKTtcclxuICAgIHlpZWxkIHB1dChnZXRVc2VyTm90aWZpY2F0aW9uc1N1Y2Nlc3MocmVzcG9uc2UuZGF0YSkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbW9kYWxPcGVuKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIkVycm9yIFdoaWxlIEZldGNoaW5nIE5vdGlmaWNhdGlvbnNcIik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZ2V0UHVyY2hhc2VZZWFyKHsgcGF5bG9hZCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChcclxuICAgICAgQWNjb3VudFJlcG9zaXRvcnkuZ2V0VXNlclB1cmNoYXNlWWVhcnMsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICB5aWVsZCBwdXQoXHJcbiAgICAgIHJlc3BvbnNlLmh0dHBjb2RlID09IDIwMCAmJiBnZXRVc2VyUHVyY2hhc2VZZWFyU3VjY2VzcyhyZXNwb25zZS5kYXRhKVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIG1vZGFsT3BlbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBXaGlsZSBGZXRjaGluZyBZZWFycyFcIik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiogcm9vdFNhZ2EoKSB7XHJcbiAgLy8geWllbGQgYWxsKFtcclxuICAvLyAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfTkVXX1NFTExFUl9DSEFUUywgZ2V0TmV3U2VsbGVyQ2hhdHNTYWdhKSxcclxuICAvLyBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KFxyXG4gICAgICBhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfQ0hBVF9NRVNTQUdFLFxyXG4gICAgICBnZXRDdXN0b21lckNoYXRNZXNzYWdlU2FnYVxyXG4gICAgKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLlNFTkRfTUVTU0FHRV9UT19TRUxMRVIsIHNlbmRNZXNzYWdlVG9TZWxsZXJTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfQ0hBVF9MSVNULCBnZXRDaGF0TGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX01ZX09SREVSUywgZ2V0TXlPcmRlcnNTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9DVVNUT01FUl9QUk9GSUxFLCBnZXRDdXN0b21lclByb2ZpbGUpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5VUERBVEVfQ1VTVE9NRVJfUFJPRklMRSwgdXBkYXRlQ3VzdG9tZXJQcm9maWxlKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KFxyXG4gICAgICBhY3Rpb25UeXBlcy5HRVRfQ1VTVE9NRVJfUkVDRU5UX1ZJRVdTLFxyXG4gICAgICBnZXRDdXN0b21lclJlY2VudFZpZXdzU2x1Z1xyXG4gICAgKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9DVVNUT01FUl9BRERSRVNTLCBnZXRDdXN0b21lckFkZHJlc3NTbHVnKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLk1BS0VfREVGQVVMVF9BRERSRVNTLCBtYWtlRGVmYXVsdEFkZHJlc3NTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5BRERfQUREUkVTUywgYWRkQWRkcmVzc1NhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuREVMRVRFX0FERFJFU1MsIGRlbGV0ZUFkZHJlc3NTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9PUkRFUl9ERVRBSUxTLCBnZXRPcmRlckRldGFpbHNTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoYWN0aW9uVHlwZXMuTUFLRV9DQU5DRUxfT1JERVJfUkVRVUVTVCwgY2FuY2VsT3JkZXJSZXF1ZXN0U2FnYSksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX1RPS0VOX0xJU1QsIGdldFRva2VuTGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShcclxuICAgICAgYWN0aW9uVHlwZXMuR0VUX1NVUFBPUlRfTUVTU0FHRV9CWV9TVVBQT1JUX0lELFxyXG4gICAgICBnZXRTdXBwb3J0TWVzc2FnZVNhZ2FcclxuICAgICksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX1dBTExFVF9ERVRBSUxTLCBnZXRVc2VyV2FsbGV0RGV0YWlscyldKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQVVDVElPTl9DQVJUX0RBVEEsIGdldEF1Y3Rpb25EYXRhU2FnYSldKTtcclxuICB5aWVsZCBhbGwoW1xyXG4gICAgdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9BVUNUSU9OX09SREVSX0xJU1QsIGdldEF1Y3Rpb25PcmRlckxpc3RTYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfQ09VTlRSWV9EQVRBLCBnZXRDb3VudHJ5RGF0YVNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfVVNFUl9OT1RJRklDQVRJT04sIGdldFVzZXJOb3RpZmljYXRpb25TYWdhKSxcclxuICBdKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5HRVRfVVNFUl9QVVJDSEFTRV9ZRUFSUywgZ2V0UHVyY2hhc2VZZWFyKV0pO1xyXG59XHJcbiIsImV4cG9ydCBjb25zdCBhY3Rpb25UeXBlcyA9IHtcclxuICBHRVRfQ0FSVDogXCJHRVRfQ0FSVFwiLFxyXG4gIEdFVF9DQVJUX1NVQ0NFU1M6IFwiR0VUX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIEdFVF9DQVJUX0VSUk9SOiBcIkdFVF9DQVJUX0VSUk9SXCIsXHJcblxyXG4gIEdFVF9DQVJUX1RPVEFMX1FVQU5USVRZOiBcIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZXCIsXHJcbiAgR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlfU1VDQ0VTUzogXCJHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWV9TVUNDRVNTXCIsXHJcblxyXG4gIEFERF9JVEVNOiBcIkFERF9JVEVNXCIsXHJcbiAgUkVNT1ZFX0lURU06IFwiUkVNT1ZFX0lURU1cIixcclxuICBSRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXOiBcIlJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVdcIixcclxuXHJcbiAgQ0xFQVJfQ0FSVDogXCJDTEVBUl9DQVJUXCIsXHJcbiAgQ0xFQVJfQ0FSVF9TVUNDRVNTOiBcIkNMRUFSX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIENMRUFSX0NBUlRfRVJST1I6IFwiQ0xFQVJfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBJTkNSRUFTRV9RVFk6IFwiSU5DUkVBU0VfUVRZXCIsXHJcbiAgSU5DUkVBU0VfUVRZX1NVQ0NFU1M6IFwiSU5DUkVBU0VfUVRZX1NVQ0NFU1NcIixcclxuICBJTkNSRUFTRV9RVFlfRVJST1I6IFwiSU5DUkVBU0VfUVRZX0VSUk9SXCIsXHJcblxyXG4gIERFQ1JFQVNFX1FUWTogXCJERUNSRUFTRV9RVFlcIixcclxuICBVUERBVEVfQ0FSVDogXCJVUERBVEVfQ0FSVFwiLFxyXG5cclxuICBVUERBVEVfQ0FSVF9TVUNDRVNTOiBcIlVQREFURV9DQVJUX1NVQ0NFU1NcIixcclxuICBVUERBVEVfQ0FSVF9FUlJPUjogXCJVUERBVEVfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBVUERBVEVfU0VMRUNURURfQUREUkVTUzogXCJVUERBVEVfU0VMRUNURURfQUREUkVTU1wiLFxyXG5cclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSOiBcIkZFVENIX1BMQVRGT1JNX1ZPVUNIRVJcIixcclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSX1NVQ0NFU1M6IFwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTXCIsXHJcblxyXG4gIFRPVEFMX0RJU0NPVU5UOiBcIlRPVEFMX0RJU0NPVU5UXCIsXHJcblxyXG4gIEFQUExJRURfU0VMTEVSX1ZPVUNIRVI6IFwiQVBQTElFRF9TRUxMRVJfVk9VQ0hFUlwiLFxyXG5cclxuICBBUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVI6IFwiQVBQTElFRF9QTEFURk9STV9WT1VDSEVSXCIsXHJcblxyXG4gIEdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUU6IFwiR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRVwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9ESVNDT1VOVDogXCJTRUxMRVJfV0lTRV9ESVNDT1VOVFwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9NRVNTQUdFUzogXCJTRUxMRVJfV0lTRU1FU1NBR0VTXCIsXHJcblxyXG4gIFVTRURfV0FMTEVUX0FNT1VOVDogXCJVU0VEX1dBTExFVF9BTU9VTlRcIixcclxuXHJcbiAgU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUjogXCJTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSXCIsXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3KHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5SRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RlZFBheW1lbnRPcHRpb24ocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTEVDVEVEX1BBWU1FTlRfT1BUSU9OX0JZX1VTRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbGxlcldpc2VNZXNzYWdlKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5TRUxMRVJfV0lTRV9NRVNTQUdFUywgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlZFdhbGxldEFtb3VudChwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuVVNFRF9XQUxMRVRfQU1PVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxsZXJXaXNlRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTExFUl9XSVNFX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBncmFuZFRvdGFsV2l0aERpc2NvdW50VmFsdWUocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUUsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGxpZWRTZWxsZXJWb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1NFTExFUl9WT1VDSEVSLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBsaWVkUGxhdGZvcm1Wb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvdGFsRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlRPVEFMX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbigpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUixcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hQbGF0Zm9ybVZvdWNoZXJBY3Rpb25TdWNjZXNzKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydCgpIHtcclxuIC8vIGFsZXJ0KFwiZ2V0Q2FydFwiKVxyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJ0U3VjY2VzcyhwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUX1NVQ0NFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJ0RXJyb3IoZXJyb3IpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuR0VUX0NBUlRfRVJST1IsXHJcbiAgICBlcnJvcixcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlU2VsZWN0ZWRBZGRyZXNzKHBheWxvYWQpIHtcclxuIC8vIGFsZXJ0KFwiY2FsbFwiKVxyXG4gIGNvbnNvbGUubG9nKFwiLi41NTU1NTUuLi4uXCIscGF5bG9hZClcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLlVQREFURV9TRUxFQ1RFRF9BRERSRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYWRkSXRlbShwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuQUREX0lURU0sIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZUl0ZW0ocHJvZHVjdCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlJFTU9WRV9JVEVNLCBwcm9kdWN0IH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmNyZWFzZUl0ZW1RdHkocHJvZHVjdCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLklOQ1JFQVNFX1FUWSwgcHJvZHVjdCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZGVjcmVhc2VJdGVtUXR5KHByb2R1Y3QpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5ERUNSRUFTRV9RVFksIHByb2R1Y3QgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZUNhcnRTdWNjZXNzKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX0NBUlRfU1VDQ0VTUyxcclxuICAgIHBheWxvYWQsXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZUNhcnRFcnJvcihwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLlVQREFURV9DQVJUX0VSUk9SLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJDYXJ0KCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkNMRUFSX0NBUlQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyQ2FydFN1Y2Nlc3MoKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuQ0xFQVJfQ0FSVF9TVUNDRVNTIH07XHJcbn1cclxuIiwiaW1wb3J0IHsgYWxsLCBwdXQsIHRha2VFdmVyeSwgY2FsbCB9IGZyb20gXCJyZWR1eC1zYWdhL2VmZmVjdHNcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgYWN0aW9uVHlwZXMsXHJcbiAgZ2V0Q2FydEVycm9yLFxyXG4gIGdldENhcnRTdWNjZXNzLFxyXG4gIHVwZGF0ZUNhcnRTdWNjZXNzLFxyXG4gIHVwZGF0ZUNhcnRFcnJvcixcclxuICBnZXRDYXJ0LFxyXG4gIGNsZWFyQ2FydFN1Y2Nlc3MsXHJcbiAgZmV0Y2hQbGF0Zm9ybVZvdWNoZXJBY3Rpb25TdWNjZXNzLFxyXG59IGZyb20gXCIuL2FjdGlvblwiO1xyXG5pbXBvcnQgQ2FydFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL0NhcnRSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgZGlzcGxheU5vdGlmaWNhdGlvbiB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5cclxuY29uc3QgbW9kYWxTdWNjZXNzID0gKHR5cGUsIG1lc3NhZ2UpID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZSxcclxuICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgcHJvZHVjdCBoYXMgYmVlbiBhZGRlZCB0byB5b3VyIGNhcnQhXCIsXHJcbiAgICBkdXJhdGlvbjogMSxcclxuICB9KTtcclxufTtcclxuY29uc3QgbW9kYWxXYXJuaW5nID0gKHR5cGUpID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZTogXCJSZW1vdmUgQSBJdGVtXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJUaGlzIHByb2R1Y3QgaGFzIGJlZW4gcmVtb3ZlZCBmcm9tIHlvdXIgY2FydCFcIixcclxuICAgIGR1cmF0aW9uOiAxLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGNhbGN1bGF0ZUFtb3VudCA9IChvYmopID0+XHJcbiAgT2JqZWN0LnZhbHVlcyhvYmopXHJcbiAgICAucmVkdWNlKChhY2MsIHsgcXVhbnRpdHksIHByaWNlIH0pID0+IGFjYyArIHF1YW50aXR5ICogcHJpY2UsIDApXHJcbiAgICAudG9GaXhlZCgyKTtcclxuXHJcbmZ1bmN0aW9uKiBnZXRDYXJ0U2FnYSgpIHtcclxuIC8vIGFsZXJ0KFwiYmJiYmJcIilcclxuICB0cnkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgbGV0IGxhbmdfaWQgPSAobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJsYW5nSWRcIikpO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgbGFuZ19pZCxcclxuICAgIH07XHJcbmNvbnNvbGUubG9nKFwiLi4uZ2V0Q2FydFNhZ2EuLnBheWxvYWQuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSB5aWVsZCBjYWxsKENhcnRSZXBvc2l0b3J5LmdldENhcnRJdGVtLCBwYXlsb2FkKTtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uZ2V0Q2FydFNhZ2EuLnBheWxvYWQuLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uLi5hYmNkLi4uLi5cIixyZXNwb25zZSlcclxuICAgIHlpZWxkIHB1dChnZXRDYXJ0U3VjY2VzcyhyZXNwb25zZS5kYXRhKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGFkZEl0ZW1TYWdhKHsgcGF5bG9hZCB9KSB7XHJcbi8vICBhbGVydChcImFhYWFhYWFhYWFhXCIpXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0geWllbGQgY2FsbChDYXJ0UmVwb3NpdG9yeS5hZGRQcm9kdWN0VG9DYXJ0LCBwYXlsb2FkKTtcclxuXHJcbiAgICBtb2RhbFN1Y2Nlc3MocmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5tZXNzYWdlKTtcclxuICAgIHlpZWxkIHB1dChnZXRDYXJ0KHBheWxvYWQuYWNjZXNzX3Rva2VuKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIHJlbW92ZUl0ZW1TYWdhKHBheWxvYWQpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgeyBwcm9kdWN0IH0gPSBwYXlsb2FkO1xyXG4gICAgbGV0IGxvY2FsQ2FydCA9IEpTT04ucGFyc2UoXHJcbiAgICAgIEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJwZXJzaXN0Okthbmd0YW9cIikpLmNhcnRcclxuICAgICk7XHJcblxyXG4gICAgbGV0IGluZGV4ID0gbG9jYWxDYXJ0LmNhcnRJdGVtcy5maW5kSW5kZXgoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHByb2R1Y3QuaWQpO1xyXG4gICAgbG9jYWxDYXJ0LmNhcnRUb3RhbCA9IGxvY2FsQ2FydC5jYXJ0VG90YWwgLSBwcm9kdWN0LnF1YW50aXR5O1xyXG4gICAgbG9jYWxDYXJ0LmNhcnRJdGVtcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgbG9jYWxDYXJ0LmFtb3VudCA9IGNhbGN1bGF0ZUFtb3VudChsb2NhbENhcnQuY2FydEl0ZW1zKTtcclxuICAgIGlmIChsb2NhbENhcnQuY2FydEl0ZW1zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBsb2NhbENhcnQuY2FydEl0ZW1zID0gW107XHJcbiAgICAgIGxvY2FsQ2FydC5hbW91bnQgPSAwO1xyXG4gICAgICBsb2NhbENhcnQuY2FydFRvdGFsID0gMDtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dCh1cGRhdGVDYXJ0U3VjY2Vzcyhsb2NhbENhcnQpKTtcclxuICAgIG1vZGFsV2FybmluZyhcIndhcm5pbmdcIik7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGluY3JlYXNlUXR5U2FnYShwYXlsb2FkKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHsgcHJvZHVjdCB9ID0gcGF5bG9hZDtcclxuICAgIGxldCBsb2NhbENhcnQgPSBKU09OLnBhcnNlKFxyXG4gICAgICBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicGVyc2lzdDpLYW5ndGFvXCIpKS5jYXJ0XHJcbiAgICApO1xyXG4gICAgbGV0IHNlbGVjdGVkSXRlbSA9IGxvY2FsQ2FydC5jYXJ0SXRlbXMuZmluZChcclxuICAgICAgKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHByb2R1Y3QuaWRcclxuICAgICk7XHJcbiAgICBpZiAoc2VsZWN0ZWRJdGVtKSB7XHJcbiAgICAgIHNlbGVjdGVkSXRlbS5xdWFudGl0eSsrO1xyXG4gICAgICBsb2NhbENhcnQuY2FydFRvdGFsKys7XHJcbiAgICAgIGxvY2FsQ2FydC5hbW91bnQgPSBjYWxjdWxhdGVBbW91bnQobG9jYWxDYXJ0LmNhcnRJdGVtcyk7XHJcbiAgICB9XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlQ2FydFN1Y2Nlc3MobG9jYWxDYXJ0KSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICB5aWVsZCBwdXQoZ2V0Q2FydEVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGRlY3JlYXNlSXRlbVF0eVNhZ2EocGF5bG9hZCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB7IHByb2R1Y3QgfSA9IHBheWxvYWQ7XHJcbiAgICBjb25zdCBsb2NhbENhcnQgPSBKU09OLnBhcnNlKFxyXG4gICAgICBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicGVyc2lzdDpLYW5ndGFvXCIpKS5jYXJ0XHJcbiAgICApO1xyXG4gICAgbGV0IHNlbGVjdGVkSXRlbSA9IGxvY2FsQ2FydC5jYXJ0SXRlbXMuZmluZChcclxuICAgICAgKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHByb2R1Y3QuaWRcclxuICAgICk7XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkSXRlbSkge1xyXG4gICAgICBzZWxlY3RlZEl0ZW0ucXVhbnRpdHktLTtcclxuICAgICAgbG9jYWxDYXJ0LmNhcnRUb3RhbC0tO1xyXG4gICAgICBsb2NhbENhcnQuYW1vdW50ID0gY2FsY3VsYXRlQW1vdW50KGxvY2FsQ2FydC5jYXJ0SXRlbXMpO1xyXG4gICAgfVxyXG4gICAgeWllbGQgcHV0KHVwZGF0ZUNhcnRTdWNjZXNzKGxvY2FsQ2FydCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgeWllbGQgcHV0KGdldENhcnRFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiBjbGVhckNhcnRTYWdhKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBlbXB0eUNhcnQgPSB7XHJcbiAgICAgIGNhcnRJdGVtczogW10sXHJcbiAgICAgIGFtb3VudDogMCxcclxuICAgICAgY2FydFRvdGFsOiAwLFxyXG4gICAgICBjYXJ0OiBbXSxcclxuICAgIH07XHJcbiAgICB5aWVsZCBwdXQoY2xlYXJDYXJ0U3VjY2VzcyhlbXB0eUNhcnQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHlpZWxkIHB1dCh1cGRhdGVDYXJ0RXJyb3IoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiogZmV0Y2hQbGF0Zm9ybVZvdWNoZXJTYWdhKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoQ2FydFJlcG9zaXRvcnkuZmV0Y2hQbGF0Zm9ybVZvdWNoZXIpO1xyXG4gICAgeWllbGQgcHV0KGZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uU3VjY2VzcyhyZXNwb25zZS5kYXRhLmNvdXBvbikpO1xyXG4gIH0gY2F0Y2ggKGVycikge31cclxufVxyXG5cclxuZnVuY3Rpb24qIHJlbW92ZUZyb21DYXJ0TmV3U2FnYSh7IHBheWxvYWQgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IHlpZWxkIGNhbGwoUHJvZHVjdFJlcG9zaXRvcnkuZGVsZXRlQ2FydCwgcGF5bG9hZCk7XHJcbiAgICBpZiAocmVzcG9uc2UgJiYgcmVzcG9uc2UuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJzdWNjZXNzXCIsIFwiU3VjY2Vzc1wiLCBcIlByb2R1Y3QgUmVtb3ZlZFwiKTtcclxuICAgIH1cclxuICAgIHlpZWxkIHB1dChnZXRDYXJ0KCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJFcnJvciBpbiByZW1vdmluZyBJdGVtXCIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24qIHJvb3RTYWdhKCkge1xyXG4gLy8gYWxlcnQoXCJjY2NjXCIpXHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuR0VUX0NBUlQsIGdldENhcnRTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkFERF9JVEVNLCBhZGRJdGVtU2FnYSldKTtcclxuICB5aWVsZCBhbGwoW3Rha2VFdmVyeShhY3Rpb25UeXBlcy5SRU1PVkVfSVRFTSwgcmVtb3ZlSXRlbVNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuSU5DUkVBU0VfUVRZLCBpbmNyZWFzZVF0eVNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFt0YWtlRXZlcnkoYWN0aW9uVHlwZXMuREVDUkVBU0VfUVRZLCBkZWNyZWFzZUl0ZW1RdHlTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkNMRUFSX0NBUlQsIGNsZWFyQ2FydFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5GRVRDSF9QTEFURk9STV9WT1VDSEVSLCBmZXRjaFBsYXRmb3JtVm91Y2hlclNhZ2EpLFxyXG4gIF0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoYWN0aW9uVHlwZXMuUkVNT1ZFX1BST0RVQ1RfRlJPTV9DQVJUX05FVywgcmVtb3ZlRnJvbUNhcnROZXdTYWdhKSxcclxuICBdKTtcclxufVxyXG4iLCJpbXBvcnQgeyBhbGwsIHB1dCwgdGFrZUV2ZXJ5LCBjYWxsIH0gZnJvbSBcInJlZHV4LXNhZ2EvZWZmZWN0c1wiO1xyXG5pbXBvcnQgeyBtZXNzYWdlLCBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIGFjdGlvblR5cGVzLFxyXG4gIGdldFdpc2hsaXN0TGlzdFN1Y2Nlc3MsXHJcbiAgdXBkYXRlV2lzaGxpc3RMaXN0U3VjY2VzcyxcclxuICBnZXRXaXNobGlzdExpc3QsXHJcbiAgY2xlYXJXaXNobGlzdCxcclxufSBmcm9tIFwiLi9hY3Rpb25cIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBhcGliYXNldXJsIH0gZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1JlcG9zaXRvcnlcIjtcclxuaW1wb3J0IFByb2R1Y3RSZXBvc2l0b3J5IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9Qcm9kdWN0UmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgV2lzaGxpc3RSZXBvc2l0b3J5IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9XaXNobGlzdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgZ2V0UHJvZHVjdHNCeUlkLCB1cGRhdGVTaG9ja2luZ3NhbGVXaXNobGlzdCB9IGZyb20gXCIuLi9wcm9kdWN0L2FjdGlvblwiO1xyXG5cclxuY29uc3QgbW9kYWxTdWNjZXNzID0gKHR5cGUpID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZTogXCJBZGRlZCB0byB3aXNobGlzaHQhXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJUaGlzIHByb2R1Y3QgaGFzIGJlZW4gYWRkZWQgdG8gd2lzaGxpc3QhXCIsXHJcbiAgfSk7XHJcbn07XHJcblxyXG5jb25zdCBtb2RhbFdhcm5pbmcgPSAodHlwZSwgbWVzc2FnZSwgZGVzY3JpcHRpb24pID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZTogXCJSZW1vdmVkIGZyb20gd2lzaGxpc3RcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgcHJvZHVjdCBoYXMgYmVlbiByZW1vdmVkIGZyb20gd2lzaGxpc3QhXCIsXHJcbiAgfSk7XHJcbn07XHJcblxyXG5jb25zdCBtb2RhbFJlbW92ZVdhcm5pbmcgPSAodHlwZSwgbWVzc2FnZSwgZGVzY3JpcHRpb24pID0+IHtcclxuICBub3RpZmljYXRpb25bdHlwZV0oe1xyXG4gICAgbWVzc2FnZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gIH0pO1xyXG59O1xyXG5cclxuY29uc3QgbW9kYWxTaG93ID0gKHR5cGUsIG1lc3NhZ2UsIGRlc2NyaXB0aW9uKSA9PiB7XHJcbiAgbm90aWZpY2F0aW9uW3R5cGVdKHtcclxuICAgIG1lc3NhZ2UsXHJcbiAgICBkZXNjcmlwdGlvbixcclxuICB9KTtcclxufTtcclxuXHJcbmZ1bmN0aW9uKiBnZXRXaXNobGlzdExpc3RTYWdhKCkge1xyXG4gIHRyeSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBsZXQgbGFuZ19pZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFuZ0lkXCIpO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgbGFuZ19pZCxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LmdldFByb2R1Y3RUb1dpc2hsaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG5cclxuICAgIHlpZWxkIHB1dChcclxuICAgICAgcmVzcG9uc2VEYXRhPy5odHRwY29kZSA9PSBcIjIwMFwiICYmXHJcbiAgICAgICAgZ2V0V2lzaGxpc3RMaXN0U3VjY2VzcyhyZXNwb25zZURhdGEuZGF0YSlcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGFkZEl0ZW1Ub1dpc2hsaXN0U2FnYSh7IHByb2R1Y3QgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LFxyXG4gICAgICB0eXBlOiBcIndlYlwiLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZXNwb25zZURhdGEgPSB5aWVsZCBjYWxsKFxyXG4gICAgICBXaXNobGlzdFJlcG9zaXRvcnkuYWRkUHJvZHVjdFRvV2lzaExpc3QsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICBtb2RhbFNob3coXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5zdGF0dXMsXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5tZXNzYWdlLFxyXG4gICAgICByZXNwb25zZURhdGEuZGF0YS5tZXNzYWdlXHJcbiAgICApO1xyXG4gICAgeWllbGQgcHV0KGdldFdpc2hsaXN0TGlzdCgpKTtcclxuICAgIHlpZWxkIHB1dChnZXRQcm9kdWN0c0J5SWQocHJvZHVjdCkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVJdGVtV2lzaGxpc3RTYWdhKHsgcHJvZHVjdCB9KSB7XHJcbiAgdHJ5IHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBhY2Nlc3NfdG9rZW4sXHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3QsXHJcbiAgICB9O1xyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LnJlbW92ZVByb2R1Y3RGcm9tV2lzaExpc3QsXHJcbiAgICAgIHBheWxvYWRcclxuICAgICk7XHJcbiAgICBtb2RhbFJlbW92ZVdhcm5pbmcoXHJcbiAgICAgIFwid2FybmluZ1wiLFxyXG4gICAgICByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgcmVzcG9uc2VEYXRhLmRhdGEubWVzc2FnZVxyXG4gICAgKTtcclxuICAgIHlpZWxkIHB1dChnZXRXaXNobGlzdExpc3QoKSk7XHJcblxyXG4gICAgeWllbGQgcHV0KGdldFByb2R1Y3RzQnlJZChwcm9kdWN0KSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24qIGNsZWFyV2lzaGxpc3RMaXN0U2FnYSgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZW1wdHlDYXJ0ID0ge1xyXG4gICAgICB3aXNobGlzdEl0ZW1zOiBbXSxcclxuICAgICAgd2lzaGxpc3RUb3RhbDogMCxcclxuICAgIH07XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlV2lzaGxpc3RMaXN0U3VjY2VzcyhlbXB0eUNhcnQpKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgfVxyXG59XHJcbmZ1bmN0aW9uKiBhZGRTaG9ja2luZ1NhbGVJdGVtVG9XaXNobGlzdFNhZ2EoeyBwcm9kdWN0IH0pIHtcclxuICB0cnkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbixcclxuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdCxcclxuICAgICAgdHlwZTogXCJ3ZWJcIixcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0geWllbGQgY2FsbChcclxuICAgICAgV2lzaGxpc3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb1dpc2hMaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgbW9kYWxTaG93KFxyXG4gICAgICByZXNwb25zZURhdGEuc3RhdHVzLFxyXG4gICAgICByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgcmVzcG9uc2VEYXRhLmRhdGEubWVzc2FnZVxyXG4gICAgKTtcclxuICAgIHlpZWxkIHB1dChnZXRXaXNobGlzdExpc3QoKSk7XHJcbiAgICB5aWVsZCBwdXQodXBkYXRlU2hvY2tpbmdzYWxlV2lzaGxpc3QodHJ1ZSkpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5sb2coZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uKiByZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0U2FnYSh7IHByb2R1Y3QgfSkge1xyXG4gIHRyeSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LFxyXG4gICAgfTtcclxuICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IHlpZWxkIGNhbGwoXHJcbiAgICAgIFdpc2hsaXN0UmVwb3NpdG9yeS5yZW1vdmVQcm9kdWN0RnJvbVdpc2hMaXN0LFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApO1xyXG4gICAgbW9kYWxSZW1vdmVXYXJuaW5nKFxyXG4gICAgICBcIndhcm5pbmdcIixcclxuICAgICAgcmVzcG9uc2VEYXRhLm1lc3NhZ2UsXHJcbiAgICAgIHJlc3BvbnNlRGF0YS5kYXRhLm1lc3NhZ2VcclxuICAgICk7XHJcbiAgICB5aWVsZCBwdXQoZ2V0V2lzaGxpc3RMaXN0KCkpO1xyXG4gICAgeWllbGQgcHV0KHVwZGF0ZVNob2NraW5nc2FsZVdpc2hsaXN0KGZhbHNlKSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24qIHJvb3RTYWdhKCkge1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkdFVF9XSVNITElTVF9MSVNULCBnZXRXaXNobGlzdExpc3RTYWdhKV0pO1xyXG4gIHlpZWxkIGFsbChbdGFrZUV2ZXJ5KGFjdGlvblR5cGVzLkFERF9JVEVNX1dJU0hMSVNILCBhZGRJdGVtVG9XaXNobGlzdFNhZ2EpXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShhY3Rpb25UeXBlcy5SRU1PVkVfSVRFTV9XSVNITElTSCwgcmVtb3ZlSXRlbVdpc2hsaXN0U2FnYSksXHJcbiAgXSk7XHJcbiAgeWllbGQgYWxsKFtcclxuICAgIHRha2VFdmVyeShcclxuICAgICAgYWN0aW9uVHlwZXMuQUREX1NIT0NLSU5HX1NBTEVfSVRFTV9UT19XSVNITElTVCxcclxuICAgICAgYWRkU2hvY2tpbmdTYWxlSXRlbVRvV2lzaGxpc3RTYWdhXHJcbiAgICApLFxyXG4gIF0pO1xyXG4gIHlpZWxkIGFsbChbXHJcbiAgICB0YWtlRXZlcnkoXHJcbiAgICAgIGFjdGlvblR5cGVzLlJFTU9WRV9TSE9DS0lOR19TQUxFX0lURU1fRlJPTV9XSVNITElTVCxcclxuICAgICAgcmVtb3ZlU2hvY2tpbmdTYWxlSXRlbUZyb21XaXNobGlzdFNhZ2FcclxuICAgICksXHJcbiAgXSk7XHJcbn1cclxuIiwiLypcclxuICogUmVhY3QgdGVtcGxhdGUgaGVscGVyc1xyXG4gKiBBdXRob3I6IE5vdXRoZW1lc1xyXG4gKiBEZXZlbG9wZWQ6IGRpYXJ5Zm9ybGlmZVxyXG4gKiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGF6eUxvYWQgZnJvbSBcInJlYWN0LWxhenlsb2FkXCI7XHJcbmltcG9ydCB7IGJhc2VVcmwgfSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBSb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBleGFjdE1hdGggPSByZXF1aXJlKFwiZXhhY3QtbWF0aFwiKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByb3V0ZVdpdGhvdXRSZWZyZXNoKHJvdXRlTGluaykge1xyXG4gIFJvdXRlci5yZXBsYWNlKHJvdXRlTGluaywgdW5kZWZpbmVkLCB7XHJcbiAgICBzaGFsbG93OiB0cnVlLFxyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaG9tZVBhZ2VQcm9kdWN0UHJpY2VIZWxwZXIocHJvZHVjdCkge1xyXG4gIGlmIChwcm9kdWN0Lm9mZmVyX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3Qub2ZmZXJfcHJpY2UgPyBwcm9kdWN0Lm9mZmVyX3ByaWNlIDogMH1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICBpZiAocHJvZHVjdC5zaG9ja19zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3Quc2hvY2tfc2FsZV9wcmljZX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICBpZiAocHJvZHVjdC5zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugb2ZmZXJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3Quc2FsZV9wcmljZX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICBTQVIge3Byb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwfVxyXG4gICAgICAgIDwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG4gICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgU0FSIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgIDwvcD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmV0dXJuVG90YWxPZkNhcnRWYWx1ZShwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX3ByaWNlID0gcHJvZHVjdHMucmVkdWNlKChwcmV2LCBuZXh0KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICBOdW1iZXIocHJpY2VIZWxwZXIocHJldikpICtcclxuICAgICAgTnVtYmVyKFxyXG4gICAgICAgIHByaWNlSGVscGVyKFxyXG4gICAgICAgICAgbmV4dC50b3RhbF9kaXNjb3VudF9wcmljZSA9PSAwXHJcbiAgICAgICAgICAgID8gbmV4dC50b3RhbF9hY3R1YWxfcHJpY2VcclxuICAgICAgICAgICAgOiBuZXh0LnRvdGFsX2Rpc2NvdW50X3ByaWNlXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICApO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF9wcmljZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJldHVyblRvdGFsQ29tbWlzc2lvbihwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX2NvbW1pc3Npb24gPSBwcm9kdWN0cy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IHtcclxuICAgIHJldHVybiBOdW1iZXIocHJpY2VIZWxwZXIocHJldikpICsgTnVtYmVyKHByaWNlSGVscGVyKG5leHQuY29tbWlzc2lvbikpO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF9jb21taXNzaW9uO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmV0dXJuVG90YWxPZkNhcnRUYXhWYWx1ZShwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX3RheCA9IHByb2R1Y3RzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgTnVtYmVyKHByaWNlSGVscGVyKHByZXYpKSArIE51bWJlcihwcmljZUhlbHBlcihuZXh0LnRvdGFsX3RheF92YWx1ZSkpXHJcbiAgICApO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF90YXg7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwcmljZUhlbHBlcihudW0pIHtcclxuICBsZXQgbnVtYmVyQXJyYXkgPSBudW0/LnRvU3RyaW5nKCkuc3BsaXQoXCIsXCIpO1xyXG4gIGlmIChudW1iZXJBcnJheSAmJiBudW1iZXJBcnJheT8ubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIG51bWJlckFycmF5LnJlZHVjZSgocHJldiwgbmV4dCkgPT4gcHJldiArIG5leHQpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gMDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQoY3VycmVuY3lWYWwpIHtcclxuICByZXR1cm4gbmV3IEludGwuTnVtYmVyRm9ybWF0KFwibXMtTVlcIiwge1xyXG4gICAgc3R5bGU6IFwiY3VycmVuY3lcIixcclxuICAgIGN1cnJlbmN5OiBcIk1ZUlwiLFxyXG4gIH0pLmZvcm1hdChwcmljZUhlbHBlcihjdXJyZW5jeVZhbCkpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbWF0aEZvcm11bGEoZm9ybXVsYVRleHQpIHtcclxuICBsZXQgcmVzdWx0ID0gZXhhY3RNYXRoLmZvcm11bGEoZm9ybXVsYVRleHQpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZGl2Q3VycmVuY3koZmlyc3RWYWwsIHNlY29uZFZhbCkge1xyXG4gIGxldCBkaXZEYXRhID0gZXhhY3RNYXRoLmRpdihcclxuICAgIHByaWNlSGVscGVyKGZpcnN0VmFsIHx8IDApLFxyXG4gICAgcHJpY2VIZWxwZXIoc2Vjb25kVmFsIHx8IDEpXHJcbiAgKTtcclxuICByZXR1cm4gZGl2RGF0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG11bEN1cnJlbmN5KGZpcnN0VmFsLCBzZWNvbmRWYWwpIHtcclxuICBsZXQgbXVsRGF0YSA9IGV4YWN0TWF0aC5tdWwoXHJcbiAgICBwcmljZUhlbHBlcihmaXJzdFZhbCB8fCAxKSxcclxuICAgIHByaWNlSGVscGVyKHNlY29uZFZhbCB8fCAxKVxyXG4gICk7XHJcbiAgcmV0dXJuIG11bERhdGE7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhZGRDdXJyZW5jeShjdXJyZW5jeVZhbEZpcnN0LCBjdXJyZW5jeVZhbFNlY29uZCkge1xyXG4gIGxldCBhZGREYXRhID0gZXhhY3RNYXRoLmFkZChcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsRmlyc3QgfHwgMCksXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbFNlY29uZCB8fCAwKVxyXG4gICk7XHJcblxyXG4gIHJldHVybiBhZGREYXRhO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzdWJDdXJyZW5jeShjdXJyZW5jeVZhbEZpcnN0LCBjdXJyZW5jeVZhbFNlY29uZCkge1xyXG4gIGxldCBzdWJEYXRhID0gZXhhY3RNYXRoLnN1YihcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsRmlyc3QgfHwgMCksXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbFNlY29uZCB8fCAwKVxyXG4gICk7XHJcblxyXG4gIHJldHVybiBzdWJEYXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0Q3VycmVuY3kobnVtKSB7XHJcbiAgaWYgKG51bSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gcGFyc2VGbG9hdChudW0pXHJcbiAgICAgIC50b1N0cmluZygpXHJcbiAgICAgIC5yZXBsYWNlKC8oXFxkKSg/PShcXGR7M30pKyg/IVxcZCkpL2csIFwiJDEsXCIpO1xyXG4gIH0gZWxzZSB7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29sbGV0aW9uQnlTbHVnKGNvbGxlY3Rpb25zLCBzbHVnKSB7XHJcbiAgaWYgKGNvbGxlY3Rpb25zLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGNvbGxlY3Rpb25zLmZpbmQoKGl0ZW0pID0+IGl0ZW0uc2x1ZyA9PT0gc2x1Zy50b1N0cmluZygpKTtcclxuICAgIGlmIChyZXN1bHQgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICByZXR1cm4gcmVzdWx0LnByb2R1Y3RzO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIFtdO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gW107XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0SXRlbUJ5U2x1ZyhiYW5uZXJzLCBzbHVnKSB7XHJcbiAgaWYgKGJhbm5lcnMubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgYmFubmVyID0gYmFubmVycy5maW5kKChpdGVtKSA9PiBpdGVtLnNsdWcgPT09IHNsdWcudG9TdHJpbmcoKSk7XHJcbiAgICBpZiAoYmFubmVyICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgcmV0dXJuIGJhbm5lcjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjb252ZXJ0U2x1Z3NRdWVyeVN0cmluZyhwYXlsb2FkKSB7XHJcbiAgbGV0IHF1ZXJ5ID0gXCJcIjtcclxuICBpZiAocGF5bG9hZC5sZW5ndGggPiAwKSB7XHJcbiAgICBwYXlsb2FkLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHF1ZXJ5ID09PSBcIlwiKSB7XHJcbiAgICAgICAgcXVlcnkgPSBgc2x1Z19pbj0ke2l0ZW19YDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBxdWVyeSA9IHF1ZXJ5ICsgYCZzbHVnX2luPSR7aXRlbX1gO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbiAgcmV0dXJuIHF1ZXJ5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdEJhZGdlKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5iYWRnZSAmJiBwcm9kdWN0LmJhZGdlICE9PSBudWxsKSB7XHJcbiAgICB2aWV3ID0gcHJvZHVjdC5iYWRnZS5tYXAoKGJhZGdlKSA9PiB7XHJcbiAgICAgIGlmIChiYWRnZS50eXBlID09PSBcInNhbGVcIikge1xyXG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2JhZGdlXCI+e2JhZGdlLnZhbHVlfTwvZGl2PjtcclxuICAgICAgfSBlbHNlIGlmIChiYWRnZS50eXBlID09PSBcIm91dFN0b2NrXCIpIHtcclxuICAgICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19iYWRnZSBvdXQtc3RvY2tcIj57YmFkZ2UudmFsdWV9PC9kaXY+O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2JhZGdlIGhvdFwiPntiYWRnZS52YWx1ZX08L2Rpdj47XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZShwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuaXNfc2FsZSA9PT0gdHJ1ZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+U0FSIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfTwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9PC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VfTmV3KHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFNBUiB7cHJvZHVjdC5zYWxlX3ByaWNlfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlNBUiB7cHJvZHVjdC5hY3R1YWxfcHJpY2V9PC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlNBUiB7cHJvZHVjdC5hY3R1YWxfcHJpY2V9PC9wPjtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZWF0dXJlcHJvZHVjdHByaWNlKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5pc19zYWxlID09PSB0cnVlKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICAgIFNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlKX17XCIgXCJ9XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGluLXByZHRcIj5cclxuICAgICAgICBTQVIge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QuYWN0dWFsX3ByaWNlKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgICAgU0FSIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfXtcIiBcIn1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsaW4tcHJkdFwiPlxyXG4gICAgICAgIFNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5hY3R1YWxfcHJpY2UpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuaXNfc2FsZSA9PT0gdHJ1ZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+U0FSIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfTwvZGVsPlxyXG4gICAgICAgIDxzbWFsbD4xOCUgb2ZmPC9zbWFsbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5TQVIge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UpfTwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlRXhwYW5kZWRPdGhlcihwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIHZpZXcgPSAoXHJcbiAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICBTQVIge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Qub2ZmZXJfcHJpY2UgPyBwcm9kdWN0Lm9mZmVyX3ByaWNlIDogMCl9XHJcbiAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICBTQVIge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwKX1cclxuICAgICAgPC9kZWw+XHJcbiAgICAgIDxzbWFsbD57cHJvZHVjdC5vZmZlciA/IHByb2R1Y3Qub2ZmZXIgOiAwfTwvc21hbGw+XHJcbiAgICA8L3A+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIxKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgdmlldyA9IChcclxuICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgIFNBUiB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlID8gcHJvZHVjdC5zYWxlX3ByaWNlIDogMCl9XHJcbiAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICBTQVIge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UgPyBwcm9kdWN0LnByaWNlIDogMCl9XHJcbiAgICAgIDwvZGVsPlxyXG4gICAgICA8c21hbGw+e3Byb2R1Y3Qub2ZmZXIgPyBwcm9kdWN0Lm9mZmVyIDogMH08L3NtYWxsPlxyXG4gICAgPC9wPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFRodW1ibmFpbChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LnRodW1ibmFpbCkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e2Ake2Jhc2VVcmx9JHtwcm9kdWN0LnRodW1ibmFpbC51cmx9YH1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QudGl0bGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiIGFsdD1cIkthbmd0YW9cIiAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RUaHVtYm5haWxPdGhlcihwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LmltYWdlLmxlbmd0aCA+IDApIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RUaHVtYm5haWxEZXRhaWwocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICBpZiAocHJvZHVjdC5pbWFnZS5sZW5ndGggPiAwKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9XHJcbiAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0LnByb2R1Y3RfbmFtZX1cclxuICAgICAgICAgICAgICB3aWR0aD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9XCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJcclxuICAgICAgICAgICAgICBhbHQ9XCJLYW5ndGFvXCJcclxuICAgICAgICAgICAgICB3aWR0aD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNob2NraW5ncHJvZHVjdHRodW1ibmFpbChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LmltYWdlLmxlbmd0aCA+IDApIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNvbG9ySGVscGVyKCkge1xyXG4gIGNvbnNvbGUubG9nKFwiaGVsbG9cIik7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==