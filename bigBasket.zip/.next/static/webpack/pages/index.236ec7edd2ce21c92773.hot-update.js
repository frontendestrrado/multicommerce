webpackHotUpdate_N_E("pages/index",{

/***/ "./components/elements/detail/modules/ModuleDetailShoppingActions.jsx":
/*!****************************************************************************!*\
  !*** ./components/elements/detail/modules/ModuleDetailShoppingActions.jsx ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons */ "./node_modules/@material-ui/icons/esm/index.js");
/* harmony import */ var _store_product_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/store/product/action */ "./store/product/action.js");
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _store_compare_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/store/compare/action */ "./store/compare/action.js");
/* harmony import */ var _store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/store/wishlist/action */ "./store/wishlist/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _ModuleDetailProductGroup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ModuleDetailProductGroup */ "./components/elements/detail/modules/ModuleDetailProductGroup.jsx");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");




var _jsxFileName = "E:\\bigBasket\\components\\elements\\detail\\modules\\ModuleDetailShoppingActions.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }
















const ModuleDetailShoppingActions = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.memo(_c = _s(({
  product,
  extended = false,
  shockingsale = false
}) => {
  _s();

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["useDispatch"])();
  const {
    0: quantity,
    1: setQuantity
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(1);
  const {
    0: wishlistFromServer,
    1: setWishlistFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const Router = Object(next_router__WEBPACK_IMPORTED_MODULE_9__["useRouter"])();
  const {
    0: loading1,
    1: setLoading1
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading2,
    1: setLoading2
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading3,
    1: setLoading3
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["useSelector"])(state => state.auth);

  const handleAddItemToCart = async e => {
    var _product$product;

    console.log("...111.....");
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("...111..userdata...", userdata);
    console.log("...111...parsedata..", parsedata);
    console.log("...111..token...", token);

    if (userdata === undefined || userdata === null) {
      console.log("...111...222..");
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else if ((product === null || product === void 0 ? void 0 : (_product$product = product.product) === null || _product$product === void 0 ? void 0 : _product$product.product_type) == "config" && (filterAssocProd.assocValSel == "" || filterAssocProd.assocValSizeSel == "")) {
      console.log("...111...555..");
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please Select Varient",
        duration: 1
      });
      return false;
    } else {
      var _product$product2, _payload;

      console.log("...111..666...");
      setLoading1(true);
      let payload = {
        // user_id: 1,
        prd_assign_id: "",
        quantity: quantity,
        cart_type: "web",
        access_token: token
      };
      console.log("...111..777...");

      if ((product === null || product === void 0 ? void 0 : (_product$product2 = product.product) === null || _product$product2 === void 0 ? void 0 : _product$product2.product_type) == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: getProductId(filterAssocProd.assocValSizeSel)
        });
        const {
          out_of_stock_selling,
          stock
        } = getOutOfstockValueConfigProd(filterAssocProd.assocValSizeSel);

        if (out_of_stock_selling === false && stock <= 0) {
          console.log("...111..8888...");
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading1(false);
          return false;
        } //condition for config end

      } else {
        console.log("...111...999..");
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          console.log("...111..1111222...");
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading1(false);
          return false;
        }
      }

      const responseData = ((_payload = payload) === null || _payload === void 0 ? void 0 : _payload.access_token) && (await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__["default"].addProductToCart(payload));

      if (responseData && responseData.httpcode == "200") {
        let tmp = product;
        tmp.quantity = quantity; // dispatch(addItem(tmp));

        dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
        setLoading1(false);
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"][responseData.status]({
          message: responseData.message,
          description: responseData.response,
          duration: 1
        });
        setTimeout(function () {
          Router.push("/account/shopping-cart");
        }, 200);
      } else {
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
          message: "Error",
          description: responseData.message,
          duration: 1
        });
        setLoading1(false);
      }
    }
  };

  const handleBuynow = async e => {
    if (auth.isLoggedIn !== true) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else if (product.product.product_type == "config" && (filterAssocProd.assocValSel == "" || filterAssocProd.assocValSizeSel == "")) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please Select Varient",
        duration: 1
      });
      return false;
    } else {
      setLoading2(true);
      let payload = {
        // user_id: 1,
        prd_assign_id: "",
        quantity: quantity,
        access_token: auth.access_token,
        cart_type: "web"
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: getProductId(filterAssocProd.assocValSizeSel)
        });
        const {
          out_of_stock_selling,
          stock
        } = getOutOfstockValueConfigProd(filterAssocProd.assocValSizeSel);

        if (out_of_stock_selling === false && stock <= 0) {
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading2(false);
          return false;
        }
      }

      const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__["default"].addProductToCart(payload);

      if (responseData.httpcode == 200) {
        let tmp = product;
        tmp.quantity = quantity;
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"][responseData.status]({
          description: responseData.response,
          duration: 1
        }); // dispatch(addItem(tmp));

        setTimeout(function () {
          Router.push("/account/checkout");
        }, 1000);
        setLoading2(false);
      } else {
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
          message: "Error",
          description: responseData.message,
          duration: 1
        });
        setLoading2(false);
      }
    }
  };

  const handleAddItemToCompare = e => {
    dispatch(Object(_store_compare_action__WEBPACK_IMPORTED_MODULE_6__["addItemToCompare"])(product));
  };

  const handleAddItemToWishlist = async e => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      if (shockingsale == true) {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["addShockingSaleItemToWishlist"])(product.product.product_id));
      } else {
        console.log("lllll..........ll....", product.product.product_id);
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["addItemToWishlist"])(product.product.product_id));
      }
    }
  };

  const handleRemoveWishListItem = () => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      if (shockingsale == true) {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["removeShockingSaleItemFromWishlist"])(product.product.product_id));
      } else {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["removeWishlistItem"])(product.product.product_id));
      }
    }
  };

  const handleIncreaseItemQty = e => {
    setQuantity(quantity + 1);
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setProductQuantityAction"])(quantity + 1));
  };

  const handleDecreaseItemQty = e => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
      dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setProductQuantityAction"])(quantity - 1));
    }
  };

  const {
    0: associativeProd,
    1: setAssociativeProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const {
    0: uniqueAssociativeProd,
    1: setUniqueAssociativeProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const {
    0: filterAssocProd,
    1: setFilterAssocProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    assocVal: "",
    assocValSel: "",
    assocValSize: "",
    assocValSizeSel: "",
    assocProdId: ""
  });
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    var _product$associative_;

    setAssociativeProd(product === null || product === void 0 ? void 0 : product.associative_products);
    let arrayVals = [...new Map(product === null || product === void 0 ? void 0 : (_product$associative_ = product.associative_products) === null || _product$associative_ === void 0 ? void 0 : _product$associative_.map(item => [item["attr_value"], item])).values()];
    setUniqueAssociativeProd(arrayVals);
  }, [product]);

  const handleChangeAttr = e => {
    setFilterAssocProd(_objectSpread(_objectSpread({}, filterAssocProd), {}, {
      assocValSel: e.target.value
    }));
    setTimeout(() => {
      getProductId(filterAssocProd.assocValSizeSel);
    }, 1000);
  };

  const handleChangeAttrSize = e => {
    setFilterAssocProd(_objectSpread(_objectSpread({}, filterAssocProd), {}, {
      assocValSizeSel: e.target.value
    }));
    setTimeout(() => {
      getProductId(e.target.value);
    }, 1000);
  };

  const renderAssociativeProduct = () => {
    var _associativeProd$, _associativeProd$2, _associativeProd$2$su, _associativeProd$filt, _associativeProd$filt2;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__groupped",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("table", {
        className: "table table-borderless",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tbody", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: (_associativeProd$ = associativeProd[0]) === null || _associativeProd$ === void 0 ? void 0 : _associativeProd$.attr_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 360,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Group, {
                size: "large",
                className: "ml-4",
                onChange: handleChangeAttr,
                defaultValue: filterAssocProd === null || filterAssocProd === void 0 ? void 0 : filterAssocProd.assocVal,
                children: uniqueAssociativeProd === null || uniqueAssociativeProd === void 0 ? void 0 : uniqueAssociativeProd.map((attr, index) => {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Button, {
                    value: attr.attr_value,
                    className: "mr-2",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Avatar"], {
                      src: attr.image
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 383,
                      columnNumber: 27
                    }, undefined)
                  }, index, false, {
                    fileName: _jsxFileName,
                    lineNumber: 378,
                    columnNumber: 25
                  }, undefined);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 370,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 369,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 359,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 391,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 390,
            columnNumber: 15
          }, undefined), filterAssocProd.assocValSel ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: (_associativeProd$2 = associativeProd[0]) === null || _associativeProd$2 === void 0 ? void 0 : (_associativeProd$2$su = _associativeProd$2.sub_attributes[0]) === null || _associativeProd$2$su === void 0 ? void 0 : _associativeProd$2$su.attr_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 395,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Group, {
                size: "large",
                className: "ml-4",
                onChange: handleChangeAttrSize,
                children: associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt = associativeProd.filter(prod => prod.attr_value.toLowerCase() === filterAssocProd.assocValSel.toLowerCase())) === null || _associativeProd$filt === void 0 ? void 0 : (_associativeProd$filt2 = _associativeProd$filt.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt2 === void 0 ? void 0 : _associativeProd$filt2.map((values, index) => {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Button, {
                    value: values.attr_value,
                    children: values.attr_value
                  }, index, false, {
                    fileName: _jsxFileName,
                    lineNumber: 419,
                    columnNumber: 29
                  }, undefined);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 405,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 404,
              columnNumber: 19
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 17
          }, undefined) : null, filterAssocProd.assocValSizeSel ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            className: renderPrice() !== undefined ? `` : `d-none`,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: "Price:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 431,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 400,
                fontSize: "large"
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "ml-4",
                children: Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_14__["currencyHelperConvertToRinggit"])(renderPrice())
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 446,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 440,
              columnNumber: 19
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 430,
            columnNumber: 17
          }, undefined) : null]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 358,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 357,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 356,
      columnNumber: 9
    }, undefined);
  };

  const renderPrice = () => {
    var _associativeProd$filt3, _associativeProd$filt4, _associativeProd$filt5, _associativeProd$filt6, _associativeProd$filt7, _associativeProd$filt8;

    // const price = associativeProd
    //   ?.filter((prod) => prod.attr_value == filterAssocProd.assocValSel)[0]
    //   ?.sub_attributes?.filter(
    //     (attr) => attr.attr_value == filterAssocProd.assocValSizeSel
    //   )[0]?.actual_price;
    const price = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt3 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt3 === void 0 ? void 0 : (_associativeProd$filt4 = _associativeProd$filt3.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt4 === void 0 ? void 0 : (_associativeProd$filt5 = _associativeProd$filt4.filter(attr => attr.attr_value == filterAssocProd.assocValSizeSel)[0]) === null || _associativeProd$filt5 === void 0 ? void 0 : _associativeProd$filt5.actual_price;
    const prod_sale_price = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt6 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt6 === void 0 ? void 0 : (_associativeProd$filt7 = _associativeProd$filt6.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt7 === void 0 ? void 0 : (_associativeProd$filt8 = _associativeProd$filt7.filter(attr => attr.attr_value == filterAssocProd.assocValSizeSel)[0]) === null || _associativeProd$filt8 === void 0 ? void 0 : _associativeProd$filt8.sale_price;

    if (prod_sale_price !== false) {
      return prod_sale_price;
    } else {
      return price;
    }
  };

  const getOutOfstockValueConfigProd = sizeValue => {
    var _associativeProd$filt9, _associativeProd$filt10, _associativeProd$filt11, _associativeProd$filt12, _associativeProd$filt13, _associativeProd$filt14;

    const out_of_stock_selling = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt9 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt9 === void 0 ? void 0 : (_associativeProd$filt10 = _associativeProd$filt9.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt10 === void 0 ? void 0 : (_associativeProd$filt11 = _associativeProd$filt10.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt11 === void 0 ? void 0 : _associativeProd$filt11.out_of_stock_selling;
    const stock = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt12 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt12 === void 0 ? void 0 : (_associativeProd$filt13 = _associativeProd$filt12.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt13 === void 0 ? void 0 : (_associativeProd$filt14 = _associativeProd$filt13.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt14 === void 0 ? void 0 : _associativeProd$filt14.stock;
    return {
      stock,
      out_of_stock_selling
    };
  };

  const getProductId = sizeValue => {
    var _associativeProd$filt15, _associativeProd$filt16, _associativeProd$filt17;

    const selectedProductID = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt15 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt15 === void 0 ? void 0 : (_associativeProd$filt16 = _associativeProd$filt15.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt16 === void 0 ? void 0 : (_associativeProd$filt17 = _associativeProd$filt16.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt17 === void 0 ? void 0 : _associativeProd$filt17.product_id;
    const {
      stock,
      out_of_stock_selling
    } = getOutOfstockValueConfigProd(sizeValue);
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductID"])(selectedProductID));
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductStock"])(stock));
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductOutOfStockSelling"])(out_of_stock_selling));
    return selectedProductID;
  };

  if (!extended && product.product) {
    var _product$product3;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [(product === null || product === void 0 ? void 0 : (_product$product3 = product.product) === null || _product$product3 === void 0 ? void 0 : _product$product3.product_type) == "config" ? renderAssociativeProduct() : null, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__shopping",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "Quantity"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 526,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group--number",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "up",
              onClick: e => handleIncreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-plus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 532,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 528,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "down",
              onClick: e => handleDecreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-minus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 538,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 534,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              className: "form-control",
              type: "text",
              placeholder: quantity,
              disabled: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 540,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 527,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 525,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--yellow",
          onClick: e => handleAddItemToCart(e),
          children: loading1 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 552,
            columnNumber: 27
          }, undefined) : "Add to cart1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 548,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--blu",
          onClick: e => handleBuynow(e),
          children: loading2 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 555,
            columnNumber: 27
          }, undefined) : "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 554,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__actions",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: [loading3 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
              size: 20
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 560,
              columnNumber: 19
            }, undefined) : product.product.in_wishlist == 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__["FavoriteBorder"], {
              color: "inherit",
              fontSize: "large",
              onClick: e => handleAddItemToWishlist(e),
              style: {
                cursor: "pointer"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 563,
              columnNumber: 21
            }, undefined), loading3 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
              size: 20
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 572,
              columnNumber: 19
            }, undefined) : product.product.in_wishlist == 1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__["Favorite"], {
              color: "secondary",
              fontSize: "large",
              onClick: e => handleRemoveWishListItem(e),
              style: {
                cursor: "pointer"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 575,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 558,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 557,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 524,
        columnNumber: 11
      }, undefined)]
    }, void 0, true);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__shopping extend",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__btn-group",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "Quantity"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 599,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group--number",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "up",
              onClick: e => handleIncreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-plus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 605,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 601,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "down",
              onClick: e => handleDecreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-minus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 611,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 607,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              className: "form-control",
              type: "text",
              placeholder: quantity,
              disabled: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 613,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 600,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 598,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--black",
          href: "#",
          onClick: e => handleAddItemToCart(e),
          children: "Add to cart2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 621,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__actions",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "#",
            onClick: e => handleAddItemToWishlist(e),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
              className: "icon-heart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 630,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 629,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 628,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 597,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        className: "ps-btn text-white",
        href: "#",
        onClick: e => handleBuynow(e),
        children: "Buy Now"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 637,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 596,
      columnNumber: 9
    }, undefined);
  }
}, "3eckObuHGK8RoUO3o2ueFhzm+Lk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_8__["useDispatch"], next_router__WEBPACK_IMPORTED_MODULE_9__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_8__["useSelector"]];
})); // export default connect((state) => state)(ModuleDetailShoppingActions);

_c2 = ModuleDetailShoppingActions;
/* harmony default export */ __webpack_exports__["default"] = (ModuleDetailShoppingActions);

var _c, _c2;

$RefreshReg$(_c, "ModuleDetailShoppingActions$React.memo");
$RefreshReg$(_c2, "ModuleDetailShoppingActions");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductAuction.jsx":
/*!*********************************************************!*\
  !*** ./components/elements/products/ProductAuction.jsx ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/ProductThumbnail */ "./components/elements/common/ProductThumbnail.jsx");
/* harmony import */ var _CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../CountDownSimpleDiff */ "./components/elements/CountDownSimpleDiff.jsx");

var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductAuction.jsx";







const ProductAuction = ({
  product,
  widthGiven,
  marginGiven
}) => {
  var _product$image$;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Card"], {
    style: {
      width: widthGiven || 255,
      margin: marginGiven || "20px"
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-block--countdown-deal mb-3",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
        className: "figure-timer--font",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
          children: "End in:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_6__["default"], {
          endTime: product.end_date,
          classAdd: "home-auction--slider"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__thumbnail",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/auction/[pid]",
        as: `/auction/${product.auction_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_5__["default"], {
            imageLink: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__container mt-2 text-truncate",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/auction/[pid]",
        as: `/auction/${product.auction_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-product__vendor",
          style: {
            fontWeight: "400"
          },
          children: product.seller ? product.seller : "NA"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, undefined), product.sale_price !== false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price",
        style: {
          fontWeight: "bold",
          fontSize: "large"
        },
        children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
          className: "ml-2",
          children: ["RM ", product.price]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price",
        style: {
          fontWeight: "bold",
          fontSize: "large"
        },
        children: ["RM ", product.price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__content",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
          href: "/auction/[pid]",
          as: `/auction/${product.auction_id}`,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: "ps-product__title d-inline-block text-truncate",
            style: {
              fontSize: "large",
              fontWeight: 500,
              marginTop: "1rem",
              maxWidth: "200px"
            },
            children: product.product_name
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "mt-2",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: ["No. of Bids", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "float-right",
            children: product.no_of_bids
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, undefined), "Min. Bid", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "float-right",
            children: Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__["currencyHelperConvertToRinggit"])(product.min_bid_price)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, undefined);
};

_c = ProductAuction;
/* harmony default export */ __webpack_exports__["default"] = (ProductAuction);

var _c;

$RefreshReg$(_c, "ProductAuction");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductAuctionSlide.jsx":
/*!**************************************************************!*\
  !*** ./components/elements/products/ProductAuctionSlide.jsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/ProductThumbnail */ "./components/elements/common/ProductThumbnail.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductAuctionSlide.jsx";







const ProductAuctionSlide = ({
  product
}) => {
  var _product$image$, _product$image$2;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Card"], {
      bordered: false,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-block--countdown-deal mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          className: "figure-timer--font",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "End in:"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(CountDownSimpleDiff, {
            endTime: product.end_date,
            classAdd: "home-auction--slider"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__thumbnail",
        children: product !== null && product !== void 0 && (_product$image$ = product.image[0]) !== null && _product$image$ !== void 0 && _product$image$.image ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
          href: "/auction/[pid]",
          as: `/auction/${product.auction_id}`,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_4___default.a, {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__["default"], {
                imageLink: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 13
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
          href: "/auction/[pid]",
          as: `/auction/${product.auction_id}`,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_4___default.a, {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: "/static/img/not-found.jpg",
                alt: "Kangtao",
                height: "150px"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 34,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 33,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 32,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__container mt-2 text-truncate",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
          href: "/auction/[pid]",
          as: `/auction/${product.auction_id}`,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: "ps-product__vendor",
            style: {
              fontWeight: "400"
            },
            children: product.seller ? product.seller : "NA"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, undefined), product.sale_price !== false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "ps-product__price",
          style: {
            fontWeight: "bold",
            fontSize: "large"
          },
          children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
            className: "ml-2",
            children: ["RM ", product.price]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 13
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "ps-product__price",
          style: {
            fontWeight: "bold",
            fontSize: "large"
          },
          children: ["RM ", product.price]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__content",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: "/auction/[pid]",
            as: `/auction/${product.auction_id}`,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-product__title d-inline-block text-truncate",
              style: {
                fontSize: "large",
                fontWeight: 500,
                marginTop: "1rem",
                maxWidth: "200px"
              },
              children: product.product_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 69,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "mt-2",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            children: ["No. of Bids", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "float-right",
              children: product.no_of_bids
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 85,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 15
            }, undefined), "Min. Bid", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "float-right",
              children: Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__["currencyHelperConvertToRinggit"])(product.min_bid_price)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 88,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 83,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

_c = ProductAuctionSlide;
/* harmony default export */ __webpack_exports__["default"] = (ProductAuctionSlide);

var _c;

$RefreshReg$(_c, "ProductAuctionSlide");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductOnCart.jsx":
/*!********************************************************!*\
  !*** ./components/elements/products/ProductOnCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");



var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductOnCart.jsx",
    _s = $RefreshSig$();







const ProductOnCart = ({
  product
}) => {
  _s();

  var _product$image$;

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"])();

  const handleRemoveCartItem = async product => {
    // e.preventDefault();
    let userdata = localStorage.getItem("user");

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_5__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      let parsedata = JSON.parse(userdata);
      let token = parsedata.access_token;
      let payload = {
        cart_id: [product.cart_id],
        access_token: token
      };
      antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].confirm({
        title: "Delete this product?",
        onOk: function (e) {
          dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_3__["removeProductFromCartNew"])(payload));
          antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].destroyAll();
        },
        onCancel: function (e) {
          antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].destroyAll();
        },
        okButtonProps: {
          danger: true
        }
      });
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product--cart-mobile",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__thumbnail",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: (product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image) || "/static/img/not-found.jpg",
        onError: e => {
          e.target.onerror = null;
          e.target.src = "/static/img/not-found.jpg";
        },
        alt: "product",
        title: "product"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        className: "ps-product__remove",
        onClick: e => handleRemoveCartItem(product),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          className: "icon-cross"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.product_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-product__title",
          children: [product.product_name, product.attr_name1 ? ` (${product.attr_name1}${product.attr_name2 ? ` ${product.attr_name2}` : ""})` : ""]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
          children: ["RM", " ", product.unit_discount_price !== false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
              children: product.unit_actual_price
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 17
            }, undefined), " ", product.unit_discount_price]
          }, void 0, true) : product.unit_actual_price, " ", "x ", product.quantity]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 5
  }, undefined);
};

_s(ProductOnCart, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"]];
});

_c = ProductOnCart;
/* harmony default export */ __webpack_exports__["default"] = (ProductOnCart);

var _c;

$RefreshReg$(_c, "ProductOnCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductSearchResult.jsx":
/*!**************************************************************!*\
  !*** ./components/elements/products/ProductSearchResult.jsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/elements/Rating */ "./components/elements/Rating.jsx");

var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductSearchResult.jsx";






const ProductSearchResult = ({
  product
}) => {
  var _product$image$, _product$image$2;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product ps-product--wide ps-product--search-result",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__thumbnail",
      children: product !== null && product !== void 0 && (_product$image$ = product.image[0]) !== null && _product$image$ !== void 0 && _product$image$.image ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
              alt: product.title
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/static/img/not-found.jpg",
              alt: "Kangtao"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-product__title",
          children: product.product_name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__rating",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_5__["default"], {
          rating: product.rating
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), product.sale_price > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price sale",
        children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
          className: "ml-2",
          children: ["RM ", product.actual_price]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price sale",
        children: ["RM ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, undefined);
};

_c = ProductSearchResult;
/* harmony default export */ __webpack_exports__["default"] = (ProductSearchResult);

var _c;

$RefreshReg$(_c, "ProductSearchResult");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductShockingSale.jsx":
/*!**************************************************************!*\
  !*** ./components/elements/products/ProductShockingSale.jsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/Rating */ "./components/elements/Rating.jsx");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/ProductThumbnail */ "./components/elements/common/ProductThumbnail.jsx");
/* harmony import */ var _CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../CountDownSimpleDiff */ "./components/elements/CountDownSimpleDiff.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductShockingSale.jsx";








const ProductShockingSale = ({
  product
}) => {
  var _product$image$;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Card"], {
      style: {
        width: 255,
        margin: "20px"
      },
      className: "text-capitalize",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-block--countdown-deal mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          className: "figure-timer--font",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "End in:"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__["default"], {
            endTime: product.end_time,
            classAdd: "home-shockingsale--slider"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__["default"], {
            imageLink: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__container text-truncate",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__content mt-4",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-product__title d-inline-block text-truncate",
              style: {
                fontSize: "large",
                fontWeight: 500,
                marginTop: "1rem",
                maxWidth: "200px"
              },
              children: product.product_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "ps-product__rating",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__["default"], {
              rating: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 15
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 50
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "ps-product__price",
            style: {
              fontWeight: "lighter"
            },
            children: ["RM ", product.offer_price !== false ? product.offer_price : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                className: "ml-2",
                children: ["RM ", product.actual_price ? product.actual_price : ""]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              style: {
                color: "red"
              },
              className: "ml-2",
              children: product.offer ? product.offer : ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 61,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

_c = ProductShockingSale;
/* harmony default export */ __webpack_exports__["default"] = (ProductShockingSale);

var _c;

$RefreshReg$(_c, "ProductShockingSale");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductShockingSaleSlide.jsx":
/*!*******************************************************************!*\
  !*** ./components/elements/products/ProductShockingSaleSlide.jsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/Rating */ "./components/elements/Rating.jsx");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/ProductThumbnail */ "./components/elements/common/ProductThumbnail.jsx");
/* harmony import */ var _CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../CountDownSimpleDiff */ "./components/elements/CountDownSimpleDiff.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductShockingSaleSlide.jsx";








const ProductShockingSaleSlide = ({
  product
}) => {
  var _product$image$;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Card"], {
      bordered: false,
      className: " text-capitalize",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-block--countdown-deal mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          className: "figure-timer--font",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "End in:"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_CountDownSimpleDiff__WEBPACK_IMPORTED_MODULE_7__["default"], {
            endTime: product.end_time,
            classAdd: "home-shockingsale--slider"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_common_ProductThumbnail__WEBPACK_IMPORTED_MODULE_6__["default"], {
            imageLink: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__container text-truncate",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__content mt-4",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: `shockingsale/${product.shock_sale_id}?pr_id=${product.product_id}`,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-product__title",
              style: {
                fontSize: "large",
                fontWeight: 500,
                marginTop: "1rem"
              },
              children: product.product_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "ps-product__rating",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_4__["default"], {
              rating: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 15
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: product.rating
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 50
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "ps-product__price",
            style: {
              fontWeight: "lighter"
            },
            children: ["RM ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                className: "ml-2",
                children: ["RM ", product.actual_price ? product.actual_price : 0]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              style: {
                color: "red"
              },
              className: "ml-2",
              children: product.offer ? product.offer : 0
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined)
  }, void 0, false);
};

_c = ProductShockingSaleSlide;
/* harmony default export */ __webpack_exports__["default"] = (ProductShockingSaleSlide);

var _c;

$RefreshReg$(_c, "ProductShockingSaleSlide");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/home-default/FeatureAndRecent.jsx":
/*!************************************************************************!*\
  !*** ./components/partials/homepage/home-default/FeatureAndRecent.jsx ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\home-default\\FeatureAndRecent.jsx",
    _s = $RefreshSig$();




const FeatureAndRecent = ({
  homeitems,
  loading
}) => {
  _s();

  var _homeitems$featured_p, _homeitems$center_off;

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {}, []);
  let mainCarouselView;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$featured_p = homeitems.featured_products) === null || _homeitems$featured_p === void 0 ? void 0 : _homeitems$featured_p.length) > 0) {
    // const carouseItems = homeitems.main_banner.map((item, index) => (
    //   <div key={index}>{mainBannerMedia(item)}</div>
    // ));
    mainCarouselView = homeitems.featured_products.slice(5, 8).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "product-list mb-30",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "card product-card border-0",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "card-body p-0",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "media",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "product-thumbnail",
              style: {
                display: item.image.length > 0 ? 'block' : 'none'
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                href: "/product/[pid]",
                as: `/product/${item.product_id}`,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "single-product.html",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    className: "first-img",
                    src: item.image.length > 0 ? item.image[0].thumbnail : '',
                    alt: "thumbnail"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 25,
                    columnNumber: 30
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 25
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 21
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "media-body",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "product-desc",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                  className: "title",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "shop-grid-4-column.html",
                    children: item.product_name
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 31,
                    columnNumber: 51
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 29
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "d-flex align-items-center justify-content-between",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                    className: "product-price",
                    children: ["$", item.actual_price]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 33,
                    columnNumber: 33
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 32,
                  columnNumber: 29
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 17
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 9
    }, undefined));
  }

  let mainCarouselView1;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$center_off = homeitems.center_offer_banner) === null || _homeitems$center_off === void 0 ? void 0 : _homeitems$center_off.length) > 0) {
    // const carouseItems = homeitems.main_banner.map((item, index) => (
    //   <div key={index}>{mainBannerMedia(item)}</div>
    // ));
    mainCarouselView1 = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "col-12 col-md-8 mx-auto col-lg-4 mb-50",
      style: {
        display: homeitems.center_offer_banner.length > 0 ? 'block' : 'none'
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "banner-thumb",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "shop-grid-4-column.html",
          className: "zoom-in d-block overflow-hidden position-relative zIndex-3",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: homeitems.center_offer_banner.length > 0 ? homeitems.center_offer_banner[0].media : '',
            alt: "banner-thumb-naile"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 18
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 9
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "featurandrecent",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12 col-lg-4 mb-50",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                className: "title text-dark text-capitalize",
                children: "Featured products "
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "featured-init",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "slider-item",
                children: mainCarouselView
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 13
          }, undefined), mainCarouselView1, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col-12 col-lg-4 mb-50",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "section-title mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                className: "title text-dark text-capitalize",
                children: "Recommended Products"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 85,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "featured-init2 slick-nav",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "slider-item",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 95,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 94,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Brixton Patrol All Terrain Anorak Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 101,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 101,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 104,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 103,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 100,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 93,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 92,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 90,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 118,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 117,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Juicy Couture Solid Sleeve Puffer Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 124,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 124,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 127,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 126,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 123,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 122,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 116,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 115,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 114,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list mb-30",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 141,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 140,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "New Balance Fresh Foam LAZR v1 Sport"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 147,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 147,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 150,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 149,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 146,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 145,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 139,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 138,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 137,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 25
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "product-list",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "card product-card border-0",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-body p-0",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "media",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "product-thumbnail",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            href: "single-product.html"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 164,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 163,
                          columnNumber: 41
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "media-body",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                            className: "product-desc",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                              className: "title",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                                href: "shop-grid-4-column.html",
                                children: "Couture Juicy Quilted Terry Track Jacket"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 172,
                                columnNumber: 71
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 172,
                              columnNumber: 49
                            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                              className: "d-flex align-items-center justify-content-between",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                                className: "product-price",
                                children: "$11.90"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 175,
                                columnNumber: 53
                              }, undefined)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 174,
                              columnNumber: 49
                            }, undefined)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 171,
                            columnNumber: 45
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 170,
                          columnNumber: 41
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 162,
                        columnNumber: 37
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 161,
                      columnNumber: 33
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 160,
                    columnNumber: 29
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 159,
                  columnNumber: 25
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 89,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 88,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 9
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 5
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 5
    }, undefined)
  }, void 0, false);
};

_s(FeatureAndRecent, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = FeatureAndRecent;
/* harmony default export */ __webpack_exports__["default"] = (FeatureAndRecent);
/*connect(state => state.media)();*/

var _c;

$RefreshReg$(_c, "FeatureAndRecent");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/homepage/home-default/HomeDefaultBanner.jsx":
/*!*************************************************************************!*\
  !*** ./components/partials/homepage/home-default/HomeDefaultBanner.jsx ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_static_img_custom_images_home_page_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/public/static/img/custom_images/home_page.jpg */ "./public/static/img/custom_images/home_page.jpg?e3ab");
/* harmony import */ var _public_static_img_custom_images_home_page_jpg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_public_static_img_custom_images_home_page_jpg__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/elements/carousel/NextArrow */ "./components/elements/carousel/NextArrow.jsx");
/* harmony import */ var _components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/carousel/PrevArrow */ "./components/elements/carousel/PrevArrow.jsx");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _repositories_MediaRepository__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/repositories/MediaRepository */ "./repositories/MediaRepository.js");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_media_Promotion__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/components/elements/media/Promotion */ "./components/elements/media/Promotion.js");



var _jsxFileName = "E:\\bigBasket\\components\\partials\\homepage\\home-default\\HomeDefaultBanner.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }










 // import YouTube from "react-youtube";

const HomeDefaultBanner = ({
  homeitems,
  loading
}) => {
  _s();

  var _homeitems$main_banne;

  const {
    0: promotion1,
    1: setPromotion1
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
  const {
    0: promotion2,
    1: setPromotion2
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);

  async function getPromotions() {
    const responseData = await _repositories_MediaRepository__WEBPACK_IMPORTED_MODULE_8__["default"].getPromotionsBySlug("home_fullwidth_promotions");

    if (responseData) {
      setPromotion1(Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_10__["getItemBySlug"])(responseData, "main_1"));
      setPromotion2(Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_10__["getItemBySlug"])(responseData, "main_2"));
    }
  }

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    // getBannerItems();
    getPromotions();
  }, []);

  function mainBannerMedia(item) {
    switch (item.media_type) {
      case "video":
        return (
          /*#__PURE__*/
          // <ReactPlayer url="https://www.youtube.com/watch?v=ysz5S6PUM-U" />
          Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("iframe", {
            src: `${item.media}?autoplay=1&mute=1`,
            frameBorder: "0",
            allow: "autoplay; encrypted-media",
            allowFullScreen: true,
            title: "video"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 11
          }, this) // <YouTube videoId={"w3Wluvzoggg"} />

        );

      case "image":
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
          href: item.button_link,
          className: "ps-banner-item--default bg--cover",
          style: {
            backgroundImage: `url(${item.media})`
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 11
        }, this);

      default:
        break;
    }
  }

  const carouselSetting = {
    dots: false,
    infinite: true,
    speed: 750,
    fade: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 16
    }, undefined),
    prevArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 16
    }, undefined)
  };
  const carouselStandard = {
    dots: false,
    arrows: true,
    infinite: true,
    speed: 750,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 16
    }, undefined),
    prevArrow: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 16
    }, undefined),
    responsive: [{
      breakpoint: 1024,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    }, {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        initialSlide: 1
      }
    }, {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  }; // Views

  let mainCarouselView;

  if (!loading && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$main_banne = homeitems.main_banner) === null || _homeitems$main_banne === void 0 ? void 0 : _homeitems$main_banne.length) > 0) {
    const carouseItems = homeitems.main_banner.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      children: mainBannerMedia(item)
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 115,
      columnNumber: 7
    }, undefined));
    mainCarouselView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, carouselStandard), {}, {
      className: "ps-carousel",
      children: carouseItems
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 118,
      columnNumber: 7
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    className: "ps-home-banner ps-home-banner--1",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "ps-container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "ps-section__left",
        children: mainCarouselView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 129,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 128,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 125,
    columnNumber: 5
  }, undefined);
};

_s(HomeDefaultBanner, "RTDUTbYRCl164avbHRRII77Zd+Q=");

_c = HomeDefaultBanner;
/* harmony default export */ __webpack_exports__["default"] = (HomeDefaultBanner);
/*connect(state => state.media)();*/

var _c;

$RefreshReg$(_c, "HomeDefaultBanner");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/shop/ShopItems1.jsx":
/*!*************************************************!*\
  !*** ./components/partials/shop/ShopItems1.jsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _components_elements_products_ShopProduct__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/products/ShopProduct */ "./components/elements/products/ShopProduct.jsx");
/* harmony import */ var _components_elements_products_ShopProductWide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/elements/products/ShopProductWide */ "./components/elements/products/ShopProductWide.jsx");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _components_partials_shop_modules_ModuleShopSortBy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/partials/shop/modules/ModuleShopSortBy */ "./components/partials/shop/modules/ModuleShopSortBy.jsx");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/components/elements/skeletons/SkeletonProduct */ "./components/elements/skeletons/SkeletonProduct.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\partials\\shop\\ShopItems1.jsx",
    _s = $RefreshSig$();












const ShopItems = ({
  columns = 4,
  pageSize = 12,
  homeitems
}) => {
  _s();

  const Router = Object(next_router__WEBPACK_IMPORTED_MODULE_8__["useRouter"])();
  const pathDetail = Router.pathname;
  const {
    page,
    category,
    subcategory_id,
    brand,
    price_gt,
    price_lt,
    low_to_high,
    high_to_low,
    latest
  } = Router.query;
  const {
    query
  } = Router;
  const {
    0: listView,
    1: setListView
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const {
    0: productItems,
    1: setProductItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: total,
    1: setTotal
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    0: classes,
    1: setClasses
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("col-xxl-4 col-xl-4 col-lg-4 col-md-3 col-sm-6 col-6");

  function handleChangeViewMode(e) {
    e.preventDefault();
    setListView(!listView);
  }

  async function getProducts(params) {
    setLoading(true);
    let payload = {
      page: page === undefined ? 1 : page
    };
    const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].getProducts(payload);

    if (responseData) {
      setProductItems(responseData.items);
      setTotal(responseData.totalItems);
      setTimeout(function () {
        setLoading(false);
      }.bind(this), 250);
    }
  }

  async function getProductsbyfilters() {
    setLoading(true);
    let payload = {
      page: page === undefined ? 1 : page,
      lang_id: 1,
      category_id: category ? category : "",
      subcategory_id: subcategory_id ? subcategory_id : "",
      brand_id: brand ? brand : "",
      max_price: price_lt ? price_lt : "",
      min_price: price_gt ? price_gt : "",
      low_to_high: low_to_high ? low_to_high : "",
      high_to_low: high_to_low ? high_to_low : "",
      latest: latest ? latest : ""
    };
    const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].getProductsbyFilter(payload);

    if (responseData) {
      setProductItems(responseData.items);
      setTotal(responseData.totalItems);
      setTimeout(function () {
        setLoading(false);
      }.bind(this), 250);
    }
  }

  function handlePagination(page, pageSize) {
    let filterpart = window.location.search;

    if (category !== undefined || subcategory_id !== undefined || brand !== undefined || price_gt !== undefined || price_lt !== undefined || low_to_high !== undefined || high_to_low !== undefined || latest !== undefined) {
      let newdd = filterpart.replace(/\&page.*/, "");
      Router.push("/shop" + newdd + "&page=" + page);
    } else {
      Router.push(`/shop?page=${page}`);
    }
  }

  async function getTotalRecords(params) {
    const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].getTotalRecords();

    if (responseData) {// setTotal(responseData);
    }
  }

  function handleSetColumns() {
    switch (columns) {
      case 2:
        setClasses("col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6");
        return 3;
        break;

      case 4:
        setClasses("col-xl-3 col-lg-4 col-md-6 col-sm-6 col-6");
        return 4;
        break;
      // case 6:
      //   setClasses("col-xxl-2 col-xl-2 col-lg-4 col-md-6 col-sm-6 col-6");
      //   return 6;
      //   break;

      default:
        setClasses("col-xl-3 col-lg-3 col-md-3 ");
    }
  }

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    // let params;
    // if (query) {
    //   if (query.page) {
    //     params = {
    //       _start: page * pageSize,
    //       _limit: pageSize,
    //     };
    //   } else {
    //     params = query;
    //     params._limit = pageSize;
    //   }
    // } else {
    //   params = {
    //     _limit: pageSize,
    //   };
    // }
    //  getTotalRecords();
    // if (
    //   category !== undefined ||
    //   subcategory_id !== undefined ||
    //   brand !== undefined ||
    //   price_gt !== undefined ||
    //   price_lt !== undefined ||
    //   low_to_high !== undefined ||
    //   high_to_low !== undefined ||
    //   latest !== undefined
    // ) {
    //  getProductsbyfilters();
    // } else {
    //  getProducts(params);
    // }
    handleSetColumns();
  }, [query]); // Views

  let productItemsView;

  if (!loading) {
    var _homeitems$trending_p;

    if (homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$trending_p = homeitems.trending_products) === null || _homeitems$trending_p === void 0 ? void 0 : _homeitems$trending_p.length) > 0) {
      if (listView) {
        const items = homeitems.trending_products.slice(0, 8).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: classes,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ShopProduct__WEBPACK_IMPORTED_MODULE_4__["default"], {
            product: item
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 178,
            columnNumber: 13
          }, undefined)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 177,
          columnNumber: 11
        }, undefined));
        productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-shop-items",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "row",
            children: items
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 183,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 182,
          columnNumber: 11
        }, undefined);
      } else {
        productItemsView = homeitems.trending_products.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ShopProductWide__WEBPACK_IMPORTED_MODULE_5__["default"], {
          product: item
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 188,
          columnNumber: 11
        }, undefined));
      }
    } else {
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: "No product found."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 192,
        columnNumber: 26
      }, undefined);
    }
  } else {
    const skeletonItems = Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["generateTempArray"])(12).map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: classes,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 197,
        columnNumber: 9
      }, undefined)
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 196,
      columnNumber: 7
    }, undefined));
    productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: skeletonItems
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 200,
      columnNumber: 24
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-shopping",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-container",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "ps-section__header justify-content-center d-flex",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "ps-block--countdown-deal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "ps-block__left",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
              className: "text-center",
              children: "Trending Now"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 209,
              columnNumber: 13
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text-center p-3",
              children: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 210,
              columnNumber: 13
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 208,
            columnNumber: 11
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 207,
          columnNumber: 9
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 206,
        columnNumber: 7
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "d-flex justify-content-end vual",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
          href: "/newdeals",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: "View All"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 216,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 215,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 214,
        columnNumber: 7
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-shopping__actions",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-shopping__view"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 226,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 224,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-shopping__content pt-5",
        children: productItemsView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 243,
        columnNumber: 7
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-shopping__footer text-center"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 244,
        columnNumber: 7
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 204,
    columnNumber: 5
  }, undefined);
};

_s(ShopItems, "y6gJXdeRxMfiuofOr+Jqtiibiz8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_8__["useRouter"]];
});

_c = ShopItems;
/* harmony default export */ __webpack_exports__["default"] = (ShopItems);

var _c;

$RefreshReg$(_c, "ShopItems");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/footers/modules/FooterCopyright.jsx":
/*!***************************************************************!*\
  !*** ./components/shared/footers/modules/FooterCopyright.jsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);


var _jsxFileName = "E:\\bigBasket\\components\\shared\\footers\\modules\\FooterCopyright.jsx";



const FooterCopyright = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "footer-bottom pt-80 pb-30",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget mx-w-400",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "footer-logo mb-35",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "index.html"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 14,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 13,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text mb-30",
              children: "We are a team of designers and developers that create high quality Magento, Prestashop, Opencart."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 18,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "address-widget mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "media",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "address-icon me-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 22,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "media-body",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    className: "help-text text-uppercase",
                    children: "NEED HELP?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 35
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                    className: "title text-dark",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "tel:+1(123)8889999",
                      children: "(+800) 345 678"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 27,
                      columnNumber: 67
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 27,
                    columnNumber: 35
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 25,
                  columnNumber: 31
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 21,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "social-network",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                className: "d-flex",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-facebook"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 34,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 34,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 34,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-twitter"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 36,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 36,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 36,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-youtube"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 38,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 38,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 38,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  className: "me-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-instagram"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 40,
                      columnNumber: 90
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 40,
                    columnNumber: 52
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 40,
                  columnNumber: 31
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 12,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-2 mb-30 pl-40",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Information"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 50,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 49,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "footer-menu",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Delivery"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 55,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 55,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "About us"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Secure payment"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 57,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Contact us"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 58,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 58,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Sitemap"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Stores"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 60,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 60,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 54,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-2 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Custom Links"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 69,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 68,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "footer-menu",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Legal Notice"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 74,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 74,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Prices drop"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 75,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "New products"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 77,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Best sales"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 79,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 79,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Login"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 81,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "My account"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 83,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Newsletter"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 91,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 90,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text mb-20",
              children: "You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 95,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "nletter-form mb-35",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "form-inline position-relative",
                action: "/page/blank",
                target: "_blank",
                method: "post",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
                  className: "btn nletter-btn text-capitalize",
                  type: "submit",
                  children: "Sign up"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 102,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 98,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 97,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "store d-flex",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/page/blank",
                className: "d-inline-block me-3"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/page/blank",
                className: "d-inline-block"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 15
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 3
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "coppy-right pb-80",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-start",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "mb-3 mb-md-0",
              children: ["\xA9 2021 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "text-capitalize",
                children: "Junno"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 127,
                columnNumber: 18
              }, undefined), " Made with ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: "\u2764"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 16
              }, undefined), " by", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                target: "_blank",
                href: "https://hasthemes.com/",
                children: "HasThemes"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 129,
                columnNumber: 11
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 126,
              columnNumber: 23
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-start"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 15
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 122,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 121,
    columnNumber: 3
  }, undefined)]
}, void 0, true);

_c = FooterCopyright;
/* harmony default export */ __webpack_exports__["default"] = (FooterCopyright);

var _c;

$RefreshReg$(_c, "FooterCopyright");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/HeaderDefault.jsx":
/*!*****************************************************!*\
  !*** ./components/shared/headers/HeaderDefault.jsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/common/Logo */ "./components/elements/common/Logo.js");
/* harmony import */ var _components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/shared/headers/modules/SearchHeader */ "./components/shared/headers/modules/SearchHeader.jsx");
/* harmony import */ var _components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/shared/navigation/NavigationDefault */ "./components/shared/navigation/NavigationDefault.jsx");
/* harmony import */ var _components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/shared/headers/modules/HeaderActions */ "./components/shared/headers/modules/HeaderActions.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/shared/menus/MenuCategoriesDropdown */ "./components/shared/menus/MenuCategoriesDropdown.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\HeaderDefault.jsx",
    _s = $RefreshSig$();











const HeaderDefault = () => {
  _s();

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (true) {
      window.addEventListener("scroll", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__["stickyHeader"]);
    }
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
    className: "header header--1",
    "data-sticky": "true",
    id: "headerSticky",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "head-top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "d-flex justify-content-end",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "top-content",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "top-url",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "top-li",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  children: " Eng "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: " Sign In"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 29,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 28,
                  columnNumber: 20
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: "Register"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 32,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 11
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 25,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 24,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "header__top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__left",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__categ",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "d-flex justify-content-center align-items-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "",
            children: "Offer Zone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__right",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 58,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 5
  }, undefined);
};

_s(HeaderDefault, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = HeaderDefault;
/* harmony default export */ __webpack_exports__["default"] = (HeaderDefault);

var _c;

$RefreshReg$(_c, "HeaderDefault");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/MiniCart.jsx":
/*!********************************************************!*\
  !*** ./components/shared/headers/modules/MiniCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductOnCart */ "./components/elements/products/ProductOnCart.jsx");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\MiniCart.jsx",
    _s = $RefreshSig$();











const MiniCart = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(_c = _s(({
  cart
}) => {
  var _cart$product, _cartdata$product, _cartdata$product2;

  _s();

  let cartItemsView;
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(state => state.auth);
  const productItemWithSeller = cart === null || cart === void 0 ? void 0 : (_cart$product = cart.product) === null || _cart$product === void 0 ? void 0 : _cart$product.map(productItem => {
    var _productItem$seller, _productItem$seller2, _productItem$seller3, _productItem$seller3$;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "stor-tit",
        children: productItem === null || productItem === void 0 ? void 0 : (_productItem$seller2 = productItem.seller) === null || _productItem$seller2 === void 0 ? void 0 : _productItem$seller2.seller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }, undefined), productItem === null || productItem === void 0 ? void 0 : (_productItem$seller3 = productItem.seller) === null || _productItem$seller3 === void 0 ? void 0 : (_productItem$seller3$ = _productItem$seller3.products) === null || _productItem$seller3$ === void 0 ? void 0 : _productItem$seller3$.map(cartProduct => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: cartProduct
      }, cartProduct === null || cartProduct === void 0 ? void 0 : cartProduct.cart_id, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined))]
    }, productItem === null || productItem === void 0 ? void 0 : (_productItem$seller = productItem.seller) === null || _productItem$seller === void 0 ? void 0 : _productItem$seller.seller_id, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, undefined);
  });
  const {
    0: cartdata,
    1: setCartdata
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: totalItems,
    1: setTotalItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log(".productItemNext......cart.....", cart); // console.log(".productItemNext...........", productItemNext)

    let isMounted = true;

    if (isMounted) {
      var _cart$product2;

      //alert("bhbhhbhhh")
      const cartTotalProductsFromAllSeller = cart === null || cart === void 0 ? void 0 : (_cart$product2 = cart.product) === null || _cart$product2 === void 0 ? void 0 : _cart$product2.reduce((productItemPrev, productItemNext) => {
        return Number(productItemPrev) + Number(productItemNext.seller.products.length);
      }, 0);
      setTotalItems(cartTotalProductsFromAllSeller);
      setCartdata(cart);
    }

    return () => {
      isMounted = false;
    };
  }, [cart === null || cart === void 0 ? void 0 : cart.product]); // async getCartItem(payload) {

  const getCartItem = payload => {
    alert("7777767"); //alert("d")

    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]
    });
    console.log("....aaaaaaaaaaaaaaaa...", user_token);
    console.log("....bbbbbbbbbbbbbbbb...", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]);
    const data = axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }).then(response => response.data).then(data => {
      console.log("...iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setCartdata(data.data);
        setTotalItems(data.data.cart_count); //   alert("yes")
        //  setOfferData(data.data)
        // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {// notification["error"]({
      //   message: error,
      // });
    });
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]); // console.log("....bbbbb...bbb...",payload)
    // let userdata = localStorage.getItem("user");
    // let parsedata = JSON.parse(userdata);
    // let access_token = parsedata?.access_token;
    // const user_token = access_token;
    // const response =  Repository.post(`${apibaseurl}/api/customer/cart`, {
    //   access_token: user_token,
    //   lang_id: 1,
    //   device_id: getDeviceId,
    //   page_url: "http://localhost:3000/product/2",
    //   os_type: "WEB",
    // })
    // console.log("....bbbbb...bbb..444444444444.",response)
    //   // .then((response) => {
    //     if (response.data.httpcode == "200") {
    //       return response.data;
    //     }
    //   //   return response.data;
    //   // })
    //   // .catch((error) => ({ error: JSON.stringify(error) }));
    // return response;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("..557..", cart);
    getCartItem();

    if (cart == undefined) {
      // alert("ddfffd")
      (auth === null || auth === void 0 ? void 0 : auth.access_token) && dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
    }
  }, [auth.access_token, cart === null || cart === void 0 ? void 0 : cart.product]);

  if (cartdata !== null && cartdata !== undefined && cartdata !== null && cartdata !== void 0 && (_cartdata$product = cartdata.product) !== null && _cartdata$product !== void 0 && _cartdata$product.length && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product2 = cartdata.product) === null || _cartdata$product2 === void 0 ? void 0 : _cartdata$product2.length) !== 0) {
    var _cartdata$product3;

    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: productItemWithSeller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 145,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__footer",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          children: ["Sub Total:", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            children: cartdata && cartdata !== null && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product3 = cartdata.product) === null || _cartdata$product3 === void 0 ? void 0 : _cartdata$product3.length) > 0 ? Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__["currencyHelperConvertToRinggit"])(cartdata.grand_total) : 0
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 149,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 147,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/shopping-cart",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "View Cart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 157,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 156,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/checkout",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "Checkout"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 160,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 159,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 155,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 144,
      columnNumber: 7
    }, undefined);
  } else {
    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          children: "No products in cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 170,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 169,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 168,
      columnNumber: 7
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-cart--mini",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "header__extra",
      href: "#",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-bag2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 179,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          children: cartdata !== null && cartdata !== undefined && totalItems > 0 ? totalItems : 0
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 178,
      columnNumber: 7
    }, undefined), cartItemsView]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 177,
    columnNumber: 5
  }, undefined);
}, "lT+bflo29ZWMxNMJEjF2ThtquLk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"]];
}));
_c2 = MiniCart;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(state => state.cart)(MiniCart));

var _c, _c2;

$RefreshReg$(_c, "MiniCart$React.memo");
$RefreshReg$(_c2, "MiniCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/SearchHeader.jsx":
/*!************************************************************!*\
  !*** ./components/shared/headers/modules/SearchHeader.jsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _components_elements_products_ProductSearchResult__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductSearchResult */ "./components/elements/products/ProductSearchResult.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\SearchHeader.jsx",
    _s = $RefreshSig$(),
    _s2 = $RefreshSig$();







const exampleCategories = [{
  id: "",
  category_name: "All"
}, {
  id: 4,
  category_name: "Grocery"
}, {
  id: 5,
  category_name: "Electronics"
}, {
  id: 6,
  category_name: "Bakery"
}, {
  id: 7,
  category_name: "Fashion"
}, {
  id: 8,
  category_name: "shoes"
}, {
  id: 10,
  category_name: "kids fashion"
}, {
  id: 11,
  category_name: "Dairy Products"
}, {
  id: 12,
  category_name: "Home"
}, {
  id: 13,
  category_name: "Appliances"
}, {
  id: 14,
  category_name: "Mobiles"
}, {
  id: 15,
  category_name: "Toys"
}, {
  id: 18,
  category_name: "Jewelleryy"
}];

function useDebounce(value, delay) {
  _s();

  const {
    0: debouncedValue,
    1: setDebouncedValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(value);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    // Update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

_s(useDebounce, "KDuPAtDOgxm8PU6legVJOb3oOmA=");

const SearchHeader = () => {
  _s2();

  const inputEl = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const {
    0: isSearch,
    1: setIsSearch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    0: keyword,
    1: setKeyword
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: category,
    1: setCategory
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: resultItems,
    1: setResultItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const debouncedSearchTerm = useDebounce(keyword, 1500);

  function handleClearKeyword() {
    setKeyword("");
    setIsSearch(false);
    setLoading(false);
  }

  function handleSubmit(e) {
    e.preventDefault();
    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push(`/search?keyword=${keyword}`);
  }

  const {
    0: menuDataFromServer,
    1: setMenuDataFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([{
    category_id: "",
    category_name: "All"
  }]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let isSubscribed = true;

    const fetchMenuDataFromServer = async () => {
      try {
        const response = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__["default"].getProductCategories();
        isSubscribed ? setMenuDataFromServer([{
          category_id: "",
          category_name: "All"
        }, ...response.data.cat_subcat]) : null;
      } catch (error) {
        console.error(error);
      }
    };

    fetchMenuDataFromServer();
    return () => isSubscribed = false;
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (debouncedSearchTerm) {
      setLoading(true);

      if (keyword) {
        const queries = {
          _limit: 5,
          title_contains: keyword,
          category_id: category
        }; // const products = ProductRepository.getRecords(queries);

        const products = _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__["default"].getSearchedProducts(queries);
        products.then(result => {
          setLoading(false);
          setResultItems(result.items);
          setIsSearch(true);
        });
      } else {
        setIsSearch(false);
        setKeyword("");
      }

      if (loading) {
        setIsSearch(false);
      }
    } else {
      setLoading(false);
      setIsSearch(false);
    }
  }, [debouncedSearchTerm]); // Views

  let productItemsView, clearTextView, selectOptionView, loadingView, loadMoreView;

  if (!loading) {
    if (resultItems && resultItems.length > 0) {
      if (resultItems.length > 5) {
        loadMoreView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-panel__footer text-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: "/search",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              children: "See all results"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 169,
          columnNumber: 11
        }, undefined);
      }

      productItemsView = resultItems.map(product => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductSearchResult__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: product
      }, product.id, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 9
      }, undefined));
    } else {
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: "No product found."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 26
      }, undefined);
    }

    if (keyword !== "") {
      clearTextView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "ps-form__action",
        onClick: handleClearKeyword,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          className: "icon icon-cross2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, undefined);
    }
  } else {
    loadingView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      className: "ps-form__action",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Spin"], {
        size: "small"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 192,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 191,
      columnNumber: 7
    }, undefined);
  }

  if ((menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : menuDataFromServer.length) > 0) {
    selectOptionView = menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : menuDataFromServer.map((option, index) => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        value: option.category_id,
        children: option.category_name
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 200,
        columnNumber: 9
      }, undefined);
    });
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
    className: "ps-form--quick-search",
    method: "get",
    action: "/",
    onSubmit: handleSubmit,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-form__input",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        ref: inputEl,
        className: "form-control",
        type: "text",
        value: keyword,
        placeholder: "I'm shopping for...",
        onChange: e => setKeyword(e.target.value)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 225,
        columnNumber: 9
      }, undefined), clearTextView, loadingView]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 224,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: `ps-panel--search-result${isSearch ? " active " : ""}`,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-panel__content",
        children: productItemsView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 238,
        columnNumber: 9
      }, undefined), loadMoreView]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 207,
    columnNumber: 5
  }, undefined);
};

_s2(SearchHeader, "GQPNfgs0fy5+VuJqVQjKSUl/sFg=", false, function () {
  return [useDebounce];
});

_c = SearchHeader;
/* harmony default export */ __webpack_exports__["default"] = (SearchHeader);

var _c;

$RefreshReg$(_c, "SearchHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/menus/MenuCategoriesDropdown.js":
/*!***********************************************************!*\
  !*** ./components/shared/menus/MenuCategoriesDropdown.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/public/static/data/menu.json */ "./public/static/data/menu.json");
var _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! ~/public/static/data/menu.json */ "./public/static/data/menu.json", 1);
/* harmony import */ var _components_elements_menu_MenuShopBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/components/elements/menu/MenuShopBy */ "./components/elements/menu/MenuShopBy.jsx");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\menus\\MenuCategoriesDropdown.js",
    _s = $RefreshSig$();








const MenuCategoriesDropdown = () => {
  _s();

  var _menuDataFromServer$d;

  const {
    0: menuDataFromServer,
    1: setMenuDataFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);

  const fetchMenuDataFromServer = async () => {
    try {
      const response = await axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_5__["apibaseurl"]}/api/customer/cat-subcat`);
      setMenuDataFromServer(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const {
    homedata
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_6__["useSelector"])(state => state.home);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let handler;
    handler = setTimeout(async () => {
      await fetchMenuDataFromServer();
    }, 100);
    return () => {
      clearTimeout(handler);
    };
  }, [homedata]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "menu--product-categories",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "menu__toggle",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-menu"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: "Shop by Category"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "menu__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_menu_MenuShopBy__WEBPACK_IMPORTED_MODULE_3__["default"], {
        source: menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : (_menuDataFromServer$d = menuDataFromServer.data) === null || _menuDataFromServer$d === void 0 ? void 0 : _menuDataFromServer$d.cat_subcat,
        className: "menu--dropdown"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 5
  }, undefined);
};

_s(MenuCategoriesDropdown, "WtezKyIDxrDtIFdB+9B4q/fq25U=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_6__["useSelector"]];
});

_c = MenuCategoriesDropdown;
/* harmony default export */ __webpack_exports__["default"] = (MenuCategoriesDropdown);

var _c;

$RefreshReg$(_c, "MenuCategoriesDropdown");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/@popperjs/core/lib/createPopper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/contains.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getParentNode.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/instanceOf.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isLayoutViewport.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isTableElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js":
false,

/***/ "./node_modules/@popperjs/core/lib/enums.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/arrow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/computeStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/eventListeners.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/flip.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/hide.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/offset.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/popperOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/preventOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper-base.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/debounce.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/detectOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/expandToHashMap.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/format.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getAltAxis.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getBasePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getFreshSideObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getVariation.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/math.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergeByName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergePaddingObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/orderModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/rectToClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/uniqueBy.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/userAgent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/validateModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/within.js":
false,

/***/ "./node_modules/@react-aria/ssr/dist/module.js":
false,

/***/ "./node_modules/@restart/hooks/esm/index.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCallbackRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCommittedRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventCallback.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useForceUpdate.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useGlobalListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useImage.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useIsomorphicEffect.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeState.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeStateFromProps.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergedRefs.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMounted.js":
false,

/***/ "./node_modules/@restart/hooks/esm/usePrevious.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useRafInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useResizeObserver.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useSafeState.js":
false,

/***/ "./node_modules/@restart/ui/esm/Anchor.js":
false,

/***/ "./node_modules/@restart/ui/esm/Button.js":
false,

/***/ "./node_modules/@restart/ui/esm/DataKey.js":
false,

/***/ "./node_modules/@restart/ui/esm/Dropdown.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownItem.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownMenu.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownToggle.js":
false,

/***/ "./node_modules/@restart/ui/esm/NavContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/SelectableContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/mergeOptionsWithPopperConfig.js":
false,

/***/ "./node_modules/@restart/ui/esm/popper.js":
false,

/***/ "./node_modules/@restart/ui/esm/ssr.js":
false,

/***/ "./node_modules/@restart/ui/esm/useClickOutside.js":
false,

/***/ "./node_modules/@restart/ui/esm/usePopper.js":
false,

/***/ "./node_modules/@restart/ui/esm/useWindow.js":
false,

/***/ "./node_modules/dequal/dist/index.mjs":
false,

/***/ "./node_modules/dom-helpers/esm/addEventListener.js":
false,

/***/ "./node_modules/dom-helpers/esm/camelize.js":
false,

/***/ "./node_modules/dom-helpers/esm/canUseDOM.js":
false,

/***/ "./node_modules/dom-helpers/esm/contains.js":
false,

/***/ "./node_modules/dom-helpers/esm/listen.js":
false,

/***/ "./node_modules/dom-helpers/esm/ownerDocument.js":
false,

/***/ "./node_modules/dom-helpers/esm/querySelectorAll.js":
false,

/***/ "./node_modules/dom-helpers/esm/removeEventListener.js":
false,

/***/ "./node_modules/invariant/browser.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Button.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Dropdown.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownItem.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownMenu.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownToggle.js":
false,

/***/ "./node_modules/react-bootstrap/esm/InputGroupContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/NavbarContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/ThemeProvider.js":
false,

/***/ "./node_modules/react-bootstrap/esm/createWithBsPrefix.js":
false,

/***/ "./node_modules/react-bootstrap/esm/types.js":
false,

/***/ "./node_modules/react-bootstrap/esm/useWrappedRefWithWarning.js":
false,

/***/ "./node_modules/react/cjs/react-jsx-runtime.development.js":
false,

/***/ "./node_modules/react/jsx-runtime.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/hook.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/index.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/uncontrollable.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/utils.js":
false,

/***/ "./pages/index.jsx":
/*!*************************!*\
  !*** ./pages/index.jsx ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_partials_homepage_home_default_SiteFeatures__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/SiteFeatures */ "./components/partials/homepage/home-default/SiteFeatures.jsx");
/* harmony import */ var _components_partials_shop_ShopItems1__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/components/partials/shop/ShopItems1 */ "./components/partials/shop/ShopItems1.jsx");
/* harmony import */ var _components_partials_commons_DownLoadApp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/partials/commons/DownLoadApp */ "./components/partials/commons/DownLoadApp.jsx");
/* harmony import */ var _components_layouts_ContainerHomeDefault__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/layouts/ContainerHomeDefault */ "./components/layouts/ContainerHomeDefault.jsx");
/* harmony import */ var _components_partials_homepage_home_default_FeatureAndRecent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/FeatureAndRecent */ "./components/partials/homepage/home-default/FeatureAndRecent.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Advert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Advert */ "./components/partials/homepage/home-default/Advert.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Discount__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Discount */ "./components/partials/homepage/home-default/Discount.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Brand__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Brand */ "./components/partials/homepage/home-default/Brand.jsx");
/* harmony import */ var _components_partials_homepage_home_default_BottomCategory__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/BottomCategory */ "./components/partials/homepage/home-default/BottomCategory.jsx");
/* harmony import */ var _components_partials_homepage_home_default_HomeDefaultBanner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/HomeDefaultBanner */ "./components/partials/homepage/home-default/HomeDefaultBanner.jsx");
/* harmony import */ var _components_partials_homepage_category_homecategories__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/components/partials/homepage/category/homecategories */ "./components/partials/homepage/category/homecategories.jsx");
/* harmony import */ var _components_partials_homepage_new_deals_daily_newdealsdaily__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~/components/partials/homepage/new-deals-daily/newdealsdaily */ "./components/partials/homepage/new-deals-daily/newdealsdaily.jsx");
/* harmony import */ var _components_partials_homepage_new_deals_daily_newdealsdaily1__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/components/partials/homepage/new-deals-daily/newdealsdaily1 */ "./components/partials/homepage/new-deals-daily/newdealsdaily1.jsx");
/* harmony import */ var _components_partials_homepage_shockingsale_shockingsale__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~/components/partials/homepage/shockingsale/shockingsale */ "./components/partials/homepage/shockingsale/shockingsale.jsx");
/* harmony import */ var _components_partials_homepage_featureproducts_featureproducts__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~/components/partials/homepage/featureproducts/featureproducts */ "./components/partials/homepage/featureproducts/featureproducts.jsx");
/* harmony import */ var _components_partials_homepage_auction_auction__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~/components/partials/homepage/auction/auction */ "./components/partials/homepage/auction/auction.jsx");
/* harmony import */ var _components_partials_homepage_home_default_Bestseller__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~/components/partials/homepage/home-default/Bestseller */ "./components/partials/homepage/home-default/Bestseller.jsx");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var _components_shared_footers_modules_FooterLinks__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~/components/shared/footers/modules/FooterLinks */ "./components/shared/footers/modules/FooterLinks.jsx");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _utilities_home_helper__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ~/utilities/home-helper */ "./utilities/home-helper.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _store_home_action__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ~/store/home/action */ "./store/home/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");


var _jsxFileName = "E:\\bigBasket\\pages\\index.jsx",
    _s = $RefreshSig$();




























const HomepageDefaultPage = () => {
  _s();

  var _homeitems$category, _homeitems$shocking_s, _homeitems$new_arriva;

  const {
    0: homeitems,
    1: setHomeitems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: getOfferData,
    1: setOfferData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_23__["useRouter"])();
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_25__["useDispatch"])();

  async function loadHomedata() {
    let responseData = await Object(_utilities_home_helper__WEBPACK_IMPORTED_MODULE_22__["getHomedata"])(router.asPath);

    if (responseData) {
      dispatch(Object(_store_home_action__WEBPACK_IMPORTED_MODULE_24__["getHomeSuccess"])(responseData.data));
      setHomeitems(responseData.data);
    }

    setTimeout(() => {
      setLoading(false);
    }, 250);
  }

  const offer = () => {
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_19__["apibaseurl"]
    });
    const data = axios__WEBPACK_IMPORTED_MODULE_21___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_19__["apibaseurl"]}/api/customer/offer/list`).then(response => response.data).then(data => {
      console.log("...offerrrrrrrrrrrr.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setOfferData(data.data); // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {
      notification["error"]({
        message: error
      });
    });
  };

  const {
    homedata
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_25__["useSelector"])(state => state.home);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("...homedata....", homedata);

    if (homedata == null) {
      loadHomedata();
    } else {
      setHomeitems(homedata);
      setTimeout(() => {
        setLoading(false);
      }, 250);
    }

    offer();
  }, [homedata]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_26__["Spin"], {
    spinning: loading,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_layouts_ContainerHomeDefault__WEBPACK_IMPORTED_MODULE_5__["default"], {
      title: "Big Basket",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_HomeDefaultBanner__WEBPACK_IMPORTED_MODULE_11__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 9
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$category = homeitems.category) === null || _homeitems$category === void 0 ? void 0 : _homeitems$category.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_new_deals_daily_newdealsdaily1__WEBPACK_IMPORTED_MODULE_14__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_shop_ShopItems1__WEBPACK_IMPORTED_MODULE_3__["default"], {
        homeitems: homeitems
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 9
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$shocking_s = homeitems.shocking_sale) === null || _homeitems$shocking_s === void 0 ? void 0 : _homeitems$shocking_s.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_shockingsale_shockingsale__WEBPACK_IMPORTED_MODULE_15__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_Advert__WEBPACK_IMPORTED_MODULE_7__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 12
      }, undefined), !loading && homeitems && (homeitems === null || homeitems === void 0 ? void 0 : (_homeitems$new_arriva = homeitems.new_arrivals) === null || _homeitems$new_arriva === void 0 ? void 0 : _homeitems$new_arriva.length) > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_new_deals_daily_newdealsdaily__WEBPACK_IMPORTED_MODULE_13__["default"], {
        collectionSlug: "deal-of-the-day",
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_FeatureAndRecent__WEBPACK_IMPORTED_MODULE_6__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 131,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_partials_homepage_home_default_BottomCategory__WEBPACK_IMPORTED_MODULE_10__["default"], {
        homeitems: homeitems,
        loading: loading
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 133,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "top-stories",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-container",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_footers_modules_FooterLinks__WEBPACK_IMPORTED_MODULE_20__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 143,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 142,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 90,
    columnNumber: 5
  }, undefined);
};

_s(HomepageDefaultPage, "nCzXSAgIpEBw3Ka+/AZRYpmvuhY=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_23__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_25__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_25__["useSelector"]];
});

_c = HomepageDefaultPage;
/* harmony default export */ __webpack_exports__["default"] = (HomepageDefaultPage);

var _c;

$RefreshReg$(_c, "HomepageDefaultPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Homeapi.js":
/*!*********************************!*\
  !*** ./repositories/Homeapi.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");




class Homeapi {
  async getHomedata(pathName) {
    let payload = {
      access_token: "",
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["getDeviceId"],
      page_url: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["makePageUrl"])("/"),
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["osType"])()
    };
    const CancelToken = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken;
    let source = CancelToken.source();
    source && source.cancel("Operation canceled due to new request."); // save the new request for cancellation

    source = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken.source();
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/home`, payload, {
      cancelToken: source.token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    })); // cancel the request (the message parameter is optional)

    source.cancel("Operation canceled by the user.");
    return reponse;
  }

  async submitReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-product-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async submitSellerReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-seller-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getHomedata() {
  //   const response = await axios
  //     .get(`https://estrradoweb.com/kangtao/api/customer/home`, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     })
  //     .then((response) => response.data)
  //     .catch((error) => error);
  //   return response;
  // }


}

/* harmony default export */ __webpack_exports__["default"] = (new Homeapi());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/ProductRepository.js":
/*!*******************************************!*\
  !*** ./repositories/ProductRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");



class ProductRepository {
  async getRecords(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(params)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getSearchedProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-search`, {
      lang_id: "",
      category_id: params.category_id,
      keyword: params.title_contains
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.no_of_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list?page=` + params.page, {
      lang_id: 1,
      access_token: "",
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: "https://abc.com/products/us/img",
      os_type: "WEB"
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list-filter?page=` + payload.page, payload).then(response => {
      console.log("############", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getBrands() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/brand`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductCategories() {
    // const reponse = await Repository.get(`${baseUrl}/product-categories`)
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cat-subcat`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getTotalRecords() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products/count`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsById(id) {
    console.log("....dddddd..1..", id);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("....dddddd..1.userdata.", userdata);
    console.log("....dddddd..1..parsedata", parsedata);
    console.log("....dddddd..1.access_token.", access_token);
    console.log("....dddddd..1.getDeviceId.", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"]);
    console.log("....dddddd..1.access_token.", access_token);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-detail`, {
      access_token,
      id,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["basePathUrl"]}/product/${id}`,
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["osType"])()
    }).then(response => {
      console.log("....dddddd....", response);
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getShockSaleByid(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getProductsByCategory(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/product-categories?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrand(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByPriceRange(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(payload)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addProductToCart(payload) {
    console.log(".....56565656565656...", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async changeQty(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart/change-qty`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeOrder(payload) {
    console.log("......3333333333.......", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/placeorder`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCart(payload) {
    console.log("....aaaa....", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteCart(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/delete-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getAuctionProductByAuctionId(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createBid(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-bid`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShopDetailById(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shop-detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCheckoutInfo(payload) {
    console.log("...getCheckoutInfo... apyload..", payload);
    console.log("...getCheckoutInfo... apibaseurl..", _Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/checkout-info`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeAuctionOrder(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/checkout`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new ProductRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Repository.js":
/*!************************************!*\
  !*** ./repositories/Repository.js ***!
  \************************************/
/*! exports provided: basePostUrl, baseStoreURL, apibaseurl, basePathUrl, customHeaders, baseUrl, default, serializeQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePostUrl", function() { return basePostUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseStoreURL", function() { return baseStoreURL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "apibaseurl", function() { return apibaseurl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePathUrl", function() { return basePathUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customHeaders", function() { return customHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "serializeQuery", function() { return serializeQuery; });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseDomain = "https://beta.apinouthemes.com"; // API for products

const basePostUrl = "https://beta.apinouthemes.com"; // API for post

const baseStoreURL = "https://beta.apinouthemes.com"; // API for vendor(store)

let apibaseurlCustom = "https://dev-bigbasket.estrradoweb.com";
let basePath = "https://dev-kangtao.vercel.app";

if (true) {
  if (window.location.hostname == "uat-kangtao.vercel.app") {
    apibaseurlCustom = "https://uat-kt.estrradoweb.com";
    basePath = "https://uat-kangtao.vercel.app";
  }

  if (window.location.hostname == "qa-kangtao.vercel.app") {
    apibaseurlCustom = "https://qa-kt.estrradoweb.com";
    basePath = "https://qa-kangtao.vercel.app";
  }
}

const apibaseurl = apibaseurlCustom;
const basePathUrl = basePath;
const customHeaders = {
  Accept: "application/json"
};
const baseUrl = `${baseDomain}`;
/* harmony default export */ __webpack_exports__["default"] = (axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseUrl,
  headers: customHeaders
}));
const serializeQuery = query => {
  return Object.keys(query).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`).join("&");
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/action.js":
/*!******************************!*\
  !*** ./store/cart/action.js ***!
  \******************************/
/*! exports provided: actionTypes, removeProductFromCartNew, selectedPaymentOption, sellerWiseMessage, usedWalletAmount, sellerWiseDiscount, grandTotalWithDiscountValue, appliedSellerVoucher, appliedPlatformVoucher, totalDiscount, fetchPlatformVoucherAction, fetchPlatformVoucherActionSuccess, getCart, getCartSuccess, getCartError, updateSelectedAddress, addItem, removeItem, increaseItemQty, decreaseItemQty, updateCartSuccess, updateCartError, clearCart, clearCartSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "actionTypes", function() { return actionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeProductFromCartNew", function() { return removeProductFromCartNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedPaymentOption", function() { return selectedPaymentOption; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseMessage", function() { return sellerWiseMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "usedWalletAmount", function() { return usedWalletAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseDiscount", function() { return sellerWiseDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "grandTotalWithDiscountValue", function() { return grandTotalWithDiscountValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedSellerVoucher", function() { return appliedSellerVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedPlatformVoucher", function() { return appliedPlatformVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalDiscount", function() { return totalDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherAction", function() { return fetchPlatformVoucherAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherActionSuccess", function() { return fetchPlatformVoucherActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCart", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartSuccess", function() { return getCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartError", function() { return getCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSelectedAddress", function() { return updateSelectedAddress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addItem", function() { return addItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeItem", function() { return removeItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "increaseItemQty", function() { return increaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decreaseItemQty", function() { return decreaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartSuccess", function() { return updateCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartError", function() { return updateCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCart", function() { return clearCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCartSuccess", function() { return clearCartSuccess; });
const actionTypes = {
  GET_CART: "GET_CART",
  GET_CART_SUCCESS: "GET_CART_SUCCESS",
  GET_CART_ERROR: "GET_CART_ERROR",
  GET_CART_TOTAL_QUANTITY: "GET_CART_TOTAL_QUANTITY",
  GET_CART_TOTAL_QUANTITY_SUCCESS: "GET_CART_TOTAL_QUANTITY_SUCCESS",
  ADD_ITEM: "ADD_ITEM",
  REMOVE_ITEM: "REMOVE_ITEM",
  REMOVE_PRODUCT_FROM_CART_NEW: "REMOVE_PRODUCT_FROM_CART_NEW",
  CLEAR_CART: "CLEAR_CART",
  CLEAR_CART_SUCCESS: "CLEAR_CART_SUCCESS",
  CLEAR_CART_ERROR: "CLEAR_CART_ERROR",
  INCREASE_QTY: "INCREASE_QTY",
  INCREASE_QTY_SUCCESS: "INCREASE_QTY_SUCCESS",
  INCREASE_QTY_ERROR: "INCREASE_QTY_ERROR",
  DECREASE_QTY: "DECREASE_QTY",
  UPDATE_CART: "UPDATE_CART",
  UPDATE_CART_SUCCESS: "UPDATE_CART_SUCCESS",
  UPDATE_CART_ERROR: "UPDATE_CART_ERROR",
  UPDATE_SELECTED_ADDRESS: "UPDATE_SELECTED_ADDRESS",
  FETCH_PLATFORM_VOUCHER: "FETCH_PLATFORM_VOUCHER",
  FETCH_PLATFORM_VOUCHER_SUCCESS: "FETCH_PLATFORM_VOUCHER_SUCCESS",
  TOTAL_DISCOUNT: "TOTAL_DISCOUNT",
  APPLIED_SELLER_VOUCHER: "APPLIED_SELLER_VOUCHER",
  APPLIED_PLATFORM_VOUCHER: "APPLIED_PLATFORM_VOUCHER",
  GRAND_TOTAL_WITH_DISCOUNT_VALUE: "GRAND_TOTAL_WITH_DISCOUNT_VALUE",
  SELLER_WISE_DISCOUNT: "SELLER_WISE_DISCOUNT",
  SELLER_WISE_MESSAGES: "SELLER_WISEMESSAGES",
  USED_WALLET_AMOUNT: "USED_WALLET_AMOUNT",
  SELECTED_PAYMENT_OPTION_BY_USER: "SELECTED_PAYMENT_OPTION_BY_USER"
};
function removeProductFromCartNew(payload) {
  return {
    type: actionTypes.REMOVE_PRODUCT_FROM_CART_NEW,
    payload
  };
}
function selectedPaymentOption(payload) {
  return {
    type: actionTypes.SELECTED_PAYMENT_OPTION_BY_USER,
    payload
  };
}
function sellerWiseMessage(payload) {
  return {
    type: actionTypes.SELLER_WISE_MESSAGES,
    payload
  };
}
function usedWalletAmount(payload) {
  return {
    type: actionTypes.USED_WALLET_AMOUNT,
    payload
  };
}
function sellerWiseDiscount(payload) {
  return {
    type: actionTypes.SELLER_WISE_DISCOUNT,
    payload
  };
}
function grandTotalWithDiscountValue(payload) {
  return {
    type: actionTypes.GRAND_TOTAL_WITH_DISCOUNT_VALUE,
    payload
  };
}
function appliedSellerVoucher(payload) {
  return {
    type: actionTypes.APPLIED_SELLER_VOUCHER,
    payload
  };
}
function appliedPlatformVoucher(payload) {
  return {
    type: actionTypes.APPLIED_PLATFORM_VOUCHER,
    payload
  };
}
function totalDiscount(payload) {
  return {
    type: actionTypes.TOTAL_DISCOUNT,
    payload
  };
}
function fetchPlatformVoucherAction() {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER
  };
}
function fetchPlatformVoucherActionSuccess(payload) {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER_SUCCESS,
    payload
  };
}
function getCart() {
  alert("getCart");
  return {
    type: actionTypes.GET_CART
  };
}
function getCartSuccess(payload) {
  return {
    type: actionTypes.GET_CART_SUCCESS,
    payload
  };
}
function getCartError(error) {
  return {
    type: actionTypes.GET_CART_ERROR,
    error
  };
}
function updateSelectedAddress(payload) {
  alert("call");
  console.log("..555555....", payload);
  return {
    type: actionTypes.UPDATE_SELECTED_ADDRESS,
    payload
  };
}
function addItem(payload) {
  return {
    type: actionTypes.ADD_ITEM,
    payload
  };
}
function removeItem(product) {
  return {
    type: actionTypes.REMOVE_ITEM,
    product
  };
}
function increaseItemQty(product) {
  return {
    type: actionTypes.INCREASE_QTY,
    product
  };
}
function decreaseItemQty(product) {
  return {
    type: actionTypes.DECREASE_QTY,
    product
  };
}
function updateCartSuccess(payload) {
  return {
    type: actionTypes.UPDATE_CART_SUCCESS,
    payload
  };
}
function updateCartError(payload) {
  return {
    type: actionTypes.UPDATE_CART_ERROR,
    payload
  };
}
function clearCart() {
  return {
    type: actionTypes.CLEAR_CART
  };
}
function clearCartSuccess() {
  return {
    type: actionTypes.CLEAR_CART_SUCCESS
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./utilities/product-helper.js":
/*!*************************************!*\
  !*** ./utilities/product-helper.js ***!
  \*************************************/
/*! exports provided: routeWithoutRefresh, homePageProductPriceHelper, returnTotalOfCartValue, returnTotalCommission, returnTotalOfCartTaxValue, priceHelper, currencyHelperConvertToRinggit, mathFormula, divCurrency, mulCurrency, addCurrency, subCurrency, formatCurrency, getColletionBySlug, getItemBySlug, convertSlugsQueryString, StrapiProductBadge, StrapiProductPrice, StrapiProductPrice_New, featureproductprice, StrapiProductPriceExpanded, StrapiProductPriceExpandedOther, StrapiProductPriceExpandedOther1, StrapiProductThumbnail, StrapiProductThumbnailOther, StrapiProductThumbnailDetail, Shockingproductthumbnail, colorHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routeWithoutRefresh", function() { return routeWithoutRefresh; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "homePageProductPriceHelper", function() { return homePageProductPriceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartValue", function() { return returnTotalOfCartValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalCommission", function() { return returnTotalCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartTaxValue", function() { return returnTotalOfCartTaxValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "priceHelper", function() { return priceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currencyHelperConvertToRinggit", function() { return currencyHelperConvertToRinggit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mathFormula", function() { return mathFormula; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "divCurrency", function() { return divCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mulCurrency", function() { return mulCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addCurrency", function() { return addCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subCurrency", function() { return subCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatCurrency", function() { return formatCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColletionBySlug", function() { return getColletionBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getItemBySlug", function() { return getItemBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertSlugsQueryString", function() { return convertSlugsQueryString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductBadge", function() { return StrapiProductBadge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice", function() { return StrapiProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice_New", function() { return StrapiProductPrice_New; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "featureproductprice", function() { return featureproductprice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpanded", function() { return StrapiProductPriceExpanded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther", function() { return StrapiProductPriceExpandedOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther1", function() { return StrapiProductPriceExpandedOther1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnail", function() { return StrapiProductThumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailOther", function() { return StrapiProductThumbnailOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailDetail", function() { return StrapiProductThumbnailDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Shockingproductthumbnail", function() { return Shockingproductthumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorHelper", function() { return colorHelper; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "E:\\bigBasket\\utilities\\product-helper.js";

/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */






const exactMath = __webpack_require__(/*! exact-math */ "./node_modules/exact-math/dist/exact-math.node.js");

function routeWithoutRefresh(routeLink) {
  next_router__WEBPACK_IMPORTED_MODULE_5___default.a.replace(routeLink, undefined, {
    shallow: true
  });
}
function homePageProductPriceHelper(product) {
  if (product.offer_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this);
  }

  if (product.shock_sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.shock_sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this);
  }

  if (product.sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", product.actual_price ? product.actual_price : 0]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
function returnTotalOfCartValue(products) {
  let cart_total_price = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_discount_price == 0 ? next.total_actual_price : next.total_discount_price));
  }, 0);
  return cart_total_price;
}
function returnTotalCommission(products) {
  let cart_total_commission = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.commission));
  }, 0);
  return cart_total_commission;
}
function returnTotalOfCartTaxValue(products) {
  let cart_total_tax = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_tax_value));
  }, 0);
  return cart_total_tax;
}
function priceHelper(num) {
  let numberArray = num === null || num === void 0 ? void 0 : num.toString().split(",");

  if (numberArray && (numberArray === null || numberArray === void 0 ? void 0 : numberArray.length) > 0) {
    return numberArray.reduce((prev, next) => prev + next);
  } else {
    return 0;
  }
}
function currencyHelperConvertToRinggit(currencyVal) {
  return new Intl.NumberFormat("ms-MY", {
    style: "currency",
    currency: "MYR"
  }).format(priceHelper(currencyVal));
}
function mathFormula(formulaText) {
  let result = exactMath.formula(formulaText);
}
function divCurrency(firstVal, secondVal) {
  let divData = exactMath.div(priceHelper(firstVal || 0), priceHelper(secondVal || 1));
  return divData;
}
function mulCurrency(firstVal, secondVal) {
  let mulData = exactMath.mul(priceHelper(firstVal || 1), priceHelper(secondVal || 1));
  return mulData;
}
function addCurrency(currencyValFirst, currencyValSecond) {
  let addData = exactMath.add(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return addData;
}
function subCurrency(currencyValFirst, currencyValSecond) {
  let subData = exactMath.sub(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return subData;
}
function formatCurrency(num) {
  if (num !== undefined) {
    return parseFloat(num).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
  } else {}
}
function getColletionBySlug(collections, slug) {
  if (collections.length > 0) {
    const result = collections.find(item => item.slug === slug.toString());

    if (result !== undefined) {
      return result.products;
    } else {
      return [];
    }
  } else {
    return [];
  }
}
function getItemBySlug(banners, slug) {
  if (banners.length > 0) {
    const banner = banners.find(item => item.slug === slug.toString());

    if (banner !== undefined) {
      return banner;
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function convertSlugsQueryString(payload) {
  let query = "";

  if (payload.length > 0) {
    payload.forEach(item => {
      if (query === "") {
        query = `slug_in=${item}`;
      } else {
        query = query + `&slug_in=${item}`;
      }
    });
  }

  return query;
}
function StrapiProductBadge(product) {
  let view;

  if (product.badge && product.badge !== null) {
    view = product.badge.map(badge => {
      if (badge.type === "sale") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 16
        }, this);
      } else if (badge.type === "outStock") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge out-stock",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 16
        }, this);
      } else {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge hot",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 16
        }, this);
      }
    });
  }

  return view;
}
_c = StrapiProductBadge;
function StrapiProductPrice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 216,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 223,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c2 = StrapiProductPrice;
function StrapiProductPrice_New(product) {
  let view;

  if (product.sale_price !== false) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 235,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", product.actual_price]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 239,
      columnNumber: 12
    }, this);
  }

  return view;
}
_c3 = StrapiProductPrice_New;
function featureproductprice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 259,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 7
    }, this);
  }

  return view;
}
function StrapiProductPriceExpanded(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 274,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
        children: "18% off"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 275,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 272,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 280,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c4 = StrapiProductPriceExpanded;
function StrapiProductPriceExpandedOther(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.offer_price ? product.offer_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.actual_price ? product.actual_price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 292,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 295,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 290,
    columnNumber: 5
  }, this);
  return view;
}
_c5 = StrapiProductPriceExpandedOther;
function StrapiProductPriceExpandedOther1(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.sale_price ? product.sale_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.price ? product.price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 307,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 310,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 305,
    columnNumber: 5
  }, this);
  return view;
}
_c6 = StrapiProductPriceExpandedOther1;
function StrapiProductThumbnail(product) {
  let view;

  if (product.thumbnail) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: `${_repositories_Repository__WEBPACK_IMPORTED_MODULE_3__["baseUrl"]}${product.thumbnail.url}`,
            alt: product.title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 323,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 322,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 338,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 337,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 336,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 335,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c7 = StrapiProductThumbnail;
function StrapiProductThumbnailOther(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 356,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 355,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 353,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 371,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 370,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 368,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c8 = StrapiProductThumbnailOther;
function StrapiProductThumbnailDetail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$2;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
            alt: product.product_name,
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 393,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 392,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 391,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 409,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 408,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 407,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 406,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c9 = StrapiProductThumbnailDetail;
function Shockingproductthumbnail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$3;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$3 = product.image[0]) === null || _product$image$3 === void 0 ? void 0 : _product$image$3.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 432,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 431,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 430,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 429,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 447,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 446,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 445,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 444,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c10 = Shockingproductthumbnail;
function colorHelper() {
  console.log("hello");
}

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;

$RefreshReg$(_c, "StrapiProductBadge");
$RefreshReg$(_c2, "StrapiProductPrice");
$RefreshReg$(_c3, "StrapiProductPrice_New");
$RefreshReg$(_c4, "StrapiProductPriceExpanded");
$RefreshReg$(_c5, "StrapiProductPriceExpandedOther");
$RefreshReg$(_c6, "StrapiProductPriceExpandedOther1");
$RefreshReg$(_c7, "StrapiProductThumbnail");
$RefreshReg$(_c8, "StrapiProductThumbnailOther");
$RefreshReg$(_c9, "StrapiProductThumbnailDetail");
$RefreshReg$(_c10, "Shockingproductthumbnail");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9kZXRhaWwvbW9kdWxlcy9Nb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL2VsZW1lbnRzL3Byb2R1Y3RzL1Byb2R1Y3RBdWN0aW9uLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0QXVjdGlvblNsaWRlLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0T25DYXJ0LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2VhcmNoUmVzdWx0LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2hvY2tpbmdTYWxlLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGUuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2hvbWUtZGVmYXVsdC9GZWF0dXJlQW5kUmVjZW50LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvSG9tZURlZmF1bHRCYW5uZXIuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3BhcnRpYWxzL3Nob3AvU2hvcEl0ZW1zMS5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2Zvb3RlcnMvbW9kdWxlcy9Gb290ZXJDb3B5cmlnaHQuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL0hlYWRlckRlZmF1bHQuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL21vZHVsZXMvTWluaUNhcnQuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL21vZHVsZXMvU2VhcmNoSGVhZGVyLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9zaGFyZWQvbWVudXMvTWVudUNhdGVnb3JpZXNEcm9wZG93bi5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanN4Iiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvSG9tZWFwaS5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vcmVwb3NpdG9yaWVzL1Byb2R1Y3RSZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeS5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vc3RvcmUvY2FydC9hY3Rpb24uanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlci5qcyJdLCJuYW1lcyI6WyJNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMiLCJSZWFjdCIsIm1lbW8iLCJwcm9kdWN0IiwiZXh0ZW5kZWQiLCJzaG9ja2luZ3NhbGUiLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwicXVhbnRpdHkiLCJzZXRRdWFudGl0eSIsInVzZVN0YXRlIiwid2lzaGxpc3RGcm9tU2VydmVyIiwic2V0V2lzaGxpc3RGcm9tU2VydmVyIiwiUm91dGVyIiwidXNlUm91dGVyIiwibG9hZGluZzEiLCJzZXRMb2FkaW5nMSIsImxvYWRpbmcyIiwic2V0TG9hZGluZzIiLCJsb2FkaW5nMyIsInNldExvYWRpbmczIiwiYXV0aCIsInVzZVNlbGVjdG9yIiwic3RhdGUiLCJoYW5kbGVBZGRJdGVtVG9DYXJ0IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJ1c2VyZGF0YSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJwYXJzZWRhdGEiLCJKU09OIiwicGFyc2UiLCJ0b2tlbiIsImFjY2Vzc190b2tlbiIsInVuZGVmaW5lZCIsIm5vdGlmaWNhdGlvbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImR1cmF0aW9uIiwicHJvZHVjdF90eXBlIiwiZmlsdGVyQXNzb2NQcm9kIiwiYXNzb2NWYWxTZWwiLCJhc3NvY1ZhbFNpemVTZWwiLCJwYXlsb2FkIiwicHJkX2Fzc2lnbl9pZCIsImNhcnRfdHlwZSIsInByb2R1Y3RfaWQiLCJnZXRQcm9kdWN0SWQiLCJvdXRfb2Zfc3RvY2tfc2VsbGluZyIsInN0b2NrIiwiZ2V0T3V0T2ZzdG9ja1ZhbHVlQ29uZmlnUHJvZCIsInJlc3BvbnNlRGF0YSIsIlByb2R1Y3RSZXBvc2l0b3J5IiwiYWRkUHJvZHVjdFRvQ2FydCIsImh0dHBjb2RlIiwidG1wIiwiZ2V0Q2FydCIsInN0YXR1cyIsInJlc3BvbnNlIiwic2V0VGltZW91dCIsInB1c2giLCJoYW5kbGVCdXlub3ciLCJpc0xvZ2dlZEluIiwiaGFuZGxlQWRkSXRlbVRvQ29tcGFyZSIsImFkZEl0ZW1Ub0NvbXBhcmUiLCJoYW5kbGVBZGRJdGVtVG9XaXNobGlzdCIsImFkZFNob2NraW5nU2FsZUl0ZW1Ub1dpc2hsaXN0IiwiYWRkSXRlbVRvV2lzaGxpc3QiLCJoYW5kbGVSZW1vdmVXaXNoTGlzdEl0ZW0iLCJyZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0IiwicmVtb3ZlV2lzaGxpc3RJdGVtIiwiaGFuZGxlSW5jcmVhc2VJdGVtUXR5Iiwic2V0UHJvZHVjdFF1YW50aXR5QWN0aW9uIiwiaGFuZGxlRGVjcmVhc2VJdGVtUXR5IiwiYXNzb2NpYXRpdmVQcm9kIiwic2V0QXNzb2NpYXRpdmVQcm9kIiwidW5pcXVlQXNzb2NpYXRpdmVQcm9kIiwic2V0VW5pcXVlQXNzb2NpYXRpdmVQcm9kIiwic2V0RmlsdGVyQXNzb2NQcm9kIiwiYXNzb2NWYWwiLCJhc3NvY1ZhbFNpemUiLCJhc3NvY1Byb2RJZCIsInVzZUVmZmVjdCIsImFzc29jaWF0aXZlX3Byb2R1Y3RzIiwiYXJyYXlWYWxzIiwiTWFwIiwibWFwIiwiaXRlbSIsInZhbHVlcyIsImhhbmRsZUNoYW5nZUF0dHIiLCJ0YXJnZXQiLCJ2YWx1ZSIsImhhbmRsZUNoYW5nZUF0dHJTaXplIiwicmVuZGVyQXNzb2NpYXRpdmVQcm9kdWN0IiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwid2lkdGgiLCJhdHRyX25hbWUiLCJhdHRyIiwiaW5kZXgiLCJhdHRyX3ZhbHVlIiwiaW1hZ2UiLCJzdWJfYXR0cmlidXRlcyIsImZpbHRlciIsInByb2QiLCJ0b0xvd2VyQ2FzZSIsInJlbmRlclByaWNlIiwiY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IiwicHJpY2UiLCJhY3R1YWxfcHJpY2UiLCJwcm9kX3NhbGVfcHJpY2UiLCJzYWxlX3ByaWNlIiwic2l6ZVZhbHVlIiwic2VsZWN0ZWRQcm9kdWN0SUQiLCJzZXRDb25maWdQcm9kdWN0SUQiLCJzZXRDb25maWdQcm9kdWN0U3RvY2siLCJzZXRDb25maWdQcm9kdWN0T3V0T2ZTdG9ja1NlbGxpbmciLCJpbl93aXNobGlzdCIsImN1cnNvciIsIlByb2R1Y3RBdWN0aW9uIiwid2lkdGhHaXZlbiIsIm1hcmdpbkdpdmVuIiwibWFyZ2luIiwiZW5kX2RhdGUiLCJhdWN0aW9uX2lkIiwic2VsbGVyIiwibWFyZ2luVG9wIiwibWF4V2lkdGgiLCJwcm9kdWN0X25hbWUiLCJub19vZl9iaWRzIiwibWluX2JpZF9wcmljZSIsIlByb2R1Y3RBdWN0aW9uU2xpZGUiLCJQcm9kdWN0T25DYXJ0IiwiaGFuZGxlUmVtb3ZlQ2FydEl0ZW0iLCJjYXJ0X2lkIiwiTW9kYWwiLCJjb25maXJtIiwidGl0bGUiLCJvbk9rIiwicmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3IiwiZGVzdHJveUFsbCIsIm9uQ2FuY2VsIiwib2tCdXR0b25Qcm9wcyIsImRhbmdlciIsIm9uZXJyb3IiLCJzcmMiLCJhdHRyX25hbWUxIiwiYXR0cl9uYW1lMiIsInVuaXRfZGlzY291bnRfcHJpY2UiLCJ1bml0X2FjdHVhbF9wcmljZSIsIlByb2R1Y3RTZWFyY2hSZXN1bHQiLCJpZCIsInJhdGluZyIsIlByb2R1Y3RTaG9ja2luZ1NhbGUiLCJlbmRfdGltZSIsInNob2NrX3NhbGVfaWQiLCJvZmZlcl9wcmljZSIsImNvbG9yIiwib2ZmZXIiLCJQcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGUiLCJGZWF0dXJlQW5kUmVjZW50IiwiaG9tZWl0ZW1zIiwibG9hZGluZyIsIm1haW5DYXJvdXNlbFZpZXciLCJmZWF0dXJlZF9wcm9kdWN0cyIsImxlbmd0aCIsInNsaWNlIiwiZGlzcGxheSIsInRodW1ibmFpbCIsIm1haW5DYXJvdXNlbFZpZXcxIiwiY2VudGVyX29mZmVyX2Jhbm5lciIsIm1lZGlhIiwiSG9tZURlZmF1bHRCYW5uZXIiLCJwcm9tb3Rpb24xIiwic2V0UHJvbW90aW9uMSIsInByb21vdGlvbjIiLCJzZXRQcm9tb3Rpb24yIiwiZ2V0UHJvbW90aW9ucyIsIk1lZGlhUmVwb3NpdG9yeSIsImdldFByb21vdGlvbnNCeVNsdWciLCJnZXRJdGVtQnlTbHVnIiwibWFpbkJhbm5lck1lZGlhIiwibWVkaWFfdHlwZSIsImJ1dHRvbl9saW5rIiwiYmFja2dyb3VuZEltYWdlIiwiY2Fyb3VzZWxTZXR0aW5nIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJmYWRlIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJuZXh0QXJyb3ciLCJwcmV2QXJyb3ciLCJjYXJvdXNlbFN0YW5kYXJkIiwiYXJyb3dzIiwicmVzcG9uc2l2ZSIsImJyZWFrcG9pbnQiLCJzZXR0aW5ncyIsImluaXRpYWxTbGlkZSIsIm1haW5fYmFubmVyIiwiY2Fyb3VzZUl0ZW1zIiwiU2hvcEl0ZW1zIiwiY29sdW1ucyIsInBhZ2VTaXplIiwicGF0aERldGFpbCIsInBhdGhuYW1lIiwicGFnZSIsImNhdGVnb3J5Iiwic3ViY2F0ZWdvcnlfaWQiLCJicmFuZCIsInByaWNlX2d0IiwicHJpY2VfbHQiLCJsb3dfdG9faGlnaCIsImhpZ2hfdG9fbG93IiwibGF0ZXN0IiwicXVlcnkiLCJsaXN0VmlldyIsInNldExpc3RWaWV3IiwicHJvZHVjdEl0ZW1zIiwic2V0UHJvZHVjdEl0ZW1zIiwidG90YWwiLCJzZXRUb3RhbCIsInNldExvYWRpbmciLCJjbGFzc2VzIiwic2V0Q2xhc3NlcyIsImhhbmRsZUNoYW5nZVZpZXdNb2RlIiwicHJldmVudERlZmF1bHQiLCJnZXRQcm9kdWN0cyIsInBhcmFtcyIsIml0ZW1zIiwidG90YWxJdGVtcyIsImJpbmQiLCJnZXRQcm9kdWN0c2J5ZmlsdGVycyIsImxhbmdfaWQiLCJjYXRlZ29yeV9pZCIsImJyYW5kX2lkIiwibWF4X3ByaWNlIiwibWluX3ByaWNlIiwiZ2V0UHJvZHVjdHNieUZpbHRlciIsImhhbmRsZVBhZ2luYXRpb24iLCJmaWx0ZXJwYXJ0Iiwid2luZG93IiwibG9jYXRpb24iLCJzZWFyY2giLCJuZXdkZCIsInJlcGxhY2UiLCJnZXRUb3RhbFJlY29yZHMiLCJoYW5kbGVTZXRDb2x1bW5zIiwicHJvZHVjdEl0ZW1zVmlldyIsInRyZW5kaW5nX3Byb2R1Y3RzIiwic2tlbGV0b25JdGVtcyIsImdlbmVyYXRlVGVtcEFycmF5IiwiRm9vdGVyQ29weXJpZ2h0IiwiSGVhZGVyRGVmYXVsdCIsImFkZEV2ZW50TGlzdGVuZXIiLCJzdGlja3lIZWFkZXIiLCJNaW5pQ2FydCIsImNhcnQiLCJjYXJ0SXRlbXNWaWV3IiwicHJvZHVjdEl0ZW1XaXRoU2VsbGVyIiwicHJvZHVjdEl0ZW0iLCJwcm9kdWN0cyIsImNhcnRQcm9kdWN0Iiwic2VsbGVyX2lkIiwiY2FydGRhdGEiLCJzZXRDYXJ0ZGF0YSIsInNldFRvdGFsSXRlbXMiLCJpc01vdW50ZWQiLCJjYXJ0VG90YWxQcm9kdWN0c0Zyb21BbGxTZWxsZXIiLCJyZWR1Y2UiLCJwcm9kdWN0SXRlbVByZXYiLCJwcm9kdWN0SXRlbU5leHQiLCJOdW1iZXIiLCJnZXRDYXJ0SXRlbSIsImFsZXJ0IiwidXNlcl90b2tlbiIsImFwaWJhc2V1cmwiLCJnZXREZXZpY2VJZCIsImRhdGEiLCJBeGlvcyIsInBvc3QiLCJkZXZpY2VfaWQiLCJwYWdlX3VybCIsIm9zX3R5cGUiLCJ0aGVuIiwiY2FydF9jb3VudCIsImNhdGNoIiwiZXJyb3IiLCJncmFuZF90b3RhbCIsImNvbm5lY3QiLCJleGFtcGxlQ2F0ZWdvcmllcyIsImNhdGVnb3J5X25hbWUiLCJ1c2VEZWJvdW5jZSIsImRlbGF5IiwiZGVib3VuY2VkVmFsdWUiLCJzZXREZWJvdW5jZWRWYWx1ZSIsImhhbmRsZXIiLCJjbGVhclRpbWVvdXQiLCJTZWFyY2hIZWFkZXIiLCJpbnB1dEVsIiwidXNlUmVmIiwiaXNTZWFyY2giLCJzZXRJc1NlYXJjaCIsImtleXdvcmQiLCJzZXRLZXl3b3JkIiwic2V0Q2F0ZWdvcnkiLCJyZXN1bHRJdGVtcyIsInNldFJlc3VsdEl0ZW1zIiwiZGVib3VuY2VkU2VhcmNoVGVybSIsImhhbmRsZUNsZWFyS2V5d29yZCIsImhhbmRsZVN1Ym1pdCIsIm1lbnVEYXRhRnJvbVNlcnZlciIsInNldE1lbnVEYXRhRnJvbVNlcnZlciIsImlzU3Vic2NyaWJlZCIsImZldGNoTWVudURhdGFGcm9tU2VydmVyIiwiZ2V0UHJvZHVjdENhdGVnb3JpZXMiLCJjYXRfc3ViY2F0IiwicXVlcmllcyIsIl9saW1pdCIsInRpdGxlX2NvbnRhaW5zIiwiZ2V0U2VhcmNoZWRQcm9kdWN0cyIsInJlc3VsdCIsImNsZWFyVGV4dFZpZXciLCJzZWxlY3RPcHRpb25WaWV3IiwibG9hZGluZ1ZpZXciLCJsb2FkTW9yZVZpZXciLCJvcHRpb24iLCJNZW51Q2F0ZWdvcmllc0Ryb3Bkb3duIiwiaG9tZWRhdGEiLCJob21lIiwiSG9tZXBhZ2VEZWZhdWx0UGFnZSIsInNldEhvbWVpdGVtcyIsImdldE9mZmVyRGF0YSIsInNldE9mZmVyRGF0YSIsInJvdXRlciIsImxvYWRIb21lZGF0YSIsImdldEhvbWVkYXRhIiwiYXNQYXRoIiwiZ2V0SG9tZVN1Y2Nlc3MiLCJzaG9ja2luZ19zYWxlIiwibmV3X2Fycml2YWxzIiwiSG9tZWFwaSIsInBhdGhOYW1lIiwibWFrZVBhZ2VVcmwiLCJvc1R5cGUiLCJDYW5jZWxUb2tlbiIsImF4aW9zIiwic291cmNlIiwiY2FuY2VsIiwicmVwb25zZSIsIlJlcG9zaXRvcnkiLCJjYW5jZWxUb2tlbiIsInN0cmluZ2lmeSIsInN1Ym1pdFJldmlldyIsInN1Ym1pdFNlbGxlclJldmlldyIsImdldFJlY29yZHMiLCJnZXQiLCJiYXNlVXJsIiwic2VyaWFsaXplUXVlcnkiLCJub19vZl9wcm9kdWN0cyIsInRvdGFsX3Byb2R1Y3RzIiwiZ2V0TmV3RGVhbHNQcm9kdWN0cyIsImdldFNob2NraW5nU2FsZVByb2R1Y3RzIiwic2hvY2tfc2FsZSIsImdldEZlYXR1cmVkUHJvZHVjdHMiLCJnZXROZXdEZWFsc1Byb2R1Y3RzYnlGaWx0ZXIiLCJnZXRTaG9ja2luZ1NhbGVQcm9kdWN0c2J5RmlsdGVyIiwiZ2V0RmVhdHVyZWRQcm9kdWN0c2J5RmlsdGVyIiwiZ2V0U2hvY2tpbmdQcm9kdWN0cyIsImdldEJyYW5kcyIsImdldFByb2R1Y3RzQnlJZCIsImJhc2VQYXRoVXJsIiwiZ2V0U2hvY2tTYWxlQnlpZCIsImdldFByb2R1Y3RzQnlDYXRlZ29yeSIsImdldFByb2R1Y3RzQnlCcmFuZCIsImdldFByb2R1Y3RzQnlCcmFuZHMiLCJmb3JFYWNoIiwiZ2V0UHJvZHVjdHNCeVByaWNlUmFuZ2UiLCJjaGFuZ2VRdHkiLCJwbGFjZU9yZGVyIiwiZGVsZXRlQ2FydCIsImdldEF1Y3Rpb25Qcm9kdWN0QnlBdWN0aW9uSWQiLCJjcmVhdGVCaWQiLCJnZXRTaG9wRGV0YWlsQnlJZCIsImdldENoZWNrb3V0SW5mbyIsInBsYWNlQXVjdGlvbk9yZGVyIiwiYmFzZURvbWFpbiIsImJhc2VQb3N0VXJsIiwiYmFzZVN0b3JlVVJMIiwiYXBpYmFzZXVybEN1c3RvbSIsImJhc2VQYXRoIiwiaG9zdG5hbWUiLCJjdXN0b21IZWFkZXJzIiwiQWNjZXB0IiwiY3JlYXRlIiwiaGVhZGVycyIsIk9iamVjdCIsImtleXMiLCJrZXkiLCJlbmNvZGVVUklDb21wb25lbnQiLCJqb2luIiwiYWN0aW9uVHlwZXMiLCJHRVRfQ0FSVCIsIkdFVF9DQVJUX1NVQ0NFU1MiLCJHRVRfQ0FSVF9FUlJPUiIsIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZIiwiR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlfU1VDQ0VTUyIsIkFERF9JVEVNIiwiUkVNT1ZFX0lURU0iLCJSRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXIiwiQ0xFQVJfQ0FSVCIsIkNMRUFSX0NBUlRfU1VDQ0VTUyIsIkNMRUFSX0NBUlRfRVJST1IiLCJJTkNSRUFTRV9RVFkiLCJJTkNSRUFTRV9RVFlfU1VDQ0VTUyIsIklOQ1JFQVNFX1FUWV9FUlJPUiIsIkRFQ1JFQVNFX1FUWSIsIlVQREFURV9DQVJUIiwiVVBEQVRFX0NBUlRfU1VDQ0VTUyIsIlVQREFURV9DQVJUX0VSUk9SIiwiVVBEQVRFX1NFTEVDVEVEX0FERFJFU1MiLCJGRVRDSF9QTEFURk9STV9WT1VDSEVSIiwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTIiwiVE9UQUxfRElTQ09VTlQiLCJBUFBMSUVEX1NFTExFUl9WT1VDSEVSIiwiQVBQTElFRF9QTEFURk9STV9WT1VDSEVSIiwiR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRSIsIlNFTExFUl9XSVNFX0RJU0NPVU5UIiwiU0VMTEVSX1dJU0VfTUVTU0FHRVMiLCJVU0VEX1dBTExFVF9BTU9VTlQiLCJTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSIiwidHlwZSIsInNlbGVjdGVkUGF5bWVudE9wdGlvbiIsInNlbGxlcldpc2VNZXNzYWdlIiwidXNlZFdhbGxldEFtb3VudCIsInNlbGxlcldpc2VEaXNjb3VudCIsImdyYW5kVG90YWxXaXRoRGlzY291bnRWYWx1ZSIsImFwcGxpZWRTZWxsZXJWb3VjaGVyIiwiYXBwbGllZFBsYXRmb3JtVm91Y2hlciIsInRvdGFsRGlzY291bnQiLCJmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbiIsImZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uU3VjY2VzcyIsImdldENhcnRTdWNjZXNzIiwiZ2V0Q2FydEVycm9yIiwidXBkYXRlU2VsZWN0ZWRBZGRyZXNzIiwiYWRkSXRlbSIsInJlbW92ZUl0ZW0iLCJpbmNyZWFzZUl0ZW1RdHkiLCJkZWNyZWFzZUl0ZW1RdHkiLCJ1cGRhdGVDYXJ0U3VjY2VzcyIsInVwZGF0ZUNhcnRFcnJvciIsImNsZWFyQ2FydCIsImNsZWFyQ2FydFN1Y2Nlc3MiLCJleGFjdE1hdGgiLCJyZXF1aXJlIiwicm91dGVXaXRob3V0UmVmcmVzaCIsInJvdXRlTGluayIsInNoYWxsb3ciLCJob21lUGFnZVByb2R1Y3RQcmljZUhlbHBlciIsInNob2NrX3NhbGVfcHJpY2UiLCJyZXR1cm5Ub3RhbE9mQ2FydFZhbHVlIiwiY2FydF90b3RhbF9wcmljZSIsInByZXYiLCJuZXh0IiwicHJpY2VIZWxwZXIiLCJ0b3RhbF9kaXNjb3VudF9wcmljZSIsInRvdGFsX2FjdHVhbF9wcmljZSIsInJldHVyblRvdGFsQ29tbWlzc2lvbiIsImNhcnRfdG90YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJyZXR1cm5Ub3RhbE9mQ2FydFRheFZhbHVlIiwiY2FydF90b3RhbF90YXgiLCJ0b3RhbF90YXhfdmFsdWUiLCJudW0iLCJudW1iZXJBcnJheSIsInRvU3RyaW5nIiwic3BsaXQiLCJjdXJyZW5jeVZhbCIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJzdHlsZSIsImN1cnJlbmN5IiwiZm9ybWF0IiwibWF0aEZvcm11bGEiLCJmb3JtdWxhVGV4dCIsImZvcm11bGEiLCJkaXZDdXJyZW5jeSIsImZpcnN0VmFsIiwic2Vjb25kVmFsIiwiZGl2RGF0YSIsImRpdiIsIm11bEN1cnJlbmN5IiwibXVsRGF0YSIsIm11bCIsImFkZEN1cnJlbmN5IiwiY3VycmVuY3lWYWxGaXJzdCIsImN1cnJlbmN5VmFsU2Vjb25kIiwiYWRkRGF0YSIsImFkZCIsInN1YkN1cnJlbmN5Iiwic3ViRGF0YSIsInN1YiIsImZvcm1hdEN1cnJlbmN5IiwicGFyc2VGbG9hdCIsImdldENvbGxldGlvbkJ5U2x1ZyIsImNvbGxlY3Rpb25zIiwic2x1ZyIsImZpbmQiLCJiYW5uZXJzIiwiYmFubmVyIiwiY29udmVydFNsdWdzUXVlcnlTdHJpbmciLCJTdHJhcGlQcm9kdWN0QmFkZ2UiLCJ2aWV3IiwiYmFkZ2UiLCJTdHJhcGlQcm9kdWN0UHJpY2UiLCJpc19zYWxlIiwiU3RyYXBpUHJvZHVjdFByaWNlX05ldyIsImZlYXR1cmVwcm9kdWN0cHJpY2UiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZCIsIlN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZE90aGVyMSIsIlN0cmFwaVByb2R1Y3RUaHVtYm5haWwiLCJ1cmwiLCJTdHJhcGlQcm9kdWN0VGh1bWJuYWlsT3RoZXIiLCJTdHJhcGlQcm9kdWN0VGh1bWJuYWlsRGV0YWlsIiwiU2hvY2tpbmdwcm9kdWN0dGh1bWJuYWlsIiwiY29sb3JIZWxwZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBS0E7QUFRQTtBQUNBO0FBQ0E7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNQSwyQkFBMkIsZ0JBQUdDLDRDQUFLLENBQUNDLElBQU4sU0FDbEMsQ0FBQztBQUFFQyxTQUFGO0FBQVdDLFVBQVEsR0FBRyxLQUF0QjtBQUE2QkMsY0FBWSxHQUFHO0FBQTVDLENBQUQsS0FBeUQ7QUFBQTs7QUFDdkQsUUFBTUMsUUFBUSxHQUFHQywrREFBVyxFQUE1QjtBQUNBLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQkMsc0RBQVEsQ0FBQyxDQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLGtCQUFEO0FBQUEsT0FBcUJDO0FBQXJCLE1BQThDRixzREFBUSxDQUFDLEVBQUQsQ0FBNUQ7QUFDQSxRQUFNRyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCTixzREFBUSxDQUFDLEtBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ08sUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJSLHNEQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDUyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQlYsc0RBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTVcsSUFBSSxHQUFHQywrREFBVyxDQUFFQyxLQUFELElBQVdBLEtBQUssQ0FBQ0YsSUFBbEIsQ0FBeEI7O0FBRUEsUUFBTUcsbUJBQW1CLEdBQUcsTUFBT0MsQ0FBUCxJQUFhO0FBQUE7O0FBQ3ZDQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsUUFBSUMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdMLFFBQVgsQ0FBaEI7QUFDQSxRQUFJTSxLQUFLLEdBQUdILFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUF2QjtBQUNBVCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWixFQUFrQ0MsUUFBbEM7QUFDQUYsV0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBbUNJLFNBQW5DO0FBQ0FMLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQStCTyxLQUEvQjs7QUFDQSxRQUFJTixRQUFRLEtBQUtRLFNBQWIsSUFBMEJSLFFBQVEsS0FBSyxJQUEzQyxFQUFpRDtBQUMvQ0YsYUFBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVo7QUFDQVUsd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVJELE1BUU8sSUFDTCxDQUFBckMsT0FBTyxTQUFQLElBQUFBLE9BQU8sV0FBUCxnQ0FBQUEsT0FBTyxDQUFFQSxPQUFULHNFQUFrQnNDLFlBQWxCLEtBQWtDLFFBQWxDLEtBQ0NDLGVBQWUsQ0FBQ0MsV0FBaEIsSUFBK0IsRUFBL0IsSUFDQ0QsZUFBZSxDQUFDRSxlQUFoQixJQUFtQyxFQUZyQyxDQURLLEVBSUw7QUFDQWxCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FVLHdEQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCQyxlQUFPLEVBQUUsT0FEVztBQUVwQkMsbUJBQVcsRUFBRSx1QkFGTztBQUdwQkMsZ0JBQVEsRUFBRTtBQUhVLE9BQXRCO0FBS0EsYUFBTyxLQUFQO0FBQ0QsS0FaTSxNQVlBO0FBQUE7O0FBQ0xkLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FYLGlCQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0EsVUFBSTZCLE9BQU8sR0FBRztBQUNaO0FBQ0FDLHFCQUFhLEVBQUMsRUFGRjtBQUdadEMsZ0JBQVEsRUFBRUEsUUFIRTtBQUladUMsaUJBQVMsRUFBRSxLQUpDO0FBS1paLG9CQUFZLEVBQUVEO0FBTEYsT0FBZDtBQU9BUixhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWjs7QUFDQSxVQUFJLENBQUF4QixPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLGlDQUFBQSxPQUFPLENBQUVBLE9BQVQsd0VBQWtCc0MsWUFBbEIsS0FBa0MsUUFBdEMsRUFBZ0Q7QUFHOUNJLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEcsb0JBQVUsRUFBRUMsWUFBWSxDQUFDUCxlQUFlLENBQUNFLGVBQWpCO0FBRm5CLFVBQVA7QUFJQSxjQUFNO0FBQUVNLDhCQUFGO0FBQXdCQztBQUF4QixZQUFrQ0MsNEJBQTRCLENBQ2xFVixlQUFlLENBQUNFLGVBRGtELENBQXBFOztBQUlBLFlBQUlNLG9CQUFvQixLQUFLLEtBQXpCLElBQWtDQyxLQUFLLElBQUksQ0FBL0MsRUFBa0Q7QUFDaER6QixpQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDQVUsNERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLG1CQUFPLEVBQUUsT0FEVztBQUVwQkMsdUJBQVcsRUFBRSx1QkFGTztBQUdwQkMsb0JBQVEsRUFBRTtBQUhVLFdBQXRCO0FBS0F4QixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBLGlCQUFPLEtBQVA7QUFDRCxTQXBCNkMsQ0FxQjlDOztBQUNELE9BdEJELE1Bc0JPO0FBQ0xVLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FrQixlQUFPLG1DQUNGQSxPQURFO0FBRUxHLG9CQUFVLEVBQUU3QyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QztBQUZ2QixVQUFQOztBQUlBLFlBQ0U3QyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0IrQyxvQkFBaEIsS0FBeUMsS0FBekMsSUFDQS9DLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmdELEtBQWhCLElBQXlCLENBRjNCLEVBR0U7QUFDQXpCLGlCQUFPLENBQUNDLEdBQVIsQ0FBWSxvQkFBWjtBQUNBVSw0REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsbUJBQU8sRUFBRSxPQURXO0FBRXBCQyx1QkFBVyxFQUFFLHVCQUZPO0FBR3BCQyxvQkFBUSxFQUFFO0FBSFUsV0FBdEI7QUFLQXhCLHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBRUEsaUJBQU8sS0FBUDtBQUNEO0FBQ0Y7O0FBRUQsWUFBTXFDLFlBQVksR0FDaEIsYUFBQVIsT0FBTyxVQUFQLDRDQUFTVixZQUFULE1BRUMsTUFBTW1CLHdFQUFpQixDQUFDQyxnQkFBbEIsQ0FBbUNWLE9BQW5DLENBRlAsQ0FERjs7QUFLQSxVQUFJUSxZQUFZLElBQUlBLFlBQVksQ0FBQ0csUUFBYixJQUF5QixLQUE3QyxFQUFvRDtBQUNsRCxZQUFJQyxHQUFHLEdBQUd0RCxPQUFWO0FBQ0FzRCxXQUFHLENBQUNqRCxRQUFKLEdBQWVBLFFBQWYsQ0FGa0QsQ0FHbEQ7O0FBQ0FGLGdCQUFRLENBQUNvRCxrRUFBTyxFQUFSLENBQVI7QUFFQTFDLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0FxQiwwREFBWSxDQUFDZ0IsWUFBWSxDQUFDTSxNQUFkLENBQVosQ0FBa0M7QUFDaENyQixpQkFBTyxFQUFFZSxZQUFZLENBQUNmLE9BRFU7QUFFaENDLHFCQUFXLEVBQUVjLFlBQVksQ0FBQ08sUUFGTTtBQUdoQ3BCLGtCQUFRLEVBQUU7QUFIc0IsU0FBbEM7QUFLQXFCLGtCQUFVLENBQUMsWUFBWTtBQUNyQmhELGdCQUFNLENBQUNpRCxJQUFQLENBQVksd0JBQVo7QUFDRCxTQUZTLEVBRVAsR0FGTyxDQUFWO0FBR0QsT0FmRCxNQWVPO0FBQ0x6QiwwREFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsaUJBQU8sRUFBRSxPQURXO0FBRXBCQyxxQkFBVyxFQUFFYyxZQUFZLENBQUNmLE9BRk47QUFHcEJFLGtCQUFRLEVBQUU7QUFIVSxTQUF0QjtBQUtBeEIsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGO0FBQ0YsR0FoSEQ7O0FBa0hBLFFBQU0rQyxZQUFZLEdBQUcsTUFBT3RDLENBQVAsSUFBYTtBQUNoQyxRQUFJSixJQUFJLENBQUMyQyxVQUFMLEtBQW9CLElBQXhCLEVBQThCO0FBQzVCM0Isd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVBELE1BT08sSUFDTHJDLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQnNDLFlBQWhCLElBQWdDLFFBQWhDLEtBQ0NDLGVBQWUsQ0FBQ0MsV0FBaEIsSUFBK0IsRUFBL0IsSUFDQ0QsZUFBZSxDQUFDRSxlQUFoQixJQUFtQyxFQUZyQyxDQURLLEVBSUw7QUFDQVAsd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLHVCQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVhNLE1BV0E7QUFDTHRCLGlCQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0EsVUFBSTJCLE9BQU8sR0FBRztBQUNaO0FBQ0FDLHFCQUFhLEVBQUMsRUFGRjtBQUdadEMsZ0JBQVEsRUFBRUEsUUFIRTtBQUlaMkIsb0JBQVksRUFBRWQsSUFBSSxDQUFDYyxZQUpQO0FBS1pZLGlCQUFTLEVBQUU7QUFMQyxPQUFkOztBQVFBLFVBQUk1QyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JzQyxZQUFoQixJQUFnQyxRQUFwQyxFQUE4QztBQUM1Q0ksZUFBTyxtQ0FDRkEsT0FERTtBQUVMRyxvQkFBVSxFQUFFQyxZQUFZLENBQUNQLGVBQWUsQ0FBQ0UsZUFBakI7QUFGbkIsVUFBUDtBQUtBLGNBQU07QUFBRU0sOEJBQUY7QUFBd0JDO0FBQXhCLFlBQWtDQyw0QkFBNEIsQ0FDbEVWLGVBQWUsQ0FBQ0UsZUFEa0QsQ0FBcEU7O0FBSUEsWUFBSU0sb0JBQW9CLEtBQUssS0FBekIsSUFBa0NDLEtBQUssSUFBSSxDQUEvQyxFQUFrRDtBQUNoRGQsNERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLG1CQUFPLEVBQUUsT0FEVztBQUVwQkMsdUJBQVcsRUFBRSx1QkFGTztBQUdwQkMsb0JBQVEsRUFBRTtBQUhVLFdBQXRCO0FBS0F0QixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGLE9BcEJELE1Bb0JPO0FBQ0wyQixlQUFPLG1DQUNGQSxPQURFO0FBRUxHLG9CQUFVLEVBQUU3QyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QztBQUZ2QixVQUFQOztBQUlBLFlBQ0U3QyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0IrQyxvQkFBaEIsS0FBeUMsS0FBekMsSUFDQS9DLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmdELEtBQWhCLElBQXlCLENBRjNCLEVBR0U7QUFDQWQsNERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLG1CQUFPLEVBQUUsT0FEVztBQUVwQkMsdUJBQVcsRUFBRSx1QkFGTztBQUdwQkMsb0JBQVEsRUFBRTtBQUhVLFdBQXRCO0FBS0F0QixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGOztBQUNELFlBQU1tQyxZQUFZLEdBQUcsTUFBTUMsd0VBQWlCLENBQUNDLGdCQUFsQixDQUFtQ1YsT0FBbkMsQ0FBM0I7O0FBRUEsVUFBSVEsWUFBWSxDQUFDRyxRQUFiLElBQXlCLEdBQTdCLEVBQWtDO0FBQ2hDLFlBQUlDLEdBQUcsR0FBR3RELE9BQVY7QUFDQXNELFdBQUcsQ0FBQ2pELFFBQUosR0FBZUEsUUFBZjtBQUNBNkIsMERBQVksQ0FBQ2dCLFlBQVksQ0FBQ00sTUFBZCxDQUFaLENBQWtDO0FBQ2hDcEIscUJBQVcsRUFBRWMsWUFBWSxDQUFDTyxRQURNO0FBRWhDcEIsa0JBQVEsRUFBRTtBQUZzQixTQUFsQyxFQUhnQyxDQU9oQzs7QUFDQXFCLGtCQUFVLENBQUMsWUFBWTtBQUNyQmhELGdCQUFNLENBQUNpRCxJQUFQLENBQVksbUJBQVo7QUFDRCxTQUZTLEVBRVAsSUFGTyxDQUFWO0FBR0E1QyxtQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNELE9BWkQsTUFZTztBQUNMbUIsMERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGlCQUFPLEVBQUUsT0FEVztBQUVwQkMscUJBQVcsRUFBRWMsWUFBWSxDQUFDZixPQUZOO0FBR3BCRSxrQkFBUSxFQUFFO0FBSFUsU0FBdEI7QUFLQXRCLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0Q7QUFDRjtBQUNGLEdBM0ZEOztBQTZGQSxRQUFNK0Msc0JBQXNCLEdBQUl4QyxDQUFELElBQU87QUFDcENuQixZQUFRLENBQUM0RCw4RUFBZ0IsQ0FBQy9ELE9BQUQsQ0FBakIsQ0FBUjtBQUNELEdBRkQ7O0FBSUEsUUFBTWdFLHVCQUF1QixHQUFHLE1BQU8xQyxDQUFQLElBQWE7QUFFM0MsUUFBSUcsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdMLFFBQVgsQ0FBaEI7QUFDQSxRQUFJTSxLQUFLLEdBQUdILFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUF2Qjs7QUFDQSxRQUFJUCxRQUFRLEtBQUtRLFNBQWIsSUFBMEJSLFFBQVEsS0FBSyxJQUEzQyxFQUFpRDtBQUMvQ1Msd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVBELE1BT087QUFDTCxVQUFJbkMsWUFBWSxJQUFJLElBQXBCLEVBQTBCO0FBQ3hCQyxnQkFBUSxDQUFDOEQsNEZBQTZCLENBQUNqRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QyxVQUFqQixDQUE5QixDQUFSO0FBQ0QsT0FGRCxNQUVPO0FBQ0x0QixlQUFPLENBQUNDLEdBQVIsQ0FBWSx1QkFBWixFQUFvQ3hCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQjZDLFVBQXBEO0FBQ0ExQyxnQkFBUSxDQUFDK0QsZ0ZBQWlCLENBQUNsRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QyxVQUFqQixDQUFsQixDQUFSO0FBQ0Q7QUFDRjtBQUNGLEdBcEJEOztBQXNCQSxRQUFNc0Isd0JBQXdCLEdBQUcsTUFBTTtBQUNyQyxRQUFJMUMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdMLFFBQVgsQ0FBaEI7QUFDQSxRQUFJTSxLQUFLLEdBQUdILFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUF2Qjs7QUFDQSxRQUFJUCxRQUFRLEtBQUtRLFNBQWIsSUFBMEJSLFFBQVEsS0FBSyxJQUEzQyxFQUFpRDtBQUMvQ1Msd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVBELE1BT087QUFDTCxVQUFJbkMsWUFBWSxJQUFJLElBQXBCLEVBQTBCO0FBQ3hCQyxnQkFBUSxDQUNOaUUsaUdBQWtDLENBQUNwRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QyxVQUFqQixDQUQ1QixDQUFSO0FBR0QsT0FKRCxNQUlPO0FBQ0wxQyxnQkFBUSxDQUFDa0UsaUZBQWtCLENBQUNyRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0I2QyxVQUFqQixDQUFuQixDQUFSO0FBQ0Q7QUFDRjtBQUNGLEdBcEJEOztBQXNCQSxRQUFNeUIscUJBQXFCLEdBQUloRCxDQUFELElBQU87QUFDbkNoQixlQUFXLENBQUNELFFBQVEsR0FBRyxDQUFaLENBQVg7QUFDQUYsWUFBUSxDQUFDb0Usc0ZBQXdCLENBQUNsRSxRQUFRLEdBQUcsQ0FBWixDQUF6QixDQUFSO0FBQ0QsR0FIRDs7QUFLQSxRQUFNbUUscUJBQXFCLEdBQUlsRCxDQUFELElBQU87QUFDbkMsUUFBSWpCLFFBQVEsR0FBRyxDQUFmLEVBQWtCO0FBQ2hCQyxpQkFBVyxDQUFDRCxRQUFRLEdBQUcsQ0FBWixDQUFYO0FBQ0FGLGNBQVEsQ0FBQ29FLHNGQUF3QixDQUFDbEUsUUFBUSxHQUFHLENBQVosQ0FBekIsQ0FBUjtBQUNEO0FBQ0YsR0FMRDs7QUFPQSxRQUFNO0FBQUEsT0FBQ29FLGVBQUQ7QUFBQSxPQUFrQkM7QUFBbEIsTUFBd0NuRSxzREFBUSxDQUFDLEVBQUQsQ0FBdEQ7QUFDQSxRQUFNO0FBQUEsT0FBQ29FLHFCQUFEO0FBQUEsT0FBd0JDO0FBQXhCLE1BQW9EckUsc0RBQVEsQ0FBQyxFQUFELENBQWxFO0FBRUEsUUFBTTtBQUFBLE9BQUNnQyxlQUFEO0FBQUEsT0FBa0JzQztBQUFsQixNQUF3Q3RFLHNEQUFRLENBQUM7QUFDckR1RSxZQUFRLEVBQUUsRUFEMkM7QUFFckR0QyxlQUFXLEVBQUUsRUFGd0M7QUFHckR1QyxnQkFBWSxFQUFFLEVBSHVDO0FBSXJEdEMsbUJBQWUsRUFBRSxFQUpvQztBQUtyRHVDLGVBQVcsRUFBRTtBQUx3QyxHQUFELENBQXREO0FBUUFDLHlEQUFTLENBQUMsTUFBTTtBQUFBOztBQUNkUCxzQkFBa0IsQ0FBQzFFLE9BQUQsYUFBQ0EsT0FBRCx1QkFBQ0EsT0FBTyxDQUFFa0Ysb0JBQVYsQ0FBbEI7QUFDQSxRQUFJQyxTQUFTLEdBQUcsQ0FDZCxHQUFHLElBQUlDLEdBQUosQ0FDRHBGLE9BREMsYUFDREEsT0FEQyxnREFDREEsT0FBTyxDQUFFa0Ysb0JBRFIsMERBQ0Qsc0JBQStCRyxHQUEvQixDQUFvQ0MsSUFBRCxJQUFVLENBQzNDQSxJQUFJLENBQUMsWUFBRCxDQUR1QyxFQUUzQ0EsSUFGMkMsQ0FBN0MsQ0FEQyxFQUtEQyxNQUxDLEVBRFcsQ0FBaEI7QUFRQVgsNEJBQXdCLENBQUNPLFNBQUQsQ0FBeEI7QUFDRCxHQVhRLEVBV04sQ0FBQ25GLE9BQUQsQ0FYTSxDQUFUOztBQWFBLFFBQU13RixnQkFBZ0IsR0FBSWxFLENBQUQsSUFBTztBQUM5QnVELHNCQUFrQixpQ0FBTXRDLGVBQU47QUFBdUJDLGlCQUFXLEVBQUVsQixDQUFDLENBQUNtRSxNQUFGLENBQVNDO0FBQTdDLE9BQWxCO0FBQ0FoQyxjQUFVLENBQUMsTUFBTTtBQUNmWixrQkFBWSxDQUFDUCxlQUFlLENBQUNFLGVBQWpCLENBQVo7QUFDRCxLQUZTLEVBRVAsSUFGTyxDQUFWO0FBR0QsR0FMRDs7QUFPQSxRQUFNa0Qsb0JBQW9CLEdBQUlyRSxDQUFELElBQU87QUFDbEN1RCxzQkFBa0IsaUNBQ2J0QyxlQURhO0FBRWhCRSxxQkFBZSxFQUFFbkIsQ0FBQyxDQUFDbUUsTUFBRixDQUFTQztBQUZWLE9BQWxCO0FBSUFoQyxjQUFVLENBQUMsTUFBTTtBQUNmWixrQkFBWSxDQUFDeEIsQ0FBQyxDQUFDbUUsTUFBRixDQUFTQyxLQUFWLENBQVo7QUFDRCxLQUZTLEVBRVAsSUFGTyxDQUFWO0FBR0QsR0FSRDs7QUFVQSxRQUFNRSx3QkFBd0IsR0FBRyxNQUFNO0FBQUE7O0FBQ3JDLHdCQUNFO0FBQUssZUFBUyxFQUFDLHNCQUFmO0FBQUEsNkJBQ0U7QUFBTyxpQkFBUyxFQUFDLHdCQUFqQjtBQUFBLCtCQUNFO0FBQUEsa0NBQ0U7QUFBQSxvQ0FDRTtBQUNFLG1CQUFLLEVBQUU7QUFDTEMsMEJBQVUsRUFBRSxHQURQO0FBRUxDLHdCQUFRLEVBQUUsT0FGTDtBQUdMQyxxQkFBSyxFQUFFO0FBSEYsZUFEVDtBQUFBLDZDQU9HdEIsZUFBZSxDQUFDLENBQUQsQ0FQbEIsc0RBT0csa0JBQW9CdUI7QUFQdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQVVFO0FBQUEscUNBQ0UscUVBQUMsMkNBQUQsQ0FBTyxLQUFQO0FBQ0Usb0JBQUksRUFBQyxPQURQO0FBRUUseUJBQVMsRUFBQyxNQUZaO0FBR0Usd0JBQVEsRUFBRVIsZ0JBSFo7QUFJRSw0QkFBWSxFQUFFakQsZUFBRixhQUFFQSxlQUFGLHVCQUFFQSxlQUFlLENBQUV1QyxRQUpqQztBQUFBLDBCQU1HSCxxQkFOSCxhQU1HQSxxQkFOSCx1QkFNR0EscUJBQXFCLENBQUVVLEdBQXZCLENBQTJCLENBQUNZLElBQUQsRUFBT0MsS0FBUCxLQUFpQjtBQUMzQyxzQ0FDRSxxRUFBQywyQ0FBRCxDQUFPLE1BQVA7QUFDRSx5QkFBSyxFQUFFRCxJQUFJLENBQUNFLFVBRGQ7QUFHRSw2QkFBUyxFQUFDLE1BSFo7QUFBQSwyQ0FLRSxxRUFBQyw0Q0FBRDtBQUFRLHlCQUFHLEVBQUVGLElBQUksQ0FBQ0c7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGLHFCQUVPRixLQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREY7QUFTRCxpQkFWQTtBQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQWdDRTtBQUFBLG1DQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWhDRixFQW1DRzNELGVBQWUsQ0FBQ0MsV0FBaEIsZ0JBQ0M7QUFBQSxvQ0FDRTtBQUNFLG1CQUFLLEVBQUU7QUFDTHFELDBCQUFVLEVBQUUsR0FEUDtBQUVMQyx3QkFBUSxFQUFFLE9BRkw7QUFHTEMscUJBQUssRUFBRTtBQUhGLGVBRFQ7QUFBQSw4Q0FPR3RCLGVBQWUsQ0FBQyxDQUFELENBUGxCLGdGQU9HLG1CQUFvQjRCLGNBQXBCLENBQW1DLENBQW5DLENBUEgsMERBT0csc0JBQXVDTDtBQVAxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBVUU7QUFBQSxxQ0FDRSxxRUFBQywyQ0FBRCxDQUFPLEtBQVA7QUFDRSxvQkFBSSxFQUFDLE9BRFA7QUFFRSx5QkFBUyxFQUFDLE1BRlo7QUFHRSx3QkFBUSxFQUFFTCxvQkFIWjtBQUFBLDBCQUtHbEIsZUFMSCxhQUtHQSxlQUxILGdEQUtHQSxlQUFlLENBQ1o2QixNQURILENBRUlDLElBQUQsSUFDRUEsSUFBSSxDQUFDSixVQUFMLENBQWdCSyxXQUFoQixPQUNBakUsZUFBZSxDQUFDQyxXQUFoQixDQUE0QmdFLFdBQTVCLEVBSkwsQ0FMSCxvRkFLRyxzQkFNR25CLEdBTkgsQ0FNUVksSUFBRCxJQUFVQSxJQUFJLENBQUNJLGNBQUwsQ0FBb0IsQ0FBcEIsQ0FOakIsQ0FMSCwyREFLRyx1QkFPR2hCLEdBUEgsQ0FPTyxDQUFDRSxNQUFELEVBQVNXLEtBQVQsS0FBbUI7QUFDdkIsc0NBQ0UscUVBQUMsMkNBQUQsQ0FBTyxNQUFQO0FBQWMseUJBQUssRUFBRVgsTUFBTSxDQUFDWSxVQUE1QjtBQUFBLDhCQUNHWixNQUFNLENBQUNZO0FBRFYscUJBQTZDRCxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGO0FBS0QsaUJBYkY7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREQsR0FrQ0csSUFyRU4sRUF1RUczRCxlQUFlLENBQUNFLGVBQWhCLGdCQUNDO0FBQUkscUJBQVMsRUFBRWdFLFdBQVcsT0FBT3hFLFNBQWxCLEdBQStCLEVBQS9CLEdBQW9DLFFBQW5EO0FBQUEsb0NBQ0U7QUFDRSxtQkFBSyxFQUFFO0FBQ0w0RCwwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRSxPQUZMO0FBR0xDLHFCQUFLLEVBQUU7QUFIRixlQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBVUU7QUFDRSxtQkFBSyxFQUFFO0FBQ0xGLDBCQUFVLEVBQUUsR0FEUDtBQUVMQyx3QkFBUSxFQUFFO0FBRkwsZUFEVDtBQUFBLHFDQU1FO0FBQU0seUJBQVMsRUFBQyxNQUFoQjtBQUFBLDBCQUNHWSxpR0FBOEIsQ0FBQ0QsV0FBVyxFQUFaO0FBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERCxHQXNCRyxJQTdGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQXFHRCxHQXRHRDs7QUF3R0EsUUFBTUEsV0FBVyxHQUFHLE1BQU07QUFBQTs7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLFVBQU1FLEtBQUssR0FBR2xDLGVBQUgsYUFBR0EsZUFBSCxpREFBR0EsZUFBZSxDQUN6QjZCLE1BRFUsQ0FDRkMsSUFBRCxJQUFVQSxJQUFJLENBQUNKLFVBQUwsSUFBbUI1RCxlQUFlLENBQUNDLFdBRDFDLENBQUgscUZBQUcsdUJBRVY2QyxHQUZVLENBRUxZLElBQUQsSUFBVUEsSUFBSSxDQUFDSSxjQUFMLENBQW9CLENBQXBCLENBRkosQ0FBSCxxRkFBRyx1QkFHVkMsTUFIVSxDQUlUTCxJQUFELElBQVVBLElBQUksQ0FBQ0UsVUFBTCxJQUFtQjVELGVBQWUsQ0FBQ0UsZUFKbkMsRUFLVixDQUxVLENBQUgsMkRBQUcsdUJBS05tRSxZQUxSO0FBT0EsVUFBTUMsZUFBZSxHQUFHcEMsZUFBSCxhQUFHQSxlQUFILGlEQUFHQSxlQUFlLENBQ25DNkIsTUFEb0IsQ0FDWkMsSUFBRCxJQUFVQSxJQUFJLENBQUNKLFVBQUwsSUFBbUI1RCxlQUFlLENBQUNDLFdBRGhDLENBQUgscUZBQUcsdUJBRXBCNkMsR0FGb0IsQ0FFZlksSUFBRCxJQUFVQSxJQUFJLENBQUNJLGNBQUwsQ0FBb0IsQ0FBcEIsQ0FGTSxDQUFILHFGQUFHLHVCQUdwQkMsTUFIb0IsQ0FJbkJMLElBQUQsSUFBVUEsSUFBSSxDQUFDRSxVQUFMLElBQW1CNUQsZUFBZSxDQUFDRSxlQUp6QixFQUtwQixDQUxvQixDQUFILDJEQUFHLHVCQUtoQnFFLFVBTFI7O0FBT0EsUUFBSUQsZUFBZSxLQUFLLEtBQXhCLEVBQStCO0FBQzdCLGFBQU9BLGVBQVA7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPRixLQUFQO0FBQ0Q7QUFDRixHQTFCRDs7QUE0QkEsUUFBTTFELDRCQUE0QixHQUFJOEQsU0FBRCxJQUFlO0FBQUE7O0FBQ2xELFVBQU1oRSxvQkFBb0IsR0FBRzBCLGVBQUgsYUFBR0EsZUFBSCxpREFBR0EsZUFBZSxDQUN4QzZCLE1BRHlCLENBQ2pCQyxJQUFELElBQVVBLElBQUksQ0FBQ0osVUFBTCxJQUFtQjVELGVBQWUsQ0FBQ0MsV0FEM0IsQ0FBSCxzRkFBRyx1QkFFekI2QyxHQUZ5QixDQUVwQlksSUFBRCxJQUFVQSxJQUFJLENBQUNJLGNBQUwsQ0FBb0IsQ0FBcEIsQ0FGVyxDQUFILHVGQUFHLHdCQUd6QkMsTUFIeUIsQ0FJeEJMLElBQUQsSUFBVUEsSUFBSSxDQUFDRSxVQUFMLElBQW1CWSxTQUpKLEVBS3pCLENBTHlCLENBQUgsNERBQUcsd0JBS3JCaEUsb0JBTFI7QUFPQSxVQUFNQyxLQUFLLEdBQUd5QixlQUFILGFBQUdBLGVBQUgsa0RBQUdBLGVBQWUsQ0FDekI2QixNQURVLENBQ0ZDLElBQUQsSUFBVUEsSUFBSSxDQUFDSixVQUFMLElBQW1CNUQsZUFBZSxDQUFDQyxXQUQxQyxDQUFILHVGQUFHLHdCQUVWNkMsR0FGVSxDQUVMWSxJQUFELElBQVVBLElBQUksQ0FBQ0ksY0FBTCxDQUFvQixDQUFwQixDQUZKLENBQUgsdUZBQUcsd0JBR1ZDLE1BSFUsQ0FHRkwsSUFBRCxJQUFVQSxJQUFJLENBQUNFLFVBQUwsSUFBbUJZLFNBSDFCLEVBR3FDLENBSHJDLENBQUgsNERBQUcsd0JBR3lDL0QsS0FIdkQ7QUFLQSxXQUFPO0FBQUVBLFdBQUY7QUFBU0Q7QUFBVCxLQUFQO0FBQ0QsR0FkRDs7QUFnQkEsUUFBTUQsWUFBWSxHQUFJaUUsU0FBRCxJQUFlO0FBQUE7O0FBQ2xDLFVBQU1DLGlCQUFpQixHQUFHdkMsZUFBSCxhQUFHQSxlQUFILGtEQUFHQSxlQUFlLENBQ3JDNkIsTUFEc0IsQ0FDZEMsSUFBRCxJQUFVQSxJQUFJLENBQUNKLFVBQUwsSUFBbUI1RCxlQUFlLENBQUNDLFdBRDlCLENBQUgsdUZBQUcsd0JBRXRCNkMsR0FGc0IsQ0FFakJZLElBQUQsSUFBVUEsSUFBSSxDQUFDSSxjQUFMLENBQW9CLENBQXBCLENBRlEsQ0FBSCx1RkFBRyx3QkFHdEJDLE1BSHNCLENBR2RMLElBQUQsSUFBVUEsSUFBSSxDQUFDRSxVQUFMLElBQW1CWSxTQUhkLEVBR3lCLENBSHpCLENBQUgsNERBQUcsd0JBRzZCbEUsVUFIdkQ7QUFJQSxVQUFNO0FBQUVHLFdBQUY7QUFBU0Q7QUFBVCxRQUNKRSw0QkFBNEIsQ0FBQzhELFNBQUQsQ0FEOUI7QUFHQTVHLFlBQVEsQ0FBQzhHLGdGQUFrQixDQUFDRCxpQkFBRCxDQUFuQixDQUFSO0FBQ0E3RyxZQUFRLENBQUMrRyxtRkFBcUIsQ0FBQ2xFLEtBQUQsQ0FBdEIsQ0FBUjtBQUNBN0MsWUFBUSxDQUFDZ0gsK0ZBQWlDLENBQUNwRSxvQkFBRCxDQUFsQyxDQUFSO0FBRUEsV0FBT2lFLGlCQUFQO0FBQ0QsR0FiRDs7QUFlQSxNQUFJLENBQUMvRyxRQUFELElBQWFELE9BQU8sQ0FBQ0EsT0FBekIsRUFBa0M7QUFBQTs7QUFDaEMsd0JBQ0U7QUFBQSxpQkFDRyxDQUFBQSxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLGlDQUFBQSxPQUFPLENBQUVBLE9BQVQsd0VBQWtCc0MsWUFBbEIsS0FBa0MsUUFBbEMsR0FDR3NELHdCQUF3QixFQUQzQixHQUVHLElBSE4sZUFLRTtBQUFLLGlCQUFTLEVBQUMsc0JBQWY7QUFBQSxnQ0FDRTtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBSyxxQkFBUyxFQUFDLG9CQUFmO0FBQUEsb0NBQ0U7QUFDRSx1QkFBUyxFQUFDLElBRFo7QUFFRSxxQkFBTyxFQUFHdEUsQ0FBRCxJQUFPZ0QscUJBQXFCLENBQUNoRCxDQUFELENBRnZDO0FBQUEscUNBSUU7QUFBRyx5QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFPRTtBQUNFLHVCQUFTLEVBQUMsTUFEWjtBQUVFLHFCQUFPLEVBQUdBLENBQUQsSUFBT2tELHFCQUFxQixDQUFDbEQsQ0FBRCxDQUZ2QztBQUFBLHFDQUlFO0FBQUcseUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGLGVBYUU7QUFDRSx1QkFBUyxFQUFDLGNBRFo7QUFFRSxrQkFBSSxFQUFDLE1BRlA7QUFHRSx5QkFBVyxFQUFFakIsUUFIZjtBQUlFLHNCQUFRO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBd0JFO0FBQ0UsbUJBQVMsRUFBQyx1QkFEWjtBQUVFLGlCQUFPLEVBQUdpQixDQUFELElBQU9ELG1CQUFtQixDQUFDQyxDQUFELENBRnJDO0FBQUEsb0JBSUdWLFFBQVEsZ0JBQUcscUVBQUMsbUVBQUQ7QUFBa0IsZ0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFILEdBQW9DO0FBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeEJGLGVBOEJFO0FBQUcsbUJBQVMsRUFBQyxvQkFBYjtBQUFrQyxpQkFBTyxFQUFHVSxDQUFELElBQU9zQyxZQUFZLENBQUN0QyxDQUFELENBQTlEO0FBQUEsb0JBQ0dSLFFBQVEsZ0JBQUcscUVBQUMsbUVBQUQ7QUFBa0IsZ0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFILEdBQW9DO0FBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOUJGLGVBaUNFO0FBQUssbUJBQVMsRUFBQyxxQkFBZjtBQUFBLGlDQUNFO0FBQUEsdUJBQ0dFLFFBQVEsZ0JBQ1AscUVBQUMsbUVBQUQ7QUFBa0Isa0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURPLEdBR1BoQixPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvSCxXQUFoQixJQUErQixDQUEvQixpQkFDRSxxRUFBQyxpRUFBRDtBQUNFLG1CQUFLLEVBQUUsU0FEVDtBQUVFLHNCQUFRLEVBQUMsT0FGWDtBQUdFLHFCQUFPLEVBQUc5RixDQUFELElBQU8wQyx1QkFBdUIsQ0FBQzFDLENBQUQsQ0FIekM7QUFJRSxtQkFBSyxFQUFFO0FBQUUrRixzQkFBTSxFQUFFO0FBQVY7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUxOLEVBYUdyRyxRQUFRLGdCQUNQLHFFQUFDLG1FQUFEO0FBQWtCLGtCQUFJLEVBQUU7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFETyxHQUdQaEIsT0FBTyxDQUFDQSxPQUFSLENBQWdCb0gsV0FBaEIsSUFBK0IsQ0FBL0IsaUJBQ0UscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyxFQUFFLFdBRFQ7QUFFRSxzQkFBUSxFQUFDLE9BRlg7QUFHRSxxQkFBTyxFQUFHOUYsQ0FBRCxJQUFPNkMsd0JBQXdCLENBQUM3QyxDQUFELENBSDFDO0FBSUUsbUJBQUssRUFBRTtBQUFFK0Ysc0JBQU0sRUFBRTtBQUFWO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFqQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUEsb0JBREY7QUE0RUQsR0E3RUQsTUE2RU87QUFDTCx3QkFDRTtBQUFLLGVBQVMsRUFBQyw2QkFBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyx1QkFBZjtBQUFBLGdDQUNFO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsb0JBQWY7QUFBQSxvQ0FDRTtBQUNFLHVCQUFTLEVBQUMsSUFEWjtBQUVFLHFCQUFPLEVBQUcvRixDQUFELElBQU9nRCxxQkFBcUIsQ0FBQ2hELENBQUQsQ0FGdkM7QUFBQSxxQ0FJRTtBQUFHLHlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU9FO0FBQ0UsdUJBQVMsRUFBQyxNQURaO0FBRUUscUJBQU8sRUFBR0EsQ0FBRCxJQUFPa0QscUJBQXFCLENBQUNsRCxDQUFELENBRnZDO0FBQUEscUNBSUU7QUFBRyx5QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEYsZUFhRTtBQUNFLHVCQUFTLEVBQUMsY0FEWjtBQUVFLGtCQUFJLEVBQUMsTUFGUDtBQUdFLHlCQUFXLEVBQUVqQixRQUhmO0FBSUUsc0JBQVE7QUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUF3QkU7QUFDRSxtQkFBUyxFQUFDLHNCQURaO0FBRUUsY0FBSSxFQUFDLEdBRlA7QUFHRSxpQkFBTyxFQUFHaUIsQ0FBRCxJQUFPRCxtQkFBbUIsQ0FBQ0MsQ0FBRCxDQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF4QkYsZUErQkU7QUFBSyxtQkFBUyxFQUFDLHFCQUFmO0FBQUEsaUNBQ0U7QUFBRyxnQkFBSSxFQUFDLEdBQVI7QUFBWSxtQkFBTyxFQUFHQSxDQUFELElBQU8wQyx1QkFBdUIsQ0FBQzFDLENBQUQsQ0FBbkQ7QUFBQSxtQ0FDRTtBQUFHLHVCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQXlDRTtBQUNFLGlCQUFTLEVBQUMsbUJBRFo7QUFFRSxZQUFJLEVBQUMsR0FGUDtBQUdFLGVBQU8sRUFBR0EsQ0FBRCxJQUFPc0MsWUFBWSxDQUFDdEMsQ0FBRCxDQUg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBbUREO0FBQ0YsQ0FwbUJpQztBQUFBLFVBRWZsQix1REFGZSxFQUtqQk8scURBTGlCLEVBU25CUSx1REFUbUI7QUFBQSxHQUFwQyxDLENBdW1CQTs7TUF2bUJNdEIsMkI7QUF3bUJTQSwwRkFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMW9CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXlILGNBQWMsR0FBRyxDQUFDO0FBQUV0SCxTQUFGO0FBQVd1SCxZQUFYO0FBQXVCQztBQUF2QixDQUFELEtBQTBDO0FBQUE7O0FBQy9ELHNCQUNFLHFFQUFDLHlDQUFEO0FBQU0sU0FBSyxFQUFFO0FBQUV6QixXQUFLLEVBQUV3QixVQUFVLElBQUksR0FBdkI7QUFBNEJFLFlBQU0sRUFBRUQsV0FBVyxJQUFJO0FBQW5ELEtBQWI7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQywrQkFBZjtBQUFBLDZCQUNFO0FBQVEsaUJBQVMsRUFBQyxvQkFBbEI7QUFBQSxnQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLHFFQUFDLDREQUFEO0FBQ0UsaUJBQU8sRUFBRXhILE9BQU8sQ0FBQzBILFFBRG5CO0FBRUUsa0JBQVEsRUFBRTtBQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVVFO0FBQUssZUFBUyxFQUFDLHVCQUFmO0FBQUEsNkJBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxZQUFJLEVBQUMsZ0JBQVg7QUFBNEIsVUFBRSxFQUFHLFlBQVcxSCxPQUFPLENBQUMySCxVQUFXLEVBQS9EO0FBQUEsK0JBQ0U7QUFBQSxpQ0FDRSxxRUFBQyxnRUFBRDtBQUFrQixxQkFBUyxFQUFFM0gsT0FBRixhQUFFQSxPQUFGLDBDQUFFQSxPQUFPLENBQUVvRyxLQUFULENBQWUsQ0FBZixDQUFGLG9EQUFFLGdCQUFtQkE7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFWRixlQWlCRTtBQUFLLGVBQVMsRUFBQywwQ0FBZjtBQUFBLDhCQUNFLHFFQUFDLGdEQUFEO0FBQU0sWUFBSSxFQUFDLGdCQUFYO0FBQTRCLFVBQUUsRUFBRyxZQUFXcEcsT0FBTyxDQUFDMkgsVUFBVyxFQUEvRDtBQUFBLCtCQUNFO0FBQUcsbUJBQVMsRUFBQyxvQkFBYjtBQUFrQyxlQUFLLEVBQUU7QUFBRTlCLHNCQUFVLEVBQUU7QUFBZCxXQUF6QztBQUFBLG9CQUNHN0YsT0FBTyxDQUFDNEgsTUFBUixHQUFpQjVILE9BQU8sQ0FBQzRILE1BQXpCLEdBQWtDO0FBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORixFQU9HNUgsT0FBTyxDQUFDOEcsVUFBUixLQUF1QixLQUF2QixnQkFDQztBQUNFLGlCQUFTLEVBQUMsbUJBRFo7QUFFRSxhQUFLLEVBQUU7QUFBRWpCLG9CQUFVLEVBQUUsTUFBZDtBQUFzQkMsa0JBQVEsRUFBRTtBQUFoQyxTQUZUO0FBQUEsMEJBSU05RixPQUFPLENBQUM4RyxVQUpkLGVBS0U7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSw0QkFBMEI5RyxPQUFPLENBQUMyRyxLQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURELGdCQVNDO0FBQ0UsaUJBQVMsRUFBQyxtQkFEWjtBQUVFLGFBQUssRUFBRTtBQUFFZCxvQkFBVSxFQUFFLE1BQWQ7QUFBc0JDLGtCQUFRLEVBQUU7QUFBaEMsU0FGVDtBQUFBLDBCQUlNOUYsT0FBTyxDQUFDMkcsS0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEJKLGVBdUJFO0FBQUssaUJBQVMsRUFBQyxxQkFBZjtBQUFBLCtCQUNFLHFFQUFDLGdEQUFEO0FBQU0sY0FBSSxFQUFDLGdCQUFYO0FBQTRCLFlBQUUsRUFBRyxZQUFXM0csT0FBTyxDQUFDMkgsVUFBVyxFQUEvRDtBQUFBLGlDQUNFO0FBQ0UscUJBQVMsRUFBQyxnREFEWjtBQUVFLGlCQUFLLEVBQUU7QUFDTDdCLHNCQUFRLEVBQUUsT0FETDtBQUVMRCx3QkFBVSxFQUFFLEdBRlA7QUFHTGdDLHVCQUFTLEVBQUUsTUFITjtBQUlMQyxzQkFBUSxFQUFFO0FBSkwsYUFGVDtBQUFBLHNCQVNHOUgsT0FBTyxDQUFDK0g7QUFUWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkJGLGVBc0NFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsK0JBQ0U7QUFBQSxpREFFRTtBQUFNLHFCQUFTLEVBQUMsYUFBaEI7QUFBQSxzQkFBK0IvSCxPQUFPLENBQUNnSTtBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRiwyQkFLRTtBQUFNLHFCQUFTLEVBQUMsYUFBaEI7QUFBQSxzQkFDR3RCLGdHQUE4QixDQUFDMUcsT0FBTyxDQUFDaUksYUFBVDtBQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFzRUQsQ0F2RUQ7O0tBQU1YLGM7QUF5RVNBLDZFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNWSxtQkFBbUIsR0FBRyxDQUFDO0FBQUVsSTtBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFDM0Msc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyx5Q0FBRDtBQUFNLGNBQVEsRUFBRSxLQUFoQjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQywrQkFBZjtBQUFBLCtCQUNFO0FBQVEsbUJBQVMsRUFBQyxvQkFBbEI7QUFBQSxrQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFLHFFQUFDLG1CQUFEO0FBQ0UsbUJBQU8sRUFBRUEsT0FBTyxDQUFDMEgsUUFEbkI7QUFFRSxvQkFBUSxFQUFFO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBVUU7QUFBSyxpQkFBUyxFQUFDLHVCQUFmO0FBQUEsa0JBQ0cxSCxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLHVCQUFBQSxPQUFPLENBQUVvRyxLQUFULENBQWUsQ0FBZiw2REFBbUJBLEtBQW5CLGdCQUNDLHFFQUFDLGdEQUFEO0FBQU0sY0FBSSxFQUFDLGdCQUFYO0FBQTRCLFlBQUUsRUFBRyxZQUFXcEcsT0FBTyxDQUFDMkgsVUFBVyxFQUEvRDtBQUFBLGlDQUNFO0FBQUEsbUNBQ0UscUVBQUMscURBQUQ7QUFBQSxxQ0FDRSxxRUFBQyxnRUFBRDtBQUFrQix5QkFBUyxFQUFFM0gsT0FBRixhQUFFQSxPQUFGLDJDQUFFQSxPQUFPLENBQUVvRyxLQUFULENBQWUsQ0FBZixDQUFGLHFEQUFFLGlCQUFtQkE7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERCxnQkFTQyxxRUFBQyxnREFBRDtBQUFNLGNBQUksRUFBQyxnQkFBWDtBQUE0QixZQUFFLEVBQUcsWUFBV3BHLE9BQU8sQ0FBQzJILFVBQVcsRUFBL0Q7QUFBQSxpQ0FDRTtBQUFBLG1DQUNFLHFFQUFDLHFEQUFEO0FBQUEscUNBQ0U7QUFDRSxtQkFBRyxFQUFDLDJCQUROO0FBRUUsbUJBQUcsRUFBQyxTQUZOO0FBR0Usc0JBQU0sRUFBQztBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGLGVBaUNFO0FBQUssaUJBQVMsRUFBQywwQ0FBZjtBQUFBLGdDQUNFLHFFQUFDLGdEQUFEO0FBQU0sY0FBSSxFQUFDLGdCQUFYO0FBQTRCLFlBQUUsRUFBRyxZQUFXM0gsT0FBTyxDQUFDMkgsVUFBVyxFQUEvRDtBQUFBLGlDQUNFO0FBQUcscUJBQVMsRUFBQyxvQkFBYjtBQUFrQyxpQkFBSyxFQUFFO0FBQUU5Qix3QkFBVSxFQUFFO0FBQWQsYUFBekM7QUFBQSxzQkFDRzdGLE9BQU8sQ0FBQzRILE1BQVIsR0FBaUI1SCxPQUFPLENBQUM0SCxNQUF6QixHQUFrQztBQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQU1FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkYsRUFPRzVILE9BQU8sQ0FBQzhHLFVBQVIsS0FBdUIsS0FBdkIsZ0JBQ0M7QUFDRSxtQkFBUyxFQUFDLG1CQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVqQixzQkFBVSxFQUFFLE1BQWQ7QUFBc0JDLG9CQUFRLEVBQUU7QUFBaEMsV0FGVDtBQUFBLDRCQUlNOUYsT0FBTyxDQUFDOEcsVUFKZCxlQUtFO0FBQUsscUJBQVMsRUFBQyxNQUFmO0FBQUEsOEJBQTBCOUcsT0FBTyxDQUFDMkcsS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERCxnQkFTQztBQUNFLG1CQUFTLEVBQUMsbUJBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRWQsc0JBQVUsRUFBRSxNQUFkO0FBQXNCQyxvQkFBUSxFQUFFO0FBQWhDLFdBRlQ7QUFBQSw0QkFJTTlGLE9BQU8sQ0FBQzJHLEtBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWhCSixlQXVCRTtBQUFLLG1CQUFTLEVBQUMscUJBQWY7QUFBQSxpQ0FDRSxxRUFBQyxnREFBRDtBQUFNLGdCQUFJLEVBQUMsZ0JBQVg7QUFBNEIsY0FBRSxFQUFHLFlBQVczRyxPQUFPLENBQUMySCxVQUFXLEVBQS9EO0FBQUEsbUNBQ0U7QUFDRSx1QkFBUyxFQUFDLGdEQURaO0FBRUUsbUJBQUssRUFBRTtBQUNMN0Isd0JBQVEsRUFBRSxPQURMO0FBRUxELDBCQUFVLEVBQUUsR0FGUDtBQUdMZ0MseUJBQVMsRUFBRSxNQUhOO0FBSUxDLHdCQUFRLEVBQUU7QUFKTCxlQUZUO0FBQUEsd0JBU0c5SCxPQUFPLENBQUMrSDtBQVRYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF2QkYsZUFzQ0U7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxpQ0FDRTtBQUFBLG1EQUVFO0FBQU0sdUJBQVMsRUFBQyxhQUFoQjtBQUFBLHdCQUErQi9ILE9BQU8sQ0FBQ2dJO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUhGLDJCQUtFO0FBQU0sdUJBQVMsRUFBQyxhQUFoQjtBQUFBLHdCQUNHdEIsZ0dBQThCLENBQUMxRyxPQUFPLENBQUNpSSxhQUFUO0FBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQXdGRCxDQXpGRDs7S0FBTUMsbUI7QUEyRlNBLGtGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1DLGFBQWEsR0FBRyxDQUFDO0FBQUVuSTtBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFBQTs7QUFDckMsUUFBTUcsUUFBUSxHQUFHQywrREFBVyxFQUE1Qjs7QUFDQSxRQUFNZ0ksb0JBQW9CLEdBQUcsTUFBT3BJLE9BQVAsSUFBbUI7QUFDOUM7QUFDQSxRQUFJeUIsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjs7QUFDQSxRQUFJRixRQUFRLEtBQUtRLFNBQWIsSUFBMEJSLFFBQVEsS0FBSyxJQUEzQyxFQUFpRDtBQUMvQ1MsdURBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGVBQU8sRUFBRSxPQURXO0FBRXBCQyxtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVBELE1BT087QUFDTCxVQUFJVCxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxRQUFYLENBQWhCO0FBQ0EsVUFBSU0sS0FBSyxHQUFHSCxTQUFTLENBQUNJLFlBQXRCO0FBQ0EsVUFBSVUsT0FBTyxHQUFHO0FBQ1oyRixlQUFPLEVBQUUsQ0FBQ3JJLE9BQU8sQ0FBQ3FJLE9BQVQsQ0FERztBQUVackcsb0JBQVksRUFBRUQ7QUFGRixPQUFkO0FBSUF1RyxnREFBSyxDQUFDQyxPQUFOLENBQWM7QUFDWkMsYUFBSyxFQUFFLHNCQURLO0FBRVpDLFlBQUksRUFBRSxVQUFVbkgsQ0FBVixFQUFhO0FBQ2pCbkIsa0JBQVEsQ0FBQ3VJLG1GQUF3QixDQUFDaEcsT0FBRCxDQUF6QixDQUFSO0FBQ0E0RixvREFBSyxDQUFDSyxVQUFOO0FBQ0QsU0FMVztBQU1aQyxnQkFBUSxFQUFFLFVBQVV0SCxDQUFWLEVBQWE7QUFDckJnSCxvREFBSyxDQUFDSyxVQUFOO0FBQ0QsU0FSVztBQVNaRSxxQkFBYSxFQUFFO0FBQ2JDLGdCQUFNLEVBQUU7QUFESztBQVRILE9BQWQ7QUFhRDtBQUNGLEdBL0JEOztBQWlDQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyx5QkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLHVCQUFmO0FBQUEsNkJBRUU7QUFDRSxXQUFHLEVBQUUsQ0FBQTlJLE9BQU8sU0FBUCxJQUFBQSxPQUFPLFdBQVAsK0JBQUFBLE9BQU8sQ0FBRW9HLEtBQVQsQ0FBZSxDQUFmLHFFQUFtQkEsS0FBbkIsS0FBNEIsMkJBRG5DO0FBRUUsZUFBTyxFQUFHOUUsQ0FBRCxJQUFPO0FBQ2RBLFdBQUMsQ0FBQ21FLE1BQUYsQ0FBU3NELE9BQVQsR0FBbUIsSUFBbkI7QUFDQXpILFdBQUMsQ0FBQ21FLE1BQUYsQ0FBU3VELEdBQVQsR0FBZSwyQkFBZjtBQUNELFNBTEg7QUFNRSxXQUFHLEVBQUMsU0FOTjtBQU9FLGFBQUssRUFBQztBQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBYUU7QUFBSyxlQUFTLEVBQUMscUJBQWY7QUFBQSw4QkFDRTtBQUNFLGlCQUFTLEVBQUMsb0JBRFo7QUFFRSxlQUFPLEVBQUcxSCxDQUFELElBQU84RyxvQkFBb0IsQ0FBQ3BJLE9BQUQsQ0FGdEM7QUFBQSwrQkFJRTtBQUFHLG1CQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FLHFFQUFDLGdEQUFEO0FBQU0sWUFBSSxFQUFDLGdCQUFYO0FBQTRCLFVBQUUsRUFBRyxZQUFXQSxPQUFPLENBQUM2QyxVQUFXLEVBQS9EO0FBQUEsK0JBQ0U7QUFBRyxtQkFBUyxFQUFDLG1CQUFiO0FBQUEscUJBQ0c3QyxPQUFPLENBQUMrSCxZQURYLEVBRUcvSCxPQUFPLENBQUNpSixVQUFSLEdBQ0ksS0FBSWpKLE9BQU8sQ0FBQ2lKLFVBQVcsR0FDdEJqSixPQUFPLENBQUNrSixVQUFSLEdBQXNCLElBQUdsSixPQUFPLENBQUNrSixVQUFXLEVBQTVDLEdBQWdELEVBQ2pELEdBSEosR0FJRyxFQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFpQkU7QUFBQSwrQkFDRTtBQUFBLDJCQUNLLEdBREwsRUFFR2xKLE9BQU8sQ0FBQ21KLG1CQUFSLEtBQWdDLEtBQWhDLGdCQUNDO0FBQUEsdUJBQ0csR0FESCxlQUVFO0FBQUEsd0JBQU1uSixPQUFPLENBQUNvSjtBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkYsRUFFeUMsR0FGekMsRUFHR3BKLE9BQU8sQ0FBQ21KLG1CQUhYO0FBQUEsMEJBREQsR0FPQ25KLE9BQU8sQ0FBQ29KLGlCQVRaLEVBVUssR0FWTCxRQVdLcEosT0FBTyxDQUFDSyxRQVhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWlERCxDQXBGRDs7R0FBTThILGE7VUFDYS9ILHVEOzs7S0FEYitILGE7QUFzRlNBLDRFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVGQTtBQUNBO0FBQ0E7QUFFQTtBQUlBOztBQUVBLE1BQU1rQixtQkFBbUIsR0FBRyxDQUFDO0FBQUVySjtBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFDM0Msc0JBQ0U7QUFBSyxhQUFTLEVBQUMsdURBQWY7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyx1QkFBZjtBQUFBLGdCQUdHQSxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLHVCQUFBQSxPQUFPLENBQUVvRyxLQUFULENBQWUsQ0FBZiw2REFBbUJBLEtBQW5CLGdCQUNDLHFFQUFDLGdEQUFEO0FBQU0sWUFBSSxFQUFDLGdCQUFYO0FBQTRCLFVBQUUsRUFBRyxZQUFXcEcsT0FBTyxDQUFDc0osRUFBRyxFQUF2RDtBQUFBLCtCQUNFO0FBQUEsaUNBQ0UscUVBQUMscURBQUQ7QUFBQSxtQ0FDRTtBQUFLLGlCQUFHLEVBQUV0SixPQUFGLGFBQUVBLE9BQUYsMkNBQUVBLE9BQU8sQ0FBRW9HLEtBQVQsQ0FBZSxDQUFmLENBQUYscURBQUUsaUJBQW1CQSxLQUE3QjtBQUFvQyxpQkFBRyxFQUFFcEcsT0FBTyxDQUFDd0k7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERCxnQkFTQyxxRUFBQyxnREFBRDtBQUFNLFlBQUksRUFBQyxnQkFBWDtBQUE0QixVQUFFLEVBQUcsWUFBV3hJLE9BQU8sQ0FBQ3NKLEVBQUcsRUFBdkQ7QUFBQSwrQkFDRTtBQUFBLGlDQUNFLHFFQUFDLHFEQUFEO0FBQUEsbUNBQ0U7QUFBSyxpQkFBRyxFQUFDLDJCQUFUO0FBQXFDLGlCQUFHLEVBQUM7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFzQkU7QUFBSyxlQUFTLEVBQUMscUJBQWY7QUFBQSw4QkFDRSxxRUFBQyxnREFBRDtBQUFNLFlBQUksRUFBQyxnQkFBWDtBQUE0QixVQUFFLEVBQUcsWUFBV3RKLE9BQU8sQ0FBQ3NKLEVBQUcsRUFBdkQ7QUFBQSwrQkFDRTtBQUFHLG1CQUFTLEVBQUMsbUJBQWI7QUFBQSxvQkFBa0N0SixPQUFPLENBQUMrSDtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQUssaUJBQVMsRUFBQyxvQkFBZjtBQUFBLCtCQUNFLHFFQUFDLG1FQUFEO0FBQVEsZ0JBQU0sRUFBRS9ILE9BQU8sQ0FBQ3VKO0FBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLEVBUUd2SixPQUFPLENBQUM4RyxVQUFSLEdBQXFCLENBQXJCLGdCQUNDO0FBQUcsaUJBQVMsRUFBQyx3QkFBYjtBQUFBLDBCQUNNOUcsT0FBTyxDQUFDOEcsVUFEZCxlQUVFO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUEsNEJBQTBCOUcsT0FBTyxDQUFDNEcsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERCxnQkFNQztBQUFHLGlCQUFTLEVBQUMsd0JBQWI7QUFBQSwwQkFBMEM1RyxPQUFPLENBQUM0RyxZQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTBDRCxDQTNDRDs7S0FBTXlDLG1CO0FBNENTQSxrRkFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3REQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNRyxtQkFBbUIsR0FBRyxDQUFDO0FBQUV4SjtBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFDM0Msc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyx5Q0FBRDtBQUFNLFdBQUssRUFBRTtBQUFFK0YsYUFBSyxFQUFFLEdBQVQ7QUFBYzBCLGNBQU0sRUFBRTtBQUF0QixPQUFiO0FBQTZDLGVBQVMsRUFBQyxpQkFBdkQ7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsK0JBQWY7QUFBQSwrQkFDRTtBQUFRLG1CQUFTLEVBQUMsb0JBQWxCO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSxxRUFBQyw0REFBRDtBQUNFLG1CQUFPLEVBQUV6SCxPQUFPLENBQUN5SixRQURuQjtBQUVFLG9CQUFRLEVBQUU7QUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFVRSxxRUFBQyxnREFBRDtBQUNFLFlBQUksRUFBRyxnQkFBZXpKLE9BQU8sQ0FBQzBKLGFBQWMsVUFBUzFKLE9BQU8sQ0FBQzZDLFVBQVcsRUFEMUU7QUFBQSwrQkFHRTtBQUFBLGlDQUNFLHFFQUFDLGdFQUFEO0FBQWtCLHFCQUFTLEVBQUU3QyxPQUFGLGFBQUVBLE9BQUYsMENBQUVBLE9BQU8sQ0FBRW9HLEtBQVQsQ0FBZSxDQUFmLENBQUYsb0RBQUUsZ0JBQW1CQTtBQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkYsZUFpQkU7QUFBSyxpQkFBUyxFQUFDLHFDQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLDBCQUFmO0FBQUEsa0NBQ0UscUVBQUMsZ0RBQUQ7QUFDRSxnQkFBSSxFQUFHLGdCQUFlcEcsT0FBTyxDQUFDMEosYUFBYyxVQUFTMUosT0FBTyxDQUFDNkMsVUFBVyxFQUQxRTtBQUFBLG1DQUdFO0FBQ0UsdUJBQVMsRUFBQyxnREFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTGlELHdCQUFRLEVBQUUsT0FETDtBQUVMRCwwQkFBVSxFQUFFLEdBRlA7QUFHTGdDLHlCQUFTLEVBQUUsTUFITjtBQUlMQyx3QkFBUSxFQUFFO0FBSkwsZUFGVDtBQUFBLHdCQVNHOUgsT0FBTyxDQUFDK0g7QUFUWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQWdCRTtBQUFLLHFCQUFTLEVBQUMsb0JBQWY7QUFBQSxvQ0FDRSxxRUFBQyxtRUFBRDtBQUFRLG9CQUFNLEVBQUUvSCxPQUFPLENBQUN1SjtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLG9CQUNxQztBQUFBLHdCQUFPdkosT0FBTyxDQUFDdUo7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaEJGLGVBbUJFO0FBQ0UscUJBQVMsRUFBQyxtQkFEWjtBQUVFLGlCQUFLLEVBQUU7QUFDTDFELHdCQUFVLEVBQUU7QUFEUCxhQUZUO0FBQUEsOEJBTU03RixPQUFPLENBQUMySixXQUFSLEtBQXdCLEtBQXhCLEdBQWdDM0osT0FBTyxDQUFDMkosV0FBeEMsR0FBc0QsRUFONUQsZUFPRTtBQUFBLHFDQUNFO0FBQUsseUJBQVMsRUFBQyxNQUFmO0FBQUEsa0NBQ00zSixPQUFPLENBQUM0RyxZQUFSLEdBQXVCNUcsT0FBTyxDQUFDNEcsWUFBL0IsR0FBOEMsRUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFQRixlQVlFO0FBQU8sbUJBQUssRUFBRTtBQUFFZ0QscUJBQUssRUFBRTtBQUFULGVBQWQ7QUFBZ0MsdUJBQVMsRUFBQyxNQUExQztBQUFBLHdCQUNHNUosT0FBTyxDQUFDNkosS0FBUixHQUFnQjdKLE9BQU8sQ0FBQzZKLEtBQXhCLEdBQWdDO0FBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQTRERCxDQTdERDs7S0FBTUwsbUI7QUErRFNBLGtGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1NLHdCQUF3QixHQUFHLENBQUM7QUFBRTlKO0FBQUYsQ0FBRCxLQUFpQjtBQUFBOztBQUNoRCxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLHlDQUFEO0FBQU0sY0FBUSxFQUFFLEtBQWhCO0FBQXVCLGVBQVMsRUFBQyxrQkFBakM7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsK0JBQWY7QUFBQSwrQkFDRTtBQUFRLG1CQUFTLEVBQUMsb0JBQWxCO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSxxRUFBQyw0REFBRDtBQUNFLG1CQUFPLEVBQUVBLE9BQU8sQ0FBQ3lKLFFBRG5CO0FBRUUsb0JBQVEsRUFBRTtBQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVVFLHFFQUFDLGdEQUFEO0FBQ0UsWUFBSSxFQUFHLGdCQUFlekosT0FBTyxDQUFDMEosYUFBYyxVQUFTMUosT0FBTyxDQUFDNkMsVUFBVyxFQUQxRTtBQUFBLCtCQUdFO0FBQUEsaUNBQ0UscUVBQUMsZ0VBQUQ7QUFBa0IscUJBQVMsRUFBRTdDLE9BQUYsYUFBRUEsT0FBRiwwQ0FBRUEsT0FBTyxDQUFFb0csS0FBVCxDQUFlLENBQWYsQ0FBRixvREFBRSxnQkFBbUJBO0FBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWRixlQWlCRTtBQUFLLGlCQUFTLEVBQUMscUNBQWY7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsMEJBQWY7QUFBQSxrQ0FDRSxxRUFBQyxnREFBRDtBQUNFLGdCQUFJLEVBQUcsZ0JBQWVwRyxPQUFPLENBQUMwSixhQUFjLFVBQVMxSixPQUFPLENBQUM2QyxVQUFXLEVBRDFFO0FBQUEsbUNBR0U7QUFDRSx1QkFBUyxFQUFDLG1CQURaO0FBRUUsbUJBQUssRUFBRTtBQUNMaUQsd0JBQVEsRUFBRSxPQURMO0FBRUxELDBCQUFVLEVBQUUsR0FGUDtBQUdMZ0MseUJBQVMsRUFBRTtBQUhOLGVBRlQ7QUFBQSx3QkFRRzdILE9BQU8sQ0FBQytIO0FBUlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFlRTtBQUFLLHFCQUFTLEVBQUMsb0JBQWY7QUFBQSxvQ0FDRSxxRUFBQyxtRUFBRDtBQUFRLG9CQUFNLEVBQUUvSCxPQUFPLENBQUN1SjtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLG9CQUNxQztBQUFBLHdCQUFPdkosT0FBTyxDQUFDdUo7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZkYsZUFrQkU7QUFDRSxxQkFBUyxFQUFDLG1CQURaO0FBRUUsaUJBQUssRUFBRTtBQUNMMUQsd0JBQVUsRUFBRTtBQURQLGFBRlQ7QUFBQSw4QkFNTTdGLE9BQU8sQ0FBQzJKLFdBQVIsR0FBc0IzSixPQUFPLENBQUMySixXQUE5QixHQUE0QyxDQU5sRCxlQU9FO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDTTNKLE9BQU8sQ0FBQzRHLFlBQVIsR0FBdUI1RyxPQUFPLENBQUM0RyxZQUEvQixHQUE4QyxDQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGLGVBWUU7QUFBTyxtQkFBSyxFQUFFO0FBQUVnRCxxQkFBSyxFQUFFO0FBQVQsZUFBZDtBQUFnQyx1QkFBUyxFQUFDLE1BQTFDO0FBQUEsd0JBQ0c1SixPQUFPLENBQUM2SixLQUFSLEdBQWdCN0osT0FBTyxDQUFDNkosS0FBeEIsR0FBZ0M7QUFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBMkRELENBNUREOztLQUFNQyx3QjtBQThEU0EsdUZBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEVBO0FBQ0E7O0FBQ0EsTUFBTUMsZ0JBQWdCLEdBQUcsQ0FBQztBQUFFQyxXQUFGO0FBQWFDO0FBQWIsQ0FBRCxLQUE0QjtBQUFBOztBQUFBOztBQUVuRGhGLHlEQUFTLENBQUMsTUFBTSxDQUdmLENBSFEsRUFHTixFQUhNLENBQVQ7QUFLQSxNQUFJaUYsZ0JBQUo7O0FBQ0EsTUFBSSxDQUFDRCxPQUFELElBQVksQ0FBQUQsU0FBUyxTQUFULElBQUFBLFNBQVMsV0FBVCxxQ0FBQUEsU0FBUyxDQUFFRyxpQkFBWCxnRkFBOEJDLE1BQTlCLElBQXVDLENBQXZELEVBQTBEO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBRixvQkFBZ0IsR0FDWkYsU0FBUyxDQUFDRyxpQkFBVixDQUE0QkUsS0FBNUIsQ0FBa0MsQ0FBbEMsRUFBcUMsQ0FBckMsRUFBd0NoRixHQUF4QyxDQUE0QyxDQUFDQyxJQUFELEVBQU9ZLEtBQVAsa0JBQzVDO0FBQUssZUFBUyxFQUFDLG9CQUFmO0FBQUEsNkJBQ0E7QUFBSyxpQkFBUyxFQUFDLDRCQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsT0FBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyxtQkFBZjtBQUFrQyxtQkFBSyxFQUFFO0FBQUNvRSx1QkFBTyxFQUFHaEYsSUFBSSxDQUFDYyxLQUFMLENBQVdnRSxNQUFYLEdBQW9CLENBQXBCLEdBQXdCLE9BQXhCLEdBQWdDO0FBQTNDLGVBQXpDO0FBQUEscUNBRUEscUVBQUMsZ0RBQUQ7QUFBTSxvQkFBSSxFQUFDLGdCQUFYO0FBQTRCLGtCQUFFLEVBQUcsWUFBVzlFLElBQUksQ0FBQ3pDLFVBQVcsRUFBNUQ7QUFBQSx1Q0FDSTtBQUFHLHNCQUFJLEVBQUMscUJBQVI7QUFBQSx5Q0FDSztBQUFLLDZCQUFTLEVBQUMsV0FBZjtBQUEyQix1QkFBRyxFQUFFeUMsSUFBSSxDQUFDYyxLQUFMLENBQVdnRSxNQUFYLEdBQW9CLENBQXBCLEdBQXdCOUUsSUFBSSxDQUFDYyxLQUFMLENBQVcsQ0FBWCxFQUFjbUUsU0FBdEMsR0FBaUQsRUFBakY7QUFBcUYsdUJBQUcsRUFBQztBQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBU0k7QUFBSyx1QkFBUyxFQUFDLFlBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsY0FBZjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxPQUFkO0FBQUEseUNBQXNCO0FBQUcsd0JBQUksRUFBQyx5QkFBUjtBQUFBLDhCQUFtQ2pGLElBQUksQ0FBQ3lDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFESixlQUVJO0FBQUssMkJBQVMsRUFBQyxtREFBZjtBQUFBLHlDQUNJO0FBQUksNkJBQVMsRUFBQyxlQUFkO0FBQUEsb0NBQWdDekMsSUFBSSxDQUFDc0IsWUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEQSxDQURKO0FBNEJEOztBQUdELE1BQUk0RCxpQkFBSjs7QUFDQSxNQUFJLENBQUNQLE9BQUQsSUFBWSxDQUFBRCxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUVTLG1CQUFYLGdGQUFnQ0wsTUFBaEMsSUFBeUMsQ0FBekQsRUFBNEQ7QUFDMUQ7QUFDQTtBQUNBO0FBQ0FJLHFCQUFpQixnQkFDYjtBQUFLLGVBQVMsRUFBQyx3Q0FBZjtBQUF3RCxXQUFLLEVBQUU7QUFBQ0YsZUFBTyxFQUFHTixTQUFTLENBQUNTLG1CQUFWLENBQThCTCxNQUE5QixHQUF1QyxDQUF2QyxHQUEyQyxPQUEzQyxHQUFtRDtBQUE5RCxPQUEvRDtBQUFBLDZCQUNBO0FBQUssaUJBQVMsRUFBQyxjQUFmO0FBQUEsK0JBQ0k7QUFBRyxjQUFJLEVBQUMseUJBQVI7QUFDSSxtQkFBUyxFQUFDLDREQURkO0FBQUEsaUNBRUs7QUFBSyxlQUFHLEVBQUVKLFNBQVMsQ0FBQ1MsbUJBQVYsQ0FBOEJMLE1BQTlCLEdBQXVDLENBQXZDLEdBQTJDSixTQUFTLENBQUNTLG1CQUFWLENBQThCLENBQTlCLEVBQWlDQyxLQUE1RSxHQUFtRixFQUE3RjtBQUFpRyxlQUFHLEVBQUM7QUFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESjtBQVdEOztBQUNELHNCQUVBO0FBQUEsMkJBRUU7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDQTtBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsa0NBQ0k7QUFBSyxxQkFBUyxFQUFDLHVCQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLHFCQUFmO0FBQUEscUNBQ0k7QUFBSSx5QkFBUyxFQUFDLGlDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUlJO0FBQUssdUJBQVMsRUFBQyxlQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSwwQkFDQ1I7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosRUFjS00saUJBZEwsZUFlSTtBQUFLLHFCQUFTLEVBQUMsdUJBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMscUJBQWY7QUFBQSxxQ0FDSTtBQUFJLHlCQUFTLEVBQUMsaUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBSUk7QUFBSyx1QkFBUyxFQUFDLDBCQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLGFBQWY7QUFBQSx3Q0FDSTtBQUFLLDJCQUFTLEVBQUMsb0JBQWY7QUFBQSx5Q0FDSTtBQUFLLDZCQUFTLEVBQUMsNEJBQWY7QUFBQSwyQ0FDSTtBQUFLLCtCQUFTLEVBQUMsZUFBZjtBQUFBLDZDQUNJO0FBQUssaUNBQVMsRUFBQyxPQUFmO0FBQUEsZ0RBQ0k7QUFBSyxtQ0FBUyxFQUFDLG1CQUFmO0FBQUEsaURBQ0k7QUFBRyxnQ0FBSSxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBREosZUFNSTtBQUFLLG1DQUFTLEVBQUMsWUFBZjtBQUFBLGlEQUNJO0FBQUsscUNBQVMsRUFBQyxjQUFmO0FBQUEsb0RBQ0k7QUFBSSx1Q0FBUyxFQUFDLE9BQWQ7QUFBQSxxREFBc0I7QUFBRyxvQ0FBSSxFQUFDLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBREosZUFHSTtBQUFLLHVDQUFTLEVBQUMsbURBQWY7QUFBQSxxREFDSTtBQUFJLHlDQUFTLEVBQUMsZUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUF3Qkk7QUFBSywyQkFBUyxFQUFDLG9CQUFmO0FBQUEseUNBQ0k7QUFBSyw2QkFBUyxFQUFDLDRCQUFmO0FBQUEsMkNBQ0k7QUFBSywrQkFBUyxFQUFDLGVBQWY7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsT0FBZjtBQUFBLGdEQUNJO0FBQUssbUNBQVMsRUFBQyxtQkFBZjtBQUFBLGlEQUNJO0FBQUcsZ0NBQUksRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBTUk7QUFBSyxtQ0FBUyxFQUFDLFlBQWY7QUFBQSxpREFDSTtBQUFLLHFDQUFTLEVBQUMsY0FBZjtBQUFBLG9EQUNJO0FBQUksdUNBQVMsRUFBQyxPQUFkO0FBQUEscURBQXNCO0FBQUcsb0NBQUksRUFBQyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQURKLGVBR0k7QUFBSyx1Q0FBUyxFQUFDLG1EQUFmO0FBQUEscURBQ0k7QUFBSSx5Q0FBUyxFQUFDLGVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXhCSixlQStDSTtBQUFLLDJCQUFTLEVBQUMsb0JBQWY7QUFBQSx5Q0FDSTtBQUFLLDZCQUFTLEVBQUMsNEJBQWY7QUFBQSwyQ0FDSTtBQUFLLCtCQUFTLEVBQUMsZUFBZjtBQUFBLDZDQUNJO0FBQUssaUNBQVMsRUFBQyxPQUFmO0FBQUEsZ0RBQ0k7QUFBSyxtQ0FBUyxFQUFDLG1CQUFmO0FBQUEsaURBQ0k7QUFBRyxnQ0FBSSxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBREosZUFNSTtBQUFLLG1DQUFTLEVBQUMsWUFBZjtBQUFBLGlEQUNJO0FBQUsscUNBQVMsRUFBQyxjQUFmO0FBQUEsb0RBQ0k7QUFBSSx1Q0FBUyxFQUFDLE9BQWQ7QUFBQSxxREFBc0I7QUFBRyxvQ0FBSSxFQUFDLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBREosZUFHSTtBQUFLLHVDQUFTLEVBQUMsbURBQWY7QUFBQSxxREFDSTtBQUFJLHlDQUFTLEVBQUMsZUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBL0NKLGVBc0VJO0FBQUssMkJBQVMsRUFBQyxjQUFmO0FBQUEseUNBQ0k7QUFBSyw2QkFBUyxFQUFDLDRCQUFmO0FBQUEsMkNBQ0k7QUFBSywrQkFBUyxFQUFDLGVBQWY7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsT0FBZjtBQUFBLGdEQUNJO0FBQUssbUNBQVMsRUFBQyxtQkFBZjtBQUFBLGlEQUNJO0FBQUcsZ0NBQUksRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBUUk7QUFBSyxtQ0FBUyxFQUFDLFlBQWY7QUFBQSxpREFDSTtBQUFLLHFDQUFTLEVBQUMsY0FBZjtBQUFBLG9EQUNJO0FBQUksdUNBQVMsRUFBQyxPQUFkO0FBQUEscURBQXNCO0FBQUcsb0NBQUksRUFBQyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQURKLGVBR0k7QUFBSyx1Q0FBUyxFQUFDLG1EQUFmO0FBQUEscURBQ0k7QUFBSSx5Q0FBUyxFQUFDLGVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXRFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGLG1CQUZBO0FBdUlELENBbk1EOztHQUFNVCxnQjs7S0FBQUEsZ0I7QUFxTVNBLCtFQUFmO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeE1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUVBLE1BQU1ZLGlCQUFpQixHQUFHLENBQUM7QUFBRVgsV0FBRjtBQUFhQztBQUFiLENBQUQsS0FBNEI7QUFBQTs7QUFBQTs7QUFDcEQsUUFBTTtBQUFBLE9BQUNXLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCdEssc0RBQVEsQ0FBQyxJQUFELENBQTVDO0FBQ0EsUUFBTTtBQUFBLE9BQUN1SyxVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUE4QnhLLHNEQUFRLENBQUMsSUFBRCxDQUE1Qzs7QUFFQSxpQkFBZXlLLGFBQWYsR0FBK0I7QUFDN0IsVUFBTTlILFlBQVksR0FBRyxNQUFNK0gscUVBQWUsQ0FBQ0MsbUJBQWhCLENBQ3pCLDJCQUR5QixDQUEzQjs7QUFHQSxRQUFJaEksWUFBSixFQUFrQjtBQUNoQjJILG1CQUFhLENBQUNNLGdGQUFhLENBQUNqSSxZQUFELEVBQWUsUUFBZixDQUFkLENBQWI7QUFDQTZILG1CQUFhLENBQUNJLGdGQUFhLENBQUNqSSxZQUFELEVBQWUsUUFBZixDQUFkLENBQWI7QUFDRDtBQUNGOztBQUVEK0IseURBQVMsQ0FBQyxNQUFNO0FBQ2Q7QUFDQStGLGlCQUFhO0FBQ2QsR0FIUSxFQUdOLEVBSE0sQ0FBVDs7QUFLQSxXQUFTSSxlQUFULENBQXlCOUYsSUFBekIsRUFBK0I7QUFDN0IsWUFBUUEsSUFBSSxDQUFDK0YsVUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFO0FBQUE7QUFDRTtBQUVBO0FBQ0UsZUFBRyxFQUFHLEdBQUUvRixJQUFJLENBQUNvRixLQUFNLG9CQURyQjtBQUVFLHVCQUFXLEVBQUMsR0FGZDtBQUdFLGlCQUFLLEVBQUMsMkJBSFI7QUFJRSwyQkFBZSxNQUpqQjtBQUtFLGlCQUFLLEVBQUM7QUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhGLENBVUU7O0FBVkY7O0FBYUYsV0FBSyxPQUFMO0FBQ0UsNEJBQ0U7QUFDRSxjQUFJLEVBQUVwRixJQUFJLENBQUNnRyxXQURiO0FBRUUsbUJBQVMsRUFBQyxtQ0FGWjtBQUdFLGVBQUssRUFBRTtBQUNMQywyQkFBZSxFQUFHLE9BQU1qRyxJQUFJLENBQUNvRixLQUFNO0FBRDlCO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERjs7QUFVRjtBQUNFO0FBM0JKO0FBNkJEOztBQUVELFFBQU1jLGVBQWUsR0FBRztBQUN0QkMsUUFBSSxFQUFFLEtBRGdCO0FBRXRCQyxZQUFRLEVBQUUsSUFGWTtBQUd0QkMsU0FBSyxFQUFFLEdBSGU7QUFJdEJDLFFBQUksRUFBRSxJQUpnQjtBQUt0QkMsZ0JBQVksRUFBRSxDQUxRO0FBTXRCQyxrQkFBYyxFQUFFLENBTk07QUFPdEJDLGFBQVMsZUFBRSxxRUFBQywrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBXO0FBUXRCQyxhQUFTLGVBQUUscUVBQUMsK0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJXLEdBQXhCO0FBV0EsUUFBTUMsZ0JBQWdCLEdBQUc7QUFDdkJSLFFBQUksRUFBRSxLQURpQjtBQUV2QlMsVUFBTSxFQUFFLElBRmU7QUFHdkJSLFlBQVEsRUFBRSxJQUhhO0FBSXZCQyxTQUFLLEVBQUUsR0FKZ0I7QUFLdkJFLGdCQUFZLEVBQUUsQ0FMUztBQU12QkMsa0JBQWMsRUFBRSxDQU5PO0FBT3ZCQyxhQUFTLGVBQUUscUVBQUMsK0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQWTtBQVF2QkMsYUFBUyxlQUFFLHFFQUFDLCtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUlk7QUFTdkJHLGNBQVUsRUFBRSxDQUNWO0FBQ0VDLGdCQUFVLEVBQUUsSUFEZDtBQUVFQyxjQUFRLEVBQUU7QUFDUlIsb0JBQVksRUFBRSxDQUROO0FBRVJDLHNCQUFjLEVBQUUsQ0FGUjtBQUdSSixnQkFBUSxFQUFFLElBSEY7QUFJUkQsWUFBSSxFQUFFO0FBSkU7QUFGWixLQURVLEVBVVY7QUFDRVcsZ0JBQVUsRUFBRSxHQURkO0FBRUVDLGNBQVEsRUFBRTtBQUNSUixvQkFBWSxFQUFFLENBRE47QUFFUkMsc0JBQWMsRUFBRSxDQUZSO0FBR1JRLG9CQUFZLEVBQUU7QUFITjtBQUZaLEtBVlUsRUFrQlY7QUFDRUYsZ0JBQVUsRUFBRSxHQURkO0FBRUVDLGNBQVEsRUFBRTtBQUNSUixvQkFBWSxFQUFFLENBRE47QUFFUkMsc0JBQWMsRUFBRTtBQUZSO0FBRlosS0FsQlU7QUFUVyxHQUF6QixDQTlEb0QsQ0FrR3BEOztBQUNBLE1BQUk1QixnQkFBSjs7QUFDQSxNQUFJLENBQUNELE9BQUQsSUFBWSxDQUFBRCxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUV1QyxXQUFYLGdGQUF3Qm5DLE1BQXhCLElBQWlDLENBQWpELEVBQW9EO0FBQ2xELFVBQU1vQyxZQUFZLEdBQUd4QyxTQUFTLENBQUN1QyxXQUFWLENBQXNCbEgsR0FBdEIsQ0FBMEIsQ0FBQ0MsSUFBRCxFQUFPWSxLQUFQLGtCQUM3QztBQUFBLGdCQUFrQmtGLGVBQWUsQ0FBQzlGLElBQUQ7QUFBakMsT0FBVVksS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURtQixDQUFyQjtBQUdBZ0Usb0JBQWdCLGdCQUNkLHFFQUFDLGtEQUFELGtDQUFZK0IsZ0JBQVo7QUFBOEIsZUFBUyxFQUFDLGFBQXhDO0FBQUEsZ0JBQ0dPO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQUtEOztBQUNELHNCQUVFO0FBQ0UsYUFBUyxFQUFDLGtDQURaO0FBQUEsMkJBR0U7QUFBSyxlQUFTLEVBQUMsY0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxrQkFBZjtBQUFBLGtCQUFtQ3RDO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBb0JELENBbElEOztHQUFNUyxpQjs7S0FBQUEsaUI7QUFvSVNBLGdGQUFmO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTThCLFNBQVMsR0FBRyxDQUFDO0FBQUVDLFNBQU8sR0FBRyxDQUFaO0FBQWVDLFVBQVEsR0FBRyxFQUExQjtBQUE4QjNDO0FBQTlCLENBQUQsS0FBK0M7QUFBQTs7QUFDL0QsUUFBTXRKLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxRQUFNaU0sVUFBVSxHQUFHbE0sTUFBTSxDQUFDbU0sUUFBMUI7QUFFQSxRQUFNO0FBQ0pDLFFBREk7QUFFSkMsWUFGSTtBQUdKQyxrQkFISTtBQUlKQyxTQUpJO0FBS0pDLFlBTEk7QUFNSkMsWUFOSTtBQU9KQyxlQVBJO0FBUUpDLGVBUkk7QUFTSkM7QUFUSSxNQVVGNU0sTUFBTSxDQUFDNk0sS0FWWDtBQVlBLFFBQU07QUFBRUE7QUFBRixNQUFZN00sTUFBbEI7QUFDQSxRQUFNO0FBQUEsT0FBQzhNLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCbE4sc0RBQVEsQ0FBQyxJQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNtTixZQUFEO0FBQUEsT0FBZUM7QUFBZixNQUFrQ3BOLHNEQUFRLENBQUMsSUFBRCxDQUFoRDtBQUNBLFFBQU07QUFBQSxPQUFDcU4sS0FBRDtBQUFBLE9BQVFDO0FBQVIsTUFBb0J0TixzREFBUSxDQUFDLENBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQzBKLE9BQUQ7QUFBQSxPQUFVNkQ7QUFBVixNQUF3QnZOLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDd04sT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0J6TixzREFBUSxDQUNwQyxxREFEb0MsQ0FBdEM7O0FBSUEsV0FBUzBOLG9CQUFULENBQThCM00sQ0FBOUIsRUFBaUM7QUFDL0JBLEtBQUMsQ0FBQzRNLGNBQUY7QUFDQVQsZUFBVyxDQUFDLENBQUNELFFBQUYsQ0FBWDtBQUNEOztBQUVELGlCQUFlVyxXQUFmLENBQTJCQyxNQUEzQixFQUFtQztBQUNqQ04sY0FBVSxDQUFDLElBQUQsQ0FBVjtBQUNBLFFBQUlwTCxPQUFPLEdBQUc7QUFDWm9LLFVBQUksRUFBRUEsSUFBSSxLQUFLN0ssU0FBVCxHQUFxQixDQUFyQixHQUF5QjZLO0FBRG5CLEtBQWQ7QUFJQSxVQUFNNUosWUFBWSxHQUFHLE1BQU1DLHVFQUFpQixDQUFDZ0wsV0FBbEIsQ0FBOEJ6TCxPQUE5QixDQUEzQjs7QUFFQSxRQUFJUSxZQUFKLEVBQWtCO0FBQ2hCeUsscUJBQWUsQ0FBQ3pLLFlBQVksQ0FBQ21MLEtBQWQsQ0FBZjtBQUNBUixjQUFRLENBQUMzSyxZQUFZLENBQUNvTCxVQUFkLENBQVI7QUFDQTVLLGdCQUFVLENBQ1IsWUFBWTtBQUNWb0ssa0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRCxPQUZELENBRUVTLElBRkYsQ0FFTyxJQUZQLENBRFEsRUFJUixHQUpRLENBQVY7QUFNRDtBQUNGOztBQUVELGlCQUFlQyxvQkFBZixHQUFzQztBQUNwQ1YsY0FBVSxDQUFDLElBQUQsQ0FBVjtBQUNBLFFBQUlwTCxPQUFPLEdBQUc7QUFDWm9LLFVBQUksRUFBRUEsSUFBSSxLQUFLN0ssU0FBVCxHQUFxQixDQUFyQixHQUF5QjZLLElBRG5CO0FBRVoyQixhQUFPLEVBQUUsQ0FGRztBQUdaQyxpQkFBVyxFQUFFM0IsUUFBUSxHQUFHQSxRQUFILEdBQWMsRUFIdkI7QUFJWkMsb0JBQWMsRUFBRUEsY0FBYyxHQUFHQSxjQUFILEdBQW9CLEVBSnRDO0FBS1oyQixjQUFRLEVBQUUxQixLQUFLLEdBQUdBLEtBQUgsR0FBVyxFQUxkO0FBTVoyQixlQUFTLEVBQUV6QixRQUFRLEdBQUdBLFFBQUgsR0FBYyxFQU5yQjtBQU9aMEIsZUFBUyxFQUFFM0IsUUFBUSxHQUFHQSxRQUFILEdBQWMsRUFQckI7QUFRWkUsaUJBQVcsRUFBRUEsV0FBVyxHQUFHQSxXQUFILEdBQWlCLEVBUjdCO0FBU1pDLGlCQUFXLEVBQUVBLFdBQVcsR0FBR0EsV0FBSCxHQUFpQixFQVQ3QjtBQVVaQyxZQUFNLEVBQUVBLE1BQU0sR0FBR0EsTUFBSCxHQUFZO0FBVmQsS0FBZDtBQVlBLFVBQU1wSyxZQUFZLEdBQUcsTUFBTUMsdUVBQWlCLENBQUMyTCxtQkFBbEIsQ0FBc0NwTSxPQUF0QyxDQUEzQjs7QUFDQSxRQUFJUSxZQUFKLEVBQWtCO0FBQ2hCeUsscUJBQWUsQ0FBQ3pLLFlBQVksQ0FBQ21MLEtBQWQsQ0FBZjtBQUNBUixjQUFRLENBQUMzSyxZQUFZLENBQUNvTCxVQUFkLENBQVI7QUFDQTVLLGdCQUFVLENBQ1IsWUFBWTtBQUNWb0ssa0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRCxPQUZELENBRUVTLElBRkYsQ0FFTyxJQUZQLENBRFEsRUFJUixHQUpRLENBQVY7QUFNRDtBQUNGOztBQUVELFdBQVNRLGdCQUFULENBQTBCakMsSUFBMUIsRUFBZ0NILFFBQWhDLEVBQTBDO0FBQ3hDLFFBQUlxQyxVQUFVLEdBQUdDLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsTUFBakM7O0FBQ0EsUUFDRXBDLFFBQVEsS0FBSzlLLFNBQWIsSUFDQStLLGNBQWMsS0FBSy9LLFNBRG5CLElBRUFnTCxLQUFLLEtBQUtoTCxTQUZWLElBR0FpTCxRQUFRLEtBQUtqTCxTQUhiLElBSUFrTCxRQUFRLEtBQUtsTCxTQUpiLElBS0FtTCxXQUFXLEtBQUtuTCxTQUxoQixJQU1Bb0wsV0FBVyxLQUFLcEwsU0FOaEIsSUFPQXFMLE1BQU0sS0FBS3JMLFNBUmIsRUFTRTtBQUNBLFVBQUltTixLQUFLLEdBQUdKLFVBQVUsQ0FBQ0ssT0FBWCxDQUFtQixVQUFuQixFQUErQixFQUEvQixDQUFaO0FBQ0EzTyxZQUFNLENBQUNpRCxJQUFQLENBQVksVUFBVXlMLEtBQVYsR0FBa0IsUUFBbEIsR0FBNkJ0QyxJQUF6QztBQUNELEtBWkQsTUFZTztBQUNMcE0sWUFBTSxDQUFDaUQsSUFBUCxDQUFhLGNBQWFtSixJQUFLLEVBQS9CO0FBQ0Q7QUFDRjs7QUFFRCxpQkFBZXdDLGVBQWYsQ0FBK0JsQixNQUEvQixFQUF1QztBQUNyQyxVQUFNbEwsWUFBWSxHQUFHLE1BQU1DLHVFQUFpQixDQUFDbU0sZUFBbEIsRUFBM0I7O0FBQ0EsUUFBSXBNLFlBQUosRUFBa0IsQ0FDaEI7QUFDRDtBQUNGOztBQUVELFdBQVNxTSxnQkFBVCxHQUE0QjtBQUMxQixZQUFRN0MsT0FBUjtBQUNFLFdBQUssQ0FBTDtBQUNFc0Isa0JBQVUsQ0FBQywyQ0FBRCxDQUFWO0FBQ0EsZUFBTyxDQUFQO0FBQ0E7O0FBQ0YsV0FBSyxDQUFMO0FBQ0VBLGtCQUFVLENBQUMsMkNBQUQsQ0FBVjtBQUNBLGVBQU8sQ0FBUDtBQUNBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDRUEsa0JBQVUsQ0FBQyw2QkFBRCxDQUFWO0FBZko7QUFpQkQ7O0FBRUQvSSx5REFBUyxDQUFDLE1BQU07QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNGO0FBRUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0M7QUFDRDtBQUNDc0ssb0JBQWdCO0FBQ2pCLEdBbENRLEVBa0NOLENBQUNoQyxLQUFELENBbENNLENBQVQsQ0EzSCtELENBK0ovRDs7QUFDQSxNQUFJaUMsZ0JBQUo7O0FBQ0EsTUFBSSxDQUFDdkYsT0FBTCxFQUFjO0FBQUE7O0FBQ1osUUFBSUQsU0FBUyxJQUFJLENBQUFBLFNBQVMsU0FBVCxJQUFBQSxTQUFTLFdBQVQscUNBQUFBLFNBQVMsQ0FBRXlGLGlCQUFYLGdGQUE4QnJGLE1BQTlCLElBQXVDLENBQXhELEVBQTJEO0FBQ3pELFVBQUlvRCxRQUFKLEVBQWM7QUFDWixjQUFNYSxLQUFLLEdBQUdyRSxTQUFTLENBQUN5RixpQkFBVixDQUE0QnBGLEtBQTVCLENBQWtDLENBQWxDLEVBQXFDLENBQXJDLEVBQXdDaEYsR0FBeEMsQ0FBNEMsQ0FBQ0MsSUFBRCxFQUFPWSxLQUFQLGtCQUN4RDtBQUFLLG1CQUFTLEVBQUU2SCxPQUFoQjtBQUFBLGlDQUNFLHFFQUFDLGlGQUFEO0FBQWEsbUJBQU8sRUFBRXpJO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixXQUE4QlksS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEWSxDQUFkO0FBS0FzSix3QkFBZ0IsZ0JBQ2Q7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsS0FBZjtBQUFBLHNCQUFzQm5CO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBS0QsT0FYRCxNQVdPO0FBQ0xtQix3QkFBZ0IsR0FBR3hGLFNBQVMsQ0FBQ3lGLGlCQUFWLENBQTRCcEssR0FBNUIsQ0FBZ0MsQ0FBQ0MsSUFBRCxFQUFPWSxLQUFQLGtCQUNqRCxxRUFBQyxxRkFBRDtBQUFpQixpQkFBTyxFQUFFWjtBQUExQixXQUFxQ1ksS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEaUIsQ0FBbkI7QUFHRDtBQUNGLEtBakJELE1BaUJPO0FBQ0xzSixzQkFBZ0IsZ0JBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW5CO0FBQ0Q7QUFDRixHQXJCRCxNQXFCTztBQUNMLFVBQU1FLGFBQWEsR0FBR0MsbUZBQWlCLENBQUMsRUFBRCxDQUFqQixDQUFzQnRLLEdBQXRCLENBQTBCLENBQUNDLElBQUQsRUFBT1ksS0FBUCxrQkFDOUM7QUFBSyxlQUFTLEVBQUU2SCxPQUFoQjtBQUFBLDZCQUNFLHFFQUFDLHVGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixPQUE4QjdILEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRG9CLENBQXRCO0FBS0FzSixvQkFBZ0IsZ0JBQUc7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFBLGdCQUFzQkU7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbkI7QUFDRDs7QUFFRCxzQkFDRTtBQUFLLGFBQVMsRUFBQyxhQUFmO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsY0FBZjtBQUFBLDhCQUNBO0FBQUssYUFBSyxFQUFDLGtEQUFYO0FBQUEsK0JBQ0U7QUFBSyxlQUFLLEVBQUMsMEJBQVg7QUFBQSxpQ0FDRTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQSxvQ0FDRTtBQUFJLHVCQUFTLEVBQUMsYUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFO0FBQUcsdUJBQVMsRUFBQyxpQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFEQSxlQVNBO0FBQUssaUJBQVMsRUFBQyxpQ0FBZjtBQUFBLCtCQUNJLHFFQUFDLGdEQUFEO0FBQU0sY0FBSSxFQUFDLFdBQVg7QUFBQSxpQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRBLGVBbUJFO0FBQUssaUJBQVMsRUFBQyxzQkFBZjtBQUFBLCtCQUVFO0FBQUssbUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5CRixlQXNDQTtBQUFLLGlCQUFTLEVBQUMsMkJBQWY7QUFBQSxrQkFBNENGO0FBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdENBLGVBdUNBO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXdERCxDQXZQRDs7R0FBTS9DLFM7VUFDVzlMLHFEOzs7S0FEWDhMLFM7QUF5UFNBLHdFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BRQTtBQUNBOztBQUVBLE1BQU1tRCxlQUFlLEdBQUcsbUJBRXRCO0FBQUEsMEJBRUE7QUFBSyxhQUFTLEVBQUMsMkJBQWY7QUFBQSwyQkFDSTtBQUFLLGVBQVMsRUFBQyxjQUFmO0FBQUEsNkJBQ0k7QUFBSyxpQkFBUyxFQUFDLEtBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsZ0NBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsd0JBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsbUJBQWY7QUFBQSxxQ0FDSTtBQUFHLG9CQUFJLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQU1JO0FBQUcsdUJBQVMsRUFBQyxZQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5KLGVBUUk7QUFBSyx1QkFBUyxFQUFDLHNCQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLE9BQWY7QUFBQSx3Q0FDSTtBQUFNLDJCQUFTLEVBQUM7QUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFESixlQUlJO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEsMENBQ0k7QUFBRyw2QkFBUyxFQUFDLDBCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURKLGVBRUk7QUFBSSw2QkFBUyxFQUFDLGlCQUFkO0FBQUEsMkNBQWdDO0FBQUcsMEJBQUksRUFBQyxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVJKLGVBb0JJO0FBQUssdUJBQVMsRUFBQyxnQkFBZjtBQUFBLHFDQUNJO0FBQUkseUJBQVMsRUFBQyxRQUFkO0FBQUEsd0NBQ0k7QUFBQSx5Q0FBSTtBQUFHLHdCQUFJLEVBQUMsYUFBUjtBQUFzQiwwQkFBTSxFQUFDLFFBQTdCO0FBQUEsMkNBQXNDO0FBQzlCLCtCQUFTLEVBQUM7QUFEb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFESixlQUdJO0FBQUEseUNBQUk7QUFBRyx3QkFBSSxFQUFDLGFBQVI7QUFBc0IsMEJBQU0sRUFBQyxRQUE3QjtBQUFBLDJDQUFzQztBQUM5QiwrQkFBUyxFQUFDO0FBRG9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSEosZUFLSTtBQUFBLHlDQUFJO0FBQUcsd0JBQUksRUFBQyxhQUFSO0FBQXNCLDBCQUFNLEVBQUMsUUFBN0I7QUFBQSwyQ0FBc0M7QUFDOUIsK0JBQVMsRUFBQztBQURvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUxKLGVBT0k7QUFBSSwyQkFBUyxFQUFDLE1BQWQ7QUFBQSx5Q0FBcUI7QUFBRyx3QkFBSSxFQUFDLGFBQVI7QUFBc0IsMEJBQU0sRUFBQyxRQUE3QjtBQUFBLDJDQUFzQztBQUMvQywrQkFBUyxFQUFDO0FBRHFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFvQ0k7QUFBSyxtQkFBUyxFQUFDLHNDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsMEJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDSTtBQUFJLDJCQUFTLEVBQUMsZ0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQU9JO0FBQUksdUJBQVMsRUFBQyxhQUFkO0FBQUEsc0NBQ0k7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGSixlQUdJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhKLGVBSUk7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSkosZUFLSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMSixlQU1JO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXBDSixlQXVESTtBQUFLLG1CQUFTLEVBQUMsZ0NBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQywwQkFBZjtBQUFBLHFDQUNJO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNJO0FBQUksMkJBQVMsRUFBQyxnQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBT0k7QUFBSSx1QkFBUyxFQUFDLGFBQWQ7QUFBQSxzQ0FDSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQUVJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZKLGVBSUk7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSkosZUFNSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFOSixlQVFJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJKLGVBVUk7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdkRKLGVBOEVJO0FBQUssbUJBQVMsRUFBQyxnQ0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBCQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0k7QUFBSSwyQkFBUyxFQUFDLGdDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFNSTtBQUFHLHVCQUFTLEVBQUMsWUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFOSixlQVFJO0FBQUssdUJBQVMsRUFBQyxvQkFBZjtBQUFBLHFDQUNJO0FBQU0seUJBQVMsRUFBQywrQkFBaEI7QUFDSSxzQkFBTSxFQUFDLGFBRFg7QUFFSSxzQkFBTSxFQUFDLFFBRlg7QUFFb0Isc0JBQU0sRUFBQyxNQUYzQjtBQUFBLHVDQUlJO0FBQVEsMkJBQVMsRUFBQyxpQ0FBbEI7QUFBb0Qsc0JBQUksRUFBQyxRQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVJKLGVBa0JJO0FBQUssdUJBQVMsRUFBQyxjQUFmO0FBQUEsc0NBQ0k7QUFBRyxvQkFBSSxFQUFDLGFBQVI7QUFBc0IseUJBQVMsRUFBQztBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBSUk7QUFBRyxvQkFBSSxFQUFDLGFBQVI7QUFBc0IseUJBQVMsRUFBQztBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE5RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGQSxlQW1IQTtBQUFLLGFBQVMsRUFBQyxtQkFBZjtBQUFBLDJCQUNJO0FBQUssZUFBUyxFQUFDLFdBQWY7QUFBQSw2QkFDSTtBQUFLLGlCQUFTLEVBQUMsS0FBZjtBQUFBLGdDQUNJO0FBQUssbUJBQVMsRUFBQywwQkFBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxZQUFmO0FBQUEsbUNBQ0k7QUFBRyx1QkFBUyxFQUFDLGNBQWI7QUFBQSxvREFDTDtBQUFNLHlCQUFTLEVBQUMsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURLLDhCQUVQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZPLHNCQUdaO0FBQUcsc0JBQU0sRUFBQyxRQUFWO0FBQW1CLG9CQUFJLEVBQUMsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBVUk7QUFBSyxtQkFBUyxFQUFDLDBCQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFuSEE7QUFBQSxnQkFGRjs7S0FBTUEsZTtBQThJU0EsOEVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakpBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQyxhQUFhLEdBQUcsTUFBTTtBQUFBOztBQUMxQjVLLHlEQUFTLENBQUMsTUFBTTtBQUNkLGNBQXFCO0FBQ25CZ0ssWUFBTSxDQUFDYSxnQkFBUCxDQUF3QixRQUF4QixFQUFrQ0Msc0VBQWxDO0FBQ0Q7QUFDRixHQUpRLEVBSU4sRUFKTSxDQUFUO0FBTUEsc0JBQ0U7QUFBUSxhQUFTLEVBQUMsa0JBQWxCO0FBQXFDLG1CQUFZLE1BQWpEO0FBQXdELE1BQUUsRUFBQyxjQUEzRDtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw2QkFDRTtBQUFLLGFBQUssRUFBQyxjQUFYO0FBQUEsK0JBQ0U7QUFBSyxlQUFLLEVBQUMsNEJBQVg7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsYUFBZjtBQUFBLG1DQUNFO0FBQUksdUJBQVMsRUFBQyxTQUFkO0FBQUEscUNBQ0U7QUFBSSx5QkFBUyxFQUFDLFFBQWQ7QUFBQSx3Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQUdHLHFFQUFDLGdEQUFEO0FBQU0sc0JBQUksRUFBQyxnQkFBWDtBQUFBLHlDQUNQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRE87QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFISCxlQU1OLHFFQUFDLGdEQUFEO0FBQU0sc0JBQUksRUFBQyxnQkFBWDtBQUFBLHlDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFOTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXVCRTtBQUFLLGVBQVMsRUFBQyxhQUFmO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsY0FBZjtBQUFBLGlDQUNFLHFFQUFDLHdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBS0U7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxpQ0FDRSxxRUFBQyx1RkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMRixlQVFFO0FBQUssbUJBQVMsRUFBQyxrREFBZjtBQUFBLGlDQUNFO0FBQUcsZ0JBQUksRUFBQyxFQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFSRixlQVdFO0FBQUssbUJBQVMsRUFBQyxnQkFBZjtBQUFBLGlDQUNFLHFFQUFDLHVGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhGLGVBY0U7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQSxpQ0FDRSxxRUFBQyx3RkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQStDRCxDQXRERDs7R0FBTUYsYTs7S0FBQUEsYTtBQXdEU0EsNEVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNRyxRQUFRLGdCQUFHbFEsNENBQUssQ0FBQ0MsSUFBTixTQUFXLENBQUM7QUFBRWtRO0FBQUYsQ0FBRCxLQUFjO0FBQUE7O0FBQUE7O0FBQ3hDLE1BQUlDLGFBQUo7QUFDQSxRQUFNL1AsUUFBUSxHQUFHQywrREFBVyxFQUE1QjtBQUNBLFFBQU1jLElBQUksR0FBR0MsK0RBQVcsQ0FBRUMsS0FBRCxJQUFXQSxLQUFLLENBQUNGLElBQWxCLENBQXhCO0FBRUEsUUFBTWlQLHFCQUFxQixHQUFHRixJQUFILGFBQUdBLElBQUgsd0NBQUdBLElBQUksQ0FBRWpRLE9BQVQsa0RBQUcsY0FBZXFGLEdBQWYsQ0FBb0IrSyxXQUFEO0FBQUE7O0FBQUEsd0JBQy9DO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDLFVBQWI7QUFBQSxrQkFBeUJBLFdBQXpCLGFBQXlCQSxXQUF6QiwrQ0FBeUJBLFdBQVcsQ0FBRXhJLE1BQXRDLHlEQUF5QixxQkFBcUJBO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFFR3dJLFdBRkgsYUFFR0EsV0FGSCwrQ0FFR0EsV0FBVyxDQUFFeEksTUFGaEIsa0ZBRUcscUJBQXFCeUksUUFGeEIsMERBRUcsc0JBQStCaEwsR0FBL0IsQ0FBb0NpTCxXQUFELGlCQUNsQyxxRUFBQyxtRkFBRDtBQUFlLGVBQU8sRUFBRUE7QUFBeEIsU0FBMENBLFdBQTFDLGFBQTBDQSxXQUExQyx1QkFBMENBLFdBQVcsQ0FBRWpJLE9BQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREQsQ0FGSDtBQUFBLE9BQVUrSCxXQUFWLGFBQVVBLFdBQVYsOENBQVVBLFdBQVcsQ0FBRXhJLE1BQXZCLHdEQUFVLG9CQUFxQjJJLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRCtDO0FBQUEsR0FBbkIsQ0FBOUI7QUFRQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJsUSxzREFBUSxDQUFDLElBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQytOLFVBQUQ7QUFBQSxPQUFhb0M7QUFBYixNQUE4Qm5RLHNEQUFRLENBQUMsQ0FBRCxDQUE1QztBQUVBMEUseURBQVMsQ0FBQyxNQUFNO0FBQ2QxRCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUErQ3lPLElBQS9DLEVBRGMsQ0FFZjs7QUFDQyxRQUFJVSxTQUFTLEdBQUcsSUFBaEI7O0FBRUEsUUFBSUEsU0FBSixFQUFlO0FBQUE7O0FBQ2I7QUFDQSxZQUFNQyw4QkFBOEIsR0FBR1gsSUFBSCxhQUFHQSxJQUFILHlDQUFHQSxJQUFJLENBQUVqUSxPQUFULG1EQUFHLGVBQWU2USxNQUFmLENBQ3JDLENBQUNDLGVBQUQsRUFBa0JDLGVBQWxCLEtBQXNDO0FBQ3BDLGVBQ0VDLE1BQU0sQ0FBQ0YsZUFBRCxDQUFOLEdBRUNFLE1BQU0sQ0FBQ0QsZUFBZSxDQUFDbkosTUFBaEIsQ0FBdUJ5SSxRQUF2QixDQUFnQ2pHLE1BQWpDLENBSFQ7QUFLRCxPQVBvQyxFQVFyQyxDQVJxQyxDQUF2QztBQVdBc0csbUJBQWEsQ0FBQ0UsOEJBQUQsQ0FBYjtBQUNBSCxpQkFBVyxDQUFDUixJQUFELENBQVg7QUFDRDs7QUFDRCxXQUFPLE1BQU07QUFDWFUsZUFBUyxHQUFHLEtBQVo7QUFDRCxLQUZEO0FBR0QsR0F4QlEsRUF3Qk4sQ0FBQ1YsSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUVqUSxPQUFQLENBeEJNLENBQVQsQ0FoQndDLENBMEN4Qzs7QUFFRSxRQUFNaVIsV0FBVyxHQUFJdk8sT0FBRCxJQUFhO0FBQy9Cd08sU0FBSyxDQUFDLFNBQUQsQ0FBTCxDQUQrQixDQUVqQzs7QUFDQSxRQUFJelAsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdMLFFBQVgsQ0FBaEI7QUFDQSxRQUFJTyxZQUFZLEdBQUdKLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUE5QjtBQUNBLFVBQU1tUCxVQUFVLEdBQUduUCxZQUFuQjtBQUNBVCxXQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFxRDtBQUFDNFAsc0ZBQVVBO0FBQVgsS0FBckQ7QUFDQTdQLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDMlAsVUFBdEM7QUFDQTVQLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDNlAscUVBQXRDO0FBRUEsVUFBTUMsSUFBSSxHQUFHQyw0Q0FBSyxDQUFDQyxJQUFOLENBQ1YsR0FBRUosb0VBQVcsb0JBREgsRUFFWDtBQUNFcFAsa0JBQVksRUFBRW1QLFVBRGhCO0FBRUUxQyxhQUFPLEVBQUUsQ0FGWDtBQUdFZ0QsZUFBUyxFQUFFSixxRUFIYjtBQUlFSyxjQUFRLEVBQUUsaUNBSlo7QUFLRUMsYUFBTyxFQUFFO0FBTFgsS0FGVyxFQVNWQyxJQVRVLENBU0puTyxRQUFELElBQWNBLFFBQVEsQ0FBQzZOLElBVGxCLEVBVVZNLElBVlUsQ0FVSk4sSUFBRCxJQUFVO0FBQ2QvUCxhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWixFQUFvRDhQLElBQXBELEVBRGMsQ0FFbEI7O0FBQ0ksVUFBSUEsSUFBSSxDQUFDak8sUUFBTCxJQUFpQixHQUFqQixJQUF3QmlPLElBQUksQ0FBQzlOLE1BQUwsSUFBZSxPQUEzQyxFQUFvRCxDQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUNELFVBQUk4TixJQUFJLENBQUNqTyxRQUFMLElBQWlCLEdBQWpCLElBQXdCaU8sSUFBSSxDQUFDOU4sTUFBTCxJQUFlLFNBQTNDLEVBQXNEO0FBQ3BEaU4sbUJBQVcsQ0FBQ2EsSUFBSSxDQUFDQSxJQUFOLENBQVg7QUFDQVoscUJBQWEsQ0FBQ1ksSUFBSSxDQUFDQSxJQUFMLENBQVVPLFVBQVgsQ0FBYixDQUZvRCxDQUd2RDtBQUNDO0FBQ0U7QUFDQTtBQUNBO0FBQ0Q7O0FBQ0M7QUFDRDtBQUNGLEtBOUJVLEVBK0JWQyxLQS9CVSxDQStCSEMsS0FBRCxJQUFXLENBQ2hCO0FBQ0E7QUFDQTtBQUNELEtBbkNVLENBQWI7QUFzQ0N4USxXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQzZQLHFFQUF0QyxFQWpEZ0MsQ0FrRGxDO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELEdBeEVDOztBQXlFRnBNLHlEQUFTLENBQUMsTUFBTTtBQUNkMUQsV0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQnlPLElBQXRCO0FBQ0FnQixlQUFXOztBQUNYLFFBQUloQixJQUFJLElBQUloTyxTQUFaLEVBQXVCO0FBQ3RCO0FBQ0MsT0FBQWYsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUVjLFlBQU4sS0FBc0I3QixRQUFRLENBQUNvRCxrRUFBTyxFQUFSLENBQTlCO0FBQ0Q7QUFDRixHQVBRLEVBT04sQ0FBQ3JDLElBQUksQ0FBQ2MsWUFBTixFQUFvQmlPLElBQXBCLGFBQW9CQSxJQUFwQix1QkFBb0JBLElBQUksQ0FBRWpRLE9BQTFCLENBUE0sQ0FBVDs7QUFTQSxNQUNFd1EsUUFBUSxLQUFLLElBQWIsSUFDQUEsUUFBUSxLQUFLdk8sU0FEYixJQUVBdU8sUUFGQSxhQUVBQSxRQUZBLG9DQUVBQSxRQUFRLENBQUV4USxPQUZWLDhDQUVBLGtCQUFtQm9LLE1BRm5CLElBR0EsQ0FBQW9HLFFBQVEsU0FBUixJQUFBQSxRQUFRLFdBQVIsa0NBQUFBLFFBQVEsQ0FBRXhRLE9BQVYsMEVBQW1Cb0ssTUFBbkIsTUFBOEIsQ0FKaEMsRUFLRTtBQUFBOztBQUNBOEYsaUJBQWEsZ0JBQ1g7QUFBSyxlQUFTLEVBQUMsa0JBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSxrQkFBaUNDO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLGlCQUFTLEVBQUMsaUJBQWY7QUFBQSxnQ0FDRTtBQUFBLGdEQUVFO0FBQUEsc0JBQ0dLLFFBQVEsSUFBSUEsUUFBUSxLQUFLLElBQXpCLElBQWlDLENBQUFBLFFBQVEsU0FBUixJQUFBQSxRQUFRLFdBQVIsa0NBQUFBLFFBQVEsQ0FBRXhRLE9BQVYsMEVBQW1Cb0ssTUFBbkIsSUFBNEIsQ0FBN0QsR0FDRzFELGdHQUE4QixDQUFDOEosUUFBUSxDQUFDd0IsV0FBVixDQURqQyxHQUVHO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFTRTtBQUFBLGtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksRUFBQyx3QkFBWDtBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksRUFBQyxtQkFBWDtBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQXVCRCxHQTdCRCxNQTZCTztBQUNMOUIsaUJBQWEsZ0JBQ1g7QUFBSyxlQUFTLEVBQUMsa0JBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSwrQkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBT0Q7O0FBRUQsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsZUFBZjtBQUFBLDRCQUNFO0FBQUcsZUFBUyxFQUFDLGVBQWI7QUFBNkIsVUFBSSxFQUFDLEdBQWxDO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUEsK0JBQ0U7QUFBQSxvQkFDR00sUUFBUSxLQUFLLElBQWIsSUFBcUJBLFFBQVEsS0FBS3ZPLFNBQWxDLElBQStDcU0sVUFBVSxHQUFHLENBQTVELEdBQ0dBLFVBREgsR0FFRztBQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixFQVdHNEIsYUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBcExnQjtBQUFBLFVBRUU5UCx1REFGRixFQUdGZSx1REFIRTtBQUFBLEdBQWpCO01BQU02TyxRO0FBc0xTaUMsMEhBQU8sQ0FBRTdRLEtBQUQsSUFBV0EsS0FBSyxDQUFDNk8sSUFBbEIsQ0FBUCxDQUErQkQsUUFBL0IsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTWtDLGlCQUFpQixHQUFHLENBQ3hCO0FBQ0U1SSxJQUFFLEVBQUUsRUFETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBRHdCLEVBS3hCO0FBQ0U3SSxJQUFFLEVBQUUsQ0FETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBTHdCLEVBU3hCO0FBQ0U3SSxJQUFFLEVBQUUsQ0FETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBVHdCLEVBYXhCO0FBQ0U3SSxJQUFFLEVBQUUsQ0FETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBYndCLEVBaUJ4QjtBQUNFN0ksSUFBRSxFQUFFLENBRE47QUFFRTZJLGVBQWEsRUFBRTtBQUZqQixDQWpCd0IsRUFxQnhCO0FBQ0U3SSxJQUFFLEVBQUUsQ0FETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBckJ3QixFQXlCeEI7QUFDRTdJLElBQUUsRUFBRSxFQUROO0FBRUU2SSxlQUFhLEVBQUU7QUFGakIsQ0F6QndCLEVBNkJ4QjtBQUNFN0ksSUFBRSxFQUFFLEVBRE47QUFFRTZJLGVBQWEsRUFBRTtBQUZqQixDQTdCd0IsRUFpQ3hCO0FBQ0U3SSxJQUFFLEVBQUUsRUFETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBakN3QixFQXFDeEI7QUFDRTdJLElBQUUsRUFBRSxFQUROO0FBRUU2SSxlQUFhLEVBQUU7QUFGakIsQ0FyQ3dCLEVBeUN4QjtBQUNFN0ksSUFBRSxFQUFFLEVBRE47QUFFRTZJLGVBQWEsRUFBRTtBQUZqQixDQXpDd0IsRUE2Q3hCO0FBQ0U3SSxJQUFFLEVBQUUsRUFETjtBQUVFNkksZUFBYSxFQUFFO0FBRmpCLENBN0N3QixFQWlEeEI7QUFDRTdJLElBQUUsRUFBRSxFQUROO0FBRUU2SSxlQUFhLEVBQUU7QUFGakIsQ0FqRHdCLENBQTFCOztBQXVEQSxTQUFTQyxXQUFULENBQXFCMU0sS0FBckIsRUFBNEIyTSxLQUE1QixFQUFtQztBQUFBOztBQUNqQyxRQUFNO0FBQUEsT0FBQ0MsY0FBRDtBQUFBLE9BQWlCQztBQUFqQixNQUFzQ2hTLHNEQUFRLENBQUNtRixLQUFELENBQXBEO0FBQ0FULHlEQUFTLENBQUMsTUFBTTtBQUNkO0FBQ0EsVUFBTXVOLE9BQU8sR0FBRzlPLFVBQVUsQ0FBQyxNQUFNO0FBQy9CNk8sdUJBQWlCLENBQUM3TSxLQUFELENBQWpCO0FBQ0QsS0FGeUIsRUFFdkIyTSxLQUZ1QixDQUExQjtBQUlBLFdBQU8sTUFBTTtBQUNYSSxrQkFBWSxDQUFDRCxPQUFELENBQVo7QUFDRCxLQUZEO0FBR0QsR0FUUSxFQVNOLENBQUM5TSxLQUFELEVBQVEyTSxLQUFSLENBVE0sQ0FBVDtBQVdBLFNBQU9DLGNBQVA7QUFDRDs7R0FkUUYsVzs7QUFnQlQsTUFBTU0sWUFBWSxHQUFHLE1BQU07QUFBQTs7QUFDekIsUUFBTUMsT0FBTyxHQUFHQyxvREFBTSxDQUFDLElBQUQsQ0FBdEI7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJ2UyxzREFBUSxDQUFDLEtBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3dTLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCelMsc0RBQVEsQ0FBQyxFQUFELENBQXRDO0FBQ0EsUUFBTTtBQUFBLE9BQUN3TSxRQUFEO0FBQUEsT0FBV2tHO0FBQVgsTUFBMEIxUyxzREFBUSxDQUFDLEVBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQzJTLFdBQUQ7QUFBQSxPQUFjQztBQUFkLE1BQWdDNVMsc0RBQVEsQ0FBQyxJQUFELENBQTlDO0FBQ0EsUUFBTTtBQUFBLE9BQUMwSixPQUFEO0FBQUEsT0FBVTZEO0FBQVYsTUFBd0J2TixzREFBUSxDQUFDLEtBQUQsQ0FBdEM7QUFDQSxRQUFNNlMsbUJBQW1CLEdBQUdoQixXQUFXLENBQUNXLE9BQUQsRUFBVSxJQUFWLENBQXZDOztBQUVBLFdBQVNNLGtCQUFULEdBQThCO0FBQzVCTCxjQUFVLENBQUMsRUFBRCxDQUFWO0FBQ0FGLGVBQVcsQ0FBQyxLQUFELENBQVg7QUFDQWhGLGNBQVUsQ0FBQyxLQUFELENBQVY7QUFDRDs7QUFFRCxXQUFTd0YsWUFBVCxDQUFzQmhTLENBQXRCLEVBQXlCO0FBQ3ZCQSxLQUFDLENBQUM0TSxjQUFGO0FBQ0F4TixzREFBTSxDQUFDaUQsSUFBUCxDQUFhLG1CQUFrQm9QLE9BQVEsRUFBdkM7QUFDRDs7QUFDRCxRQUFNO0FBQUEsT0FBQ1Esa0JBQUQ7QUFBQSxPQUFxQkM7QUFBckIsTUFBOENqVCxzREFBUSxDQUFDLENBQzNEO0FBQ0VtTyxlQUFXLEVBQUUsRUFEZjtBQUVFeUQsaUJBQWEsRUFBRTtBQUZqQixHQUQyRCxDQUFELENBQTVEO0FBT0FsTix5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJd08sWUFBWSxHQUFHLElBQW5COztBQUNBLFVBQU1DLHVCQUF1QixHQUFHLFlBQVk7QUFDMUMsVUFBSTtBQUNGLGNBQU1qUSxRQUFRLEdBQUcsTUFBTU4sdUVBQWlCLENBQUN3USxvQkFBbEIsRUFBdkI7QUFDQUYsb0JBQVksR0FDUkQscUJBQXFCLENBQUMsQ0FDcEI7QUFDRTlFLHFCQUFXLEVBQUUsRUFEZjtBQUVFeUQsdUJBQWEsRUFBRTtBQUZqQixTQURvQixFQUtwQixHQUFHMU8sUUFBUSxDQUFDNk4sSUFBVCxDQUFjc0MsVUFMRyxDQUFELENBRGIsR0FRUixJQVJKO0FBU0QsT0FYRCxDQVdFLE9BQU83QixLQUFQLEVBQWM7QUFDZHhRLGVBQU8sQ0FBQ3dRLEtBQVIsQ0FBY0EsS0FBZDtBQUNEO0FBQ0YsS0FmRDs7QUFpQkEyQiwyQkFBdUI7QUFFdkIsV0FBTyxNQUFPRCxZQUFZLEdBQUcsS0FBN0I7QUFDRCxHQXRCUSxFQXNCTixFQXRCTSxDQUFUO0FBd0JBeE8seURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSW1PLG1CQUFKLEVBQXlCO0FBQ3ZCdEYsZ0JBQVUsQ0FBQyxJQUFELENBQVY7O0FBQ0EsVUFBSWlGLE9BQUosRUFBYTtBQUNYLGNBQU1jLE9BQU8sR0FBRztBQUNkQyxnQkFBTSxFQUFFLENBRE07QUFFZEMsd0JBQWMsRUFBRWhCLE9BRkY7QUFHZHJFLHFCQUFXLEVBQUUzQjtBQUhDLFNBQWhCLENBRFcsQ0FNWDs7QUFDQSxjQUFNc0QsUUFBUSxHQUFHbE4sdUVBQWlCLENBQUM2USxtQkFBbEIsQ0FBc0NILE9BQXRDLENBQWpCO0FBRUF4RCxnQkFBUSxDQUFDdUIsSUFBVCxDQUFlcUMsTUFBRCxJQUFZO0FBQ3hCbkcsb0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDQXFGLHdCQUFjLENBQUNjLE1BQU0sQ0FBQzVGLEtBQVIsQ0FBZDtBQUNBeUUscUJBQVcsQ0FBQyxJQUFELENBQVg7QUFDRCxTQUpEO0FBS0QsT0FkRCxNQWNPO0FBQ0xBLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0FFLGtCQUFVLENBQUMsRUFBRCxDQUFWO0FBQ0Q7O0FBQ0QsVUFBSS9JLE9BQUosRUFBYTtBQUNYNkksbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGLEtBdkJELE1BdUJPO0FBQ0xoRixnQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNBZ0YsaUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGLEdBNUJRLEVBNEJOLENBQUNNLG1CQUFELENBNUJNLENBQVQsQ0FsRHlCLENBZ0Z6Qjs7QUFDQSxNQUFJNUQsZ0JBQUosRUFDRTBFLGFBREYsRUFFRUMsZ0JBRkYsRUFHRUMsV0FIRixFQUlFQyxZQUpGOztBQUtBLE1BQUksQ0FBQ3BLLE9BQUwsRUFBYztBQUNaLFFBQUlpSixXQUFXLElBQUlBLFdBQVcsQ0FBQzlJLE1BQVosR0FBcUIsQ0FBeEMsRUFBMkM7QUFDekMsVUFBSThJLFdBQVcsQ0FBQzlJLE1BQVosR0FBcUIsQ0FBekIsRUFBNEI7QUFDMUJpSyxvQkFBWSxnQkFDVjtBQUFLLG1CQUFTLEVBQUMsOEJBQWY7QUFBQSxpQ0FDRSxxRUFBQyxnREFBRDtBQUFNLGdCQUFJLEVBQUMsU0FBWDtBQUFBLG1DQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFPRDs7QUFDRDdFLHNCQUFnQixHQUFHMEQsV0FBVyxDQUFDN04sR0FBWixDQUFpQnJGLE9BQUQsaUJBQ2pDLHFFQUFDLHlGQUFEO0FBQXFCLGVBQU8sRUFBRUE7QUFBOUIsU0FBNENBLE9BQU8sQ0FBQ3NKLEVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRGlCLENBQW5CO0FBR0QsS0FiRCxNQWFPO0FBQ0xrRyxzQkFBZ0IsZ0JBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW5CO0FBQ0Q7O0FBQ0QsUUFBSXVELE9BQU8sS0FBSyxFQUFoQixFQUFvQjtBQUNsQm1CLG1CQUFhLGdCQUNYO0FBQU0saUJBQVMsRUFBQyxpQkFBaEI7QUFBa0MsZUFBTyxFQUFFYixrQkFBM0M7QUFBQSwrQkFDRTtBQUFHLG1CQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQUtEO0FBQ0YsR0F4QkQsTUF3Qk87QUFDTGUsZUFBVyxnQkFDVDtBQUFNLGVBQVMsRUFBQyxpQkFBaEI7QUFBQSw2QkFDRSxxRUFBQyx5Q0FBRDtBQUFNLFlBQUksRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBS0Q7O0FBRUQsTUFBSSxDQUFBYixrQkFBa0IsU0FBbEIsSUFBQUEsa0JBQWtCLFdBQWxCLFlBQUFBLGtCQUFrQixDQUFFbkosTUFBcEIsSUFBNkIsQ0FBakMsRUFBb0M7QUFDbEMrSixvQkFBZ0IsR0FBR1osa0JBQUgsYUFBR0Esa0JBQUgsdUJBQUdBLGtCQUFrQixDQUFFbE8sR0FBcEIsQ0FBd0IsQ0FBQ2lQLE1BQUQsRUFBU3BPLEtBQVQsS0FBbUI7QUFDNUQsMEJBQ0U7QUFBUSxhQUFLLEVBQUVvTyxNQUFNLENBQUM1RixXQUF0QjtBQUFBLGtCQUNHNEYsTUFBTSxDQUFDbkM7QUFEVixTQUF3Q2pNLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREY7QUFLRCxLQU5rQixDQUFuQjtBQU9EOztBQUNELHNCQUNFO0FBQ0UsYUFBUyxFQUFDLHVCQURaO0FBRUUsVUFBTSxFQUFDLEtBRlQ7QUFHRSxVQUFNLEVBQUMsR0FIVDtBQUlFLFlBQVEsRUFBRW9OLFlBSlo7QUFBQSw0QkFpQkU7QUFBSyxlQUFTLEVBQUMsZ0JBQWY7QUFBQSw4QkFDRTtBQUNFLFdBQUcsRUFBRVgsT0FEUDtBQUVFLGlCQUFTLEVBQUMsY0FGWjtBQUdFLFlBQUksRUFBQyxNQUhQO0FBSUUsYUFBSyxFQUFFSSxPQUpUO0FBS0UsbUJBQVcsRUFBQyxxQkFMZDtBQU1FLGdCQUFRLEVBQUd6UixDQUFELElBQU8wUixVQUFVLENBQUMxUixDQUFDLENBQUNtRSxNQUFGLENBQVNDLEtBQVY7QUFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQVNHd08sYUFUSCxFQVVHRSxXQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkYsZUE4QkU7QUFBSyxlQUFTLEVBQUcsMEJBQXlCdkIsUUFBUSxHQUFHLFVBQUgsR0FBZ0IsRUFBRyxFQUFyRTtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxtQkFBZjtBQUFBLGtCQUFvQ3JEO0FBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFFRzZFLFlBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFDRCxDQXBLRDs7SUFBTTNCLFk7VUFPd0JOLFc7OztLQVB4Qk0sWTtBQXNLU0EsMkVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTTZCLHNCQUFzQixHQUFHLE1BQU07QUFBQTs7QUFBQTs7QUFDbkMsUUFBTTtBQUFBLE9BQUNoQixrQkFBRDtBQUFBLE9BQXFCQztBQUFyQixNQUE4Q2pULHNEQUFRLENBQUMsRUFBRCxDQUE1RDs7QUFFQSxRQUFNbVQsdUJBQXVCLEdBQUcsWUFBWTtBQUMxQyxRQUFJO0FBQ0YsWUFBTWpRLFFBQVEsR0FBRyxNQUFNOE4sNENBQUssQ0FBQ0MsSUFBTixDQUNwQixHQUFFSixtRUFBVywwQkFETyxDQUF2QjtBQUdBb0MsMkJBQXFCLENBQUMvUCxRQUFRLENBQUM2TixJQUFWLENBQXJCO0FBQ0QsS0FMRCxDQUtFLE9BQU9TLEtBQVAsRUFBYztBQUNkeFEsYUFBTyxDQUFDd1EsS0FBUixDQUFjQSxLQUFkO0FBQ0Q7QUFDRixHQVREOztBQVdBLFFBQU07QUFBRXlDO0FBQUYsTUFBZXJULCtEQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDcVQsSUFBbEIsQ0FBaEM7QUFFQXhQLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUl1TixPQUFKO0FBQ0FBLFdBQU8sR0FBRzlPLFVBQVUsQ0FBQyxZQUFZO0FBQy9CLFlBQU1nUSx1QkFBdUIsRUFBN0I7QUFDRCxLQUZtQixFQUVqQixHQUZpQixDQUFwQjtBQUdBLFdBQU8sTUFBTTtBQUNYakIsa0JBQVksQ0FBQ0QsT0FBRCxDQUFaO0FBQ0QsS0FGRDtBQUdELEdBUlEsRUFRTixDQUFDZ0MsUUFBRCxDQVJNLENBQVQ7QUFVQSxzQkFDRTtBQUFLLGFBQVMsRUFBQywwQkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLGNBQWY7QUFBQSw4QkFDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBS0U7QUFBSyxlQUFTLEVBQUMsZUFBZjtBQUFBLDZCQUNFLHFFQUFDLDRFQUFEO0FBQ0UsY0FBTSxFQUFFakIsa0JBQUYsYUFBRUEsa0JBQUYsZ0RBQUVBLGtCQUFrQixDQUFFakMsSUFBdEIsMERBQUUsc0JBQTBCc0MsVUFEcEM7QUFFRSxpQkFBUyxFQUFDO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFjRCxDQXhDRDs7R0FBTVcsc0I7VUFjaUJwVCx1RDs7O0tBZGpCb1Qsc0I7QUEwQ1NBLHFGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1HLG1CQUFtQixHQUFHLE1BQU07QUFBQTs7QUFBQTs7QUFDaEMsUUFBTTtBQUFBLE9BQUMxSyxTQUFEO0FBQUEsT0FBWTJLO0FBQVosTUFBNEJwVSxzREFBUSxDQUFDLEVBQUQsQ0FBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQ3FVLFlBQUQ7QUFBQSxPQUFlQztBQUFmLE1BQStCdFUsc0RBQVEsQ0FBQyxFQUFELENBQTdDO0FBQ0EsUUFBTTtBQUFBLE9BQUMwSixPQUFEO0FBQUEsT0FBVTZEO0FBQVYsTUFBd0J2TixzREFBUSxDQUFDLElBQUQsQ0FBdEM7QUFDQSxRQUFNdVUsTUFBTSxHQUFHblUsOERBQVMsRUFBeEI7QUFDQSxRQUFNUixRQUFRLEdBQUdDLGdFQUFXLEVBQTVCOztBQUVBLGlCQUFlMlUsWUFBZixHQUE4QjtBQUM1QixRQUFJN1IsWUFBWSxHQUFHLE1BQU04UiwyRUFBVyxDQUFDRixNQUFNLENBQUNHLE1BQVIsQ0FBcEM7O0FBQ0EsUUFBSS9SLFlBQUosRUFBa0I7QUFDaEIvQyxjQUFRLENBQUMrVSwwRUFBYyxDQUFDaFMsWUFBWSxDQUFDb08sSUFBZCxDQUFmLENBQVI7QUFDQXFELGtCQUFZLENBQUN6UixZQUFZLENBQUNvTyxJQUFkLENBQVo7QUFDRDs7QUFDRDVOLGNBQVUsQ0FBQyxNQUFNO0FBQ2ZvSyxnQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNELEtBRlMsRUFFUCxHQUZPLENBQVY7QUFHRDs7QUFDRCxRQUFNakUsS0FBSyxHQUFHLE1BQU07QUFDbEJ0SSxXQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFxRDtBQUFDNFAsc0ZBQVVBO0FBQVgsS0FBckQ7QUFDQSxVQUFNRSxJQUFJLEdBQUdDLDZDQUFLLENBQUNDLElBQU4sQ0FDVixHQUFFSixvRUFBVywwQkFESCxFQUVWUSxJQUZVLENBRUpuTyxRQUFELElBQWNBLFFBQVEsQ0FBQzZOLElBRmxCLEVBR1ZNLElBSFUsQ0FHSk4sSUFBRCxJQUFVO0FBQ2QvUCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBWixFQUFtQzhQLElBQW5DLEVBRGMsQ0FFbEI7O0FBQ0ksVUFBSUEsSUFBSSxDQUFDak8sUUFBTCxJQUFpQixHQUFqQixJQUF3QmlPLElBQUksQ0FBQzlOLE1BQUwsSUFBZSxPQUEzQyxFQUFvRCxDQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNEOztBQUNELFVBQUk4TixJQUFJLENBQUNqTyxRQUFMLElBQWlCLEdBQWpCLElBQXdCaU8sSUFBSSxDQUFDOU4sTUFBTCxJQUFlLFNBQTNDLEVBQXNEO0FBQ3BEcVIsb0JBQVksQ0FBQ3ZELElBQUksQ0FBQ0EsSUFBTixDQUFaLENBRG9ELENBRXBEO0FBQ0E7QUFDQTtBQUNEOztBQUNDO0FBQ0Q7QUFDRixLQXBCVSxFQXFCVlEsS0FyQlUsQ0FxQkhDLEtBQUQsSUFBVztBQUNoQjdQLGtCQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCQyxlQUFPLEVBQUU0UDtBQURXLE9BQXRCO0FBR0QsS0F6QlUsQ0FBYjtBQTBCRCxHQTVCRDs7QUE2QkEsUUFBTTtBQUFFeUM7QUFBRixNQUFlclQsZ0VBQVcsQ0FBRUMsS0FBRCxJQUFXQSxLQUFLLENBQUNxVCxJQUFsQixDQUFoQztBQUNBeFAseURBQVMsQ0FBQyxNQUFNO0FBQ2QxRCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QmdULFFBQTlCOztBQUNBLFFBQUlBLFFBQVEsSUFBSSxJQUFoQixFQUFzQjtBQUNwQk8sa0JBQVk7QUFDYixLQUZELE1BRU87QUFDTEosa0JBQVksQ0FBQ0gsUUFBRCxDQUFaO0FBQ0E5USxnQkFBVSxDQUFDLE1BQU07QUFDZm9LLGtCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0QsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdEOztBQUVMakUsU0FBSztBQUNGLEdBWlEsRUFZTixDQUFDMkssUUFBRCxDQVpNLENBQVQ7QUFjQSxzQkFDRSxxRUFBQywwQ0FBRDtBQUFNLFlBQVEsRUFBRXZLLE9BQWhCO0FBQUEsMkJBQ0UscUVBQUMsZ0ZBQUQ7QUFBc0IsV0FBSyxFQUFDLFlBQTVCO0FBQUEsOEJBQ0UscUVBQUMscUdBQUQ7QUFBbUIsaUJBQVMsRUFBRUQsU0FBOUI7QUFBeUMsZUFBTyxFQUFFQztBQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLEVBSUksQ0FBQ0EsT0FBRCxJQUFZRCxTQUFaLElBQXlCLENBQUFBLFNBQVMsU0FBVCxJQUFBQSxTQUFTLFdBQVQsbUNBQUFBLFNBQVMsQ0FBRStDLFFBQVgsNEVBQXFCM0MsTUFBckIsSUFBOEIsQ0FBdkQsaUJBQ0EscUVBQUMscUdBQUQ7QUFDRSxzQkFBYyxFQUFDLGlCQURqQjtBQUVFLGlCQUFTLEVBQUVKLFNBRmI7QUFHRSxlQUFPLEVBQUVDO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMSixlQVdFLHFFQUFDLDRFQUFEO0FBQWEsaUJBQVMsRUFBRUQ7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRixFQWFHLENBQUNDLE9BQUQsSUFBWUQsU0FBWixJQUF5QixDQUFBQSxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUVtTCxhQUFYLGdGQUEwQi9LLE1BQTFCLElBQW1DLENBQTVELGlCQUNDLHFFQUFDLGdHQUFEO0FBQ0Usc0JBQWMsRUFBQyxpQkFEakI7QUFFRSxpQkFBUyxFQUFFSixTQUZiO0FBR0UsZUFBTyxFQUFFQztBQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEosZUF1QksscUVBQUMseUZBQUQ7QUFBUyxpQkFBUyxFQUFFRCxTQUFwQjtBQUErQixlQUFPLEVBQUVDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkJMLEVBeUJNLENBQUNBLE9BQUQsSUFBWUQsU0FBWixJQUF5QixDQUFBQSxTQUFTLFNBQVQsSUFBQUEsU0FBUyxXQUFULHFDQUFBQSxTQUFTLENBQUVvTCxZQUFYLGdGQUF5QmhMLE1BQXpCLElBQWtDLENBQTNELGlCQUNGLHFFQUFDLG9HQUFEO0FBQ0Usc0JBQWMsRUFBQyxpQkFEakI7QUFFRSxpQkFBUyxFQUFFSixTQUZiO0FBR0UsZUFBTyxFQUFFQztBQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMUJKLGVBd0NFLHFFQUFDLG1HQUFEO0FBQWtCLGlCQUFTLEVBQUVELFNBQTdCO0FBQXdDLGVBQU8sRUFBRUM7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4Q0YsZUEwQ0UscUVBQUMsa0dBQUQ7QUFBZ0IsaUJBQVMsRUFBRUQsU0FBM0I7QUFBc0MsZUFBTyxFQUFFQztBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFDRixlQWtERTtBQUFLLGlCQUFTLEVBQUMsYUFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxjQUFmO0FBQUEsaUNBQ0UscUVBQUMsdUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUE0REQsQ0F6SEQ7O0dBQU15SyxtQjtVQUlXL1Qsc0QsRUFDRVAsd0QsRUF5Q0llLHdEOzs7S0E5Q2pCdVQsbUI7QUEySFNBLGtGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTVcsT0FBTixDQUFjO0FBQ1osUUFBTUwsV0FBTixDQUFrQk0sUUFBbEIsRUFBNEI7QUFDMUIsUUFBSTVTLE9BQU8sR0FBRztBQUNaVixrQkFBWSxFQUFFLEVBREY7QUFFWnlNLGFBQU8sRUFBRSxDQUZHO0FBR1pnRCxlQUFTLEVBQUVKLHFFQUhDO0FBSVpLLGNBQVEsRUFBRTZELDZFQUFXLENBQUMsR0FBRCxDQUpUO0FBS1o1RCxhQUFPLEVBQUU2RCx3RUFBTTtBQUxILEtBQWQ7QUFRQSxVQUFNQyxXQUFXLEdBQUdDLDRDQUFLLENBQUNELFdBQTFCO0FBQ0EsUUFBSUUsTUFBTSxHQUFHRixXQUFXLENBQUNFLE1BQVosRUFBYjtBQUVBQSxVQUFNLElBQUlBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLHdDQUFkLENBQVYsQ0FaMEIsQ0FhMUI7O0FBQ0FELFVBQU0sR0FBR0QsNENBQUssQ0FBQ0QsV0FBTixDQUFrQkUsTUFBbEIsRUFBVDtBQUVBLFVBQU1FLE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyxvQkFETSxFQUVwQjFPLE9BRm9CLEVBR3BCO0FBQ0VxVCxpQkFBVyxFQUFFSixNQUFNLENBQUM1VDtBQUR0QixLQUhvQixFQU9uQjZQLElBUG1CLENBT2JuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQVRtQixFQVVuQlEsS0FWbUIsQ0FVWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBVmEsQ0FBdEIsQ0FoQjBCLENBMkIxQjs7QUFDQTRELFVBQU0sQ0FBQ0MsTUFBUCxDQUFjLGlDQUFkO0FBQ0EsV0FBT0MsT0FBUDtBQUNEOztBQUVELFFBQU1JLFlBQU4sQ0FBbUJ2VCxPQUFuQixFQUE0QjtBQUMxQixVQUFNbVQsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLG1DQURNLEVBRXBCMU8sT0FGb0IsRUFJbkJrUCxJQUptQixDQUlibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJRLEtBUG1CLENBT1pDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNSyxrQkFBTixDQUF5QnhULE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsa0NBRE0sRUFFcEIxTyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQU5tQixFQU9uQlEsS0FQbUIsQ0FPWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPOEQsT0FBUDtBQUNELEdBdkRXLENBd0RaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQWxFWTs7QUFxRUMsbUVBQUlSLE9BQUosRUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekVBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7O0FBT0EsTUFBTWxTLGlCQUFOLENBQXdCO0FBQ3RCLFFBQU1nVCxVQUFOLENBQWlCL0gsTUFBakIsRUFBeUI7QUFDdkIsVUFBTXlILE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDTSxHQUFYLENBQ25CLEdBQUVDLG1EQUFRLGFBQVlDLGtFQUFjLENBQUNsSSxNQUFELENBQVMsRUFEMUIsRUFHbkJ3RCxJQUhtQixDQUdibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FMbUIsRUFNbkJRLEtBTm1CLENBTVpDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQU5hLENBQXRCO0FBT0EsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNN0IsbUJBQU4sQ0FBMEI1RixNQUExQixFQUFrQztBQUNoQyxVQUFNeUgsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLDhCQURNLEVBRXBCO0FBQ0UzQyxhQUFPLEVBQUUsRUFEWDtBQUVFQyxpQkFBVyxFQUFFTixNQUFNLENBQUNNLFdBRnRCO0FBR0VxRSxhQUFPLEVBQUUzRSxNQUFNLENBQUMyRjtBQUhsQixLQUZvQixFQVFuQm5DLElBUm1CLENBUWJuTyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMNEssYUFBSyxFQUFFNUssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1CakIsUUFEckI7QUFFTC9CLGtCQUFVLEVBQUU3SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJpRjtBQUYxQixPQUFQO0FBSUQsS0FibUIsRUFlbkJ6RSxLQWZtQixDQWVaQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FmYSxDQUF0QjtBQWdCQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU0xSCxXQUFOLENBQWtCQyxNQUFsQixFQUEwQjtBQUN4QixVQUFNeUgsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLGtDQUFkLEdBQWtEaEQsTUFBTSxDQUFDdEIsSUFEckMsRUFFcEI7QUFDRTJCLGFBQU8sRUFBRSxDQURYO0FBRUV6TSxrQkFBWSxFQUFFLEVBRmhCO0FBR0V5UCxlQUFTLEVBQUVKLHFFQUhiO0FBSUVLLGNBQVEsRUFBRSxpQ0FKWjtBQUtFQyxhQUFPLEVBQUU7QUFMWCxLQUZvQixFQVVuQkMsSUFWbUIsQ0FVYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0w0SyxhQUFLLEVBQUU1SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJqQixRQURyQjtBQUVML0Isa0JBQVUsRUFBRTdLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmtGO0FBRjFCLE9BQVA7QUFJRCxLQWZtQixFQWlCbkIxRSxLQWpCbUIsQ0FpQlpDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQWpCYSxDQUF0QjtBQWtCQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1ZLG1CQUFOLENBQTBCL1QsT0FBMUIsRUFBbUMwTCxNQUFuQyxFQUEyQztBQUN6QyxVQUFNeUgsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLG1DQUFkLEdBQW1EaEQsTUFBTSxDQUFDdEIsSUFEdEMsRUFFcEJwSyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMNEssYUFBSyxFQUFFNUssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1CakIsUUFEckI7QUFFTC9CLGtCQUFVLEVBQUU3SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJrRjtBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkIxRSxLQVhtQixDQVdaQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWEsdUJBQU4sQ0FBOEJoVSxPQUE5QixFQUF1QzBMLE1BQXZDLEVBQStDO0FBQzdDLFVBQU15SCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcseUNBQWQsR0FBeURoRCxNQUFNLENBQUN0QixJQUQ1QyxFQUVwQnBLLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0w0SyxhQUFLLEVBQUU1SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJxRixVQURyQjtBQUVMckksa0JBQVUsRUFBRTdLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmtGO0FBRjFCLE9BQVA7QUFJRCxLQVRtQixFQVduQjFFLEtBWG1CLENBV1pDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNZSxtQkFBTixDQUEwQmxVLE9BQTFCLEVBQW1DMEwsTUFBbkMsRUFBMkM7QUFDekMsVUFBTXlILE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyxzQ0FBZCxHQUFzRGhELE1BQU0sQ0FBQ3RCLElBRHpDLEVBRXBCcEssT0FGb0IsRUFJbkJrUCxJQUptQixDQUlibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTDRLLGFBQUssRUFBRTVLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmpCLFFBRHJCO0FBRUwvQixrQkFBVSxFQUFFN0ssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0Y7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMUUsS0FYbUIsQ0FXWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU0vRyxtQkFBTixDQUEwQnBNLE9BQTFCLEVBQW1DO0FBQ2pDLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcseUNBQWQsR0FBeUQxTyxPQUFPLENBQUNvSyxJQUQ3QyxFQUVwQnBLLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQmxDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBMkJpQyxRQUEzQjtBQUNBLGFBQU87QUFDTDRLLGFBQUssRUFBRTVLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmpCLFFBRHJCO0FBRUwvQixrQkFBVSxFQUFFN0ssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0Y7QUFGMUIsT0FBUDtBQUlELEtBVm1CLEVBWW5CMUUsS0FabUIsQ0FZWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBWmEsQ0FBdEI7QUFhQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1nQiwyQkFBTixDQUFrQ25VLE9BQWxDLEVBQTJDO0FBQ3pDLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsbUNBQWQsR0FBbUQxTyxPQUFPLENBQUNvSyxJQUR2QyxFQUVwQnBLLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0w0SyxhQUFLLEVBQUU1SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJqQixRQURyQjtBQUVML0Isa0JBQVUsRUFBRTdLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmtGO0FBRjFCLE9BQVA7QUFJRCxLQVRtQixFQVduQjFFLEtBWG1CLENBV1pDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNaUIsK0JBQU4sQ0FBc0NwVSxPQUF0QyxFQUErQztBQUM3QyxVQUFNbVQsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLHlDQUFkLEdBQXlEMU8sT0FBTyxDQUFDb0ssSUFEN0MsRUFFcEJwSyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMNEssYUFBSyxFQUFFNUssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1CcUYsVUFEckI7QUFFTHJJLGtCQUFVLEVBQUU3SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJrRjtBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkIxRSxLQVhtQixDQVdaQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FYYSxDQUF0QjtBQVlBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWtCLDJCQUFOLENBQWtDclUsT0FBbEMsRUFBMkM7QUFDekMsVUFBTW1ULE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyxzQ0FBZCxHQUFzRDFPLE9BQU8sQ0FBQ29LLElBRDFDLEVBRXBCcEssT0FGb0IsRUFJbkJrUCxJQUptQixDQUlibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTDRLLGFBQUssRUFBRTVLLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQmpCLFFBRHJCO0FBRUwvQixrQkFBVSxFQUFFN0ssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1Ca0Y7QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMUUsS0FYbUIsQ0FXWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1tQixtQkFBTixDQUEwQjVJLE1BQTFCLEVBQWtDO0FBQ2hDLFVBQU15SCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcseUNBQWQsR0FBeURoRCxNQUFNLENBQUN0QixJQUQ1QyxFQUduQjhFLElBSG1CLENBR2JuTyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMNEssYUFBSyxFQUFFNUssUUFBUSxDQUFDNk4sSUFBVCxDQUFjQSxJQUFkLENBQW1CcUYsVUFEckI7QUFFTHJJLGtCQUFVLEVBQUU3SyxRQUFRLENBQUM2TixJQUFULENBQWNBLElBQWQsQ0FBbUJrRjtBQUYxQixPQUFQO0FBSUQsS0FSbUIsRUFVbkIxRSxLQVZtQixDQVVaQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FWYSxDQUF0QjtBQVdBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9CLFNBQU4sR0FBa0I7QUFDaEIsVUFBTXBCLE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUFpQixHQUFFSixzREFBVyxxQkFBOUIsRUFDbkJRLElBRG1CLENBQ2JuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQUhtQixFQUluQlEsS0FKbUIsQ0FJWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1sQyxvQkFBTixHQUE2QjtBQUMzQjtBQUNBLFVBQU1rQyxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsMEJBRE0sRUFHbkJRLElBSG1CLENBR2JuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQUxtQixFQU1uQlEsS0FObUIsQ0FNWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBTmEsQ0FBdEI7QUFPQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU12RyxlQUFOLEdBQXdCO0FBQ3RCLFVBQU11RyxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ00sR0FBWCxDQUFnQixHQUFFQyxtREFBUSxpQkFBMUIsRUFDbkJ6RSxJQURtQixDQUNibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FIbUIsRUFJbkJRLEtBSm1CLENBSVpDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQUphLENBQXRCO0FBS0EsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNcUIsZUFBTixDQUFzQjVOLEVBQXRCLEVBQTBCO0FBQ3hCL0gsV0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQVosRUFBOEI4SCxFQUE5QjtBQUNBLFFBQUk3SCxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0wsUUFBWCxDQUFoQjtBQUNBLFFBQUlPLFlBQVksR0FBR0osU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQTlCO0FBQ0FULFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDQyxRQUF0QztBQUNBRixXQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWixFQUF1Q0ksU0FBdkM7QUFDQUwsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQVosRUFBMENRLFlBQTFDO0FBQ0FULFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQXlDNlAscUVBQXpDO0FBQ0E5UCxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEwQ1EsWUFBMUM7QUFDQSxVQUFNeUIsUUFBUSxHQUFHLE1BQU1xUyxtREFBVSxDQUFDdEUsSUFBWCxDQUNwQixHQUFFSixzREFBVyw4QkFETyxFQUVyQjtBQUNFcFAsa0JBREY7QUFFRXNILFFBRkY7QUFHRW1GLGFBQU8sRUFBRSxDQUhYO0FBSUVnRCxlQUFTLEVBQUVKLHFFQUpiO0FBS0VLLGNBQVEsRUFBRyxHQUFFeUYsdURBQVksWUFBVzdOLEVBQUcsRUFMekM7QUFNRXFJLGFBQU8sRUFBRTZELHdFQUFNO0FBTmpCLEtBRnFCLEVBV3BCNUQsSUFYb0IsQ0FXZG5PLFFBQUQsSUFBYztBQUNsQmxDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQTZCaUMsUUFBN0I7QUFDQSxhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBZG9CLEVBZXBCUSxLQWZvQixDQWViQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FmYyxDQUF2QjtBQWdCQSxXQUFPdE8sUUFBUDtBQUNEOztBQUVELFFBQU0yVCxnQkFBTixDQUF1QjFVLE9BQXZCLEVBQWdDO0FBQzlCLFVBQU1lLFFBQVEsR0FBRyxNQUFNcVMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDcEIsR0FBRUosc0RBQVcsMEJBRE8sRUFFckIxTyxPQUZxQixFQUlwQmtQLElBSm9CLENBSWRuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQU5vQixFQU9wQlEsS0FQb0IsQ0FPYkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPdE8sUUFBUDtBQUNEOztBQUVELFFBQU00VCxxQkFBTixDQUE0QjNVLE9BQTVCLEVBQXFDO0FBQ25DLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ00sR0FBWCxDQUNuQixHQUFFQyxtREFBUSw0QkFBMkIzVCxPQUFRLEVBRDFCLEVBR25Ca1AsSUFIbUIsQ0FHYm5PLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUM2TixJQUFiLEVBQW1CO0FBQ2pCLFlBQUk3TixRQUFRLENBQUM2TixJQUFULENBQWNsSCxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQzVCLGlCQUFPM0csUUFBUSxDQUFDNk4sSUFBVCxDQUFjLENBQWQsQ0FBUDtBQUNEO0FBQ0YsT0FKRCxNQUlPO0FBQ0wsZUFBTyxJQUFQO0FBQ0Q7QUFDRixLQVhtQixFQVluQlEsS0FabUIsQ0FZYixNQUFNO0FBQ1gsYUFBTyxJQUFQO0FBQ0QsS0FkbUIsQ0FBdEI7QUFlQSxXQUFPK0QsT0FBUDtBQUNEOztBQUNELFFBQU15QixrQkFBTixDQUF5QjVVLE9BQXpCLEVBQWtDO0FBQ2hDLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ00sR0FBWCxDQUFnQixHQUFFQyxtREFBUSxnQkFBZTNULE9BQVEsRUFBakQsRUFDbkJrUCxJQURtQixDQUNibk8sUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQzZOLElBQWIsRUFBbUI7QUFDakIsWUFBSTdOLFFBQVEsQ0FBQzZOLElBQVQsQ0FBY2xILE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUIsaUJBQU8zRyxRQUFRLENBQUM2TixJQUFULENBQWMsQ0FBZCxDQUFQO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTCxlQUFPLElBQVA7QUFDRDtBQUNGLEtBVG1CLEVBVW5CUSxLQVZtQixDQVViLE1BQU07QUFDWCxhQUFPLElBQVA7QUFDRCxLQVptQixDQUF0QjtBQWFBLFdBQU8rRCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTBCLG1CQUFOLENBQTBCN1UsT0FBMUIsRUFBbUM7QUFDakMsUUFBSTZLLEtBQUssR0FBRyxFQUFaO0FBQ0E3SyxXQUFPLENBQUM4VSxPQUFSLENBQWlCbFMsSUFBRCxJQUFVO0FBQ3hCLFVBQUlpSSxLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNoQkEsYUFBSyxHQUFJLFNBQVFqSSxJQUFLLEVBQXRCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xpSSxhQUFLLEdBQUdBLEtBQUssR0FBSSxVQUFTakksSUFBSyxFQUEvQjtBQUNEO0FBQ0YsS0FORDtBQU9BLFVBQU11USxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ00sR0FBWCxDQUFnQixHQUFFQyxtREFBUSxXQUFVOUksS0FBTSxFQUExQyxFQUNuQnFFLElBRG1CLENBQ2JuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQUhtQixFQUluQlEsS0FKbUIsQ0FJWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU0wQixtQkFBTixDQUEwQjdVLE9BQTFCLEVBQW1DO0FBQ2pDLFFBQUk2SyxLQUFLLEdBQUcsRUFBWjtBQUNBN0ssV0FBTyxDQUFDOFUsT0FBUixDQUFpQmxTLElBQUQsSUFBVTtBQUN4QixVQUFJaUksS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDaEJBLGFBQUssR0FBSSxTQUFRakksSUFBSyxFQUF0QjtBQUNELE9BRkQsTUFFTztBQUNMaUksYUFBSyxHQUFHQSxLQUFLLEdBQUksVUFBU2pJLElBQUssRUFBL0I7QUFDRDtBQUNGLEtBTkQ7QUFPQSxVQUFNdVEsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUNNLEdBQVgsQ0FBZ0IsR0FBRUMsbURBQVEsV0FBVTlJLEtBQU0sRUFBMUMsRUFDbkJxRSxJQURtQixDQUNibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FIbUIsRUFJbkJRLEtBSm1CLENBSVpDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQUphLENBQXRCO0FBS0EsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNNEIsdUJBQU4sQ0FBOEIvVSxPQUE5QixFQUF1QztBQUNyQyxVQUFNbVQsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUNNLEdBQVgsQ0FDbkIsR0FBRUMsbURBQVEsYUFBWUMsa0VBQWMsQ0FBQzVULE9BQUQsQ0FBVSxFQUQzQixFQUduQmtQLElBSG1CLENBR2JuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQUxtQixFQU1uQlEsS0FObUIsQ0FNWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBTmEsQ0FBdEI7QUFPQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU16UyxnQkFBTixDQUF1QlYsT0FBdkIsRUFBZ0M7QUFDOUJuQixXQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFxQ2tCLE9BQXJDO0FBQ0EsVUFBTW1ULE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyx3QkFETSxFQUVwQjFPLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBTm1CLEVBT25CUSxLQVBtQixDQU9aQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBQ0QsUUFBTTZCLFNBQU4sQ0FBZ0JoVixPQUFoQixFQUF5QjtBQUN2QixVQUFNbVQsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLCtCQURNLEVBRXBCMU8sT0FGb0IsRUFJbkJrUCxJQUptQixDQUlibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJRLEtBUG1CLENBT1pDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNOEIsVUFBTixDQUFpQmpWLE9BQWpCLEVBQTBCO0FBQ3hCbkIsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0NrQixPQUF0QztBQUNBLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsZ0NBRE0sRUFFcEIxTyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQU5tQixFQU9uQlEsS0FQbUIsQ0FPWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU10UyxPQUFOLENBQWNiLE9BQWQsRUFBdUI7QUFDckJuQixXQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTJCa0IsT0FBM0I7QUFDQSxVQUFNbVQsT0FBTyxHQUFHLE1BQU1DLG1EQUFVLENBQUN0RSxJQUFYLENBQ25CLEdBQUVKLHNEQUFXLG9CQURNLEVBRXBCMU8sT0FGb0IsRUFJbkJrUCxJQUptQixDQUlibk8sUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQzZOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJRLEtBUG1CLENBT1pDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUVsUSxJQUFJLENBQUNtVSxTQUFMLENBQWVqRSxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzhELE9BQVA7QUFDRDs7QUFFRCxRQUFNK0IsVUFBTixDQUFpQmxWLE9BQWpCLEVBQTBCO0FBQ3hCLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsMkJBRE0sRUFFcEIxTyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQU5tQixFQU9uQlEsS0FQbUIsQ0FPWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1nQyw0QkFBTixDQUFtQ25WLE9BQW5DLEVBQTRDO0FBQzFDLFVBQU1tVCxPQUFPLEdBQUcsTUFBTUMsbURBQVUsQ0FBQ3RFLElBQVgsQ0FDbkIsR0FBRUosc0RBQVcsdUJBRE0sRUFFcEIxTyxPQUZvQixFQUluQmtQLElBSm1CLENBSWJuTyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDNk4sSUFBaEI7QUFDRCxLQU5tQixFQU9uQlEsS0FQbUIsQ0FPWkMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRWxRLElBQUksQ0FBQ21VLFNBQUwsQ0FBZWpFLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPOEQsT0FBUDtBQUNEOztBQUVELFFBQU1pQyxTQUFOLENBQWdCcFYsT0FBaEIsRUFBeUI7QUFDdkIsVUFBTW1ULE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVywwQkFETSxFQUVwQjFPLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBTm1CLEVBT25CUSxLQVBtQixDQU9aQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWtDLGlCQUFOLENBQXdCclYsT0FBeEIsRUFBaUM7QUFDL0IsVUFBTW1ULE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVywyQkFETSxFQUVwQjFPLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBTm1CLEVBT25CUSxLQVBtQixDQU9aQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW1DLGVBQU4sQ0FBc0J0VixPQUF0QixFQUErQjtBQUM3Qm5CLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaLEVBQThDa0IsT0FBOUM7QUFDQW5CLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLG9DQUFaLEVBQWlENFAsc0RBQWpEO0FBQ0EsVUFBTXlFLE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyxtQ0FETSxFQUVwQjFPLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBTm1CLEVBT25CUSxLQVBtQixDQU9aQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9DLGlCQUFOLENBQXdCdlYsT0FBeEIsRUFBaUM7QUFDL0IsVUFBTW1ULE9BQU8sR0FBRyxNQUFNQyxtREFBVSxDQUFDdEUsSUFBWCxDQUNuQixHQUFFSixzREFBVyxnQ0FETSxFQUVwQjFPLE9BRm9CLEVBSW5Ca1AsSUFKbUIsQ0FJYm5PLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUM2TixJQUFoQjtBQUNELEtBTm1CLEVBT25CUSxLQVBtQixDQU9aQyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFbFEsSUFBSSxDQUFDbVUsU0FBTCxDQUFlakUsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU84RCxPQUFQO0FBQ0Q7O0FBdmNxQjs7QUEwY1QsbUVBQUkxUyxpQkFBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsZEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE1BQU0rVSxVQUFVLEdBQUcsK0JBQW5CLEMsQ0FBb0Q7O0FBQzdDLE1BQU1DLFdBQVcsR0FBRywrQkFBcEIsQyxDQUFxRDs7QUFDckQsTUFBTUMsWUFBWSxHQUFHLCtCQUFyQixDLENBQXNEOztBQUU3RCxJQUFJQyxnQkFBZ0IsR0FBRyx1Q0FBdkI7QUFDQSxJQUFJQyxRQUFRLEdBQUcsZ0NBQWY7O0FBQ0EsVUFBbUM7QUFDakMsTUFBSXJKLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQnFKLFFBQWhCLElBQTRCLHdCQUFoQyxFQUEwRDtBQUN4REYsb0JBQWdCLEdBQUcsZ0NBQW5CO0FBQ0FDLFlBQVEsR0FBRyxnQ0FBWDtBQUNEOztBQUNELE1BQUlySixNQUFNLENBQUNDLFFBQVAsQ0FBZ0JxSixRQUFoQixJQUE0Qix1QkFBaEMsRUFBeUQ7QUFDdkRGLG9CQUFnQixHQUFHLCtCQUFuQjtBQUNBQyxZQUFRLEdBQUcsK0JBQVg7QUFDRDtBQUNGOztBQUVNLE1BQU1sSCxVQUFVLEdBQUdpSCxnQkFBbkI7QUFDQSxNQUFNbEIsV0FBVyxHQUFHbUIsUUFBcEI7QUFFQSxNQUFNRSxhQUFhLEdBQUc7QUFDM0JDLFFBQU0sRUFBRTtBQURtQixDQUF0QjtBQUlBLE1BQU1wQyxPQUFPLEdBQUksR0FBRTZCLFVBQVcsRUFBOUI7QUFFUXhDLDJHQUFLLENBQUNnRCxNQUFOLENBQWE7QUFDMUJyQyxTQUQwQjtBQUUxQnNDLFNBQU8sRUFBRUg7QUFGaUIsQ0FBYixDQUFmO0FBS08sTUFBTWxDLGNBQWMsR0FBSS9JLEtBQUQsSUFBVztBQUN2QyxTQUFPcUwsTUFBTSxDQUFDQyxJQUFQLENBQVl0TCxLQUFaLEVBQ0psSSxHQURJLENBRUZ5VCxHQUFELElBQVUsR0FBRUMsa0JBQWtCLENBQUNELEdBQUQsQ0FBTSxJQUFHQyxrQkFBa0IsQ0FBQ3hMLEtBQUssQ0FBQ3VMLEdBQUQsQ0FBTixDQUFhLEVBRm5FLEVBSUpFLElBSkksQ0FJQyxHQUpELENBQVA7QUFLRCxDQU5NOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQ1A7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNQyxXQUFXLEdBQUc7QUFDekJDLFVBQVEsRUFBRSxVQURlO0FBRXpCQyxrQkFBZ0IsRUFBRSxrQkFGTztBQUd6QkMsZ0JBQWMsRUFBRSxnQkFIUztBQUt6QkMseUJBQXVCLEVBQUUseUJBTEE7QUFNekJDLGlDQUErQixFQUFFLGlDQU5SO0FBUXpCQyxVQUFRLEVBQUUsVUFSZTtBQVN6QkMsYUFBVyxFQUFFLGFBVFk7QUFVekJDLDhCQUE0QixFQUFFLDhCQVZMO0FBWXpCQyxZQUFVLEVBQUUsWUFaYTtBQWF6QkMsb0JBQWtCLEVBQUUsb0JBYks7QUFjekJDLGtCQUFnQixFQUFFLGtCQWRPO0FBZ0J6QkMsY0FBWSxFQUFFLGNBaEJXO0FBaUJ6QkMsc0JBQW9CLEVBQUUsc0JBakJHO0FBa0J6QkMsb0JBQWtCLEVBQUUsb0JBbEJLO0FBb0J6QkMsY0FBWSxFQUFFLGNBcEJXO0FBcUJ6QkMsYUFBVyxFQUFFLGFBckJZO0FBdUJ6QkMscUJBQW1CLEVBQUUscUJBdkJJO0FBd0J6QkMsbUJBQWlCLEVBQUUsbUJBeEJNO0FBMEJ6QkMseUJBQXVCLEVBQUUseUJBMUJBO0FBNEJ6QkMsd0JBQXNCLEVBQUUsd0JBNUJDO0FBNkJ6QkMsZ0NBQThCLEVBQUUsZ0NBN0JQO0FBK0J6QkMsZ0JBQWMsRUFBRSxnQkEvQlM7QUFpQ3pCQyx3QkFBc0IsRUFBRSx3QkFqQ0M7QUFtQ3pCQywwQkFBd0IsRUFBRSwwQkFuQ0Q7QUFxQ3pCQyxpQ0FBK0IsRUFBRSxpQ0FyQ1I7QUF1Q3pCQyxzQkFBb0IsRUFBRSxzQkF2Q0c7QUF5Q3pCQyxzQkFBb0IsRUFBRSxxQkF6Q0c7QUEyQ3pCQyxvQkFBa0IsRUFBRSxvQkEzQ0s7QUE2Q3pCQyxpQ0FBK0IsRUFBRTtBQTdDUixDQUFwQjtBQWdEQSxTQUFTcFMsd0JBQVQsQ0FBa0NoRyxPQUFsQyxFQUEyQztBQUNoRCxTQUFPO0FBQUVxWSxRQUFJLEVBQUU5QixXQUFXLENBQUNRLDRCQUFwQjtBQUFrRC9XO0FBQWxELEdBQVA7QUFDRDtBQUVNLFNBQVNzWSxxQkFBVCxDQUErQnRZLE9BQS9CLEVBQXdDO0FBQzdDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQzZCLCtCQUFwQjtBQUFxRHBZO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVN1WSxpQkFBVCxDQUEyQnZZLE9BQTNCLEVBQW9DO0FBQ3pDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQzJCLG9CQUFwQjtBQUEwQ2xZO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVN3WSxnQkFBVCxDQUEwQnhZLE9BQTFCLEVBQW1DO0FBQ3hDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQzRCLGtCQUFwQjtBQUF3Q25ZO0FBQXhDLEdBQVA7QUFDRDtBQUVNLFNBQVN5WSxrQkFBVCxDQUE0QnpZLE9BQTVCLEVBQXFDO0FBQzFDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQzBCLG9CQUFwQjtBQUEwQ2pZO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVMwWSwyQkFBVCxDQUFxQzFZLE9BQXJDLEVBQThDO0FBQ25ELFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ3lCLCtCQUFwQjtBQUFxRGhZO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVMyWSxvQkFBVCxDQUE4QjNZLE9BQTlCLEVBQXVDO0FBQzVDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ3VCLHNCQUFwQjtBQUE0QzlYO0FBQTVDLEdBQVA7QUFDRDtBQUVNLFNBQVM0WSxzQkFBVCxDQUFnQzVZLE9BQWhDLEVBQXlDO0FBQzlDLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ3dCLHdCQUFwQjtBQUE4Qy9YO0FBQTlDLEdBQVA7QUFDRDtBQUVNLFNBQVM2WSxhQUFULENBQXVCN1ksT0FBdkIsRUFBZ0M7QUFDckMsU0FBTztBQUFFcVksUUFBSSxFQUFFOUIsV0FBVyxDQUFDc0IsY0FBcEI7QUFBb0M3WDtBQUFwQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTOFksMEJBQVQsR0FBc0M7QUFDM0MsU0FBTztBQUNMVCxRQUFJLEVBQUU5QixXQUFXLENBQUNvQjtBQURiLEdBQVA7QUFHRDtBQUVNLFNBQVNvQixpQ0FBVCxDQUEyQy9ZLE9BQTNDLEVBQW9EO0FBQ3pELFNBQU87QUFDTHFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ3FCLDhCQURiO0FBRUw1WDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVNhLE9BQVQsR0FBbUI7QUFDeEIyTixPQUFLLENBQUMsU0FBRCxDQUFMO0FBQ0EsU0FBTztBQUFFNkosUUFBSSxFQUFFOUIsV0FBVyxDQUFDQztBQUFwQixHQUFQO0FBQ0Q7QUFFTSxTQUFTd0MsY0FBVCxDQUF3QmhaLE9BQXhCLEVBQWlDO0FBQ3RDLFNBQU87QUFDTHFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ0UsZ0JBRGI7QUFFTHpXO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBU2laLFlBQVQsQ0FBc0I1SixLQUF0QixFQUE2QjtBQUNsQyxTQUFPO0FBQ0xnSixRQUFJLEVBQUU5QixXQUFXLENBQUNHLGNBRGI7QUFFTHJIO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBUzZKLHFCQUFULENBQStCbFosT0FBL0IsRUFBd0M7QUFDN0N3TyxPQUFLLENBQUMsTUFBRCxDQUFMO0FBQ0EzUCxTQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTJCa0IsT0FBM0I7QUFFQSxTQUFPO0FBQ0xxWSxRQUFJLEVBQUU5QixXQUFXLENBQUNtQix1QkFEYjtBQUVMMVg7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTbVosT0FBVCxDQUFpQm5aLE9BQWpCLEVBQTBCO0FBQy9CLFNBQU87QUFBRXFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ00sUUFBcEI7QUFBOEI3VztBQUE5QixHQUFQO0FBQ0Q7QUFFTSxTQUFTb1osVUFBVCxDQUFvQjliLE9BQXBCLEVBQTZCO0FBQ2xDLFNBQU87QUFBRSthLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ08sV0FBcEI7QUFBaUN4WjtBQUFqQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTK2IsZUFBVCxDQUF5Qi9iLE9BQXpCLEVBQWtDO0FBQ3ZDLFNBQU87QUFBRSthLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ1ksWUFBcEI7QUFBa0M3WjtBQUFsQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTZ2MsZUFBVCxDQUF5QmhjLE9BQXpCLEVBQWtDO0FBQ3ZDLFNBQU87QUFBRSthLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ2UsWUFBcEI7QUFBa0NoYTtBQUFsQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTaWMsaUJBQVQsQ0FBMkJ2WixPQUEzQixFQUFvQztBQUN6QyxTQUFPO0FBQ0xxWSxRQUFJLEVBQUU5QixXQUFXLENBQUNpQixtQkFEYjtBQUVMeFg7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTd1osZUFBVCxDQUF5QnhaLE9BQXpCLEVBQWtDO0FBQ3ZDLFNBQU87QUFDTHFZLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ2tCLGlCQURiO0FBRUx6WDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVN5WixTQUFULEdBQXFCO0FBQzFCLFNBQU87QUFBRXBCLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ1M7QUFBcEIsR0FBUDtBQUNEO0FBRU0sU0FBUzBDLGdCQUFULEdBQTRCO0FBQ2pDLFNBQU87QUFBRXJCLFFBQUksRUFBRTlCLFdBQVcsQ0FBQ1U7QUFBcEIsR0FBUDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEtEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU0wQyxTQUFTLEdBQUdDLG1CQUFPLENBQUMscUVBQUQsQ0FBekI7O0FBRU8sU0FBU0MsbUJBQVQsQ0FBNkJDLFNBQTdCLEVBQXdDO0FBQzdDOWIsb0RBQU0sQ0FBQzJPLE9BQVAsQ0FBZW1OLFNBQWYsRUFBMEJ2YSxTQUExQixFQUFxQztBQUNuQ3dhLFdBQU8sRUFBRTtBQUQwQixHQUFyQztBQUdEO0FBRU0sU0FBU0MsMEJBQVQsQ0FBb0MxYyxPQUFwQyxFQUE2QztBQUNsRCxNQUFJQSxPQUFPLENBQUMySixXQUFSLEtBQXdCLEtBQTVCLEVBQW1DO0FBQ2pDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEsd0JBQ00zSixPQUFPLENBQUMySixXQUFSLEdBQXNCM0osT0FBTyxDQUFDMkosV0FBOUIsR0FBNEMsQ0FEbEQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUNNM0osT0FBTyxDQUFDNEcsWUFBUixHQUF1QjVHLE9BQU8sQ0FBQzRHLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0QsTUFBSTVHLE9BQU8sQ0FBQzJjLGdCQUFSLEtBQTZCLEtBQWpDLEVBQXdDO0FBQ3RDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEsd0JBQ00zYyxPQUFPLENBQUMyYyxnQkFEZCxlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQ00zYyxPQUFPLENBQUM0RyxZQUFSLEdBQXVCNUcsT0FBTyxDQUFDNEcsWUFBL0IsR0FBOEMsQ0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxNQUFJNUcsT0FBTyxDQUFDOEcsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQyx3QkFDRTtBQUFHLGVBQVMsRUFBQyx5QkFBYjtBQUFBLHdCQUNNOUcsT0FBTyxDQUFDOEcsVUFEZCxlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQ005RyxPQUFPLENBQUM0RyxZQUFSLEdBQXVCNUcsT0FBTyxDQUFDNEcsWUFBL0IsR0FBOEMsQ0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxzQkFDRTtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHNCQUNNNUcsT0FBTyxDQUFDNEcsWUFBUixHQUF1QjVHLE9BQU8sQ0FBQzRHLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBS0Q7QUFFTSxTQUFTZ1csc0JBQVQsQ0FBZ0N2TSxRQUFoQyxFQUEwQztBQUMvQyxNQUFJd00sZ0JBQWdCLEdBQUd4TSxRQUFRLENBQUNRLE1BQVQsQ0FBZ0IsQ0FBQ2lNLElBQUQsRUFBT0MsSUFBUCxLQUFnQjtBQUNyRCxXQUNFL0wsTUFBTSxDQUFDZ00sV0FBVyxDQUFDRixJQUFELENBQVosQ0FBTixHQUNBOUwsTUFBTSxDQUNKZ00sV0FBVyxDQUNURCxJQUFJLENBQUNFLG9CQUFMLElBQTZCLENBQTdCLEdBQ0lGLElBQUksQ0FBQ0csa0JBRFQsR0FFSUgsSUFBSSxDQUFDRSxvQkFIQSxDQURQLENBRlI7QUFVRCxHQVhzQixFQVdwQixDQVhvQixDQUF2QjtBQWFBLFNBQU9KLGdCQUFQO0FBQ0Q7QUFFTSxTQUFTTSxxQkFBVCxDQUErQjlNLFFBQS9CLEVBQXlDO0FBQzlDLE1BQUkrTSxxQkFBcUIsR0FBRy9NLFFBQVEsQ0FBQ1EsTUFBVCxDQUFnQixDQUFDaU0sSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQzFELFdBQU8vTCxNQUFNLENBQUNnTSxXQUFXLENBQUNGLElBQUQsQ0FBWixDQUFOLEdBQTRCOUwsTUFBTSxDQUFDZ00sV0FBVyxDQUFDRCxJQUFJLENBQUNNLFVBQU4sQ0FBWixDQUF6QztBQUNELEdBRjJCLEVBRXpCLENBRnlCLENBQTVCO0FBSUEsU0FBT0QscUJBQVA7QUFDRDtBQUVNLFNBQVNFLHlCQUFULENBQW1Dak4sUUFBbkMsRUFBNkM7QUFDbEQsTUFBSWtOLGNBQWMsR0FBR2xOLFFBQVEsQ0FBQ1EsTUFBVCxDQUFnQixDQUFDaU0sSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQ25ELFdBQ0UvTCxNQUFNLENBQUNnTSxXQUFXLENBQUNGLElBQUQsQ0FBWixDQUFOLEdBQTRCOUwsTUFBTSxDQUFDZ00sV0FBVyxDQUFDRCxJQUFJLENBQUNTLGVBQU4sQ0FBWixDQURwQztBQUdELEdBSm9CLEVBSWxCLENBSmtCLENBQXJCO0FBTUEsU0FBT0QsY0FBUDtBQUNEO0FBRU0sU0FBU1AsV0FBVCxDQUFxQlMsR0FBckIsRUFBMEI7QUFDL0IsTUFBSUMsV0FBVyxHQUFHRCxHQUFILGFBQUdBLEdBQUgsdUJBQUdBLEdBQUcsQ0FBRUUsUUFBTCxHQUFnQkMsS0FBaEIsQ0FBc0IsR0FBdEIsQ0FBbEI7O0FBQ0EsTUFBSUYsV0FBVyxJQUFJLENBQUFBLFdBQVcsU0FBWCxJQUFBQSxXQUFXLFdBQVgsWUFBQUEsV0FBVyxDQUFFdFQsTUFBYixJQUFzQixDQUF6QyxFQUE0QztBQUMxQyxXQUFPc1QsV0FBVyxDQUFDN00sTUFBWixDQUFtQixDQUFDaU0sSUFBRCxFQUFPQyxJQUFQLEtBQWdCRCxJQUFJLEdBQUdDLElBQTFDLENBQVA7QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPLENBQVA7QUFDRDtBQUNGO0FBRU0sU0FBU3JXLDhCQUFULENBQXdDbVgsV0FBeEMsRUFBcUQ7QUFDMUQsU0FBTyxJQUFJQyxJQUFJLENBQUNDLFlBQVQsQ0FBc0IsT0FBdEIsRUFBK0I7QUFDcENDLFNBQUssRUFBRSxVQUQ2QjtBQUVwQ0MsWUFBUSxFQUFFO0FBRjBCLEdBQS9CLEVBR0pDLE1BSEksQ0FHR2xCLFdBQVcsQ0FBQ2EsV0FBRCxDQUhkLENBQVA7QUFJRDtBQUVNLFNBQVNNLFdBQVQsQ0FBcUJDLFdBQXJCLEVBQWtDO0FBQ3ZDLE1BQUluSyxNQUFNLEdBQUdvSSxTQUFTLENBQUNnQyxPQUFWLENBQWtCRCxXQUFsQixDQUFiO0FBQ0Q7QUFFTSxTQUFTRSxXQUFULENBQXFCQyxRQUFyQixFQUErQkMsU0FBL0IsRUFBMEM7QUFDL0MsTUFBSUMsT0FBTyxHQUFHcEMsU0FBUyxDQUFDcUMsR0FBVixDQUNaMUIsV0FBVyxDQUFDdUIsUUFBUSxJQUFJLENBQWIsQ0FEQyxFQUVadkIsV0FBVyxDQUFDd0IsU0FBUyxJQUFJLENBQWQsQ0FGQyxDQUFkO0FBSUEsU0FBT0MsT0FBUDtBQUNEO0FBRU0sU0FBU0UsV0FBVCxDQUFxQkosUUFBckIsRUFBK0JDLFNBQS9CLEVBQTBDO0FBQy9DLE1BQUlJLE9BQU8sR0FBR3ZDLFNBQVMsQ0FBQ3dDLEdBQVYsQ0FDWjdCLFdBQVcsQ0FBQ3VCLFFBQVEsSUFBSSxDQUFiLENBREMsRUFFWnZCLFdBQVcsQ0FBQ3dCLFNBQVMsSUFBSSxDQUFkLENBRkMsQ0FBZDtBQUlBLFNBQU9JLE9BQVA7QUFDRDtBQUVNLFNBQVNFLFdBQVQsQ0FBcUJDLGdCQUFyQixFQUF1Q0MsaUJBQXZDLEVBQTBEO0FBQy9ELE1BQUlDLE9BQU8sR0FBRzVDLFNBQVMsQ0FBQzZDLEdBQVYsQ0FDWmxDLFdBQVcsQ0FBQytCLGdCQUFnQixJQUFJLENBQXJCLENBREMsRUFFWi9CLFdBQVcsQ0FBQ2dDLGlCQUFpQixJQUFJLENBQXRCLENBRkMsQ0FBZDtBQUtBLFNBQU9DLE9BQVA7QUFDRDtBQUNNLFNBQVNFLFdBQVQsQ0FBcUJKLGdCQUFyQixFQUF1Q0MsaUJBQXZDLEVBQTBEO0FBQy9ELE1BQUlJLE9BQU8sR0FBRy9DLFNBQVMsQ0FBQ2dELEdBQVYsQ0FDWnJDLFdBQVcsQ0FBQytCLGdCQUFnQixJQUFJLENBQXJCLENBREMsRUFFWi9CLFdBQVcsQ0FBQ2dDLGlCQUFpQixJQUFJLENBQXRCLENBRkMsQ0FBZDtBQUtBLFNBQU9JLE9BQVA7QUFDRDtBQUVNLFNBQVNFLGNBQVQsQ0FBd0I3QixHQUF4QixFQUE2QjtBQUNsQyxNQUFJQSxHQUFHLEtBQUt4YixTQUFaLEVBQXVCO0FBQ3JCLFdBQU9zZCxVQUFVLENBQUM5QixHQUFELENBQVYsQ0FDSkUsUUFESSxHQUVKdE8sT0FGSSxDQUVJLHlCQUZKLEVBRStCLEtBRi9CLENBQVA7QUFHRCxHQUpELE1BSU8sQ0FDTjtBQUNGO0FBRU0sU0FBU21RLGtCQUFULENBQTRCQyxXQUE1QixFQUF5Q0MsSUFBekMsRUFBK0M7QUFDcEQsTUFBSUQsV0FBVyxDQUFDclYsTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQixVQUFNNkosTUFBTSxHQUFHd0wsV0FBVyxDQUFDRSxJQUFaLENBQWtCcmEsSUFBRCxJQUFVQSxJQUFJLENBQUNvYSxJQUFMLEtBQWNBLElBQUksQ0FBQy9CLFFBQUwsRUFBekMsQ0FBZjs7QUFDQSxRQUFJMUosTUFBTSxLQUFLaFMsU0FBZixFQUEwQjtBQUN4QixhQUFPZ1MsTUFBTSxDQUFDNUQsUUFBZDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sRUFBUDtBQUNEO0FBQ0YsR0FQRCxNQU9PO0FBQ0wsV0FBTyxFQUFQO0FBQ0Q7QUFDRjtBQUVNLFNBQVNsRixhQUFULENBQXVCeVUsT0FBdkIsRUFBZ0NGLElBQWhDLEVBQXNDO0FBQzNDLE1BQUlFLE9BQU8sQ0FBQ3hWLE1BQVIsR0FBaUIsQ0FBckIsRUFBd0I7QUFDdEIsVUFBTXlWLE1BQU0sR0FBR0QsT0FBTyxDQUFDRCxJQUFSLENBQWNyYSxJQUFELElBQVVBLElBQUksQ0FBQ29hLElBQUwsS0FBY0EsSUFBSSxDQUFDL0IsUUFBTCxFQUFyQyxDQUFmOztBQUNBLFFBQUlrQyxNQUFNLEtBQUs1ZCxTQUFmLEVBQTBCO0FBQ3hCLGFBQU80ZCxNQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxJQUFQO0FBQ0Q7QUFDRixHQVBELE1BT087QUFDTCxXQUFPLElBQVA7QUFDRDtBQUNGO0FBRU0sU0FBU0MsdUJBQVQsQ0FBaUNwZCxPQUFqQyxFQUEwQztBQUMvQyxNQUFJNkssS0FBSyxHQUFHLEVBQVo7O0FBQ0EsTUFBSTdLLE9BQU8sQ0FBQzBILE1BQVIsR0FBaUIsQ0FBckIsRUFBd0I7QUFDdEIxSCxXQUFPLENBQUM4VSxPQUFSLENBQWlCbFMsSUFBRCxJQUFVO0FBQ3hCLFVBQUlpSSxLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNoQkEsYUFBSyxHQUFJLFdBQVVqSSxJQUFLLEVBQXhCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xpSSxhQUFLLEdBQUdBLEtBQUssR0FBSSxZQUFXakksSUFBSyxFQUFqQztBQUNEO0FBQ0YsS0FORDtBQU9EOztBQUNELFNBQU9pSSxLQUFQO0FBQ0Q7QUFFTSxTQUFTd1Msa0JBQVQsQ0FBNEIvZixPQUE1QixFQUFxQztBQUMxQyxNQUFJZ2dCLElBQUo7O0FBQ0EsTUFBSWhnQixPQUFPLENBQUNpZ0IsS0FBUixJQUFpQmpnQixPQUFPLENBQUNpZ0IsS0FBUixLQUFrQixJQUF2QyxFQUE2QztBQUMzQ0QsUUFBSSxHQUFHaGdCLE9BQU8sQ0FBQ2lnQixLQUFSLENBQWM1YSxHQUFkLENBQW1CNGEsS0FBRCxJQUFXO0FBQ2xDLFVBQUlBLEtBQUssQ0FBQ2xGLElBQU4sS0FBZSxNQUFuQixFQUEyQjtBQUN6Qiw0QkFBTztBQUFLLG1CQUFTLEVBQUMsbUJBQWY7QUFBQSxvQkFBb0NrRixLQUFLLENBQUN2YTtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFQO0FBQ0QsT0FGRCxNQUVPLElBQUl1YSxLQUFLLENBQUNsRixJQUFOLEtBQWUsVUFBbkIsRUFBK0I7QUFDcEMsNEJBQU87QUFBSyxtQkFBUyxFQUFDLDZCQUFmO0FBQUEsb0JBQThDa0YsS0FBSyxDQUFDdmE7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBUDtBQUNELE9BRk0sTUFFQTtBQUNMLDRCQUFPO0FBQUssbUJBQVMsRUFBQyx1QkFBZjtBQUFBLG9CQUF3Q3VhLEtBQUssQ0FBQ3ZhO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQVA7QUFDRDtBQUNGLEtBUk0sQ0FBUDtBQVNEOztBQUNELFNBQU9zYSxJQUFQO0FBQ0Q7S0FkZUQsa0I7QUFnQlQsU0FBU0csa0JBQVQsQ0FBNEJsZ0IsT0FBNUIsRUFBcUM7QUFDMUMsTUFBSWdnQixJQUFKOztBQUNBLE1BQUloZ0IsT0FBTyxDQUFDbWdCLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJILFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx3QkFDTVYsY0FBYyxDQUFDdGYsT0FBTyxDQUFDMkcsS0FBVCxDQURwQixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQTBCMlksY0FBYyxDQUFDdGYsT0FBTyxDQUFDOEcsVUFBVCxDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQU1ELEdBUEQsTUFPTztBQUNMa1osUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUFxQ1YsY0FBYyxDQUFDdGYsT0FBTyxDQUFDMkcsS0FBVCxDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQUdEOztBQUNELFNBQU9xWixJQUFQO0FBQ0Q7TUFmZUUsa0I7QUFpQlQsU0FBU0Usc0JBQVQsQ0FBZ0NwZ0IsT0FBaEMsRUFBeUM7QUFDOUMsTUFBSWdnQixJQUFKOztBQUNBLE1BQUloZ0IsT0FBTyxDQUFDOEcsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQ2taLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx3QkFDTWhnQixPQUFPLENBQUM4RyxVQURkLGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwwQkFBMEI5RyxPQUFPLENBQUM0RyxZQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQU1ELEdBUEQsTUFPTztBQUNMb1osUUFBSSxnQkFBRztBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUFxQ2hnQixPQUFPLENBQUM0RyxZQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBUDtBQUNEOztBQUNELFNBQU9vWixJQUFQO0FBQ0Q7TUFiZUksc0I7QUFlVCxTQUFTQyxtQkFBVCxDQUE2QnJnQixPQUE3QixFQUFzQztBQUMzQyxNQUFJZ2dCLElBQUo7O0FBQ0EsTUFBSWhnQixPQUFPLENBQUNtZ0IsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkgsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUNNVixjQUFjLENBQUN0ZixPQUFPLENBQUM4RyxVQUFULENBRHBCLEVBQzBDLEdBRDFDLGVBRUU7QUFBTSxpQkFBUyxFQUFDLFVBQWhCO0FBQUEsMEJBQ013WSxjQUFjLENBQUN0ZixPQUFPLENBQUM0RyxZQUFULENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQsR0FURCxNQVNPO0FBQ0xvWixRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEsd0JBQ01WLGNBQWMsQ0FBQ3RmLE9BQU8sQ0FBQzhHLFVBQVQsQ0FEcEIsRUFDMEMsR0FEMUMsZUFFRTtBQUFNLGlCQUFTLEVBQUMsVUFBaEI7QUFBQSwwQkFDTXdZLGNBQWMsQ0FBQ3RmLE9BQU8sQ0FBQzRHLFlBQVQsQ0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxTQUFPb1osSUFBUDtBQUNEO0FBRU0sU0FBU00sMEJBQVQsQ0FBb0N0Z0IsT0FBcEMsRUFBNkM7QUFDbEQsTUFBSWdnQixJQUFKOztBQUNBLE1BQUloZ0IsT0FBTyxDQUFDbWdCLE9BQVIsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJILFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx3QkFDTVYsY0FBYyxDQUFDdGYsT0FBTyxDQUFDMkcsS0FBVCxDQURwQixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQTBCMlksY0FBYyxDQUFDdGYsT0FBTyxDQUFDOEcsVUFBVCxDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFPRCxHQVJELE1BUU87QUFDTGtaLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsbUJBQWI7QUFBQSx3QkFBcUNWLGNBQWMsQ0FBQ3RmLE9BQU8sQ0FBQzJHLEtBQVQsQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFHRDs7QUFDRCxTQUFPcVosSUFBUDtBQUNEO01BaEJlTSwwQjtBQWtCVCxTQUFTQywrQkFBVCxDQUF5Q3ZnQixPQUF6QyxFQUFrRDtBQUN2RCxNQUFJZ2dCLElBQUo7QUFFQUEsTUFBSSxnQkFDRjtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHNCQUNNVixjQUFjLENBQUN0ZixPQUFPLENBQUMySixXQUFSLEdBQXNCM0osT0FBTyxDQUFDMkosV0FBOUIsR0FBNEMsQ0FBN0MsQ0FEcEIsZUFFRTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQUEsd0JBQ00yVixjQUFjLENBQUN0ZixPQUFPLENBQUM0RyxZQUFSLEdBQXVCNUcsT0FBTyxDQUFDNEcsWUFBL0IsR0FBOEMsQ0FBL0MsQ0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFLRTtBQUFBLGdCQUFRNUcsT0FBTyxDQUFDNkosS0FBUixHQUFnQjdKLE9BQU8sQ0FBQzZKLEtBQXhCLEdBQWdDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVVBLFNBQU9tVyxJQUFQO0FBQ0Q7TUFkZU8sK0I7QUFlVCxTQUFTQyxnQ0FBVCxDQUEwQ3hnQixPQUExQyxFQUFtRDtBQUN4RCxNQUFJZ2dCLElBQUo7QUFFQUEsTUFBSSxnQkFDRjtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHNCQUNNVixjQUFjLENBQUN0ZixPQUFPLENBQUM4RyxVQUFSLEdBQXFCOUcsT0FBTyxDQUFDOEcsVUFBN0IsR0FBMEMsQ0FBM0MsQ0FEcEIsZUFFRTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQUEsd0JBQ013WSxjQUFjLENBQUN0ZixPQUFPLENBQUMyRyxLQUFSLEdBQWdCM0csT0FBTyxDQUFDMkcsS0FBeEIsR0FBZ0MsQ0FBakMsQ0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFLRTtBQUFBLGdCQUFRM0csT0FBTyxDQUFDNkosS0FBUixHQUFnQjdKLE9BQU8sQ0FBQzZKLEtBQXhCLEdBQWdDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVVBLFNBQU9tVyxJQUFQO0FBQ0Q7TUFkZVEsZ0M7QUFnQlQsU0FBU0Msc0JBQVQsQ0FBZ0N6Z0IsT0FBaEMsRUFBeUM7QUFDOUMsTUFBSWdnQixJQUFKOztBQUVBLE1BQUloZ0IsT0FBTyxDQUFDdUssU0FBWixFQUF1QjtBQUNyQnlWLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdoZ0IsT0FBTyxDQUFDc0osRUFBRyxFQUF2RDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBRyxHQUFFK00sZ0VBQVEsR0FBRXJXLE9BQU8sQ0FBQ3VLLFNBQVIsQ0FBa0JtVyxHQUFJLEVBRDFDO0FBRUUsZUFBRyxFQUFFMWdCLE9BQU8sQ0FBQ3dJO0FBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBWUQsR0FiRCxNQWFPO0FBQ0x3WCxRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGdCLE9BQU8sQ0FBQ3NKLEVBQUcsRUFBdkQ7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFBSyxlQUFHLEVBQUMsMkJBQVQ7QUFBcUMsZUFBRyxFQUFDO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQVNEOztBQUVELFNBQU8wVyxJQUFQO0FBQ0Q7TUE3QmVTLHNCO0FBK0JULFNBQVNFLDJCQUFULENBQXFDM2dCLE9BQXJDLEVBQThDO0FBQ25ELE1BQUlnZ0IsSUFBSjs7QUFFQSxNQUFJaGdCLE9BQU8sQ0FBQ29HLEtBQVIsQ0FBY2dFLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUI0VixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGdCLE9BQU8sQ0FBQzZDLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUU3QyxPQUFGLGFBQUVBLE9BQUYsMENBQUVBLE9BQU8sQ0FBRW9HLEtBQVQsQ0FBZSxDQUFmLENBQUYsb0RBQUUsZ0JBQW1CQSxLQUQxQjtBQUVFLGVBQUcsRUFBRXBHLE9BQU8sQ0FBQytILFlBRmY7QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0QsR0FmRCxNQWVPO0FBQ0xpWSxRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGdCLE9BQU8sQ0FBQzZDLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUMsMkJBRE47QUFFRSxlQUFHLEVBQUMsU0FGTjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRDs7QUFFRCxTQUFPbWQsSUFBUDtBQUNEO01BcENlVywyQjtBQXNDVCxTQUFTQyw0QkFBVCxDQUFzQzVnQixPQUF0QyxFQUErQztBQUNwRCxNQUFJZ2dCLElBQUo7O0FBRUEsTUFBSWhnQixPQUFPLENBQUNvRyxLQUFSLENBQWNnRSxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQUE7O0FBQzVCNFYsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV2hnQixPQUFPLENBQUM2QyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFFN0MsT0FBRixhQUFFQSxPQUFGLDJDQUFFQSxPQUFPLENBQUVvRyxLQUFULENBQWUsQ0FBZixDQUFGLHFEQUFFLGlCQUFtQkEsS0FEMUI7QUFFRSxlQUFHLEVBQUVwRyxPQUFPLENBQUMrSCxZQUZmO0FBR0UsaUJBQUssRUFBQyxNQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNELEdBZkQsTUFlTztBQUNMaVksUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV2hnQixPQUFPLENBQUM2QyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFDLDJCQUROO0FBRUUsZUFBRyxFQUFDLFNBRk47QUFHRSxpQkFBSyxFQUFDLE1BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0Q7O0FBRUQsU0FBT21kLElBQVA7QUFDRDtNQXBDZVksNEI7QUFzQ1QsU0FBU0Msd0JBQVQsQ0FBa0M3Z0IsT0FBbEMsRUFBMkM7QUFDaEQsTUFBSWdnQixJQUFKOztBQUVBLE1BQUloZ0IsT0FBTyxDQUFDb0csS0FBUixDQUFjZ0UsTUFBZCxHQUF1QixDQUEzQixFQUE4QjtBQUFBOztBQUM1QjRWLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdoZ0IsT0FBTyxDQUFDNkMsVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBRTdDLE9BQUYsYUFBRUEsT0FBRiwyQ0FBRUEsT0FBTyxDQUFFb0csS0FBVCxDQUFlLENBQWYsQ0FBRixxREFBRSxpQkFBbUJBLEtBRDFCO0FBRUUsZUFBRyxFQUFFcEcsT0FBTyxDQUFDK0gsWUFGZjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRCxHQWZELE1BZU87QUFDTGlZLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdoZ0IsT0FBTyxDQUFDNkMsVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBQywyQkFETjtBQUVFLGVBQUcsRUFBQyxTQUZOO0FBR0UsaUJBQUssRUFBQyxPQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNEOztBQUVELFNBQU9tZCxJQUFQO0FBQ0Q7T0FwQ2VhLHdCO0FBc0NULFNBQVNDLFdBQVQsR0FBdUI7QUFDNUJ2ZixTQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0QiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMjM2ZWM3ZWRkMmNlMjFjOTI3NzMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgRmF2b3JpdGUsXHJcbiAgRmF2b3JpdGVCb3JkZXIsXHJcbiAgQXNzZXNzbWVudE91dGxpbmVkLFxyXG59IGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnNcIjtcclxuaW1wb3J0IHtcclxuICBnZXRQcm9kdWN0c0J5SWQsXHJcbiAgc2V0Q29uZmlnUHJvZHVjdElELFxyXG4gIHNldENvbmZpZ1Byb2R1Y3RPdXRPZlN0b2NrU2VsbGluZyxcclxuICBzZXRDb25maWdQcm9kdWN0U3RvY2ssXHJcbiAgc2V0UHJvZHVjdFF1YW50aXR5QWN0aW9uLFxyXG4gIHVwZGF0ZVNob2NraW5nc2FsZVdpc2hsaXN0LFxyXG59IGZyb20gXCJ+L3N0b3JlL3Byb2R1Y3QvYWN0aW9uXCI7XHJcbmltcG9ydCB7IGFkZEl0ZW0gfSBmcm9tIFwifi9zdG9yZS9jYXJ0L2FjdGlvblwiO1xyXG5pbXBvcnQgeyBhZGRJdGVtVG9Db21wYXJlIH0gZnJvbSBcIn4vc3RvcmUvY29tcGFyZS9hY3Rpb25cIjtcclxuaW1wb3J0IHtcclxuICBhZGRJdGVtVG9XaXNobGlzdCxcclxuICBhZGRTaG9ja2luZ1NhbGVJdGVtVG9XaXNobGlzdCxcclxuICBnZXRXaXNobGlzdExpc3QsXHJcbiAgcmVtb3ZlU2hvY2tpbmdTYWxlSXRlbUZyb21XaXNobGlzdCxcclxuICByZW1vdmVXaXNobGlzdEl0ZW0sXHJcbn0gZnJvbSBcIn4vc3RvcmUvd2lzaGxpc3QvYWN0aW9uXCI7XHJcblxyXG5pbXBvcnQgeyBnZXRDYXJ0IH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgUHJvZHVjdFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1Byb2R1Y3RSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IEF2YXRhciwgSW1hZ2UsIG5vdGlmaWNhdGlvbiwgUmFkaW8gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBDaXJjdWxhclByb2dyZXNzIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCB7IENvbnRhY3RzT3V0bGluZWQgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zXCI7XHJcbmltcG9ydCBNb2R1bGVEZXRhaWxQcm9kdWN0R3JvdXAgZnJvbSBcIi4vTW9kdWxlRGV0YWlsUHJvZHVjdEdyb3VwXCI7XHJcbmltcG9ydCB7IGN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdCB9IGZyb20gXCJ+L3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlclwiO1xyXG5cclxuY29uc3QgTW9kdWxlRGV0YWlsU2hvcHBpbmdBY3Rpb25zID0gUmVhY3QubWVtbyhcclxuICAoeyBwcm9kdWN0LCBleHRlbmRlZCA9IGZhbHNlLCBzaG9ja2luZ3NhbGUgPSBmYWxzZSB9KSA9PiB7XHJcbiAgICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcbiAgICBjb25zdCBbcXVhbnRpdHksIHNldFF1YW50aXR5XSA9IHVzZVN0YXRlKDEpO1xyXG4gICAgY29uc3QgW3dpc2hsaXN0RnJvbVNlcnZlciwgc2V0V2lzaGxpc3RGcm9tU2VydmVyXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgY29uc3QgW2xvYWRpbmcxLCBzZXRMb2FkaW5nMV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbG9hZGluZzIsIHNldExvYWRpbmcyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nMywgc2V0TG9hZGluZzNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgYXV0aCA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuYXV0aCk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQWRkSXRlbVRvQ2FydCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiLi4uMTExLi4uLi5cIilcclxuICAgICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAgIGxldCB0b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4udXNlcmRhdGEuLi5cIix1c2VyZGF0YSlcclxuICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLi5wYXJzZWRhdGEuLlwiLHBhcnNlZGF0YSlcclxuICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLnRva2VuLi4uXCIsdG9rZW4pXHJcbiAgICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLi4yMjIuLlwiKVxyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBsZWFzZSBsb2dpbiBmaXJzdFwiLFxyXG4gICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAgIHByb2R1Y3Q/LnByb2R1Y3Q/LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiICYmXHJcbiAgICAgICAgKGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbCA9PSBcIlwiIHx8XHJcbiAgICAgICAgICBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsID09IFwiXCIpXHJcbiAgICAgICkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLi4uMTExLi4uNTU1Li5cIilcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgU2VsZWN0IFZhcmllbnRcIixcclxuICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uNjY2Li4uXCIpXHJcbiAgICAgICAgc2V0TG9hZGluZzEodHJ1ZSk7XHJcbiAgICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAvLyB1c2VyX2lkOiAxLFxyXG4gICAgICAgICAgcHJkX2Fzc2lnbl9pZDpcIlwiLFxyXG4gICAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxyXG4gICAgICAgICAgY2FydF90eXBlOiBcIndlYlwiLFxyXG4gICAgICAgICAgYWNjZXNzX3Rva2VuOiB0b2tlbixcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLi4uMTExLi43NzcuLi5cIilcclxuICAgICAgICBpZiAocHJvZHVjdD8ucHJvZHVjdD8ucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIpIHtcclxuICAgICAgICAgIFxyXG5cclxuICAgICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGdldFByb2R1Y3RJZChmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsKSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICBjb25zdCB7IG91dF9vZl9zdG9ja19zZWxsaW5nLCBzdG9jayB9ID0gZ2V0T3V0T2ZzdG9ja1ZhbHVlQ29uZmlnUHJvZChcclxuICAgICAgICAgICAgZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2l6ZVNlbFxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBpZiAob3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmIHN0b2NrIDw9IDApIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLjg4ODguLi5cIilcclxuICAgICAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIixcclxuICAgICAgICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLy9jb25kaXRpb24gZm9yIGNvbmZpZyBlbmRcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLi45OTkuLlwiKVxyXG4gICAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgICAgLi4ucGF5bG9hZCxcclxuICAgICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Qub3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmXHJcbiAgICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5zdG9jayA8PSAwXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLjExMTEyMjIuLi5cIilcclxuICAgICAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIixcclxuICAgICAgICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XHJcbiAgICAgICAgICBwYXlsb2FkPy5hY2Nlc3NfdG9rZW4gJiZcclxuICAgICAgICBcclxuICAgICAgICAgIChhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5hZGRQcm9kdWN0VG9DYXJ0KHBheWxvYWQpKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlRGF0YSAmJiByZXNwb25zZURhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgICAgICAgbGV0IHRtcCA9IHByb2R1Y3Q7XHJcbiAgICAgICAgICB0bXAucXVhbnRpdHkgPSBxdWFudGl0eTtcclxuICAgICAgICAgIC8vIGRpc3BhdGNoKGFkZEl0ZW0odG1wKSk7XHJcbiAgICAgICAgICBkaXNwYXRjaChnZXRDYXJ0KCkpO1xyXG5cclxuICAgICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuICAgICAgICAgIG5vdGlmaWNhdGlvbltyZXNwb25zZURhdGEuc3RhdHVzXSh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlRGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogcmVzcG9uc2VEYXRhLnJlc3BvbnNlLFxyXG4gICAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIFJvdXRlci5wdXNoKFwiL2FjY291bnQvc2hvcHBpbmctY2FydFwiKTtcclxuICAgICAgICAgIH0sIDIwMCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogcmVzcG9uc2VEYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nMShmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUJ1eW5vdyA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIGlmIChhdXRoLmlzTG9nZ2VkSW4gIT09IHRydWUpIHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgbG9naW4gZmlyc3RcIixcclxuICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIgJiZcclxuICAgICAgICAoZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsID09IFwiXCIgfHxcclxuICAgICAgICAgIGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWwgPT0gXCJcIilcclxuICAgICAgKSB7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIFNlbGVjdCBWYXJpZW50XCIsXHJcbiAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0TG9hZGluZzIodHJ1ZSk7XHJcbiAgICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAvLyB1c2VyX2lkOiAxLFxyXG4gICAgICAgICAgcHJkX2Fzc2lnbl9pZDpcIlwiLFxyXG4gICAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxyXG4gICAgICAgICAgYWNjZXNzX3Rva2VuOiBhdXRoLmFjY2Vzc190b2tlbixcclxuICAgICAgICAgIGNhcnRfdHlwZTogXCJ3ZWJcIixcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAocHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiKSB7XHJcbiAgICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBnZXRQcm9kdWN0SWQoZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2l6ZVNlbCksXHJcbiAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgIGNvbnN0IHsgb3V0X29mX3N0b2NrX3NlbGxpbmcsIHN0b2NrIH0gPSBnZXRPdXRPZnN0b2NrVmFsdWVDb25maWdQcm9kKFxyXG4gICAgICAgICAgICBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGlmIChvdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiYgc3RvY2sgPD0gMCkge1xyXG4gICAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2R1Y3QgT3V0IG9mIFN0b2NrIVwiLFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5vdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiZcclxuICAgICAgICAgICAgcHJvZHVjdC5wcm9kdWN0LnN0b2NrIDw9IDBcclxuICAgICAgICAgICkge1xyXG4gICAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2R1Y3QgT3V0IG9mIFN0b2NrIVwiLFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXNwb25zZURhdGEgPSBhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5hZGRQcm9kdWN0VG9DYXJ0KHBheWxvYWQpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2VEYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgbGV0IHRtcCA9IHByb2R1Y3Q7XHJcbiAgICAgICAgICB0bXAucXVhbnRpdHkgPSBxdWFudGl0eTtcclxuICAgICAgICAgIG5vdGlmaWNhdGlvbltyZXNwb25zZURhdGEuc3RhdHVzXSh7XHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZURhdGEucmVzcG9uc2UsXHJcbiAgICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICAvLyBkaXNwYXRjaChhZGRJdGVtKHRtcCkpO1xyXG4gICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIFJvdXRlci5wdXNoKFwiL2FjY291bnQvY2hlY2tvdXRcIik7XHJcbiAgICAgICAgICB9LCAxMDAwKTtcclxuICAgICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQWRkSXRlbVRvQ29tcGFyZSA9IChlKSA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKGFkZEl0ZW1Ub0NvbXBhcmUocHJvZHVjdCkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBZGRJdGVtVG9XaXNobGlzdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgIFxyXG4gICAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgICAgbGV0IHRva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIsXHJcbiAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHNob2NraW5nc2FsZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICBkaXNwYXRjaChhZGRTaG9ja2luZ1NhbGVJdGVtVG9XaXNobGlzdChwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcImxsbGxsLi4uLi4uLi4uLmxsLi4uLlwiLHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X2lkKVxyXG4gICAgICAgICAgZGlzcGF0Y2goYWRkSXRlbVRvV2lzaGxpc3QocHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfaWQpKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVtb3ZlV2lzaExpc3RJdGVtID0gKCkgPT4ge1xyXG4gICAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgICAgbGV0IHRva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIsXHJcbiAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKHNob2NraW5nc2FsZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICBkaXNwYXRjaChcclxuICAgICAgICAgICAgcmVtb3ZlU2hvY2tpbmdTYWxlSXRlbUZyb21XaXNobGlzdChwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZClcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGRpc3BhdGNoKHJlbW92ZVdpc2hsaXN0SXRlbShwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVJbmNyZWFzZUl0ZW1RdHkgPSAoZSkgPT4ge1xyXG4gICAgICBzZXRRdWFudGl0eShxdWFudGl0eSArIDEpO1xyXG4gICAgICBkaXNwYXRjaChzZXRQcm9kdWN0UXVhbnRpdHlBY3Rpb24ocXVhbnRpdHkgKyAxKSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZURlY3JlYXNlSXRlbVF0eSA9IChlKSA9PiB7XHJcbiAgICAgIGlmIChxdWFudGl0eSA+IDEpIHtcclxuICAgICAgICBzZXRRdWFudGl0eShxdWFudGl0eSAtIDEpO1xyXG4gICAgICAgIGRpc3BhdGNoKHNldFByb2R1Y3RRdWFudGl0eUFjdGlvbihxdWFudGl0eSAtIDEpKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBbYXNzb2NpYXRpdmVQcm9kLCBzZXRBc3NvY2lhdGl2ZVByb2RdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3VuaXF1ZUFzc29jaWF0aXZlUHJvZCwgc2V0VW5pcXVlQXNzb2NpYXRpdmVQcm9kXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgICBjb25zdCBbZmlsdGVyQXNzb2NQcm9kLCBzZXRGaWx0ZXJBc3NvY1Byb2RdID0gdXNlU3RhdGUoe1xyXG4gICAgICBhc3NvY1ZhbDogXCJcIixcclxuICAgICAgYXNzb2NWYWxTZWw6IFwiXCIsXHJcbiAgICAgIGFzc29jVmFsU2l6ZTogXCJcIixcclxuICAgICAgYXNzb2NWYWxTaXplU2VsOiBcIlwiLFxyXG4gICAgICBhc3NvY1Byb2RJZDogXCJcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIHNldEFzc29jaWF0aXZlUHJvZChwcm9kdWN0Py5hc3NvY2lhdGl2ZV9wcm9kdWN0cyk7XHJcbiAgICAgIGxldCBhcnJheVZhbHMgPSBbXHJcbiAgICAgICAgLi4ubmV3IE1hcChcclxuICAgICAgICAgIHByb2R1Y3Q/LmFzc29jaWF0aXZlX3Byb2R1Y3RzPy5tYXAoKGl0ZW0pID0+IFtcclxuICAgICAgICAgICAgaXRlbVtcImF0dHJfdmFsdWVcIl0sXHJcbiAgICAgICAgICAgIGl0ZW0sXHJcbiAgICAgICAgICBdKVxyXG4gICAgICAgICkudmFsdWVzKCksXHJcbiAgICAgIF07XHJcbiAgICAgIHNldFVuaXF1ZUFzc29jaWF0aXZlUHJvZChhcnJheVZhbHMpO1xyXG4gICAgfSwgW3Byb2R1Y3RdKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDaGFuZ2VBdHRyID0gKGUpID0+IHtcclxuICAgICAgc2V0RmlsdGVyQXNzb2NQcm9kKHsgLi4uZmlsdGVyQXNzb2NQcm9kLCBhc3NvY1ZhbFNlbDogZS50YXJnZXQudmFsdWUgfSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGdldFByb2R1Y3RJZChmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsKTtcclxuICAgICAgfSwgMTAwMCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZUF0dHJTaXplID0gKGUpID0+IHtcclxuICAgICAgc2V0RmlsdGVyQXNzb2NQcm9kKHtcclxuICAgICAgICAuLi5maWx0ZXJBc3NvY1Byb2QsXHJcbiAgICAgICAgYXNzb2NWYWxTaXplU2VsOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGdldFByb2R1Y3RJZChlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgIH0sIDEwMDApO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZW5kZXJBc3NvY2lhdGl2ZVByb2R1Y3QgPSAoKSA9PiB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19ncm91cHBlZFwiPlxyXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInRhYmxlIHRhYmxlLWJvcmRlcmxlc3NcIj5cclxuICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCJsYXJnZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjIwJVwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YXNzb2NpYXRpdmVQcm9kWzBdPy5hdHRyX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2VBdHRyfVxyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17ZmlsdGVyQXNzb2NQcm9kPy5hc3NvY1ZhbH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1bmlxdWVBc3NvY2lhdGl2ZVByb2Q/Lm1hcCgoYXR0ciwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSYWRpby5CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXR0ci5hdHRyX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXItMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIHNyYz17YXR0ci5pbWFnZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZD48L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbCA/IChcclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIyMCVcIixcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2Fzc29jaWF0aXZlUHJvZFswXT8uc3ViX2F0dHJpYnV0ZXNbMF0/LmF0dHJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSYWRpby5Hcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZUF0dHJTaXplfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHthc3NvY2lhdGl2ZVByb2RcclxuICAgICAgICAgICAgICAgICAgICAgICAgPy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHByb2QpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kLmF0dHJfdmFsdWUudG9Mb3dlckNhc2UoKSA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgPy5tYXAoKGF0dHIpID0+IGF0dHIuc3ViX2F0dHJpYnV0ZXNbMF0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8ubWFwKCh2YWx1ZXMsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSYWRpby5CdXR0b24gdmFsdWU9e3ZhbHVlcy5hdHRyX3ZhbHVlfSBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZhbHVlcy5hdHRyX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSA6IG51bGx9XHJcblxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsID8gKFxyXG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT17cmVuZGVyUHJpY2UoKSAhPT0gdW5kZWZpbmVkID8gYGAgOiBgZC1ub25lYH0+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA1MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCJsYXJnZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMjAlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFByaWNlOlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNDAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwibGFyZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdChyZW5kZXJQcmljZSgpKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVuZGVyUHJpY2UgPSAoKSA9PiB7XHJcbiAgICAgIC8vIGNvbnN0IHByaWNlID0gYXNzb2NpYXRpdmVQcm9kXHJcbiAgICAgIC8vICAgPy5maWx0ZXIoKHByb2QpID0+IHByb2QuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTZWwpWzBdXHJcbiAgICAgIC8vICAgPy5zdWJfYXR0cmlidXRlcz8uZmlsdGVyKFxyXG4gICAgICAvLyAgICAgKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsXHJcbiAgICAgIC8vICAgKVswXT8uYWN0dWFsX3ByaWNlO1xyXG5cclxuICAgICAgY29uc3QgcHJpY2UgPSBhc3NvY2lhdGl2ZVByb2RcclxuICAgICAgICA/LmZpbHRlcigocHJvZCkgPT4gcHJvZC5hdHRyX3ZhbHVlID09IGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbClcclxuICAgICAgICA/Lm1hcCgoYXR0cikgPT4gYXR0ci5zdWJfYXR0cmlidXRlc1swXSlcclxuICAgICAgICA/LmZpbHRlcihcclxuICAgICAgICAgIChhdHRyKSA9PiBhdHRyLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2l6ZVNlbFxyXG4gICAgICAgIClbMF0/LmFjdHVhbF9wcmljZTtcclxuXHJcbiAgICAgIGNvbnN0IHByb2Rfc2FsZV9wcmljZSA9IGFzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgID8uZmlsdGVyKChwcm9kKSA9PiBwcm9kLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsKVxyXG4gICAgICAgID8ubWFwKChhdHRyKSA9PiBhdHRyLnN1Yl9hdHRyaWJ1dGVzWzBdKVxyXG4gICAgICAgID8uZmlsdGVyKFxyXG4gICAgICAgICAgKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsXHJcbiAgICAgICAgKVswXT8uc2FsZV9wcmljZTtcclxuXHJcbiAgICAgIGlmIChwcm9kX3NhbGVfcHJpY2UgIT09IGZhbHNlKSB7XHJcbiAgICAgICAgcmV0dXJuIHByb2Rfc2FsZV9wcmljZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gcHJpY2U7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZ2V0T3V0T2ZzdG9ja1ZhbHVlQ29uZmlnUHJvZCA9IChzaXplVmFsdWUpID0+IHtcclxuICAgICAgY29uc3Qgb3V0X29mX3N0b2NrX3NlbGxpbmcgPSBhc3NvY2lhdGl2ZVByb2RcclxuICAgICAgICA/LmZpbHRlcigocHJvZCkgPT4gcHJvZC5hdHRyX3ZhbHVlID09IGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbClcclxuICAgICAgICA/Lm1hcCgoYXR0cikgPT4gYXR0ci5zdWJfYXR0cmlidXRlc1swXSlcclxuICAgICAgICA/LmZpbHRlcihcclxuICAgICAgICAgIChhdHRyKSA9PiBhdHRyLmF0dHJfdmFsdWUgPT0gc2l6ZVZhbHVlXHJcbiAgICAgICAgKVswXT8ub3V0X29mX3N0b2NrX3NlbGxpbmc7XHJcblxyXG4gICAgICBjb25zdCBzdG9jayA9IGFzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgID8uZmlsdGVyKChwcm9kKSA9PiBwcm9kLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsKVxyXG4gICAgICAgID8ubWFwKChhdHRyKSA9PiBhdHRyLnN1Yl9hdHRyaWJ1dGVzWzBdKVxyXG4gICAgICAgID8uZmlsdGVyKChhdHRyKSA9PiBhdHRyLmF0dHJfdmFsdWUgPT0gc2l6ZVZhbHVlKVswXT8uc3RvY2s7XHJcblxyXG4gICAgICByZXR1cm4geyBzdG9jaywgb3V0X29mX3N0b2NrX3NlbGxpbmcgfTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZ2V0UHJvZHVjdElkID0gKHNpemVWYWx1ZSkgPT4ge1xyXG4gICAgICBjb25zdCBzZWxlY3RlZFByb2R1Y3RJRCA9IGFzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgID8uZmlsdGVyKChwcm9kKSA9PiBwcm9kLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsKVxyXG4gICAgICAgID8ubWFwKChhdHRyKSA9PiBhdHRyLnN1Yl9hdHRyaWJ1dGVzWzBdKVxyXG4gICAgICAgID8uZmlsdGVyKChhdHRyKSA9PiBhdHRyLmF0dHJfdmFsdWUgPT0gc2l6ZVZhbHVlKVswXT8ucHJvZHVjdF9pZDtcclxuICAgICAgY29uc3QgeyBzdG9jaywgb3V0X29mX3N0b2NrX3NlbGxpbmcgfSA9XHJcbiAgICAgICAgZ2V0T3V0T2ZzdG9ja1ZhbHVlQ29uZmlnUHJvZChzaXplVmFsdWUpO1xyXG5cclxuICAgICAgZGlzcGF0Y2goc2V0Q29uZmlnUHJvZHVjdElEKHNlbGVjdGVkUHJvZHVjdElEKSk7XHJcbiAgICAgIGRpc3BhdGNoKHNldENvbmZpZ1Byb2R1Y3RTdG9jayhzdG9jaykpO1xyXG4gICAgICBkaXNwYXRjaChzZXRDb25maWdQcm9kdWN0T3V0T2ZTdG9ja1NlbGxpbmcob3V0X29mX3N0b2NrX3NlbGxpbmcpKTtcclxuXHJcbiAgICAgIHJldHVybiBzZWxlY3RlZFByb2R1Y3RJRDtcclxuICAgIH07XHJcblxyXG4gICAgaWYgKCFleHRlbmRlZCAmJiBwcm9kdWN0LnByb2R1Y3QpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAge3Byb2R1Y3Q/LnByb2R1Y3Q/LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiXHJcbiAgICAgICAgICAgID8gcmVuZGVyQXNzb2NpYXRpdmVQcm9kdWN0KClcclxuICAgICAgICAgICAgOiBudWxsfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fc2hvcHBpbmdcIj5cclxuICAgICAgICAgICAgPGZpZ3VyZT5cclxuICAgICAgICAgICAgICA8ZmlnY2FwdGlvbj5RdWFudGl0eTwvZmlnY2FwdGlvbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtLW51bWJlclwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1cFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVJbmNyZWFzZUl0ZW1RdHkoZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXBsdXNcIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZG93blwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVEZWNyZWFzZUl0ZW1RdHkoZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLW1pbnVzXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cXVhbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1idG4gcHMtYnRuLS15ZWxsb3dcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVBZGRJdGVtVG9DYXJ0KGUpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcxID8gPENpcmN1bGFyUHJvZ3Jlc3Mgc2l6ZT17MjB9IC8+IDogXCJBZGQgdG8gY2FydDFcIn1cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJwcy1idG4gcHMtYnRuLS1ibHVcIiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQnV5bm93KGUpfT5cclxuICAgICAgICAgICAgICB7bG9hZGluZzIgPyA8Q2lyY3VsYXJQcm9ncmVzcyBzaXplPXsyMH0gLz4gOiBcIkJ1eSBOb3dcIn1cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2FjdGlvbnNcIj5cclxuICAgICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICAgIHtsb2FkaW5nMyA/IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyUHJvZ3Jlc3Mgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICBwcm9kdWN0LnByb2R1Y3QuaW5fd2lzaGxpc3QgPT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEZhdm9yaXRlQm9yZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17XCJpbmhlcml0XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVBZGRJdGVtVG9XaXNobGlzdChlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2xvYWRpbmczID8gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJQcm9ncmVzcyBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5pbl93aXNobGlzdCA9PSAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8RmF2b3JpdGVcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPXtcInNlY29uZGFyeVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlUmVtb3ZlV2lzaExpc3RJdGVtKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgIHsvKiA8YSBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvQ29tcGFyZShlKX0+XHJcbiAgICAgICAgICAgIDxBc3Nlc3NtZW50T3V0bGluZWRcclxuICAgICAgICAgICAgICBmb250U2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICBzdHlsZT17eyBjdXJzb3I6IFwicG9pbnRlclwiIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2E+ICovfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3Nob3BwaW5nIGV4dGVuZFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19idG4tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGZpZ3VyZT5cclxuICAgICAgICAgICAgICA8ZmlnY2FwdGlvbj5RdWFudGl0eTwvZmlnY2FwdGlvbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtLW51bWJlclwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ1cFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVJbmNyZWFzZUl0ZW1RdHkoZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXBsdXNcIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZG93blwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVEZWNyZWFzZUl0ZW1RdHkoZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLW1pbnVzXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cXVhbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1idG4gcHMtYnRuLS1ibGFja1wiXHJcbiAgICAgICAgICAgICAgaHJlZj1cIiNcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVBZGRJdGVtVG9DYXJ0KGUpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQWRkIHRvIGNhcnQyXHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvV2lzaGxpc3QoZSl9PlxyXG4gICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiaWNvbi1oZWFydFwiPjwvaT5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgey8qIDxhIGhyZWY9XCIjXCIgb25DbGljaz17KGUpID0+IGhhbmRsZUFkZEl0ZW1Ub0NvbXBhcmUoZSl9PlxyXG4gICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24tY2hhcnQtYmFyc1wiPjwvaT5cclxuICAgICAgICAgICAgPC9hPiAqL31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLWJ0biB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgaHJlZj1cIiNcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQnV5bm93KGUpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBCdXkgTm93XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG4pO1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgY29ubmVjdCgoc3RhdGUpID0+IHN0YXRlKShNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMpO1xyXG5leHBvcnQgZGVmYXVsdCBNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnM7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQgfSBmcm9tIFwifi91dGlsaXRpZXMvcHJvZHVjdC1oZWxwZXJcIjtcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBQcm9kdWN0VGh1bWJuYWlsIGZyb20gXCIuLi9jb21tb24vUHJvZHVjdFRodW1ibmFpbFwiO1xyXG5pbXBvcnQgQ291bnREb3duU2ltcGxlRGlmZiBmcm9tIFwiLi4vQ291bnREb3duU2ltcGxlRGlmZlwiO1xyXG5cclxuY29uc3QgUHJvZHVjdEF1Y3Rpb24gPSAoeyBwcm9kdWN0LCB3aWR0aEdpdmVuLCBtYXJnaW5HaXZlbiB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIHN0eWxlPXt7IHdpZHRoOiB3aWR0aEdpdmVuIHx8IDI1NSwgbWFyZ2luOiBtYXJnaW5HaXZlbiB8fCBcIjIwcHhcIiB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1ibG9jay0tY291bnRkb3duLWRlYWwgbWItM1wiPlxyXG4gICAgICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwiZmlndXJlLXRpbWVyLS1mb250XCI+XHJcbiAgICAgICAgICA8ZmlnY2FwdGlvbj5FbmQgaW46PC9maWdjYXB0aW9uPlxyXG4gICAgICAgICAgPENvdW50RG93blNpbXBsZURpZmZcclxuICAgICAgICAgICAgZW5kVGltZT17cHJvZHVjdC5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgY2xhc3NBZGQ9e1wiaG9tZS1hdWN0aW9uLS1zbGlkZXJcIn1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3RodW1ibmFpbFwiPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9XCIvYXVjdGlvbi9bcGlkXVwiIGFzPXtgL2F1Y3Rpb24vJHtwcm9kdWN0LmF1Y3Rpb25faWR9YH0+XHJcbiAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgPFByb2R1Y3RUaHVtYm5haWwgaW1hZ2VMaW5rPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9IC8+XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19jb250YWluZXIgbXQtMiB0ZXh0LXRydW5jYXRlXCI+XHJcbiAgICAgICAgPExpbmsgaHJlZj1cIi9hdWN0aW9uL1twaWRdXCIgYXM9e2AvYXVjdGlvbi8ke3Byb2R1Y3QuYXVjdGlvbl9pZH1gfT5cclxuICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ZlbmRvclwiIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IFwiNDAwXCIgfX0+XHJcbiAgICAgICAgICAgIHtwcm9kdWN0LnNlbGxlciA/IHByb2R1Y3Quc2VsbGVyIDogXCJOQVwifVxyXG4gICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8aHIgLz5cclxuICAgICAgICB7cHJvZHVjdC5zYWxlX3ByaWNlICE9PSBmYWxzZSA/IChcclxuICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcImxhcmdlXCIgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUk0ge3Byb2R1Y3Quc2FsZV9wcmljZX1cclxuICAgICAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+Uk0ge3Byb2R1Y3QucHJpY2V9PC9kZWw+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcImxhcmdlXCIgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUk0ge3Byb2R1Y3QucHJpY2V9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2NvbnRlbnRcIj5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYXVjdGlvbi9bcGlkXVwiIGFzPXtgL2F1Y3Rpb24vJHtwcm9kdWN0LmF1Y3Rpb25faWR9YH0+XHJcbiAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGl0bGUgZC1pbmxpbmUtYmxvY2sgdGV4dC10cnVuY2F0ZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA1MDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiMXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6IFwiMjAwcHhcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XHJcbiAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgTm8uIG9mIEJpZHNcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxvYXQtcmlnaHRcIj57cHJvZHVjdC5ub19vZl9iaWRzfTwvc3Bhbj5cclxuICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgIE1pbi4gQmlkXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsb2F0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAge2N1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdChwcm9kdWN0Lm1pbl9iaWRfcHJpY2UpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9DYXJkPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0QXVjdGlvbjtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCB7IGN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdCB9IGZyb20gXCJ+L3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlclwiO1xyXG5pbXBvcnQgTGF6eUxvYWQgZnJvbSBcInJlYWN0LWxhenlsb2FkXCI7XHJcbmltcG9ydCB7IENhcmQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgUHJvZHVjdFRodW1ibmFpbCBmcm9tIFwiLi4vY29tbW9uL1Byb2R1Y3RUaHVtYm5haWxcIjtcclxuXHJcbmNvbnN0IFByb2R1Y3RBdWN0aW9uU2xpZGUgPSAoeyBwcm9kdWN0IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPENhcmQgYm9yZGVyZWQ9e2ZhbHNlfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWJsb2NrLS1jb3VudGRvd24tZGVhbCBtYi0zXCI+XHJcbiAgICAgICAgICA8ZmlndXJlIGNsYXNzTmFtZT1cImZpZ3VyZS10aW1lci0tZm9udFwiPlxyXG4gICAgICAgICAgICA8ZmlnY2FwdGlvbj5FbmQgaW46PC9maWdjYXB0aW9uPlxyXG4gICAgICAgICAgICA8Q291bnREb3duU2ltcGxlRGlmZlxyXG4gICAgICAgICAgICAgIGVuZFRpbWU9e3Byb2R1Y3QuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgY2xhc3NBZGQ9e1wiaG9tZS1hdWN0aW9uLS1zbGlkZXJcIn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZmlndXJlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGh1bWJuYWlsXCI+XHJcbiAgICAgICAgICB7cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlID8gKFxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2F1Y3Rpb24vW3BpZF1cIiBhcz17YC9hdWN0aW9uLyR7cHJvZHVjdC5hdWN0aW9uX2lkfWB9PlxyXG4gICAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICAgICAgICA8UHJvZHVjdFRodW1ibmFpbCBpbWFnZUxpbms9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX0gLz5cclxuICAgICAgICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2F1Y3Rpb24vW3BpZF1cIiBhcz17YC9hdWN0aW9uLyR7cHJvZHVjdC5hdWN0aW9uX2lkfWB9PlxyXG4gICAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiMTUwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19jb250YWluZXIgbXQtMiB0ZXh0LXRydW5jYXRlXCI+XHJcbiAgICAgICAgICA8TGluayBocmVmPVwiL2F1Y3Rpb24vW3BpZF1cIiBhcz17YC9hdWN0aW9uLyR7cHJvZHVjdC5hdWN0aW9uX2lkfWB9PlxyXG4gICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X192ZW5kb3JcIiBzdHlsZT17eyBmb250V2VpZ2h0OiBcIjQwMFwiIH19PlxyXG4gICAgICAgICAgICAgIHtwcm9kdWN0LnNlbGxlciA/IHByb2R1Y3Quc2VsbGVyIDogXCJOQVwifVxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8aHIgLz5cclxuICAgICAgICAgIHtwcm9kdWN0LnNhbGVfcHJpY2UgIT09IGZhbHNlID8gKFxyXG4gICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCJcclxuICAgICAgICAgICAgICBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwibGFyZ2VcIiB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUk0ge3Byb2R1Y3Quc2FsZV9wcmljZX1cclxuICAgICAgICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5STSB7cHJvZHVjdC5wcmljZX08L2RlbD5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFdlaWdodDogXCJib2xkXCIsIGZvbnRTaXplOiBcImxhcmdlXCIgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJNIHtwcm9kdWN0LnByaWNlfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19jb250ZW50XCI+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYXVjdGlvbi9bcGlkXVwiIGFzPXtgL2F1Y3Rpb24vJHtwcm9kdWN0LmF1Y3Rpb25faWR9YH0+XHJcbiAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3RpdGxlIGQtaW5saW5lLWJsb2NrIHRleHQtdHJ1bmNhdGVcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwibGFyZ2VcIixcclxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNTAwLFxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiMXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICBtYXhXaWR0aDogXCIyMDBweFwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cHJvZHVjdC5wcm9kdWN0X25hbWV9XHJcbiAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICBOby4gb2YgQmlkc1xyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsb2F0LXJpZ2h0XCI+e3Byb2R1Y3Qubm9fb2ZfYmlkc308L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgTWluLiBCaWRcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbG9hdC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAge2N1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdChwcm9kdWN0Lm1pbl9iaWRfcHJpY2UpfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0QXVjdGlvblNsaWRlO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgcmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3IH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uLCBNb2RhbCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBQcm9kdWN0T25DYXJ0ID0gKHsgcHJvZHVjdCB9KSA9PiB7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUNhcnRJdGVtID0gYXN5bmMgKHByb2R1Y3QpID0+IHtcclxuICAgIC8vIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIsXHJcbiAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAgIGxldCB0b2tlbiA9IHBhcnNlZGF0YS5hY2Nlc3NfdG9rZW47XHJcbiAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGNhcnRfaWQ6IFtwcm9kdWN0LmNhcnRfaWRdLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjogdG9rZW4sXHJcbiAgICAgIH07XHJcbiAgICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4gICAgICAgIHRpdGxlOiBcIkRlbGV0ZSB0aGlzIHByb2R1Y3Q/XCIsXHJcbiAgICAgICAgb25PazogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgIGRpc3BhdGNoKHJlbW92ZVByb2R1Y3RGcm9tQ2FydE5ldyhwYXlsb2FkKSk7XHJcbiAgICAgICAgICBNb2RhbC5kZXN0cm95QWxsKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkNhbmNlbDogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgIE1vZGFsLmRlc3Ryb3lBbGwoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9rQnV0dG9uUHJvcHM6IHtcclxuICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0LS1jYXJ0LW1vYmlsZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3RodW1ibmFpbFwiPlxyXG4gICAgICAgIHsvKiB7U3RyYXBpUHJvZHVjdFRodW1ibmFpbChwcm9kdWN0KX0gKi99XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2UgfHwgXCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJ9XHJcbiAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgZS50YXJnZXQuc3JjID0gXCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCI7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgYWx0PVwicHJvZHVjdFwiXHJcbiAgICAgICAgICB0aXRsZT1cInByb2R1Y3RcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2NvbnRlbnRcIj5cclxuICAgICAgICA8YVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcmVtb3ZlXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVSZW1vdmVDYXJ0SXRlbShwcm9kdWN0KX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWNyb3NzXCI+PC9pPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGl0bGVcIj5cclxuICAgICAgICAgICAge3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICB7cHJvZHVjdC5hdHRyX25hbWUxXHJcbiAgICAgICAgICAgICAgPyBgICgke3Byb2R1Y3QuYXR0cl9uYW1lMX0ke1xyXG4gICAgICAgICAgICAgICAgICBwcm9kdWN0LmF0dHJfbmFtZTIgPyBgICR7cHJvZHVjdC5hdHRyX25hbWUyfWAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICB9KWBcclxuICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICBSTXtcIiBcIn1cclxuICAgICAgICAgICAge3Byb2R1Y3QudW5pdF9kaXNjb3VudF9wcmljZSAhPT0gZmFsc2UgPyAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgIDxkZWw+e3Byb2R1Y3QudW5pdF9hY3R1YWxfcHJpY2V9PC9kZWw+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3QudW5pdF9kaXNjb3VudF9wcmljZX1cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICBwcm9kdWN0LnVuaXRfYWN0dWFsX3ByaWNlXHJcbiAgICAgICAgICAgICl9e1wiIFwifVxyXG4gICAgICAgICAgICB4IHtwcm9kdWN0LnF1YW50aXR5fVxyXG4gICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2R1Y3RPbkNhcnQ7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgTGF6eUxvYWQgZnJvbSBcInJlYWN0LWxhenlsb2FkXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIFN0cmFwaVByb2R1Y3RQcmljZSxcclxuICBTdHJhcGlQcm9kdWN0VGh1bWJuYWlsLFxyXG59IGZyb20gXCJ+L3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlclwiO1xyXG5pbXBvcnQgUmF0aW5nIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvUmF0aW5nXCI7XHJcblxyXG5jb25zdCBQcm9kdWN0U2VhcmNoUmVzdWx0ID0gKHsgcHJvZHVjdCB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdCBwcy1wcm9kdWN0LS13aWRlIHBzLXByb2R1Y3QtLXNlYXJjaC1yZXN1bHRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X190aHVtYm5haWxcIj5cclxuICAgICAgICB7Lyoge1N0cmFwaVByb2R1Y3RUaHVtYm5haWwocHJvZHVjdCl9ICovfVxyXG5cclxuICAgICAgICB7cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlID8gKFxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9IGFsdD17cHJvZHVjdC50aXRsZX0gLz5cclxuICAgICAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIiBhbHQ9XCJLYW5ndGFvXCIgLz5cclxuICAgICAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGVudFwiPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGl0bGVcIj57cHJvZHVjdC5wcm9kdWN0X25hbWV9PC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3JhdGluZ1wiPlxyXG4gICAgICAgICAgPFJhdGluZyByYXRpbmc9e3Byb2R1Y3QucmF0aW5nfSAvPlxyXG4gICAgICAgICAgey8qIDxzcGFuPntwcm9kdWN0LnJhdGluZ0NvdW50fTwvc3Bhbj4gKi99XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge3Byb2R1Y3Quc2FsZV9wcmljZSA+IDAgPyAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBzYWxlXCI+XHJcbiAgICAgICAgICAgIFJNIHtwcm9kdWN0LnNhbGVfcHJpY2V9XHJcbiAgICAgICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L2RlbD5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0U2VhcmNoUmVzdWx0O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcbmltcG9ydCBSYXRpbmcgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9SYXRpbmdcIjtcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBQcm9kdWN0VGh1bWJuYWlsIGZyb20gXCIuLi9jb21tb24vUHJvZHVjdFRodW1ibmFpbFwiO1xyXG5pbXBvcnQgQ291bnREb3duU2ltcGxlRGlmZiBmcm9tIFwiLi4vQ291bnREb3duU2ltcGxlRGlmZlwiO1xyXG5cclxuY29uc3QgUHJvZHVjdFNob2NraW5nU2FsZSA9ICh7IHByb2R1Y3QgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8Q2FyZCBzdHlsZT17eyB3aWR0aDogMjU1LCBtYXJnaW46IFwiMjBweFwiIH19IGNsYXNzTmFtZT1cInRleHQtY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtYmxvY2stLWNvdW50ZG93bi1kZWFsIG1iLTNcIj5cclxuICAgICAgICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwiZmlndXJlLXRpbWVyLS1mb250XCI+XHJcbiAgICAgICAgICAgIDxmaWdjYXB0aW9uPkVuZCBpbjo8L2ZpZ2NhcHRpb24+XHJcbiAgICAgICAgICAgIDxDb3VudERvd25TaW1wbGVEaWZmXHJcbiAgICAgICAgICAgICAgZW5kVGltZT17cHJvZHVjdC5lbmRfdGltZX1cclxuICAgICAgICAgICAgICBjbGFzc0FkZD17XCJob21lLXNob2NraW5nc2FsZS0tc2xpZGVyXCJ9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17YHNob2NraW5nc2FsZS8ke3Byb2R1Y3Quc2hvY2tfc2FsZV9pZH0/cHJfaWQ9JHtwcm9kdWN0LnByb2R1Y3RfaWR9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgPFByb2R1Y3RUaHVtYm5haWwgaW1hZ2VMaW5rPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9IC8+XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGFpbmVyIHRleHQtdHJ1bmNhdGVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGVudCBtdC00XCI+XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgaHJlZj17YHNob2NraW5nc2FsZS8ke3Byb2R1Y3Quc2hvY2tfc2FsZV9pZH0/cHJfaWQ9JHtwcm9kdWN0LnByb2R1Y3RfaWR9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X190aXRsZSBkLWlubGluZS1ibG9jayB0ZXh0LXRydW5jYXRlXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiBcIjFyZW1cIixcclxuICAgICAgICAgICAgICAgICAgbWF4V2lkdGg6IFwiMjAwcHhcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3JhdGluZ1wiPlxyXG4gICAgICAgICAgICAgIDxSYXRpbmcgcmF0aW5nPXtwcm9kdWN0LnJhdGluZ30gLz4gPHNwYW4+e3Byb2R1Y3QucmF0aW5nfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcImxpZ2h0ZXJcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUk0ge3Byb2R1Y3Qub2ZmZXJfcHJpY2UgIT09IGZhbHNlID8gcHJvZHVjdC5vZmZlcl9wcmljZSA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogXCJcIn1cclxuICAgICAgICAgICAgICAgIDwvZGVsPlxyXG4gICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPHNtYWxsIHN0eWxlPXt7IGNvbG9yOiBcInJlZFwiIH19IGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICAgICAgICAgIHtwcm9kdWN0Lm9mZmVyID8gcHJvZHVjdC5vZmZlciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0U2hvY2tpbmdTYWxlO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcbmltcG9ydCBSYXRpbmcgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9SYXRpbmdcIjtcclxuaW1wb3J0IHsgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBQcm9kdWN0VGh1bWJuYWlsIGZyb20gXCIuLi9jb21tb24vUHJvZHVjdFRodW1ibmFpbFwiO1xyXG5pbXBvcnQgQ291bnREb3duU2ltcGxlRGlmZiBmcm9tIFwiLi4vQ291bnREb3duU2ltcGxlRGlmZlwiO1xyXG5cclxuY29uc3QgUHJvZHVjdFNob2NraW5nU2FsZVNsaWRlID0gKHsgcHJvZHVjdCB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxDYXJkIGJvcmRlcmVkPXtmYWxzZX0gY2xhc3NOYW1lPVwiIHRleHQtY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtYmxvY2stLWNvdW50ZG93bi1kZWFsIG1iLTNcIj5cclxuICAgICAgICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwiZmlndXJlLXRpbWVyLS1mb250XCI+XHJcbiAgICAgICAgICAgIDxmaWdjYXB0aW9uPkVuZCBpbjo8L2ZpZ2NhcHRpb24+XHJcbiAgICAgICAgICAgIDxDb3VudERvd25TaW1wbGVEaWZmXHJcbiAgICAgICAgICAgICAgZW5kVGltZT17cHJvZHVjdC5lbmRfdGltZX1cclxuICAgICAgICAgICAgICBjbGFzc0FkZD17XCJob21lLXNob2NraW5nc2FsZS0tc2xpZGVyXCJ9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgaHJlZj17YHNob2NraW5nc2FsZS8ke3Byb2R1Y3Quc2hvY2tfc2FsZV9pZH0/cHJfaWQ9JHtwcm9kdWN0LnByb2R1Y3RfaWR9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgPFByb2R1Y3RUaHVtYm5haWwgaW1hZ2VMaW5rPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9IC8+XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGFpbmVyIHRleHQtdHJ1bmNhdGVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGVudCBtdC00XCI+XHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgaHJlZj17YHNob2NraW5nc2FsZS8ke3Byb2R1Y3Quc2hvY2tfc2FsZV9pZH0/cHJfaWQ9JHtwcm9kdWN0LnByb2R1Y3RfaWR9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X190aXRsZVwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCJsYXJnZVwiLFxyXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA1MDAsXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogXCIxcmVtXCIsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtwcm9kdWN0LnByb2R1Y3RfbmFtZX1cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19yYXRpbmdcIj5cclxuICAgICAgICAgICAgICA8UmF0aW5nIHJhdGluZz17cHJvZHVjdC5yYXRpbmd9IC8+IDxzcGFuPntwcm9kdWN0LnJhdGluZ308L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCJcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogXCJsaWdodGVyXCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFJNIHtwcm9kdWN0Lm9mZmVyX3ByaWNlID8gcHJvZHVjdC5vZmZlcl9wcmljZSA6IDB9XHJcbiAgICAgICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgICAgICAgICAgICAgIDwvZGVsPlxyXG4gICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPHNtYWxsIHN0eWxlPXt7IGNvbG9yOiBcInJlZFwiIH19IGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICAgICAgICAgIHtwcm9kdWN0Lm9mZmVyID8gcHJvZHVjdC5vZmZlciA6IDB9XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZD5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0U2hvY2tpbmdTYWxlU2xpZGU7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuY29uc3QgRmVhdHVyZUFuZFJlY2VudCA9ICh7IGhvbWVpdGVtcywgbG9hZGluZyB9KSA9PiB7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcblxyXG4gICBcclxuICB9LCBbXSk7XHJcblxyXG4gIGxldCBtYWluQ2Fyb3VzZWxWaWV3O1xyXG4gIGlmICghbG9hZGluZyAmJiBob21laXRlbXM/LmZlYXR1cmVkX3Byb2R1Y3RzPy5sZW5ndGggPiAwKSB7XHJcbiAgICAvLyBjb25zdCBjYXJvdXNlSXRlbXMgPSBob21laXRlbXMubWFpbl9iYW5uZXIubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgLy8gICA8ZGl2IGtleT17aW5kZXh9PnttYWluQmFubmVyTWVkaWEoaXRlbSl9PC9kaXY+XHJcbiAgICAvLyApKTtcclxuICAgIG1haW5DYXJvdXNlbFZpZXcgPSAoXHJcbiAgICAgICAgaG9tZWl0ZW1zLmZlYXR1cmVkX3Byb2R1Y3RzLnNsaWNlKDUsIDgpLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtbGlzdCBtYi0zMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwcm9kdWN0LWNhcmQgYm9yZGVyLTBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LXRodW1ibmFpbFwic3R5bGU9e3tkaXNwbGF5IDogaXRlbS5pbWFnZS5sZW5ndGggPiAwID8gJ2Jsb2NrJzonbm9uZSd9fT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke2l0ZW0ucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cInNpbmdsZS1wcm9kdWN0Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIGNsYXNzTmFtZT1cImZpcnN0LWltZ1wiIHNyYz17aXRlbS5pbWFnZS5sZW5ndGggPiAwID8gaXRlbS5pbWFnZVswXS50aHVtYm5haWwgOicnfSBhbHQ9XCJ0aHVtYm5haWxcIi8+ICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGl0bGVcIj48YSBocmVmPVwic2hvcC1ncmlkLTQtY29sdW1uLmh0bWxcIj57aXRlbS5wcm9kdWN0X25hbWV9PC9hPjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwicHJvZHVjdC1wcmljZVwiPiR7aXRlbS5hY3R1YWxfcHJpY2V9PC9oNj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgICkpXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgXHJcbiAgbGV0IG1haW5DYXJvdXNlbFZpZXcxO1xyXG4gIGlmICghbG9hZGluZyAmJiBob21laXRlbXM/LmNlbnRlcl9vZmZlcl9iYW5uZXI/Lmxlbmd0aCA+IDApIHtcclxuICAgIC8vIGNvbnN0IGNhcm91c2VJdGVtcyA9IGhvbWVpdGVtcy5tYWluX2Jhbm5lci5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAvLyAgIDxkaXYga2V5PXtpbmRleH0+e21haW5CYW5uZXJNZWRpYShpdGVtKX08L2Rpdj5cclxuICAgIC8vICkpO1xyXG4gICAgbWFpbkNhcm91c2VsVmlldzEgPSAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTggbXgtYXV0byBjb2wtbGctNCBtYi01MFwiIHN0eWxlPXt7ZGlzcGxheSA6IGhvbWVpdGVtcy5jZW50ZXJfb2ZmZXJfYmFubmVyLmxlbmd0aCA+IDAgPyAnYmxvY2snOidub25lJ319PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmFubmVyLXRodW1iXCI+XHJcbiAgICAgICAgICAgIDxhIGhyZWY9XCJzaG9wLWdyaWQtNC1jb2x1bW4uaHRtbFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ6b29tLWluIGQtYmxvY2sgb3ZlcmZsb3ctaGlkZGVuIHBvc2l0aW9uLXJlbGF0aXZlIHpJbmRleC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2hvbWVpdGVtcy5jZW50ZXJfb2ZmZXJfYmFubmVyLmxlbmd0aCA+IDAgPyBob21laXRlbXMuY2VudGVyX29mZmVyX2Jhbm5lclswXS5tZWRpYSA6Jyd9IGFsdD1cImJhbm5lci10aHVtYi1uYWlsZVwiLz4gXHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gICAgXHJcbiAgfVxyXG4gIHJldHVybiAoXHJcblxyXG4gIDw+XHJcblxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJhbmRyZWNlbnRcIj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLWxnLTQgbWItNTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZSBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmsgdGV4dC1jYXBpdGFsaXplXCI+RmVhdHVyZWQgcHJvZHVjdHMgPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlZC1pbml0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbGlkZXItaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHttYWluQ2Fyb3VzZWxWaWV3fVxyXG4gICAgICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7bWFpbkNhcm91c2VsVmlldzF9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1sZy00IG1iLTUwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGUgbWItMzBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGl0bGUgdGV4dC1kYXJrIHRleHQtY2FwaXRhbGl6ZVwiPlJlY29tbWVuZGVkIFByb2R1Y3RzPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlZC1pbml0MiBzbGljay1uYXZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNsaWRlci1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1saXN0IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcHJvZHVjdC1jYXJkIGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC10aHVtYm5haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwic2luZ2xlLXByb2R1Y3QuaHRtbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyBjbGFzc05hbWU9XCJmaXJzdC1pbWdcIiBzcmM9XCJhc3NldHMvaW1nL2NhdGVnb3J5LzUuanBnXCIgYWx0PVwidGh1bWJuYWlsXCI+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWRlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRpdGxlXCI+PGEgaHJlZj1cInNob3AtZ3JpZC00LWNvbHVtbi5odG1sXCI+QnJpeHRvbiBQYXRyb2wgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVycmFpbiBBbm9yYWsgSmFja2V0PC9hPjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj4kMTEuOTA8L2g2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1saXN0IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcHJvZHVjdC1jYXJkIGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC10aHVtYm5haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwic2luZ2xlLXByb2R1Y3QuaHRtbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyBjbGFzc05hbWU9XCJmaXJzdC1pbWdcIiBzcmM9XCJhc3NldHMvaW1nL2NhdGVnb3J5LzYuanBnXCIgYWx0PVwidGh1bWJuYWlsXCI+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWRlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRpdGxlXCI+PGEgaHJlZj1cInNob3AtZ3JpZC00LWNvbHVtbi5odG1sXCI+SnVpY3kgQ291dHVyZSBTb2xpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNsZWV2ZSBQdWZmZXIgSmFja2V0PC9hPjwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj4kMTEuOTA8L2g2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1saXN0IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgcHJvZHVjdC1jYXJkIGJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC10aHVtYm5haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwic2luZ2xlLXByb2R1Y3QuaHRtbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyBjbGFzc05hbWU9XCJmaXJzdC1pbWdcIiBzcmM9XCJhc3NldHMvaW1nL2NhdGVnb3J5LzcuanBnXCIgYWx0PVwidGh1bWJuYWlsXCI+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYS1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWRlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRpdGxlXCI+PGEgaHJlZj1cInNob3AtZ3JpZC00LWNvbHVtbi5odG1sXCI+TmV3IEJhbGFuY2UgRnJlc2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGb2FtIExBWlIgdjEgU3BvcnQ8L2E+PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIGp1c3RpZnktY29udGVudC1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwicHJvZHVjdC1wcmljZVwiPiQxMS45MDwvaDY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBwcm9kdWN0LWNhcmQgYm9yZGVyLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtYm9keSBwLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LXRodW1ibmFpbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJzaW5nbGUtcHJvZHVjdC5odG1sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW1nIGNsYXNzTmFtZT1cImZpcnN0LWltZ1wiIHNyYz1cImFzc2V0cy9pbWcvY2F0ZWdvcnkvOC5qcGdcIiBhbHQ9XCJ0aHVtYm5haWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9XCJzZWNvbmQtaW1nXCIgc3JjPVwiYXNzZXRzL2ltZy9jYXRlZ29yeS84LjEuanBnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cInRodW1ibmFpbFwiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0aXRsZVwiPjxhIGhyZWY9XCJzaG9wLWdyaWQtNC1jb2x1bW4uaHRtbFwiPkNvdXR1cmUgSnVpY3lcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBRdWlsdGVkIFRlcnJ5IFRyYWNrIEphY2tldDwvYT48L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJwcm9kdWN0LXByaWNlXCI+JDExLjkwPC9oNj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG5cclxuICA8Lz5cclxuICAgXHJcbiAgICBcclxuICAgXHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZlYXR1cmVBbmRSZWNlbnQ7XHJcbi8qY29ubmVjdChzdGF0ZSA9PiBzdGF0ZS5tZWRpYSkoKTsqL1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYmFja2dyb3VuZCBmcm9tIFwifi9wdWJsaWMvc3RhdGljL2ltZy9jdXN0b21faW1hZ2VzL2hvbWVfcGFnZS5qcGdcIjtcclxuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcclxuaW1wb3J0IE5leHRBcnJvdyBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL2Nhcm91c2VsL05leHRBcnJvd1wiO1xyXG5pbXBvcnQgUHJldkFycm93IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvY2Fyb3VzZWwvUHJldkFycm93XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IE1lZGlhUmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvTWVkaWFSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IGJhc2VVcmwgfSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyBnZXRJdGVtQnlTbHVnIH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcbmltcG9ydCBQcm9tb3Rpb24gZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9tZWRpYS9Qcm9tb3Rpb25cIjtcclxuLy8gaW1wb3J0IFlvdVR1YmUgZnJvbSBcInJlYWN0LXlvdXR1YmVcIjtcclxuXHJcbmNvbnN0IEhvbWVEZWZhdWx0QmFubmVyID0gKHsgaG9tZWl0ZW1zLCBsb2FkaW5nIH0pID0+IHtcclxuICBjb25zdCBbcHJvbW90aW9uMSwgc2V0UHJvbW90aW9uMV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcHJvbW90aW9uMiwgc2V0UHJvbW90aW9uMl0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UHJvbW90aW9ucygpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IE1lZGlhUmVwb3NpdG9yeS5nZXRQcm9tb3Rpb25zQnlTbHVnKFxyXG4gICAgICBcImhvbWVfZnVsbHdpZHRoX3Byb21vdGlvbnNcIlxyXG4gICAgKTtcclxuICAgIGlmIChyZXNwb25zZURhdGEpIHtcclxuICAgICAgc2V0UHJvbW90aW9uMShnZXRJdGVtQnlTbHVnKHJlc3BvbnNlRGF0YSwgXCJtYWluXzFcIikpO1xyXG4gICAgICBzZXRQcm9tb3Rpb24yKGdldEl0ZW1CeVNsdWcocmVzcG9uc2VEYXRhLCBcIm1haW5fMlwiKSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gZ2V0QmFubmVySXRlbXMoKTtcclxuICAgIGdldFByb21vdGlvbnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGZ1bmN0aW9uIG1haW5CYW5uZXJNZWRpYShpdGVtKSB7XHJcbiAgICBzd2l0Y2ggKGl0ZW0ubWVkaWFfdHlwZSkge1xyXG4gICAgICBjYXNlIFwidmlkZW9cIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgLy8gPFJlYWN0UGxheWVyIHVybD1cImh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL3dhdGNoP3Y9eXN6NVM2UFVNLVVcIiAvPlxyXG5cclxuICAgICAgICAgIDxpZnJhbWVcclxuICAgICAgICAgICAgc3JjPXtgJHtpdGVtLm1lZGlhfT9hdXRvcGxheT0xJm11dGU9MWB9XHJcbiAgICAgICAgICAgIGZyYW1lQm9yZGVyPVwiMFwiXHJcbiAgICAgICAgICAgIGFsbG93PVwiYXV0b3BsYXk7IGVuY3J5cHRlZC1tZWRpYVwiXHJcbiAgICAgICAgICAgIGFsbG93RnVsbFNjcmVlblxyXG4gICAgICAgICAgICB0aXRsZT1cInZpZGVvXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICAvLyA8WW91VHViZSB2aWRlb0lkPXtcInczV2x1dnpvZ2dnXCJ9IC8+XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIGNhc2UgXCJpbWFnZVwiOlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8YVxyXG4gICAgICAgICAgICBocmVmPXtpdGVtLmJ1dHRvbl9saW5rfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1iYW5uZXItaXRlbS0tZGVmYXVsdCBiZy0tY292ZXJcIlxyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogYHVybCgke2l0ZW0ubWVkaWF9KWAsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgY2Fyb3VzZWxTZXR0aW5nID0ge1xyXG4gICAgZG90czogZmFsc2UsXHJcbiAgICBpbmZpbml0ZTogdHJ1ZSxcclxuICAgIHNwZWVkOiA3NTAsXHJcbiAgICBmYWRlOiB0cnVlLFxyXG4gICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICBuZXh0QXJyb3c6IDxOZXh0QXJyb3cgLz4sXHJcbiAgICBwcmV2QXJyb3c6IDxQcmV2QXJyb3cgLz4sXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2Fyb3VzZWxTdGFuZGFyZCA9IHtcclxuICAgIGRvdHM6IGZhbHNlLFxyXG4gICAgYXJyb3dzOiB0cnVlLFxyXG4gICAgaW5maW5pdGU6IHRydWUsXHJcbiAgICBzcGVlZDogNzUwLFxyXG4gICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICBuZXh0QXJyb3c6IDxOZXh0QXJyb3cgLz4sXHJcbiAgICBwcmV2QXJyb3c6IDxQcmV2QXJyb3cgLz4sXHJcbiAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBicmVha3BvaW50OiAxMDI0LFxyXG4gICAgICAgIHNldHRpbmdzOiB7XHJcbiAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXHJcbiAgICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcclxuICAgICAgICAgIGluZmluaXRlOiB0cnVlLFxyXG4gICAgICAgICAgZG90czogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGJyZWFrcG9pbnQ6IDYwMCxcclxuICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICAgICAgICBpbml0aWFsU2xpZGU6IDEsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGJyZWFrcG9pbnQ6IDQ4MCxcclxuICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgc2xpZGVzVG9TaG93OiAxLFxyXG4gICAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgfTtcclxuICAvLyBWaWV3c1xyXG4gIGxldCBtYWluQ2Fyb3VzZWxWaWV3O1xyXG4gIGlmICghbG9hZGluZyAmJiBob21laXRlbXM/Lm1haW5fYmFubmVyPy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjYXJvdXNlSXRlbXMgPSBob21laXRlbXMubWFpbl9iYW5uZXIubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICA8ZGl2IGtleT17aW5kZXh9PnttYWluQmFubmVyTWVkaWEoaXRlbSl9PC9kaXY+XHJcbiAgICApKTtcclxuICAgIG1haW5DYXJvdXNlbFZpZXcgPSAoXHJcbiAgICAgIDxTbGlkZXIgey4uLmNhcm91c2VsU3RhbmRhcmR9IGNsYXNzTmFtZT1cInBzLWNhcm91c2VsXCI+XHJcbiAgICAgICAge2Nhcm91c2VJdGVtc31cclxuICAgICAgPC9TbGlkZXI+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gKFxyXG5cclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPVwicHMtaG9tZS1iYW5uZXIgcHMtaG9tZS1iYW5uZXItLTFcIj5cclxuICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1zZWN0aW9uX19sZWZ0XCI+e21haW5DYXJvdXNlbFZpZXd9PC9kaXY+XHJcbiAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicHMtc2VjdGlvbl9fcmlnaHRcIj5cclxuICAgICAgICAgIDxQcm9tb3Rpb25cclxuICAgICAgICAgICAgbGluaz1cIi9zaG9wXCJcclxuICAgICAgICAgICAgaW1hZ2U9e3Byb21vdGlvbjEgPyBwcm9tb3Rpb24xLmltYWdlIDogbnVsbH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8UHJvbW90aW9uXHJcbiAgICAgICAgICAgIGxpbms9XCIvc2hvcFwiXHJcbiAgICAgICAgICAgIGltYWdlPXtwcm9tb3Rpb24yID8gcHJvbW90aW9uMi5pbWFnZSA6IG51bGx9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSG9tZURlZmF1bHRCYW5uZXI7XHJcbi8qY29ubmVjdChzdGF0ZSA9PiBzdGF0ZS5tZWRpYSkoKTsqL1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCB7IFBhZ2luYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgU2hvcFByb2R1Y3QgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9TaG9wUHJvZHVjdFwiO1xyXG5pbXBvcnQgU2hvcFByb2R1Y3RXaWRlIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvcHJvZHVjdHMvU2hvcFByb2R1Y3RXaWRlXCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IE1vZHVsZVNob3BTb3J0QnkgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9zaG9wL21vZHVsZXMvTW9kdWxlU2hvcFNvcnRCeVwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgZ2VuZXJhdGVUZW1wQXJyYXkgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IFNrZWxldG9uUHJvZHVjdCBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL3NrZWxldG9ucy9Ta2VsZXRvblByb2R1Y3RcIjtcclxuXHJcbmNvbnN0IFNob3BJdGVtcyA9ICh7IGNvbHVtbnMgPSA0LCBwYWdlU2l6ZSA9IDEyLCBob21laXRlbXMgfSkgPT4ge1xyXG4gIGNvbnN0IFJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHBhdGhEZXRhaWwgPSBSb3V0ZXIucGF0aG5hbWU7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHBhZ2UsXHJcbiAgICBjYXRlZ29yeSxcclxuICAgIHN1YmNhdGVnb3J5X2lkLFxyXG4gICAgYnJhbmQsXHJcbiAgICBwcmljZV9ndCxcclxuICAgIHByaWNlX2x0LFxyXG4gICAgbG93X3RvX2hpZ2gsXHJcbiAgICBoaWdoX3RvX2xvdyxcclxuICAgIGxhdGVzdCxcclxuICB9ID0gUm91dGVyLnF1ZXJ5O1xyXG5cclxuICBjb25zdCB7IHF1ZXJ5IH0gPSBSb3V0ZXI7XHJcbiAgY29uc3QgW2xpc3RWaWV3LCBzZXRMaXN0Vmlld10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbcHJvZHVjdEl0ZW1zLCBzZXRQcm9kdWN0SXRlbXNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvdGFsLCBzZXRUb3RhbF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2NsYXNzZXMsIHNldENsYXNzZXNdID0gdXNlU3RhdGUoXHJcbiAgICBcImNvbC14eGwtNCBjb2wteGwtNCBjb2wtbGctNCBjb2wtbWQtMyBjb2wtc20tNiBjb2wtNlwiXHJcbiAgKTtcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ2hhbmdlVmlld01vZGUoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0TGlzdFZpZXcoIWxpc3RWaWV3KTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3RzKHBhcmFtcykge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBwYWdlOiBwYWdlID09PSB1bmRlZmluZWQgPyAxIDogcGFnZSxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0gYXdhaXQgUHJvZHVjdFJlcG9zaXRvcnkuZ2V0UHJvZHVjdHMocGF5bG9hZCk7XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlRGF0YSkge1xyXG4gICAgICBzZXRQcm9kdWN0SXRlbXMocmVzcG9uc2VEYXRhLml0ZW1zKTtcclxuICAgICAgc2V0VG90YWwocmVzcG9uc2VEYXRhLnRvdGFsSXRlbXMpO1xyXG4gICAgICBzZXRUaW1lb3V0KFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH0uYmluZCh0aGlzKSxcclxuICAgICAgICAyNTBcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3RzYnlmaWx0ZXJzKCkge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBwYWdlOiBwYWdlID09PSB1bmRlZmluZWQgPyAxIDogcGFnZSxcclxuICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgY2F0ZWdvcnlfaWQ6IGNhdGVnb3J5ID8gY2F0ZWdvcnkgOiBcIlwiLFxyXG4gICAgICBzdWJjYXRlZ29yeV9pZDogc3ViY2F0ZWdvcnlfaWQgPyBzdWJjYXRlZ29yeV9pZCA6IFwiXCIsXHJcbiAgICAgIGJyYW5kX2lkOiBicmFuZCA/IGJyYW5kIDogXCJcIixcclxuICAgICAgbWF4X3ByaWNlOiBwcmljZV9sdCA/IHByaWNlX2x0IDogXCJcIixcclxuICAgICAgbWluX3ByaWNlOiBwcmljZV9ndCA/IHByaWNlX2d0IDogXCJcIixcclxuICAgICAgbG93X3RvX2hpZ2g6IGxvd190b19oaWdoID8gbG93X3RvX2hpZ2ggOiBcIlwiLFxyXG4gICAgICBoaWdoX3RvX2xvdzogaGlnaF90b19sb3cgPyBoaWdoX3RvX2xvdyA6IFwiXCIsXHJcbiAgICAgIGxhdGVzdDogbGF0ZXN0ID8gbGF0ZXN0IDogXCJcIixcclxuICAgIH07XHJcbiAgICBjb25zdCByZXNwb25zZURhdGEgPSBhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5nZXRQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpO1xyXG4gICAgaWYgKHJlc3BvbnNlRGF0YSkge1xyXG4gICAgICBzZXRQcm9kdWN0SXRlbXMocmVzcG9uc2VEYXRhLml0ZW1zKTtcclxuICAgICAgc2V0VG90YWwocmVzcG9uc2VEYXRhLnRvdGFsSXRlbXMpO1xyXG4gICAgICBzZXRUaW1lb3V0KFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH0uYmluZCh0aGlzKSxcclxuICAgICAgICAyNTBcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZVBhZ2luYXRpb24ocGFnZSwgcGFnZVNpemUpIHtcclxuICAgIGxldCBmaWx0ZXJwYXJ0ID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaDtcclxuICAgIGlmIChcclxuICAgICAgY2F0ZWdvcnkgIT09IHVuZGVmaW5lZCB8fFxyXG4gICAgICBzdWJjYXRlZ29yeV9pZCAhPT0gdW5kZWZpbmVkIHx8XHJcbiAgICAgIGJyYW5kICE9PSB1bmRlZmluZWQgfHxcclxuICAgICAgcHJpY2VfZ3QgIT09IHVuZGVmaW5lZCB8fFxyXG4gICAgICBwcmljZV9sdCAhPT0gdW5kZWZpbmVkIHx8XHJcbiAgICAgIGxvd190b19oaWdoICE9PSB1bmRlZmluZWQgfHxcclxuICAgICAgaGlnaF90b19sb3cgIT09IHVuZGVmaW5lZCB8fFxyXG4gICAgICBsYXRlc3QgIT09IHVuZGVmaW5lZFxyXG4gICAgKSB7XHJcbiAgICAgIGxldCBuZXdkZCA9IGZpbHRlcnBhcnQucmVwbGFjZSgvXFwmcGFnZS4qLywgXCJcIik7XHJcbiAgICAgIFJvdXRlci5wdXNoKFwiL3Nob3BcIiArIG5ld2RkICsgXCImcGFnZT1cIiArIHBhZ2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgUm91dGVyLnB1c2goYC9zaG9wP3BhZ2U9JHtwYWdlfWApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0VG90YWxSZWNvcmRzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVzcG9uc2VEYXRhID0gYXdhaXQgUHJvZHVjdFJlcG9zaXRvcnkuZ2V0VG90YWxSZWNvcmRzKCk7XHJcbiAgICBpZiAocmVzcG9uc2VEYXRhKSB7XHJcbiAgICAgIC8vIHNldFRvdGFsKHJlc3BvbnNlRGF0YSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVTZXRDb2x1bW5zKCkge1xyXG4gICAgc3dpdGNoIChjb2x1bW5zKSB7XHJcbiAgICAgIGNhc2UgMjpcclxuICAgICAgICBzZXRDbGFzc2VzKFwiY29sLXhsLTYgY29sLWxnLTYgY29sLW1kLTYgY29sLXNtLTYgY29sLTZcIik7XHJcbiAgICAgICAgcmV0dXJuIDM7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgNDpcclxuICAgICAgICBzZXRDbGFzc2VzKFwiY29sLXhsLTMgY29sLWxnLTQgY29sLW1kLTYgY29sLXNtLTYgY29sLTZcIik7XHJcbiAgICAgICAgcmV0dXJuIDQ7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIC8vIGNhc2UgNjpcclxuICAgICAgLy8gICBzZXRDbGFzc2VzKFwiY29sLXh4bC0yIGNvbC14bC0yIGNvbC1sZy00IGNvbC1tZC02IGNvbC1zbS02IGNvbC02XCIpO1xyXG4gICAgICAvLyAgIHJldHVybiA2O1xyXG4gICAgICAvLyAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBzZXRDbGFzc2VzKFwiY29sLXhsLTMgY29sLWxnLTMgY29sLW1kLTMgXCIpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIGxldCBwYXJhbXM7XHJcbiAgICAvLyBpZiAocXVlcnkpIHtcclxuICAgIC8vICAgaWYgKHF1ZXJ5LnBhZ2UpIHtcclxuICAgIC8vICAgICBwYXJhbXMgPSB7XHJcbiAgICAvLyAgICAgICBfc3RhcnQ6IHBhZ2UgKiBwYWdlU2l6ZSxcclxuICAgIC8vICAgICAgIF9saW1pdDogcGFnZVNpemUsXHJcbiAgICAvLyAgICAgfTtcclxuICAgIC8vICAgfSBlbHNlIHtcclxuICAgIC8vICAgICBwYXJhbXMgPSBxdWVyeTtcclxuICAgIC8vICAgICBwYXJhbXMuX2xpbWl0ID0gcGFnZVNpemU7XHJcbiAgICAvLyAgIH1cclxuICAgIC8vIH0gZWxzZSB7XHJcbiAgICAvLyAgIHBhcmFtcyA9IHtcclxuICAgIC8vICAgICBfbGltaXQ6IHBhZ2VTaXplLFxyXG4gICAgLy8gICB9O1xyXG4gICAgLy8gfVxyXG4gIC8vICBnZXRUb3RhbFJlY29yZHMoKTtcclxuXHJcbiAgICAvLyBpZiAoXHJcbiAgICAvLyAgIGNhdGVnb3J5ICE9PSB1bmRlZmluZWQgfHxcclxuICAgIC8vICAgc3ViY2F0ZWdvcnlfaWQgIT09IHVuZGVmaW5lZCB8fFxyXG4gICAgLy8gICBicmFuZCAhPT0gdW5kZWZpbmVkIHx8XHJcbiAgICAvLyAgIHByaWNlX2d0ICE9PSB1bmRlZmluZWQgfHxcclxuICAgIC8vICAgcHJpY2VfbHQgIT09IHVuZGVmaW5lZCB8fFxyXG4gICAgLy8gICBsb3dfdG9faGlnaCAhPT0gdW5kZWZpbmVkIHx8XHJcbiAgICAvLyAgIGhpZ2hfdG9fbG93ICE9PSB1bmRlZmluZWQgfHxcclxuICAgIC8vICAgbGF0ZXN0ICE9PSB1bmRlZmluZWRcclxuICAgIC8vICkge1xyXG4gICAgLy8gIGdldFByb2R1Y3RzYnlmaWx0ZXJzKCk7XHJcbiAgIC8vIH0gZWxzZSB7XHJcbiAgICAvLyAgZ2V0UHJvZHVjdHMocGFyYW1zKTtcclxuICAgLy8gfVxyXG4gICAgaGFuZGxlU2V0Q29sdW1ucygpO1xyXG4gIH0sIFtxdWVyeV0pO1xyXG5cclxuICAvLyBWaWV3c1xyXG4gIGxldCBwcm9kdWN0SXRlbXNWaWV3O1xyXG4gIGlmICghbG9hZGluZykge1xyXG4gICAgaWYgKGhvbWVpdGVtcyAmJiBob21laXRlbXM/LnRyZW5kaW5nX3Byb2R1Y3RzPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGlmIChsaXN0Vmlldykge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1zID0gaG9tZWl0ZW1zLnRyZW5kaW5nX3Byb2R1Y3RzLnNsaWNlKDAsIDgpLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzfSBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgPFNob3BQcm9kdWN0IHByb2R1Y3Q9e2l0ZW19IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKTtcclxuICAgICAgICBwcm9kdWN0SXRlbXNWaWV3ID0gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1zaG9wLWl0ZW1zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+e2l0ZW1zfTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBwcm9kdWN0SXRlbXNWaWV3ID0gaG9tZWl0ZW1zLnRyZW5kaW5nX3Byb2R1Y3RzLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgIDxTaG9wUHJvZHVjdFdpZGUgcHJvZHVjdD17aXRlbX0ga2V5PXtpbmRleH0gLz5cclxuICAgICAgICApKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcHJvZHVjdEl0ZW1zVmlldyA9IDxwPk5vIHByb2R1Y3QgZm91bmQuPC9wPjtcclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG4gICAgY29uc3Qgc2tlbGV0b25JdGVtcyA9IGdlbmVyYXRlVGVtcEFycmF5KDEyKS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzfSBrZXk9e2luZGV4fT5cclxuICAgICAgICA8U2tlbGV0b25Qcm9kdWN0IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKSk7XHJcbiAgICBwcm9kdWN0SXRlbXNWaWV3ID0gPGRpdiBjbGFzc05hbWU9XCJyb3dcIj57c2tlbGV0b25JdGVtc308L2Rpdj47XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1zaG9wcGluZ1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwicHMtc2VjdGlvbl9faGVhZGVyIGp1c3RpZnktY29udGVudC1jZW50ZXIgZC1mbGV4XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInBzLWJsb2NrLS1jb3VudGRvd24tZGVhbFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInBzLWJsb2NrX19sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlRyZW5kaW5nIE5vdzwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtM1wiPkxvcmVtIElwc3VtIGlzIHNpbXBseSBkdW1teSB0ZXh0IG9mIHRoZSBwcmludGluZyBhbmQgdHlwZXNldHRpbmcgaW5kdXN0cnkuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtZW5kIHZ1YWxcIj5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvbmV3ZGVhbHNcIj5cclxuICAgICAgICAgICAgPGE+VmlldyBBbGw8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJwcy1zaG9wcGluZ19faGVhZGVyXCI+ICovfVxyXG4gICAgICAgIHsvKiA8cD5cclxuICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwibXItMlwiPnt0b3RhbH08L3N0cm9uZz5cclxuICAgICAgICAgIFByb2R1Y3RzIGZvdW5kXHJcbiAgICAgICAgPC9wPiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXNob3BwaW5nX19hY3Rpb25zXCI+XHJcbiAgICAgICAgICB7LyogPE1vZHVsZVNob3BTb3J0QnkgLz4gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXNob3BwaW5nX192aWV3XCI+XHJcbiAgICAgICAgICAgIHsvKiA8cD5WaWV3PC9wPiAqL31cclxuICAgICAgICAgICAgey8qIDx1bCBjbGFzc05hbWU9XCJwcy10YWItbGlzdFwiPlxyXG4gICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9e2xpc3RWaWV3ID09PSB0cnVlID8gXCJhY3RpdmVcIiA6IFwiXCJ9PlxyXG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQ2hhbmdlVmlld01vZGUoZSl9PlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWdyaWRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPXtsaXN0VmlldyAhPT0gdHJ1ZSA/IFwiYWN0aXZlXCIgOiBcIlwifT5cclxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgb25DbGljaz17KGUpID0+IGhhbmRsZUNoYW5nZVZpZXdNb2RlKGUpfT5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiaWNvbi1saXN0NFwiPjwvaT5cclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICA8L3VsPiAqL31cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogPC9kaXY+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXNob3BwaW5nX19jb250ZW50IHB0LTVcIj57cHJvZHVjdEl0ZW1zVmlld308L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1zaG9wcGluZ19fZm9vdGVyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicHMtcGFnaW5hdGlvblwiPlxyXG4gICAgICAgICAgPFBhZ2luYXRpb25cclxuICAgICAgICAgICAgdG90YWw9e3RvdGFsIC0gMX1cclxuICAgICAgICAgICAgcGFnZVNpemU9e3BhZ2VTaXplfVxyXG4gICAgICAgICAgICByZXNwb25zaXZlPXt0cnVlfVxyXG4gICAgICAgICAgICBzaG93U2l6ZUNoYW5nZXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICBjdXJyZW50PXtwYWdlICE9PSB1bmRlZmluZWQgPyBwYXJzZUludChwYWdlKSA6IDF9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlUGFnaW5hdGlvbihlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2hvcEl0ZW1zO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuXHJcbmNvbnN0IEZvb3RlckNvcHlyaWdodCA9ICgpID0+IChcclxuXHJcbiAgPD4gIFxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ib3R0b20gcHQtODAgcGItMzBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTYgY29sLWxnLTQgbWItMzBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItd2lkZ2V0IG14LXctNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1sb2dvIG1iLTM1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImluZGV4Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgc3JjPVwiYXNzZXRzL2ltZy9sb2dvL2xvZ28tZGFyay5qcGdcIiBhbHQ9XCJmb290ZXIgbG9nb1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQgbWItMzBcIj5XZSBhcmUgYSB0ZWFtIG9mIGRlc2lnbmVycyBhbmQgZGV2ZWxvcGVycyB0aGF0IGNyZWF0ZSBoaWdoIHF1YWxpdHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBNYWdlbnRvLCBQcmVzdGFzaG9wLCBPcGVuY2FydC48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkZHJlc3Mtd2lkZ2V0IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZGRyZXNzLWljb24gbWUtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgc3JjPVwiYXNzZXRzL2ltZy9pY29uL3Bob25lLnBuZ1wiIGFsdD1cInBob25lXCI+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaGVscC10ZXh0IHRleHQtdXBwZXJjYXNlXCI+TkVFRCBIRUxQPzwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmtcIj48YSBocmVmPVwidGVsOisxKDEyMyk4ODg5OTk5XCI+KCs4MDApIDM0NSA2Nzg8L2E+PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbC1uZXR3b3JrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImQtZmxleFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgdGFyZ2V0PVwiX2JsYW5rXCI+PHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaWNvbi1zb2NpYWwtZmFjZWJvb2tcIj48L3NwYW4+PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIj48c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpY29uLXNvY2lhbC10d2l0dGVyXCI+PC9zcGFuPjwvYT48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgdGFyZ2V0PVwiX2JsYW5rXCI+PHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaWNvbi1zb2NpYWwteW91dHViZVwiPjwvc3Bhbj48L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm1lLTBcIj48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIj48c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpY29uLXNvY2lhbC1pbnN0YWdyYW1cIj48L3NwYW4+PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctMiBtYi0zMCBwbC00MFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci13aWRnZXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWJvdHRvbSBjYmIxIG1iLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlIHBiLTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmsgdGV4dC11cHBlcmNhc2VcIj5JbmZvcm1hdGlvbjwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZvb3Rlci1tZW51XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkRlbGl2ZXJ5PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkFib3V0IHVzPC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPlNlY3VyZSBwYXltZW50PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkNvbnRhY3QgdXM8L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCI+U2l0ZW1hcDwvYT48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5TdG9yZXM8L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctMiBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci13aWRnZXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWJvdHRvbSBjYmIxIG1iLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlIHBiLTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmsgdGV4dC11cHBlcmNhc2VcIj5DdXN0b20gTGlua3M8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZm9vdGVyLW1lbnVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCI+TGVnYWwgTm90aWNlPC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPlByaWNlcyBkcm9wPC9hPjwvbGk+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5OZXcgcHJvZHVjdHM8L2E+PC9saT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkJlc3Qgc2FsZXM8L2E+PC9saT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkxvZ2luPC9hPjwvbGk+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5NeSBhY2NvdW50PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC02IGNvbC1sZy00IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLXdpZGdldFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYm90dG9tIGNiYjEgbWItMjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGUgcGItMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRpdGxlIHRleHQtZGFyayB0ZXh0LXVwcGVyY2FzZVwiPk5ld3NsZXR0ZXI8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0IG1iLTIwXCI+WW91IG1heSB1bnN1YnNjcmliZSBhdCBhbnkgbW9tZW50LiBGb3IgdGhhdCBwdXJwb3NlLCBwbGVhc2UgZmluZCBvdXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWN0IGluZm8gaW4gdGhlIGxlZ2FsIG5vdGljZS48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5sZXR0ZXItZm9ybSBtYi0zNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImZvcm0taW5saW5lIHBvc2l0aW9uLXJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uPVwiL3BhZ2UvYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIiBtZXRob2Q9XCJwb3N0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW5wdXQgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIllvdXIgZW1haWwgYWRkcmVzc1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gbmxldHRlci1idG4gdGV4dC1jYXBpdGFsaXplXCIgdHlwZT1cInN1Ym1pdFwiPlNpZ25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9yZSBkLWZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiBjbGFzc05hbWU9XCJkLWlubGluZS1ibG9jayBtZS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyByYz1cImFzc2V0cy9pbWcvaWNvbi9hcHBsZS5wbmdcIiBhbHQ9XCJhcHBsZSBpY29uXCI+ICAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgY2xhc3NOYW1lPVwiZC1pbmxpbmUtYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW1nIHNyYz1cImFzc2V0cy9pbWcvaWNvbi9wbGF5LnBuZ1wiIGFsdD1cImFwcGxlIGljb25cIj4gICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICBcclxuICA8ZGl2IGNsYXNzTmFtZT1cImNvcHB5LXJpZ2h0IHBiLTgwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC02IGNvbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMyBtYi1tZC0wXCI+XHJcbiAgICAgICAgICDCqSAyMDIxIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtY2FwaXRhbGl6ZVwiPkp1bm5vPC9zcGFuPiBNYWRlXHJcbiAgICAgICAgICB3aXRoIDxzcGFuPiYjMTAwODQ7PC9zcGFuPiBieVxyXG4gICAgICAgICAgPGEgdGFyZ2V0PVwiX2JsYW5rXCIgaHJlZj1cImh0dHBzOi8vaGFzdGhlbWVzLmNvbS9cIj5IYXNUaGVtZXM8L2E+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW1nIHNyYz1cImFzc2V0cy9pbWcvcGF5bWVudC8xLnBuZ1wiIGFsdD1cImltZ1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiBcclxuICA8Lz5cclxuXHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb290ZXJDb3B5cmlnaHQ7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBMb2dvIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvY29tbW9uL0xvZ29cIjtcclxuaW1wb3J0IFNlYXJjaEhlYWRlciBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL21vZHVsZXMvU2VhcmNoSGVhZGVyXCI7XHJcbmltcG9ydCBOYXZpZ2F0aW9uRGVmYXVsdCBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9uYXZpZ2F0aW9uL05hdmlnYXRpb25EZWZhdWx0XCI7XHJcbmltcG9ydCBIZWFkZXJBY3Rpb25zIGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9IZWFkZXJBY3Rpb25zXCI7XHJcbmltcG9ydCB7IHN0aWNreUhlYWRlciB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgTWVudUNhdGVnb3JpZXNEcm9wZG93biBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9tZW51cy9NZW51Q2F0ZWdvcmllc0Ryb3Bkb3duXCI7XHJcblxyXG5jb25zdCBIZWFkZXJEZWZhdWx0ID0gKCkgPT4ge1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocHJvY2Vzcy5icm93c2VyKSB7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIHN0aWNreUhlYWRlcik7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJoZWFkZXIgaGVhZGVyLS0xXCIgZGF0YS1zdGlja3k9XCJ0cnVlXCIgaWQ9XCJoZWFkZXJTdGlja3lcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkLXRvcFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwcy1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInRvcC11cmxcIj5cclxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJ0b3AtbGlcIj5cclxuICAgICAgICAgICAgICAgICAgPGE+IEVuZyA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9hY2NvdW50L2xvZ2luXCI+XHJcbiAgICAgICAgICAgIDxhPiBTaWduIEluPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9hY2NvdW50L2xvZ2luXCI+XHJcbiAgICAgICAgICAgIDxhPlJlZ2lzdGVyPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPGEgaHJlZj1cIlwiPiBTaWduIEluIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIlwiPiBSZWdpc3RlciA8L2E+ICovfVxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX3RvcFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fbGVmdFwiPlxyXG4gICAgICAgICAgICA8TG9nbyAvPlxyXG4gICAgICAgICAgICB7LyogPE1lbnVDYXRlZ29yaWVzRHJvcGRvd24gLz4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19jYXRlZ1wiPlxyXG4gICAgICAgICAgICA8TWVudUNhdGVnb3JpZXNEcm9wZG93biAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8YSBocmVmPVwiXCI+T2ZmZXIgWm9uZTwvYT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX2NlbnRlclwiPlxyXG4gICAgICAgICAgICA8U2VhcmNoSGVhZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19yaWdodFwiPlxyXG4gICAgICAgICAgICA8SGVhZGVyQWN0aW9ucyAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogPE5hdmlnYXRpb25EZWZhdWx0IC8+ICovfVxyXG4gICAgPC9oZWFkZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWRlckRlZmF1bHQ7XHJcbiIsImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgY29ubmVjdCwgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXRDYXJ0LCByZW1vdmVJdGVtIH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IFByb2R1Y3RPbkNhcnQgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0T25DYXJ0XCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcbmltcG9ydCB7IGdldERldmljZUlkIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7IGJhc2VVcmwsIHNlcmlhbGl6ZVF1ZXJ5LCBhcGliYXNldXJsIH0gZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1JlcG9zaXRvcnlcIjtcclxuY29uc3QgTWluaUNhcnQgPSBSZWFjdC5tZW1vKCh7IGNhcnQgfSkgPT4ge1xyXG4gIGxldCBjYXJ0SXRlbXNWaWV3O1xyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuICBjb25zdCBhdXRoID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5hdXRoKTtcclxuXHJcbiAgY29uc3QgcHJvZHVjdEl0ZW1XaXRoU2VsbGVyID0gY2FydD8ucHJvZHVjdD8ubWFwKChwcm9kdWN0SXRlbSkgPT4gKFxyXG4gICAgPGRpdiBrZXk9e3Byb2R1Y3RJdGVtPy5zZWxsZXI/LnNlbGxlcl9pZH0+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInN0b3ItdGl0XCI+e3Byb2R1Y3RJdGVtPy5zZWxsZXI/LnNlbGxlcn08L3A+XHJcbiAgICAgIHtwcm9kdWN0SXRlbT8uc2VsbGVyPy5wcm9kdWN0cz8ubWFwKChjYXJ0UHJvZHVjdCkgPT4gKFxyXG4gICAgICAgIDxQcm9kdWN0T25DYXJ0IHByb2R1Y3Q9e2NhcnRQcm9kdWN0fSBrZXk9e2NhcnRQcm9kdWN0Py5jYXJ0X2lkfSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICkpO1xyXG4gIGNvbnN0IFtjYXJ0ZGF0YSwgc2V0Q2FydGRhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvdGFsSXRlbXMsIHNldFRvdGFsSXRlbXNdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi5wcm9kdWN0SXRlbU5leHQuLi4uLi5jYXJ0Li4uLi5cIiwgY2FydClcclxuICAgLy8gY29uc29sZS5sb2coXCIucHJvZHVjdEl0ZW1OZXh0Li4uLi4uLi4uLi5cIiwgcHJvZHVjdEl0ZW1OZXh0KVxyXG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XHJcblxyXG4gICAgaWYgKGlzTW91bnRlZCkge1xyXG4gICAgICAvL2FsZXJ0KFwiYmhiaGhiaGhoXCIpXHJcbiAgICAgIGNvbnN0IGNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlciA9IGNhcnQ/LnByb2R1Y3Q/LnJlZHVjZShcclxuICAgICAgICAocHJvZHVjdEl0ZW1QcmV2LCBwcm9kdWN0SXRlbU5leHQpID0+IHtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIE51bWJlcihwcm9kdWN0SXRlbVByZXYpIFxyXG4gICAgICAgICAgICAgK1xyXG4gICAgICAgICAgICAgTnVtYmVyKHByb2R1Y3RJdGVtTmV4dC5zZWxsZXIucHJvZHVjdHMubGVuZ3RoKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldFRvdGFsSXRlbXMoY2FydFRvdGFsUHJvZHVjdHNGcm9tQWxsU2VsbGVyKTtcclxuICAgICAgc2V0Q2FydGRhdGEoY2FydCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBpc01vdW50ZWQgPSBmYWxzZTtcclxuICAgIH07XHJcbiAgfSwgW2NhcnQ/LnByb2R1Y3RdKTtcclxuICBcclxuICAvLyBhc3luYyBnZXRDYXJ0SXRlbShwYXlsb2FkKSB7XHJcblxyXG4gICAgY29uc3QgZ2V0Q2FydEl0ZW0gPSAocGF5bG9hZCkgPT4ge1xyXG4gICAgICBhbGVydChcIjc3Nzc3NjdcIilcclxuICAgIC8vYWxlcnQoXCJkXCIpXHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gJHthcGliYXNldXJsfS4uLlwiLHthcGliYXNldXJsfSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmFhYWFhYWFhYWFhYWFhYWEuLi5cIix1c2VyX3Rva2VuKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmJiYmJiYmJiYmJiYi4uLlwiLGdldERldmljZUlkKVxyXG5cclxuICAgIGNvbnN0IGRhdGEgPSBBeGlvcy5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsXHJcbiAgICAgIHtcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgICAgICBvc190eXBlOiBcIldFQlwiLFxyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi5paWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWkuXCIsZGF0YSlcclxuICAgIC8vICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uIHJlc3BvbnNlLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gNDAwICYmIGRhdGEuc3RhdHVzID09IFwiZXJyb3JcIikge1xyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAvLyB9KTtcclxuICAgICAgICAgIC8vIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gMjAwICYmIGRhdGEuc3RhdHVzID09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICAgICBzZXRDYXJ0ZGF0YShkYXRhLmRhdGEpXHJcbiAgICAgICAgICBzZXRUb3RhbEl0ZW1zKGRhdGEuZGF0YS5jYXJ0X2NvdW50KVxyXG4gICAgICAgLy8gICBhbGVydChcInllc1wiKVxyXG4gICAgICAgIC8vICBzZXRPZmZlckRhdGEoZGF0YS5kYXRhKVxyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wic3VjY2Vzc1wiXSh7XHJcbiAgICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAvLyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgIC8vICAgbWVzc2FnZTogZXJyb3IsXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuY2NjY2MuLlwiLGdldERldmljZUlkKVxyXG4gICAvLyBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi4uLlwiLHBheWxvYWQpXHJcbiAgICAvLyBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAvLyBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAvLyBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAvLyBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIC8vIGNvbnN0IHJlc3BvbnNlID0gIFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsIHtcclxuICAgIC8vICAgYWNjZXNzX3Rva2VuOiB1c2VyX3Rva2VuLFxyXG4gICAgLy8gICBsYW5nX2lkOiAxLFxyXG4gICAgLy8gICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgLy8gICBwYWdlX3VybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvcHJvZHVjdC8yXCIsXHJcbiAgICAvLyAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICAvLyB9KVxyXG4gICAgLy8gY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuLjQ0NDQ0NDQ0NDQ0NC5cIixyZXNwb25zZSlcclxuICAgIC8vICAgLy8gLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAvLyAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgLy8gICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAvLyAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgLy8gICAvLyB9KVxyXG4gICAgLy8gICAvLyAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIC8vIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi41NTcuLlwiLGNhcnQpXHJcbiAgICBnZXRDYXJ0SXRlbSgpXHJcbiAgICBpZiAoY2FydCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAvLyBhbGVydChcImRkZmZmZFwiKVxyXG4gICAgICBhdXRoPy5hY2Nlc3NfdG9rZW4gJiYgZGlzcGF0Y2goZ2V0Q2FydCgpKTtcclxuICAgIH1cclxuICB9LCBbYXV0aC5hY2Nlc3NfdG9rZW4sIGNhcnQ/LnByb2R1Y3RdKTtcclxuXHJcbiAgaWYgKFxyXG4gICAgY2FydGRhdGEgIT09IG51bGwgJiZcclxuICAgIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggIT09IDBcclxuICApIHtcclxuICAgIGNhcnRJdGVtc1ZpZXcgPSAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9faXRlbXNcIj57cHJvZHVjdEl0ZW1XaXRoU2VsbGVyfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fZm9vdGVyXCI+XHJcbiAgICAgICAgICA8aDM+XHJcbiAgICAgICAgICAgIFN1YiBUb3RhbDpcclxuICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICB7Y2FydGRhdGEgJiYgY2FydGRhdGEgIT09IG51bGwgJiYgY2FydGRhdGE/LnByb2R1Y3Q/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgID8gY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0KGNhcnRkYXRhLmdyYW5kX3RvdGFsKVxyXG4gICAgICAgICAgICAgICAgOiAwfVxyXG4gICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvc2hvcHBpbmctY2FydFwiPlxyXG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLWJ0blwiPlZpZXcgQ2FydDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvY2hlY2tvdXRcIj5cclxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJwcy1idG5cIj5DaGVja291dDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2FydEl0ZW1zVmlldyA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19pdGVtc1wiPlxyXG4gICAgICAgICAgPHNwYW4+Tm8gcHJvZHVjdHMgaW4gY2FydDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydC0tbWluaVwiPlxyXG4gICAgICA8YSBjbGFzc05hbWU9XCJoZWFkZXJfX2V4dHJhXCIgaHJlZj1cIiNcIj5cclxuICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWJhZzJcIj48L2k+XHJcbiAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICA8aT5cclxuICAgICAgICAgICAge2NhcnRkYXRhICE9PSBudWxsICYmIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiYgdG90YWxJdGVtcyA+IDBcclxuICAgICAgICAgICAgICA/IHRvdGFsSXRlbXNcclxuICAgICAgICAgICAgICA6IDB9XHJcbiAgICAgICAgICA8L2k+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2E+XHJcbiAgICAgIHtjYXJ0SXRlbXNWaWV3fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KChzdGF0ZSkgPT4gc3RhdGUuY2FydCkoTWluaUNhcnQpO1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IFByb2R1Y3RTZWFyY2hSZXN1bHQgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2VhcmNoUmVzdWx0XCI7XHJcblxyXG5jb25zdCBleGFtcGxlQ2F0ZWdvcmllcyA9IFtcclxuICB7XHJcbiAgICBpZDogXCJcIixcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiQWxsXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNCxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiR3JvY2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDUsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkVsZWN0cm9uaWNzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNixcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiQmFrZXJ5XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNyxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiRmFzaGlvblwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDgsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcInNob2VzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTAsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcImtpZHMgZmFzaGlvblwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDExLFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJEYWlyeSBQcm9kdWN0c1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDEyLFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJIb21lXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTMsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkFwcGxpYW5jZXNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAxNCxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiTW9iaWxlc1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDE1LFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJUb3lzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTgsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkpld2VsbGVyeXlcIixcclxuICB9LFxyXG5dO1xyXG5cclxuZnVuY3Rpb24gdXNlRGVib3VuY2UodmFsdWUsIGRlbGF5KSB7XHJcbiAgY29uc3QgW2RlYm91bmNlZFZhbHVlLCBzZXREZWJvdW5jZWRWYWx1ZV0gPSB1c2VTdGF0ZSh2YWx1ZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIFVwZGF0ZSBkZWJvdW5jZWQgdmFsdWUgYWZ0ZXIgZGVsYXlcclxuICAgIGNvbnN0IGhhbmRsZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0RGVib3VuY2VkVmFsdWUodmFsdWUpO1xyXG4gICAgfSwgZGVsYXkpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICAgIH07XHJcbiAgfSwgW3ZhbHVlLCBkZWxheV0pO1xyXG5cclxuICByZXR1cm4gZGVib3VuY2VkVmFsdWU7XHJcbn1cclxuXHJcbmNvbnN0IFNlYXJjaEhlYWRlciA9ICgpID0+IHtcclxuICBjb25zdCBpbnB1dEVsID0gdXNlUmVmKG51bGwpO1xyXG4gIGNvbnN0IFtpc1NlYXJjaCwgc2V0SXNTZWFyY2hdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtrZXl3b3JkLCBzZXRLZXl3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Jlc3VsdEl0ZW1zLCBzZXRSZXN1bHRJdGVtc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgZGVib3VuY2VkU2VhcmNoVGVybSA9IHVzZURlYm91bmNlKGtleXdvcmQsIDE1MDApO1xyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVDbGVhcktleXdvcmQoKSB7XHJcbiAgICBzZXRLZXl3b3JkKFwiXCIpO1xyXG4gICAgc2V0SXNTZWFyY2goZmFsc2UpO1xyXG4gICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgUm91dGVyLnB1c2goYC9zZWFyY2g/a2V5d29yZD0ke2tleXdvcmR9YCk7XHJcbiAgfVxyXG4gIGNvbnN0IFttZW51RGF0YUZyb21TZXJ2ZXIsIHNldE1lbnVEYXRhRnJvbVNlcnZlcl0gPSB1c2VTdGF0ZShbXHJcbiAgICB7XHJcbiAgICAgIGNhdGVnb3J5X2lkOiBcIlwiLFxyXG4gICAgICBjYXRlZ29yeV9uYW1lOiBcIkFsbFwiLFxyXG4gICAgfSxcclxuICBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBpc1N1YnNjcmliZWQgPSB0cnVlO1xyXG4gICAgY29uc3QgZmV0Y2hNZW51RGF0YUZyb21TZXJ2ZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5nZXRQcm9kdWN0Q2F0ZWdvcmllcygpO1xyXG4gICAgICAgIGlzU3Vic2NyaWJlZFxyXG4gICAgICAgICAgPyBzZXRNZW51RGF0YUZyb21TZXJ2ZXIoW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGNhdGVnb3J5X2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgY2F0ZWdvcnlfbmFtZTogXCJBbGxcIixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIC4uLnJlc3BvbnNlLmRhdGEuY2F0X3N1YmNhdCxcclxuICAgICAgICAgICAgXSlcclxuICAgICAgICAgIDogbnVsbDtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlcigpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiAoaXNTdWJzY3JpYmVkID0gZmFsc2UpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChkZWJvdW5jZWRTZWFyY2hUZXJtKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGlmIChrZXl3b3JkKSB7XHJcbiAgICAgICAgY29uc3QgcXVlcmllcyA9IHtcclxuICAgICAgICAgIF9saW1pdDogNSxcclxuICAgICAgICAgIHRpdGxlX2NvbnRhaW5zOiBrZXl3b3JkLFxyXG4gICAgICAgICAgY2F0ZWdvcnlfaWQ6IGNhdGVnb3J5LFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy8gY29uc3QgcHJvZHVjdHMgPSBQcm9kdWN0UmVwb3NpdG9yeS5nZXRSZWNvcmRzKHF1ZXJpZXMpO1xyXG4gICAgICAgIGNvbnN0IHByb2R1Y3RzID0gUHJvZHVjdFJlcG9zaXRvcnkuZ2V0U2VhcmNoZWRQcm9kdWN0cyhxdWVyaWVzKTtcclxuXHJcbiAgICAgICAgcHJvZHVjdHMudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgIHNldFJlc3VsdEl0ZW1zKHJlc3VsdC5pdGVtcyk7XHJcbiAgICAgICAgICBzZXRJc1NlYXJjaCh0cnVlKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRJc1NlYXJjaChmYWxzZSk7XHJcbiAgICAgICAgc2V0S2V5d29yZChcIlwiKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAobG9hZGluZykge1xyXG4gICAgICAgIHNldElzU2VhcmNoKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldElzU2VhcmNoKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbZGVib3VuY2VkU2VhcmNoVGVybV0pO1xyXG5cclxuICAvLyBWaWV3c1xyXG4gIGxldCBwcm9kdWN0SXRlbXNWaWV3LFxyXG4gICAgY2xlYXJUZXh0VmlldyxcclxuICAgIHNlbGVjdE9wdGlvblZpZXcsXHJcbiAgICBsb2FkaW5nVmlldyxcclxuICAgIGxvYWRNb3JlVmlldztcclxuICBpZiAoIWxvYWRpbmcpIHtcclxuICAgIGlmIChyZXN1bHRJdGVtcyAmJiByZXN1bHRJdGVtcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGlmIChyZXN1bHRJdGVtcy5sZW5ndGggPiA1KSB7XHJcbiAgICAgICAgbG9hZE1vcmVWaWV3ID0gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wYW5lbF9fZm9vdGVyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2VhcmNoXCI+XHJcbiAgICAgICAgICAgICAgPGE+U2VlIGFsbCByZXN1bHRzPC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICAgIHByb2R1Y3RJdGVtc1ZpZXcgPSByZXN1bHRJdGVtcy5tYXAoKHByb2R1Y3QpID0+IChcclxuICAgICAgICA8UHJvZHVjdFNlYXJjaFJlc3VsdCBwcm9kdWN0PXtwcm9kdWN0fSBrZXk9e3Byb2R1Y3QuaWR9IC8+XHJcbiAgICAgICkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcHJvZHVjdEl0ZW1zVmlldyA9IDxwPk5vIHByb2R1Y3QgZm91bmQuPC9wPjtcclxuICAgIH1cclxuICAgIGlmIChrZXl3b3JkICE9PSBcIlwiKSB7XHJcbiAgICAgIGNsZWFyVGV4dFZpZXcgPSAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHMtZm9ybV9fYWN0aW9uXCIgb25DbGljaz17aGFuZGxlQ2xlYXJLZXl3b3JkfT5cclxuICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24gaWNvbi1jcm9zczJcIj48L2k+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICBsb2FkaW5nVmlldyA9IChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHMtZm9ybV9fYWN0aW9uXCI+XHJcbiAgICAgICAgPFNwaW4gc2l6ZT1cInNtYWxsXCIgLz5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChtZW51RGF0YUZyb21TZXJ2ZXI/Lmxlbmd0aCA+IDApIHtcclxuICAgIHNlbGVjdE9wdGlvblZpZXcgPSBtZW51RGF0YUZyb21TZXJ2ZXI/Lm1hcCgob3B0aW9uLCBpbmRleCkgPT4ge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxvcHRpb24gdmFsdWU9e29wdGlvbi5jYXRlZ29yeV9pZH0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICB7b3B0aW9uLmNhdGVnb3J5X25hbWV9XHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtXHJcbiAgICAgIGNsYXNzTmFtZT1cInBzLWZvcm0tLXF1aWNrLXNlYXJjaFwiXHJcbiAgICAgIG1ldGhvZD1cImdldFwiXHJcbiAgICAgIGFjdGlvbj1cIi9cIlxyXG4gICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxyXG4gICAgPlxyXG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJwcy1mb3JtX19jYXRlZ29yaWVzXCI+XHJcbiAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzZWxlY3RPcHRpb25WaWV3fVxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICA8L2Rpdj4gKi99XHJcbiAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG5cclxuICAgICAgPC9kaXY+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWZvcm1fX2lucHV0XCI+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICByZWY9e2lucHV0RWx9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2xcIlxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgdmFsdWU9e2tleXdvcmR9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkknbSBzaG9wcGluZyBmb3IuLi5cIlxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRLZXl3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHtjbGVhclRleHRWaWV3fVxyXG4gICAgICAgIHtsb2FkaW5nVmlld31cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0+U2VhcmNoPC9idXR0b24+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YHBzLXBhbmVsLS1zZWFyY2gtcmVzdWx0JHtpc1NlYXJjaCA/IFwiIGFjdGl2ZSBcIiA6IFwiXCJ9YH0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wYW5lbF9fY29udGVudFwiPntwcm9kdWN0SXRlbXNWaWV3fTwvZGl2PlxyXG4gICAgICAgIHtsb2FkTW9yZVZpZXd9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hIZWFkZXI7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBtZW51RGF0YSBmcm9tIFwifi9wdWJsaWMvc3RhdGljL2RhdGEvbWVudS5qc29uXCI7XHJcbmltcG9ydCBNZW51U2hvcEJ5IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvbWVudS9NZW51U2hvcEJ5XCI7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgYXBpYmFzZXVybCB9IGZyb20gXCIuLi8uLi8uLi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5cclxuY29uc3QgTWVudUNhdGVnb3JpZXNEcm9wZG93biA9ICgpID0+IHtcclxuICBjb25zdCBbbWVudURhdGFGcm9tU2VydmVyLCBzZXRNZW51RGF0YUZyb21TZXJ2ZXJdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlciA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQXhpb3MucG9zdChcclxuICAgICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2F0LXN1YmNhdGBcclxuICAgICAgKTtcclxuICAgICAgc2V0TWVudURhdGFGcm9tU2VydmVyKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgeyBob21lZGF0YSB9ID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5ob21lKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBoYW5kbGVyO1xyXG4gICAgaGFuZGxlciA9IHNldFRpbWVvdXQoYXN5bmMgKCkgPT4ge1xyXG4gICAgICBhd2FpdCBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlcigpO1xyXG4gICAgfSwgMTAwKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICAgIH07XHJcbiAgfSwgW2hvbWVkYXRhXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lbnUtLXByb2R1Y3QtY2F0ZWdvcmllc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lbnVfX3RvZ2dsZVwiPlxyXG4gICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24tbWVudVwiPjwvaT5cclxuICAgICAgICA8c3Bhbj5TaG9wIGJ5IENhdGVnb3J5PC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZW51X19jb250ZW50XCI+XHJcbiAgICAgICAgPE1lbnVTaG9wQnlcclxuICAgICAgICAgIHNvdXJjZT17bWVudURhdGFGcm9tU2VydmVyPy5kYXRhPy5jYXRfc3ViY2F0fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWVudS0tZHJvcGRvd25cIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lbnVDYXRlZ29yaWVzRHJvcGRvd247XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaXRlRmVhdHVyZXMgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvU2l0ZUZlYXR1cmVzXCI7XHJcbmltcG9ydCBUcmVuZGluZ05vdyBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL3Nob3AvU2hvcEl0ZW1zMVwiO1xyXG5pbXBvcnQgRG93bkxvYWRBcHAgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9jb21tb25zL0Rvd25Mb2FkQXBwXCI7XHJcbmltcG9ydCBDb250YWluZXJIb21lRGVmYXVsdCBmcm9tIFwifi9jb21wb25lbnRzL2xheW91dHMvQ29udGFpbmVySG9tZURlZmF1bHRcIjtcclxuaW1wb3J0IEZlYXR1cmVBbmRSZWNlbnQgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvRmVhdHVyZUFuZFJlY2VudFwiO1xyXG5pbXBvcnQgQWR2ZXJ0IGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0FkdmVydFwiO1xyXG5pbXBvcnQgRGlzY291bnQgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvRGlzY291bnRcIjtcclxuaW1wb3J0IEJyYW5kIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0JyYW5kXCI7XHJcbmltcG9ydCBCb3R0b21DYXRlZ29yeSBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2hvbWUtZGVmYXVsdC9Cb3R0b21DYXRlZ29yeVwiO1xyXG5pbXBvcnQgSG9tZURlZmF1bHRCYW5uZXIgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9ob21lLWRlZmF1bHQvSG9tZURlZmF1bHRCYW5uZXJcIjtcclxuaW1wb3J0IEhvbWVjYXRlZ29yaWVzIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvY2F0ZWdvcnkvaG9tZWNhdGVnb3JpZXNcIjtcclxuaW1wb3J0IE5ld0RlYWxzRGFpbHkgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9uZXctZGVhbHMtZGFpbHkvbmV3ZGVhbHNkYWlseVwiO1xyXG5pbXBvcnQgU2hvcEJ5Q2F0ZWdvcnkgZnJvbSBcIn4vY29tcG9uZW50cy9wYXJ0aWFscy9ob21lcGFnZS9uZXctZGVhbHMtZGFpbHkvbmV3ZGVhbHNkYWlseTFcIjtcclxuaW1wb3J0IFNob2NraW5nc2FsZSBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL3Nob2NraW5nc2FsZS9zaG9ja2luZ3NhbGVcIjtcclxuaW1wb3J0IEZlYXR1cmVwcm9kdWN0cyBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpYWxzL2hvbWVwYWdlL2ZlYXR1cmVwcm9kdWN0cy9mZWF0dXJlcHJvZHVjdHNcIjtcclxuaW1wb3J0IEhvbWVhdWN0aW9uIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvYXVjdGlvbi9hdWN0aW9uXCI7XHJcbmltcG9ydCBCZXN0c2VsbGVyIGZyb20gXCJ+L2NvbXBvbmVudHMvcGFydGlhbHMvaG9tZXBhZ2UvaG9tZS1kZWZhdWx0L0Jlc3RzZWxsZXJcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHsgYXBpYmFzZXVybCB9IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBGb290ZXJMaW5rcyBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9mb290ZXJzL21vZHVsZXMvRm9vdGVyTGlua3NcIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXRIb21lZGF0YSB9IGZyb20gXCJ+L3V0aWxpdGllcy9ob21lLWhlbHBlclwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgZ2V0SG9tZVN1Y2Nlc3MgfSBmcm9tIFwifi9zdG9yZS9ob21lL2FjdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VEaXNwYXRjaCwgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBIb21lcGFnZURlZmF1bHRQYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtob21laXRlbXMsIHNldEhvbWVpdGVtc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dldE9mZmVyRGF0YSwgc2V0T2ZmZXJEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRIb21lZGF0YSgpIHtcclxuICAgIGxldCByZXNwb25zZURhdGEgPSBhd2FpdCBnZXRIb21lZGF0YShyb3V0ZXIuYXNQYXRoKTtcclxuICAgIGlmIChyZXNwb25zZURhdGEpIHtcclxuICAgICAgZGlzcGF0Y2goZ2V0SG9tZVN1Y2Nlc3MocmVzcG9uc2VEYXRhLmRhdGEpKTtcclxuICAgICAgc2V0SG9tZWl0ZW1zKHJlc3BvbnNlRGF0YS5kYXRhKTtcclxuICAgIH1cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH0sIDI1MCk7XHJcbiAgfVxyXG4gIGNvbnN0IG9mZmVyID0gKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gJHthcGliYXNldXJsfS4uLlwiLHthcGliYXNldXJsfSlcclxuICAgIGNvbnN0IGRhdGEgPSBBeGlvcy5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb2ZmZXIvbGlzdGApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLm9mZmVycnJycnJycnJycnIuXCIsZGF0YSlcclxuICAgIC8vICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uIHJlc3BvbnNlLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gNDAwICYmIGRhdGEuc3RhdHVzID09IFwiZXJyb3JcIikge1xyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAvLyB9KTtcclxuICAgICAgICAgIC8vIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gMjAwICYmIGRhdGEuc3RhdHVzID09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICAgICBzZXRPZmZlckRhdGEoZGF0YS5kYXRhKVxyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wic3VjY2Vzc1wiXSh7XHJcbiAgICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAvLyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3IsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH07XHJcbiAgY29uc3QgeyBob21lZGF0YSB9ID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5ob21lKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi5ob21lZGF0YS4uLi5cIixob21lZGF0YSlcclxuICAgIGlmIChob21lZGF0YSA9PSBudWxsKSB7XHJcbiAgICAgIGxvYWRIb21lZGF0YSgpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0SG9tZWl0ZW1zKGhvbWVkYXRhKTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH0sIDI1MCk7XHJcbiAgICB9XHJcblxyXG5vZmZlcigpXHJcbiAgfSwgW2hvbWVkYXRhXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3BpbiBzcGlubmluZz17bG9hZGluZ30+XHJcbiAgICAgIDxDb250YWluZXJIb21lRGVmYXVsdCB0aXRsZT1cIkJpZyBCYXNrZXRcIj5cclxuICAgICAgICA8SG9tZURlZmF1bHRCYW5uZXIgaG9tZWl0ZW1zPXtob21laXRlbXN9IGxvYWRpbmc9e2xvYWRpbmd9IC8+XHJcbiAgICAgICAgey8qIDxNYXJrZXRQbGFjZTNTZWFyY2hUcmVuZGluZyAvPiAqL31cclxuICAgICAgICB7LyogPFNpdGVGZWF0dXJlcyAvPiAqL31cclxuICAgICAgICAgeyFsb2FkaW5nICYmIGhvbWVpdGVtcyAmJiBob21laXRlbXM/LmNhdGVnb3J5Py5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxTaG9wQnlDYXRlZ29yeVxyXG4gICAgICAgICAgICBjb2xsZWN0aW9uU2x1Zz1cImRlYWwtb2YtdGhlLWRheVwiXHJcbiAgICAgICAgICAgIGhvbWVpdGVtcz17aG9tZWl0ZW1zfVxyXG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxUcmVuZGluZ05vdyBob21laXRlbXM9e2hvbWVpdGVtc30vPlxyXG4gICAgICAgIHsvKiA8SG9tZWNhdGVnb3JpZXMgaG9tZWl0ZW1zPXtob21laXRlbXN9IGxvYWRpbmc9e2xvYWRpbmd9IC8+ICovfVxyXG4gICAgICAgIHshbG9hZGluZyAmJiBob21laXRlbXMgJiYgaG9tZWl0ZW1zPy5zaG9ja2luZ19zYWxlPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxTaG9ja2luZ3NhbGVcclxuICAgICAgICAgICAgY29sbGVjdGlvblNsdWc9XCJkZWFsLW9mLXRoZS1kYXlcIlxyXG4gICAgICAgICAgICBob21laXRlbXM9e2hvbWVpdGVtc31cclxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgIFxyXG5cclxuICAgICAgXHJcbiAgICAgICAgICAgPEFkdmVydCAgaG9tZWl0ZW1zPXtob21laXRlbXN9IGxvYWRpbmc9e2xvYWRpbmd9Lz5cclxuXHJcbiAgICAgICAgICAgeyFsb2FkaW5nICYmIGhvbWVpdGVtcyAmJiBob21laXRlbXM/Lm5ld19hcnJpdmFscz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8TmV3RGVhbHNEYWlseVxyXG4gICAgICAgICAgICBjb2xsZWN0aW9uU2x1Zz1cImRlYWwtb2YtdGhlLWRheVwiXHJcbiAgICAgICAgICAgIGhvbWVpdGVtcz17aG9tZWl0ZW1zfVxyXG4gICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICAgIHsvKiB7IWxvYWRpbmcgJiYgaG9tZWl0ZW1zICYmIGhvbWVpdGVtcz8uZmVhdHVyZWRfcHJvZHVjdHM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgPEZlYXR1cmVwcm9kdWN0c1xyXG4gICAgICAgICAgICBjb2xsZWN0aW9uU2x1Zz1cImNvbnN1bWVyLWVsZWN0cm9uaWNzXCJcclxuICAgICAgICAgICAgdGl0bGU9XCJGZWF0dXJlIHByb2R1Y3RzXCJcclxuICAgICAgICAgICAgaG9tZWl0ZW1zPXtob21laXRlbXN9XHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9ICovfVxyXG4gICAgICAgIDxGZWF0dXJlQW5kUmVjZW50IGhvbWVpdGVtcz17aG9tZWl0ZW1zfSBsb2FkaW5nPXtsb2FkaW5nfS8+XHJcbiAgICAgICAgey8qIDxEaXNjb3VudCBnZXRPZmZlckRhdGE9e2dldE9mZmVyRGF0YX0gbG9hZGluZz17bG9hZGluZ30vPiAqL31cclxuICAgICAgICA8Qm90dG9tQ2F0ZWdvcnkgaG9tZWl0ZW1zPXtob21laXRlbXN9IGxvYWRpbmc9e2xvYWRpbmd9Lz5cclxuICAgICAgICB7LyogPEJyYW5kIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSBsb2FkaW5nPXtsb2FkaW5nfS8+ICovfVxyXG4gICAgICAgIHsvKiB7IWxvYWRpbmcgJiYgaG9tZWl0ZW1zICYmIGhvbWVpdGVtcz8uYXVjdGlvbj8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICA8SG9tZWF1Y3Rpb24gaG9tZWl0ZW1zPXtob21laXRlbXN9IC8+XHJcbiAgICAgICAgKX0gKi99XHJcbiAgICAgICAgey8qIDxCZXN0c2VsbGVyIGhvbWVpdGVtcz17aG9tZWl0ZW1zfSAvPiAqL31cclxuICAgICAgICB7LyogPERvd25Mb2FkQXBwIC8+ICovfVxyXG4gICAgICAgIHsvKiA8TmV3bGV0dGVycyAvPiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC1zdG9yaWVzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICA8Rm9vdGVyTGlua3MgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0NvbnRhaW5lckhvbWVEZWZhdWx0PlxyXG4gICAgPC9TcGluPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb21lcGFnZURlZmF1bHRQYWdlO1xyXG4iLCJpbXBvcnQgUmVwb3NpdG9yeSwgeyBhcGliYXNldXJsIH0gZnJvbSBcIi4vUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IGdldERldmljZUlkLCBtYWtlUGFnZVVybCwgb3NUeXBlIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcblxyXG5jbGFzcyBIb21lYXBpIHtcclxuICBhc3luYyBnZXRIb21lZGF0YShwYXRoTmFtZSkge1xyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIGFjY2Vzc190b2tlbjogXCJcIixcclxuICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgcGFnZV91cmw6IG1ha2VQYWdlVXJsKFwiL1wiKSxcclxuICAgICAgb3NfdHlwZTogb3NUeXBlKCksXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IENhbmNlbFRva2VuID0gYXhpb3MuQ2FuY2VsVG9rZW47XHJcbiAgICBsZXQgc291cmNlID0gQ2FuY2VsVG9rZW4uc291cmNlKCk7XHJcblxyXG4gICAgc291cmNlICYmIHNvdXJjZS5jYW5jZWwoXCJPcGVyYXRpb24gY2FuY2VsZWQgZHVlIHRvIG5ldyByZXF1ZXN0LlwiKTtcclxuICAgIC8vIHNhdmUgdGhlIG5ldyByZXF1ZXN0IGZvciBjYW5jZWxsYXRpb25cclxuICAgIHNvdXJjZSA9IGF4aW9zLkNhbmNlbFRva2VuLnNvdXJjZSgpO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9ob21lYCxcclxuICAgICAgcGF5bG9hZCxcclxuICAgICAge1xyXG4gICAgICAgIGNhbmNlbFRva2VuOiBzb3VyY2UudG9rZW4sXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgLy8gY2FuY2VsIHRoZSByZXF1ZXN0ICh0aGUgbWVzc2FnZSBwYXJhbWV0ZXIgaXMgb3B0aW9uYWwpXHJcbiAgICBzb3VyY2UuY2FuY2VsKFwiT3BlcmF0aW9uIGNhbmNlbGVkIGJ5IHRoZSB1c2VyLlwiKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0UmV2aWV3KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wb3N0LXByb2R1Y3QtcmV2aWV3YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdFNlbGxlclJldmlldyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcG9zdC1zZWxsZXItcmV2aWV3YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbiAgLy8gYXN5bmMgZ2V0SG9tZWRhdGEoKSB7XHJcbiAgLy8gICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zXHJcbiAgLy8gICAgIC5nZXQoYGh0dHBzOi8vZXN0cnJhZG93ZWIuY29tL2thbmd0YW8vYXBpL2N1c3RvbWVyL2hvbWVgLCB7XHJcbiAgLy8gICAgICAgaGVhZGVyczoge1xyXG4gIC8vICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgLy8gICAgICAgfSxcclxuICAvLyAgICAgfSlcclxuICAvLyAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhKVxyXG4gIC8vICAgICAuY2F0Y2goKGVycm9yKSA9PiBlcnJvcik7XHJcbiAgLy8gICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgLy8gfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgSG9tZWFwaSgpO1xyXG4iLCJpbXBvcnQgeyBnZXREZXZpY2VJZCwgb3NUeXBlIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7XHJcbiAgYmFzZVVybCxcclxuICBzZXJpYWxpemVRdWVyeSxcclxuICBhcGliYXNldXJsLFxyXG4gIGJhc2VQYXRoVXJsLFxyXG59IGZyb20gXCIuL1JlcG9zaXRvcnlcIjtcclxuXHJcbmNsYXNzIFByb2R1Y3RSZXBvc2l0b3J5IHtcclxuICBhc3luYyBnZXRSZWNvcmRzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KFxyXG4gICAgICBgJHtiYXNlVXJsfS9wcm9kdWN0cz8ke3NlcmlhbGl6ZVF1ZXJ5KHBhcmFtcyl9YFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNlYXJjaGVkUHJvZHVjdHMocGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1zZWFyY2hgLFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFuZ19pZDogXCJcIixcclxuICAgICAgICBjYXRlZ29yeV9pZDogcGFyYW1zLmNhdGVnb3J5X2lkLFxyXG4gICAgICAgIGtleXdvcmQ6IHBhcmFtcy50aXRsZV9jb250YWlucyxcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5ub19vZl9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtbGlzdD9wYWdlPWAgKyBwYXJhbXMucGFnZSxcclxuICAgICAge1xyXG4gICAgICAgIGxhbmdfaWQ6IDEsXHJcbiAgICAgICAgYWNjZXNzX3Rva2VuOiBcIlwiLFxyXG4gICAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgICAgcGFnZV91cmw6IFwiaHR0cHM6Ly9hYmMuY29tL3Byb2R1Y3RzL3VzL2ltZ1wiLFxyXG4gICAgICAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXROZXdEZWFsc1Byb2R1Y3RzKHBheWxvYWQsIHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZGVhbHM/cGFnZT1gICsgcGFyYW1zLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja2luZ1NhbGVQcm9kdWN0cyhwYXlsb2FkLCBwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9jay1zYWxlLXByb2R1Y3RzP3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnNob2NrX3NhbGUsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRGZWF0dXJlZFByb2R1Y3RzKHBheWxvYWQsIHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZmVhdHVyZWQ/cGFnZT1gICsgcGFyYW1zLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWxpc3QtZmlsdGVyP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIiMjIyMjIyMjIyMjI1wiLHJlc3BvbnNlKVxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0TmV3RGVhbHNQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWRlYWxzP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob2NraW5nU2FsZVByb2R1Y3RzYnlGaWx0ZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Nob2NrLXNhbGUtcHJvZHVjdHM/cGFnZT1gICsgcGF5bG9hZC5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnNob2NrX3NhbGUsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRGZWF0dXJlZFByb2R1Y3RzYnlGaWx0ZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3QtZmVhdHVyZWQ/cGFnZT1gICsgcGF5bG9hZC5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvY2tpbmdQcm9kdWN0cyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9jay1zYWxlLXByb2R1Y3RzP3BhZ2U9YCArIHBhcmFtcy5wYWdlXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnNob2NrX3NhbGUsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRCcmFuZHMoKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9icmFuZGApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdENhdGVnb3JpZXMoKSB7XHJcbiAgICAvLyBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vcHJvZHVjdC1jYXRlZ29yaWVzYClcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXQtc3ViY2F0YFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFRvdGFsUmVjb3JkcygpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9wcm9kdWN0cy9jb3VudGApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUlkKGlkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuLlwiLGlkKVxyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLnVzZXJkYXRhLlwiLHVzZXJkYXRhKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLi5wYXJzZWRhdGFcIixwYXJzZWRhdGEpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuYWNjZXNzX3Rva2VuLlwiLGFjY2Vzc190b2tlbilcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS5nZXREZXZpY2VJZC5cIixnZXREZXZpY2VJZClcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS5hY2Nlc3NfdG9rZW4uXCIsYWNjZXNzX3Rva2VuKVxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWRldGFpbGAsXHJcbiAgICAgIHtcclxuICAgICAgICBhY2Nlc3NfdG9rZW4sXHJcbiAgICAgICAgaWQsXHJcbiAgICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOiBgJHtiYXNlUGF0aFVybH0vcHJvZHVjdC8ke2lkfWAsXHJcbiAgICAgICAgb3NfdHlwZTogb3NUeXBlKCksXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4uLlwiLHJlc3BvbnNlKVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob2NrU2FsZUJ5aWQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9jay1zYWxlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5Q2F0ZWdvcnkocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KFxyXG4gICAgICBgJHtiYXNlVXJsfS9wcm9kdWN0LWNhdGVnb3JpZXM/c2x1Zz0ke3BheWxvYWR9YFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YVswXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5QnJhbmQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L2JyYW5kcz9zbHVnPSR7cGF5bG9hZH1gKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YVswXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9KTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUJyYW5kcyhwYXlsb2FkKSB7XHJcbiAgICBsZXQgcXVlcnkgPSBcIlwiO1xyXG4gICAgcGF5bG9hZC5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgIGlmIChxdWVyeSA9PT0gXCJcIikge1xyXG4gICAgICAgIHF1ZXJ5ID0gYGlkX2luPSR7aXRlbX1gO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHF1ZXJ5ID0gcXVlcnkgKyBgJmlkX2luPSR7aXRlbX1gO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9icmFuZHM/JHtxdWVyeX1gKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlCcmFuZHMocGF5bG9hZCkge1xyXG4gICAgbGV0IHF1ZXJ5ID0gXCJcIjtcclxuICAgIHBheWxvYWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAocXVlcnkgPT09IFwiXCIpIHtcclxuICAgICAgICBxdWVyeSA9IGBpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBxdWVyeSA9IHF1ZXJ5ICsgYCZpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vYnJhbmRzPyR7cXVlcnl9YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5UHJpY2VSYW5nZShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoXHJcbiAgICAgIGAke2Jhc2VVcmx9L3Byb2R1Y3RzPyR7c2VyaWFsaXplUXVlcnkocGF5bG9hZCl9YFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGFkZFByb2R1Y3RUb0NhcnQocGF5bG9hZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uLjU2NTY1NjU2NTY1NjU2Li4uXCIscGF5bG9hZClcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hZGQtY2FydGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG4gIGFzeW5jIGNoYW5nZVF0eShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydC9jaGFuZ2UtcXR5YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHBsYWNlT3JkZXIocGF5bG9hZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uLi4zMzMzMzMzMzMzLi4uLi4uLlwiLHBheWxvYWQpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIvcGxhY2VvcmRlcmAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDYXJ0KHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmFhYWEuLi4uXCIscGF5bG9hZClcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jYXJ0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGRlbGV0ZUNhcnQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2RlbGV0ZS1jYXJ0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEF1Y3Rpb25Qcm9kdWN0QnlBdWN0aW9uSWQocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2F1Y3Rpb25gLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY3JlYXRlQmlkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jcmVhdGUtYmlkYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob3BEZXRhaWxCeUlkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9wLWRldGFpbGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDaGVja291dEluZm8ocGF5bG9hZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi5nZXRDaGVja291dEluZm8uLi4gYXB5bG9hZC4uXCIscGF5bG9hZClcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uZ2V0Q2hlY2tvdXRJbmZvLi4uIGFwaWJhc2V1cmwuLlwiLGFwaWJhc2V1cmwpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIvY2hlY2tvdXQtaW5mb2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBwbGFjZUF1Y3Rpb25PcmRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYXVjdGlvbi9jaGVja291dGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgUHJvZHVjdFJlcG9zaXRvcnkoKTtcclxuIiwiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5jb25zdCBiYXNlRG9tYWluID0gXCJodHRwczovL2JldGEuYXBpbm91dGhlbWVzLmNvbVwiOyAvLyBBUEkgZm9yIHByb2R1Y3RzXHJcbmV4cG9ydCBjb25zdCBiYXNlUG9zdFVybCA9IFwiaHR0cHM6Ly9iZXRhLmFwaW5vdXRoZW1lcy5jb21cIjsgLy8gQVBJIGZvciBwb3N0XHJcbmV4cG9ydCBjb25zdCBiYXNlU3RvcmVVUkwgPSBcImh0dHBzOi8vYmV0YS5hcGlub3V0aGVtZXMuY29tXCI7IC8vIEFQSSBmb3IgdmVuZG9yKHN0b3JlKVxyXG5cclxubGV0IGFwaWJhc2V1cmxDdXN0b20gPSBcImh0dHBzOi8vZGV2LWJpZ2Jhc2tldC5lc3RycmFkb3dlYi5jb21cIjtcclxubGV0IGJhc2VQYXRoID0gXCJodHRwczovL2Rldi1rYW5ndGFvLnZlcmNlbC5hcHBcIjtcclxuaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICBpZiAod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lID09IFwidWF0LWthbmd0YW8udmVyY2VsLmFwcFwiKSB7XHJcbiAgICBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL3VhdC1rdC5lc3RycmFkb3dlYi5jb21cIjtcclxuICAgIGJhc2VQYXRoID0gXCJodHRwczovL3VhdC1rYW5ndGFvLnZlcmNlbC5hcHBcIjtcclxuICB9XHJcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSA9PSBcInFhLWthbmd0YW8udmVyY2VsLmFwcFwiKSB7XHJcbiAgICBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL3FhLWt0LmVzdHJyYWRvd2ViLmNvbVwiO1xyXG4gICAgYmFzZVBhdGggPSBcImh0dHBzOi8vcWEta2FuZ3Rhby52ZXJjZWwuYXBwXCI7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgYXBpYmFzZXVybCA9IGFwaWJhc2V1cmxDdXN0b207XHJcbmV4cG9ydCBjb25zdCBiYXNlUGF0aFVybCA9IGJhc2VQYXRoO1xyXG5cclxuZXhwb3J0IGNvbnN0IGN1c3RvbUhlYWRlcnMgPSB7XHJcbiAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBiYXNlVXJsID0gYCR7YmFzZURvbWFpbn1gO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXhpb3MuY3JlYXRlKHtcclxuICBiYXNlVXJsLFxyXG4gIGhlYWRlcnM6IGN1c3RvbUhlYWRlcnMsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHNlcmlhbGl6ZVF1ZXJ5ID0gKHF1ZXJ5KSA9PiB7XHJcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHF1ZXJ5KVxyXG4gICAgLm1hcChcclxuICAgICAgKGtleSkgPT4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5W2tleV0pfWBcclxuICAgIClcclxuICAgIC5qb2luKFwiJlwiKTtcclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IGFjdGlvblR5cGVzID0ge1xyXG4gIEdFVF9DQVJUOiBcIkdFVF9DQVJUXCIsXHJcbiAgR0VUX0NBUlRfU1VDQ0VTUzogXCJHRVRfQ0FSVF9TVUNDRVNTXCIsXHJcbiAgR0VUX0NBUlRfRVJST1I6IFwiR0VUX0NBUlRfRVJST1JcIixcclxuXHJcbiAgR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFk6IFwiR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlcIixcclxuICBHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWV9TVUNDRVNTOiBcIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZX1NVQ0NFU1NcIixcclxuXHJcbiAgQUREX0lURU06IFwiQUREX0lURU1cIixcclxuICBSRU1PVkVfSVRFTTogXCJSRU1PVkVfSVRFTVwiLFxyXG4gIFJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVc6IFwiUkVNT1ZFX1BST0RVQ1RfRlJPTV9DQVJUX05FV1wiLFxyXG5cclxuICBDTEVBUl9DQVJUOiBcIkNMRUFSX0NBUlRcIixcclxuICBDTEVBUl9DQVJUX1NVQ0NFU1M6IFwiQ0xFQVJfQ0FSVF9TVUNDRVNTXCIsXHJcbiAgQ0xFQVJfQ0FSVF9FUlJPUjogXCJDTEVBUl9DQVJUX0VSUk9SXCIsXHJcblxyXG4gIElOQ1JFQVNFX1FUWTogXCJJTkNSRUFTRV9RVFlcIixcclxuICBJTkNSRUFTRV9RVFlfU1VDQ0VTUzogXCJJTkNSRUFTRV9RVFlfU1VDQ0VTU1wiLFxyXG4gIElOQ1JFQVNFX1FUWV9FUlJPUjogXCJJTkNSRUFTRV9RVFlfRVJST1JcIixcclxuXHJcbiAgREVDUkVBU0VfUVRZOiBcIkRFQ1JFQVNFX1FUWVwiLFxyXG4gIFVQREFURV9DQVJUOiBcIlVQREFURV9DQVJUXCIsXHJcblxyXG4gIFVQREFURV9DQVJUX1NVQ0NFU1M6IFwiVVBEQVRFX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIFVQREFURV9DQVJUX0VSUk9SOiBcIlVQREFURV9DQVJUX0VSUk9SXCIsXHJcblxyXG4gIFVQREFURV9TRUxFQ1RFRF9BRERSRVNTOiBcIlVQREFURV9TRUxFQ1RFRF9BRERSRVNTXCIsXHJcblxyXG4gIEZFVENIX1BMQVRGT1JNX1ZPVUNIRVI6IFwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUlwiLFxyXG4gIEZFVENIX1BMQVRGT1JNX1ZPVUNIRVJfU1VDQ0VTUzogXCJGRVRDSF9QTEFURk9STV9WT1VDSEVSX1NVQ0NFU1NcIixcclxuXHJcbiAgVE9UQUxfRElTQ09VTlQ6IFwiVE9UQUxfRElTQ09VTlRcIixcclxuXHJcbiAgQVBQTElFRF9TRUxMRVJfVk9VQ0hFUjogXCJBUFBMSUVEX1NFTExFUl9WT1VDSEVSXCIsXHJcblxyXG4gIEFQUExJRURfUExBVEZPUk1fVk9VQ0hFUjogXCJBUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVJcIixcclxuXHJcbiAgR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRTogXCJHUkFORF9UT1RBTF9XSVRIX0RJU0NPVU5UX1ZBTFVFXCIsXHJcblxyXG4gIFNFTExFUl9XSVNFX0RJU0NPVU5UOiBcIlNFTExFUl9XSVNFX0RJU0NPVU5UXCIsXHJcblxyXG4gIFNFTExFUl9XSVNFX01FU1NBR0VTOiBcIlNFTExFUl9XSVNFTUVTU0FHRVNcIixcclxuXHJcbiAgVVNFRF9XQUxMRVRfQU1PVU5UOiBcIlVTRURfV0FMTEVUX0FNT1VOVFwiLFxyXG5cclxuICBTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSOiBcIlNFTEVDVEVEX1BBWU1FTlRfT1BUSU9OX0JZX1VTRVJcIixcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVQcm9kdWN0RnJvbUNhcnROZXcocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVcsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdGVkUGF5bWVudE9wdGlvbihwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUiwgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2VsbGVyV2lzZU1lc3NhZ2UocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTExFUl9XSVNFX01FU1NBR0VTLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1c2VkV2FsbGV0QW1vdW50KHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5VU0VEX1dBTExFVF9BTU9VTlQsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbGxlcldpc2VEaXNjb3VudChwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuU0VMTEVSX1dJU0VfRElTQ09VTlQsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdyYW5kVG90YWxXaXRoRGlzY291bnRWYWx1ZShwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRSwgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYXBwbGllZFNlbGxlclZvdWNoZXIocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkFQUExJRURfU0VMTEVSX1ZPVUNIRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGxpZWRQbGF0Zm9ybVZvdWNoZXIocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkFQUExJRURfUExBVEZPUk1fVk9VQ0hFUiwgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdG90YWxEaXNjb3VudChwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuVE9UQUxfRElTQ09VTlQsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uKCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5GRVRDSF9QTEFURk9STV9WT1VDSEVSLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvblN1Y2Nlc3MocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5GRVRDSF9QTEFURk9STV9WT1VDSEVSX1NVQ0NFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJ0KCkge1xyXG4gIGFsZXJ0KFwiZ2V0Q2FydFwiKVxyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJ0U3VjY2VzcyhwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUX1NVQ0NFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXJ0RXJyb3IoZXJyb3IpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuR0VUX0NBUlRfRVJST1IsXHJcbiAgICBlcnJvcixcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlU2VsZWN0ZWRBZGRyZXNzKHBheWxvYWQpIHtcclxuICBhbGVydChcImNhbGxcIilcclxuICBjb25zb2xlLmxvZyhcIi4uNTU1NTU1Li4uLlwiLHBheWxvYWQpXHJcblxyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5VUERBVEVfU0VMRUNURURfQUREUkVTUyxcclxuICAgIHBheWxvYWQsXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFkZEl0ZW0ocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkFERF9JVEVNLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVJdGVtKHByb2R1Y3QpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5SRU1PVkVfSVRFTSwgcHJvZHVjdCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5jcmVhc2VJdGVtUXR5KHByb2R1Y3QpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5JTkNSRUFTRV9RVFksIHByb2R1Y3QgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRlY3JlYXNlSXRlbVF0eShwcm9kdWN0KSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuREVDUkVBU0VfUVRZLCBwcm9kdWN0IH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVDYXJ0U3VjY2VzcyhwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLlVQREFURV9DQVJUX1NVQ0NFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVDYXJ0RXJyb3IocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5VUERBVEVfQ0FSVF9FUlJPUixcclxuICAgIHBheWxvYWQsXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyQ2FydCgpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5DTEVBUl9DQVJUIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjbGVhckNhcnRTdWNjZXNzKCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkNMRUFSX0NBUlRfU1VDQ0VTUyB9O1xyXG59XHJcbiIsIi8qXHJcbiAqIFJlYWN0IHRlbXBsYXRlIGhlbHBlcnNcclxuICogQXV0aG9yOiBOb3V0aGVtZXNcclxuICogRGV2ZWxvcGVkOiBkaWFyeWZvcmxpZmVcclxuICogKi9cclxuXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExhenlMb2FkIGZyb20gXCJyZWFjdC1sYXp5bG9hZFwiO1xyXG5pbXBvcnQgeyBiYXNlVXJsIH0gZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1JlcG9zaXRvcnlcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgUm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuY29uc3QgZXhhY3RNYXRoID0gcmVxdWlyZShcImV4YWN0LW1hdGhcIik7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcm91dGVXaXRob3V0UmVmcmVzaChyb3V0ZUxpbmspIHtcclxuICBSb3V0ZXIucmVwbGFjZShyb3V0ZUxpbmssIHVuZGVmaW5lZCwge1xyXG4gICAgc2hhbGxvdzogdHJ1ZSxcclxuICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGhvbWVQYWdlUHJvZHVjdFByaWNlSGVscGVyKHByb2R1Y3QpIHtcclxuICBpZiAocHJvZHVjdC5vZmZlcl9wcmljZSAhPT0gZmFsc2UpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIG9mZmVyXCI+XHJcbiAgICAgICAgUk0ge3Byb2R1Y3Qub2ZmZXJfcHJpY2UgPyBwcm9kdWN0Lm9mZmVyX3ByaWNlIDogMH1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgICAgICA8L2RlbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgaWYgKHByb2R1Y3Quc2hvY2tfc2FsZV9wcmljZSAhPT0gZmFsc2UpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIG9mZmVyXCI+XHJcbiAgICAgICAgUk0ge3Byb2R1Y3Quc2hvY2tfc2FsZV9wcmljZX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgICAgICA8L2RlbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgaWYgKHByb2R1Y3Quc2FsZV9wcmljZSAhPT0gZmFsc2UpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIG9mZmVyXCI+XHJcbiAgICAgICAgUk0ge3Byb2R1Y3Quc2FsZV9wcmljZX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5cclxuICAgICAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgICAgICA8L2RlbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgIFJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMH1cclxuICAgIDwvcD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmV0dXJuVG90YWxPZkNhcnRWYWx1ZShwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX3ByaWNlID0gcHJvZHVjdHMucmVkdWNlKChwcmV2LCBuZXh0KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICBOdW1iZXIocHJpY2VIZWxwZXIocHJldikpICtcclxuICAgICAgTnVtYmVyKFxyXG4gICAgICAgIHByaWNlSGVscGVyKFxyXG4gICAgICAgICAgbmV4dC50b3RhbF9kaXNjb3VudF9wcmljZSA9PSAwXHJcbiAgICAgICAgICAgID8gbmV4dC50b3RhbF9hY3R1YWxfcHJpY2VcclxuICAgICAgICAgICAgOiBuZXh0LnRvdGFsX2Rpc2NvdW50X3ByaWNlXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICApO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF9wcmljZTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJldHVyblRvdGFsQ29tbWlzc2lvbihwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX2NvbW1pc3Npb24gPSBwcm9kdWN0cy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IHtcclxuICAgIHJldHVybiBOdW1iZXIocHJpY2VIZWxwZXIocHJldikpICsgTnVtYmVyKHByaWNlSGVscGVyKG5leHQuY29tbWlzc2lvbikpO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF9jb21taXNzaW9uO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmV0dXJuVG90YWxPZkNhcnRUYXhWYWx1ZShwcm9kdWN0cykge1xyXG4gIGxldCBjYXJ0X3RvdGFsX3RheCA9IHByb2R1Y3RzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgTnVtYmVyKHByaWNlSGVscGVyKHByZXYpKSArIE51bWJlcihwcmljZUhlbHBlcihuZXh0LnRvdGFsX3RheF92YWx1ZSkpXHJcbiAgICApO1xyXG4gIH0sIDApO1xyXG5cclxuICByZXR1cm4gY2FydF90b3RhbF90YXg7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwcmljZUhlbHBlcihudW0pIHtcclxuICBsZXQgbnVtYmVyQXJyYXkgPSBudW0/LnRvU3RyaW5nKCkuc3BsaXQoXCIsXCIpO1xyXG4gIGlmIChudW1iZXJBcnJheSAmJiBudW1iZXJBcnJheT8ubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIG51bWJlckFycmF5LnJlZHVjZSgocHJldiwgbmV4dCkgPT4gcHJldiArIG5leHQpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gMDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQoY3VycmVuY3lWYWwpIHtcclxuICByZXR1cm4gbmV3IEludGwuTnVtYmVyRm9ybWF0KFwibXMtTVlcIiwge1xyXG4gICAgc3R5bGU6IFwiY3VycmVuY3lcIixcclxuICAgIGN1cnJlbmN5OiBcIk1ZUlwiLFxyXG4gIH0pLmZvcm1hdChwcmljZUhlbHBlcihjdXJyZW5jeVZhbCkpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbWF0aEZvcm11bGEoZm9ybXVsYVRleHQpIHtcclxuICBsZXQgcmVzdWx0ID0gZXhhY3RNYXRoLmZvcm11bGEoZm9ybXVsYVRleHQpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZGl2Q3VycmVuY3koZmlyc3RWYWwsIHNlY29uZFZhbCkge1xyXG4gIGxldCBkaXZEYXRhID0gZXhhY3RNYXRoLmRpdihcclxuICAgIHByaWNlSGVscGVyKGZpcnN0VmFsIHx8IDApLFxyXG4gICAgcHJpY2VIZWxwZXIoc2Vjb25kVmFsIHx8IDEpXHJcbiAgKTtcclxuICByZXR1cm4gZGl2RGF0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG11bEN1cnJlbmN5KGZpcnN0VmFsLCBzZWNvbmRWYWwpIHtcclxuICBsZXQgbXVsRGF0YSA9IGV4YWN0TWF0aC5tdWwoXHJcbiAgICBwcmljZUhlbHBlcihmaXJzdFZhbCB8fCAxKSxcclxuICAgIHByaWNlSGVscGVyKHNlY29uZFZhbCB8fCAxKVxyXG4gICk7XHJcbiAgcmV0dXJuIG11bERhdGE7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhZGRDdXJyZW5jeShjdXJyZW5jeVZhbEZpcnN0LCBjdXJyZW5jeVZhbFNlY29uZCkge1xyXG4gIGxldCBhZGREYXRhID0gZXhhY3RNYXRoLmFkZChcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsRmlyc3QgfHwgMCksXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbFNlY29uZCB8fCAwKVxyXG4gICk7XHJcblxyXG4gIHJldHVybiBhZGREYXRhO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzdWJDdXJyZW5jeShjdXJyZW5jeVZhbEZpcnN0LCBjdXJyZW5jeVZhbFNlY29uZCkge1xyXG4gIGxldCBzdWJEYXRhID0gZXhhY3RNYXRoLnN1YihcclxuICAgIHByaWNlSGVscGVyKGN1cnJlbmN5VmFsRmlyc3QgfHwgMCksXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbFNlY29uZCB8fCAwKVxyXG4gICk7XHJcblxyXG4gIHJldHVybiBzdWJEYXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0Q3VycmVuY3kobnVtKSB7XHJcbiAgaWYgKG51bSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gcGFyc2VGbG9hdChudW0pXHJcbiAgICAgIC50b1N0cmluZygpXHJcbiAgICAgIC5yZXBsYWNlKC8oXFxkKSg/PShcXGR7M30pKyg/IVxcZCkpL2csIFwiJDEsXCIpO1xyXG4gIH0gZWxzZSB7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29sbGV0aW9uQnlTbHVnKGNvbGxlY3Rpb25zLCBzbHVnKSB7XHJcbiAgaWYgKGNvbGxlY3Rpb25zLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGNvbGxlY3Rpb25zLmZpbmQoKGl0ZW0pID0+IGl0ZW0uc2x1ZyA9PT0gc2x1Zy50b1N0cmluZygpKTtcclxuICAgIGlmIChyZXN1bHQgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICByZXR1cm4gcmVzdWx0LnByb2R1Y3RzO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIFtdO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gW107XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0SXRlbUJ5U2x1ZyhiYW5uZXJzLCBzbHVnKSB7XHJcbiAgaWYgKGJhbm5lcnMubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgYmFubmVyID0gYmFubmVycy5maW5kKChpdGVtKSA9PiBpdGVtLnNsdWcgPT09IHNsdWcudG9TdHJpbmcoKSk7XHJcbiAgICBpZiAoYmFubmVyICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgcmV0dXJuIGJhbm5lcjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjb252ZXJ0U2x1Z3NRdWVyeVN0cmluZyhwYXlsb2FkKSB7XHJcbiAgbGV0IHF1ZXJ5ID0gXCJcIjtcclxuICBpZiAocGF5bG9hZC5sZW5ndGggPiAwKSB7XHJcbiAgICBwYXlsb2FkLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHF1ZXJ5ID09PSBcIlwiKSB7XHJcbiAgICAgICAgcXVlcnkgPSBgc2x1Z19pbj0ke2l0ZW19YDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBxdWVyeSA9IHF1ZXJ5ICsgYCZzbHVnX2luPSR7aXRlbX1gO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbiAgcmV0dXJuIHF1ZXJ5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdEJhZGdlKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5iYWRnZSAmJiBwcm9kdWN0LmJhZGdlICE9PSBudWxsKSB7XHJcbiAgICB2aWV3ID0gcHJvZHVjdC5iYWRnZS5tYXAoKGJhZGdlKSA9PiB7XHJcbiAgICAgIGlmIChiYWRnZS50eXBlID09PSBcInNhbGVcIikge1xyXG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2JhZGdlXCI+e2JhZGdlLnZhbHVlfTwvZGl2PjtcclxuICAgICAgfSBlbHNlIGlmIChiYWRnZS50eXBlID09PSBcIm91dFN0b2NrXCIpIHtcclxuICAgICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19iYWRnZSBvdXQtc3RvY2tcIj57YmFkZ2UudmFsdWV9PC9kaXY+O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2JhZGdlIGhvdFwiPntiYWRnZS52YWx1ZX08L2Rpdj47XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZShwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuaXNfc2FsZSA9PT0gdHJ1ZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5STSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlKX08L2RlbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5STSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9PC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VfTmV3KHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5zYWxlX3ByaWNlICE9PSBmYWxzZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFJNIHtwcm9kdWN0LnNhbGVfcHJpY2V9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+Uk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlfTwvZGVsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5STSB7cHJvZHVjdC5hY3R1YWxfcHJpY2V9PC9wPjtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZWF0dXJlcHJvZHVjdHByaWNlKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuICBpZiAocHJvZHVjdC5pc19zYWxlID09PSB0cnVlKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfXtcIiBcIn1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsaW4tcHJkdFwiPlxyXG4gICAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QuYWN0dWFsX3ByaWNlKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Quc2FsZV9wcmljZSl9e1wiIFwifVxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxpbi1wcmR0XCI+XHJcbiAgICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5hY3R1YWxfcHJpY2UpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuaXNfc2FsZSA9PT0gdHJ1ZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX1cclxuICAgICAgICA8ZGVsIGNsYXNzTmFtZT1cIm1sLTJcIj5STSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlKX08L2RlbD5cclxuICAgICAgICA8c21hbGw+MTglIG9mZjwvc21hbGw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+Uk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UpfTwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlRXhwYW5kZWRPdGhlcihwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIHZpZXcgPSAoXHJcbiAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5vZmZlcl9wcmljZSA/IHByb2R1Y3Qub2ZmZXJfcHJpY2UgOiAwKX1cclxuICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QuYWN0dWFsX3ByaWNlID8gcHJvZHVjdC5hY3R1YWxfcHJpY2UgOiAwKX1cclxuICAgICAgPC9kZWw+XHJcbiAgICAgIDxzbWFsbD57cHJvZHVjdC5vZmZlciA/IHByb2R1Y3Qub2ZmZXIgOiAwfTwvc21hbGw+XHJcbiAgICA8L3A+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIxKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgdmlldyA9IChcclxuICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+XHJcbiAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UgPyBwcm9kdWN0LnNhbGVfcHJpY2UgOiAwKX1cclxuICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UgPyBwcm9kdWN0LnByaWNlIDogMCl9XHJcbiAgICAgIDwvZGVsPlxyXG4gICAgICA8c21hbGw+e3Byb2R1Y3Qub2ZmZXIgPyBwcm9kdWN0Lm9mZmVyIDogMH08L3NtYWxsPlxyXG4gICAgPC9wPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFRodW1ibmFpbChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LnRodW1ibmFpbCkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e2Ake2Jhc2VVcmx9JHtwcm9kdWN0LnRodW1ibmFpbC51cmx9YH1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QudGl0bGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiIGFsdD1cIkthbmd0YW9cIiAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RUaHVtYm5haWxPdGhlcihwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LmltYWdlLmxlbmd0aCA+IDApIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RUaHVtYm5haWxEZXRhaWwocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICBpZiAocHJvZHVjdC5pbWFnZS5sZW5ndGggPiAwKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9XHJcbiAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0LnByb2R1Y3RfbmFtZX1cclxuICAgICAgICAgICAgICB3aWR0aD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9XCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJcclxuICAgICAgICAgICAgICBhbHQ9XCJLYW5ndGFvXCJcclxuICAgICAgICAgICAgICB3aWR0aD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjUwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNob2NraW5ncHJvZHVjdHRodW1ibmFpbChwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIGlmIChwcm9kdWN0LmltYWdlLmxlbmd0aCA+IDApIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LnByb2R1Y3RfaWR9YH0+XHJcbiAgICAgICAgPGE+XHJcbiAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3Q/LmltYWdlWzBdPy5pbWFnZX1cclxuICAgICAgICAgICAgICBhbHQ9e3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgd2lkdGg9XCIzMDBweFwiXHJcbiAgICAgICAgICAgICAgaGVpZ2h0PVwiMjAwcHhcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNvbG9ySGVscGVyKCkge1xyXG4gIGNvbnNvbGUubG9nKFwiaGVsbG9cIik7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==