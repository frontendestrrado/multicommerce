webpackHotUpdate_N_E("pages/account/login",{

/***/ "./components/shared/headers/HeaderDefault.jsx":
/*!*****************************************************!*\
  !*** ./components/shared/headers/HeaderDefault.jsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/common/Logo */ "./components/elements/common/Logo.js");
/* harmony import */ var _components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/shared/headers/modules/SearchHeader */ "./components/shared/headers/modules/SearchHeader.jsx");
/* harmony import */ var _components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/shared/navigation/NavigationDefault */ "./components/shared/navigation/NavigationDefault.jsx");
/* harmony import */ var _components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/shared/headers/modules/HeaderActions */ "./components/shared/headers/modules/HeaderActions.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/shared/menus/MenuCategoriesDropdown */ "./components/shared/menus/MenuCategoriesDropdown.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\HeaderDefault.jsx",
    _s = $RefreshSig$();









 // import Dropdown from 'react-bootstrap/Dropdown';

const HeaderDefault = () => {
  _s();

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (true) {
      window.addEventListener("scroll", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__["stickyHeader"]);
    }
  }, []);

  const aaa = e => {
    // alert("d")
    console.log("ghfhfh", e.target.value);
    localStorage.setItem("langId", e.target.value);
    window.location.reload();
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
    className: "header header--1",
    "data-sticky": "true",
    id: "headerSticky",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "head-top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "d-flex justify-content-end",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "top-content",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "top-url",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("select", {
                  onChange: e => aaa(e),
                  nme: "cars",
                  id: "cars",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "1",
                    children: "Lang"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 34,
                    columnNumber: 19
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "1",
                    children: "English"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 35,
                    columnNumber: 5
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
                    value: "2",
                    children: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 36,
                    columnNumber: 5
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 15
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "top-li",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: " Sign In"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 52,
                  columnNumber: 20
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 39,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "header__top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__left",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__categ",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "d-flex justify-content-center align-items-center ofr",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "",
            children: "Offer Zone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__right",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, undefined);
};

_s(HeaderDefault, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = HeaderDefault;
/* harmony default export */ __webpack_exports__["default"] = (HeaderDefault);

var _c;

$RefreshReg$(_c, "HeaderDefault");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/MiniCart.jsx":
/*!********************************************************!*\
  !*** ./components/shared/headers/modules/MiniCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductOnCart */ "./components/elements/products/ProductOnCart.jsx");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\MiniCart.jsx",
    _s = $RefreshSig$();











const MiniCart = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(_c = _s(({
  cart
}) => {
  var _cart$product, _cartdata$product, _cartdata$product2;

  _s();

  let cartItemsView;
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(state => state.auth);
  const productItemWithSeller = cart === null || cart === void 0 ? void 0 : (_cart$product = cart.product) === null || _cart$product === void 0 ? void 0 : _cart$product.map(productItem => {
    var _productItem$seller, _productItem$seller2, _productItem$seller3, _productItem$seller3$;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "stor-tit",
        children: productItem === null || productItem === void 0 ? void 0 : (_productItem$seller2 = productItem.seller) === null || _productItem$seller2 === void 0 ? void 0 : _productItem$seller2.seller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }, undefined), productItem === null || productItem === void 0 ? void 0 : (_productItem$seller3 = productItem.seller) === null || _productItem$seller3 === void 0 ? void 0 : (_productItem$seller3$ = _productItem$seller3.products) === null || _productItem$seller3$ === void 0 ? void 0 : _productItem$seller3$.map(cartProduct => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: cartProduct
      }, cartProduct === null || cartProduct === void 0 ? void 0 : cartProduct.cart_id, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined))]
    }, productItem === null || productItem === void 0 ? void 0 : (_productItem$seller = productItem.seller) === null || _productItem$seller === void 0 ? void 0 : _productItem$seller.seller_id, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, undefined);
  });
  const {
    0: cartdata,
    1: setCartdata
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: totalItems,
    1: setTotalItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log(".productItemNext......cart.....", cart); // console.log(".productItemNext...........", productItemNext)

    let isMounted = true;

    if (isMounted) {
      var _cart$product2;

      //alert("bhbhhbhhh")
      const cartTotalProductsFromAllSeller = cart === null || cart === void 0 ? void 0 : (_cart$product2 = cart.product) === null || _cart$product2 === void 0 ? void 0 : _cart$product2.reduce((productItemPrev, productItemNext) => {
        return Number(productItemPrev) + Number(productItemNext.seller.products.length);
      }, 0);
      setTotalItems(cartTotalProductsFromAllSeller);
      setCartdata(cart);
    }

    return () => {
      isMounted = false;
    };
  }, [cart === null || cart === void 0 ? void 0 : cart.product]); // async getCartItem(payload) {

  const getCartItem = payload => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]
    });
    console.log("....aaaaaaaaaaaaaaaa...", user_token);
    console.log("....bbbbbbbbbbbbbbbb...", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]);
    const data = axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: localStorage.getItem("langId"),
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }).then(response => response.data).then(data => {
      console.log("...iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setCartdata(data.data);
        setTotalItems(data.data.cart_count); //   alert("yes")
        //  setOfferData(data.data)
        // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {// notification["error"]({
      //   message: error,
      // });
    });
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]); // console.log("....bbbbb...bbb...",payload)
    // let userdata = localStorage.getItem("user");
    // let parsedata = JSON.parse(userdata);
    // let access_token = parsedata?.access_token;
    // const user_token = access_token;
    // const response =  Repository.post(`${apibaseurl}/api/customer/cart`, {
    //   access_token: user_token,
    //   lang_id: 1,
    //   device_id: getDeviceId,
    //   page_url: "http://localhost:3000/product/2",
    //   os_type: "WEB",
    // })
    // console.log("....bbbbb...bbb..444444444444.",response)
    //   // .then((response) => {
    //     if (response.data.httpcode == "200") {
    //       return response.data;
    //     }
    //   //   return response.data;
    //   // })
    //   // .catch((error) => ({ error: JSON.stringify(error) }));
    // return response;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("..557..", cart);
    getCartItem();

    if (cart == undefined) {
      // alert("ddfffd")
      (auth === null || auth === void 0 ? void 0 : auth.access_token) && dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
    }
  }, [auth.access_token, cart === null || cart === void 0 ? void 0 : cart.product]);

  if (cartdata !== null && cartdata !== undefined && cartdata !== null && cartdata !== void 0 && (_cartdata$product = cartdata.product) !== null && _cartdata$product !== void 0 && _cartdata$product.length && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product2 = cartdata.product) === null || _cartdata$product2 === void 0 ? void 0 : _cartdata$product2.length) !== 0) {
    var _cartdata$product3;

    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: productItemWithSeller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 143,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__footer",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          children: ["Sub Total:", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            children: cartdata && cartdata !== null && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product3 = cartdata.product) === null || _cartdata$product3 === void 0 ? void 0 : _cartdata$product3.length) > 0 ? Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__["currencyHelperConvertToRinggit"])(cartdata.grand_total) : 0
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 147,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/shopping-cart",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "View Cart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 155,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 154,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/checkout",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "Checkout"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 158,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 157,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 153,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 144,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 142,
      columnNumber: 7
    }, undefined);
  } else {
    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          children: "No products in cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 166,
      columnNumber: 7
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-cart--mini",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "header__extra",
      href: "#",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-bag2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          children: cartdata !== null && cartdata !== undefined && totalItems > 0 ? totalItems : 0
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 179,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 178,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 176,
      columnNumber: 7
    }, undefined), cartItemsView]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 175,
    columnNumber: 5
  }, undefined);
}, "lT+bflo29ZWMxNMJEjF2ThtquLk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"]];
}));
_c2 = MiniCart;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(state => state.cart)(MiniCart));

var _c, _c2;

$RefreshReg$(_c, "MiniCart$React.memo");
$RefreshReg$(_c2, "MiniCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/@popperjs/core/lib/createPopper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/contains.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getParentNode.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/instanceOf.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isLayoutViewport.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isTableElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js":
false,

/***/ "./node_modules/@popperjs/core/lib/enums.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/arrow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/computeStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/eventListeners.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/flip.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/hide.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/offset.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/popperOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/preventOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper-base.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/debounce.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/detectOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/expandToHashMap.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/format.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getAltAxis.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getBasePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getFreshSideObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getVariation.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/math.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergeByName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergePaddingObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/orderModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/rectToClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/uniqueBy.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/userAgent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/validateModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/within.js":
false,

/***/ "./node_modules/@react-aria/ssr/dist/module.js":
false,

/***/ "./node_modules/@restart/hooks/esm/index.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCallbackRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCommittedRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventCallback.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useForceUpdate.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useGlobalListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useImage.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useIsomorphicEffect.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeState.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeStateFromProps.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergedRefs.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMounted.js":
false,

/***/ "./node_modules/@restart/hooks/esm/usePrevious.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useRafInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useResizeObserver.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useSafeState.js":
false,

/***/ "./node_modules/@restart/ui/esm/Anchor.js":
false,

/***/ "./node_modules/@restart/ui/esm/Button.js":
false,

/***/ "./node_modules/@restart/ui/esm/DataKey.js":
false,

/***/ "./node_modules/@restart/ui/esm/Dropdown.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownItem.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownMenu.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownToggle.js":
false,

/***/ "./node_modules/@restart/ui/esm/NavContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/SelectableContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/mergeOptionsWithPopperConfig.js":
false,

/***/ "./node_modules/@restart/ui/esm/popper.js":
false,

/***/ "./node_modules/@restart/ui/esm/ssr.js":
false,

/***/ "./node_modules/@restart/ui/esm/useClickOutside.js":
false,

/***/ "./node_modules/@restart/ui/esm/usePopper.js":
false,

/***/ "./node_modules/@restart/ui/esm/useWindow.js":
false,

/***/ "./node_modules/dequal/dist/index.mjs":
false,

/***/ "./node_modules/dom-helpers/esm/addEventListener.js":
false,

/***/ "./node_modules/dom-helpers/esm/camelize.js":
false,

/***/ "./node_modules/dom-helpers/esm/canUseDOM.js":
false,

/***/ "./node_modules/dom-helpers/esm/contains.js":
false,

/***/ "./node_modules/dom-helpers/esm/listen.js":
false,

/***/ "./node_modules/dom-helpers/esm/ownerDocument.js":
false,

/***/ "./node_modules/dom-helpers/esm/querySelectorAll.js":
false,

/***/ "./node_modules/dom-helpers/esm/removeEventListener.js":
false,

/***/ "./node_modules/invariant/browser.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Button.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Dropdown.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownItem.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownMenu.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownToggle.js":
false,

/***/ "./node_modules/react-bootstrap/esm/InputGroupContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/NavbarContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/ThemeProvider.js":
false,

/***/ "./node_modules/react-bootstrap/esm/createWithBsPrefix.js":
false,

/***/ "./node_modules/react-bootstrap/esm/types.js":
false,

/***/ "./node_modules/react-bootstrap/esm/useWrappedRefWithWarning.js":
false,

/***/ "./node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js":
false,

/***/ "./node_modules/react/cjs/react-jsx-runtime.development.js":
false,

/***/ "./node_modules/react/jsx-runtime.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/hook.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/index.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/uncontrollable.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/utils.js":
false,

/***/ "./node_modules/warning/warning.js":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9zaGFyZWQvaGVhZGVycy9IZWFkZXJEZWZhdWx0LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9zaGFyZWQvaGVhZGVycy9tb2R1bGVzL01pbmlDYXJ0LmpzeCJdLCJuYW1lcyI6WyJIZWFkZXJEZWZhdWx0IiwidXNlRWZmZWN0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInN0aWNreUhlYWRlciIsImFhYSIsImUiLCJjb25zb2xlIiwibG9nIiwidGFyZ2V0IiwidmFsdWUiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwibG9jYXRpb24iLCJyZWxvYWQiLCJNaW5pQ2FydCIsIlJlYWN0IiwibWVtbyIsImNhcnQiLCJjYXJ0SXRlbXNWaWV3IiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsImF1dGgiLCJ1c2VTZWxlY3RvciIsInN0YXRlIiwicHJvZHVjdEl0ZW1XaXRoU2VsbGVyIiwicHJvZHVjdCIsIm1hcCIsInByb2R1Y3RJdGVtIiwic2VsbGVyIiwicHJvZHVjdHMiLCJjYXJ0UHJvZHVjdCIsImNhcnRfaWQiLCJzZWxsZXJfaWQiLCJjYXJ0ZGF0YSIsInNldENhcnRkYXRhIiwidXNlU3RhdGUiLCJ0b3RhbEl0ZW1zIiwic2V0VG90YWxJdGVtcyIsImlzTW91bnRlZCIsImNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlciIsInJlZHVjZSIsInByb2R1Y3RJdGVtUHJldiIsInByb2R1Y3RJdGVtTmV4dCIsIk51bWJlciIsImxlbmd0aCIsImdldENhcnRJdGVtIiwicGF5bG9hZCIsInVzZXJkYXRhIiwiZ2V0SXRlbSIsInBhcnNlZGF0YSIsIkpTT04iLCJwYXJzZSIsImFjY2Vzc190b2tlbiIsInVzZXJfdG9rZW4iLCJhcGliYXNldXJsIiwiZ2V0RGV2aWNlSWQiLCJkYXRhIiwiQXhpb3MiLCJwb3N0IiwibGFuZ19pZCIsImRldmljZV9pZCIsInBhZ2VfdXJsIiwib3NfdHlwZSIsInRoZW4iLCJyZXNwb25zZSIsImh0dHBjb2RlIiwic3RhdHVzIiwiY2FydF9jb3VudCIsImNhdGNoIiwiZXJyb3IiLCJ1bmRlZmluZWQiLCJnZXRDYXJ0IiwiY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IiwiZ3JhbmRfdG90YWwiLCJjb25uZWN0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0FFQTs7QUFFQSxNQUFNQSxhQUFhLEdBQUcsTUFBTTtBQUFBOztBQUMxQkMseURBQVMsQ0FBQyxNQUFNO0FBQ2QsY0FBcUI7QUFDbkJDLFlBQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NDLHNFQUFsQztBQUNEO0FBQ0YsR0FKUSxFQUlOLEVBSk0sQ0FBVDs7QUFLQSxRQUFNQyxHQUFHLEdBQUlDLENBQUQsSUFBTztBQUVwQjtBQUNEQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCRixDQUFDLENBQUNHLE1BQUYsQ0FBU0MsS0FBOUI7QUFDQUMsZ0JBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixFQUE4Qk4sQ0FBQyxDQUFDRyxNQUFGLENBQVNDLEtBQXZDO0FBQ0FSLFVBQU0sQ0FBQ1csUUFBUCxDQUFnQkMsTUFBaEI7QUFDQyxHQU5DOztBQU9BLHNCQUNFO0FBQVEsYUFBUyxFQUFDLGtCQUFsQjtBQUFxQyxtQkFBWSxNQUFqRDtBQUF3RCxNQUFFLEVBQUMsY0FBM0Q7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsY0FBWDtBQUFBLCtCQUNFO0FBQUssZUFBSyxFQUFDLDRCQUFYO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGFBQWY7QUFBQSxtQ0FDRTtBQUFJLHVCQUFTLEVBQUMsU0FBZDtBQUFBLHNDQUNBO0FBQUEsdUNBQ0k7QUFBUSwwQkFBUSxFQUFHUixDQUFELElBQU9ELEdBQUcsQ0FBQ0MsQ0FBRCxDQUE1QjtBQUFpQyxxQkFBRyxFQUFDLE1BQXJDO0FBQTRDLG9CQUFFLEVBQUMsTUFBL0M7QUFBQSwwQ0FDQTtBQUFVLHlCQUFLLEVBQUMsR0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREEsZUFFZDtBQUFVLHlCQUFLLEVBQUMsR0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRmMsZUFHZDtBQUFRLHlCQUFLLEVBQUMsR0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFIYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURBLGVBUUU7QUFBSSx5QkFBUyxFQUFDLFFBQWQ7QUFBQSx1Q0FhRyxxRUFBQyxnREFBRDtBQUFNLHNCQUFJLEVBQUMsZ0JBQVg7QUFBQSx5Q0FDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUF3Q0U7QUFBSyxlQUFTLEVBQUMsYUFBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxjQUFmO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLGNBQWY7QUFBQSxpQ0FDRSxxRUFBQyx3RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUtFO0FBQUssbUJBQVMsRUFBQyxlQUFmO0FBQUEsaUNBQ0UscUVBQUMsdUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEYsZUFRRTtBQUFLLG1CQUFTLEVBQUMsc0RBQWY7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsRUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkYsZUFXRTtBQUFLLG1CQUFTLEVBQUMsZ0JBQWY7QUFBQSxpQ0FDRSxxRUFBQyx1RkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFYRixlQWNFO0FBQUssbUJBQVMsRUFBQyxlQUFmO0FBQUEsaUNBQ0UscUVBQUMsd0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFnRUQsQ0E3RUQ7O0dBQU1OLGE7O0tBQUFBLGE7QUErRVNBLDRFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTWUsUUFBUSxnQkFBR0MsNENBQUssQ0FBQ0MsSUFBTixTQUFXLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWM7QUFBQTs7QUFBQTs7QUFDeEMsTUFBSUMsYUFBSjtBQUNBLFFBQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7QUFDQSxRQUFNQyxJQUFJLEdBQUdDLCtEQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDRixJQUFsQixDQUF4QjtBQUVBLFFBQU1HLHFCQUFxQixHQUFHUCxJQUFILGFBQUdBLElBQUgsd0NBQUdBLElBQUksQ0FBRVEsT0FBVCxrREFBRyxjQUFlQyxHQUFmLENBQW9CQyxXQUFEO0FBQUE7O0FBQUEsd0JBQy9DO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDLFVBQWI7QUFBQSxrQkFBeUJBLFdBQXpCLGFBQXlCQSxXQUF6QiwrQ0FBeUJBLFdBQVcsQ0FBRUMsTUFBdEMseURBQXlCLHFCQUFxQkE7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQUVHRCxXQUZILGFBRUdBLFdBRkgsK0NBRUdBLFdBQVcsQ0FBRUMsTUFGaEIsa0ZBRUcscUJBQXFCQyxRQUZ4QiwwREFFRyxzQkFBK0JILEdBQS9CLENBQW9DSSxXQUFELGlCQUNsQyxxRUFBQyxtRkFBRDtBQUFlLGVBQU8sRUFBRUE7QUFBeEIsU0FBMENBLFdBQTFDLGFBQTBDQSxXQUExQyx1QkFBMENBLFdBQVcsQ0FBRUMsT0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERCxDQUZIO0FBQUEsT0FBVUosV0FBVixhQUFVQSxXQUFWLDhDQUFVQSxXQUFXLENBQUVDLE1BQXZCLHdEQUFVLG9CQUFxQkksU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEK0M7QUFBQSxHQUFuQixDQUE5QjtBQVFBLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQkMsc0RBQVEsQ0FBQyxJQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCRixzREFBUSxDQUFDLENBQUQsQ0FBNUM7QUFFQW5DLHlEQUFTLENBQUMsTUFBTTtBQUNkTSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUErQ1UsSUFBL0MsRUFEYyxDQUVmOztBQUNDLFFBQUlxQixTQUFTLEdBQUcsSUFBaEI7O0FBRUEsUUFBSUEsU0FBSixFQUFlO0FBQUE7O0FBQ2I7QUFDQSxZQUFNQyw4QkFBOEIsR0FBR3RCLElBQUgsYUFBR0EsSUFBSCx5Q0FBR0EsSUFBSSxDQUFFUSxPQUFULG1EQUFHLGVBQWVlLE1BQWYsQ0FDckMsQ0FBQ0MsZUFBRCxFQUFrQkMsZUFBbEIsS0FBc0M7QUFDcEMsZUFDRUMsTUFBTSxDQUFDRixlQUFELENBQU4sR0FFQ0UsTUFBTSxDQUFDRCxlQUFlLENBQUNkLE1BQWhCLENBQXVCQyxRQUF2QixDQUFnQ2UsTUFBakMsQ0FIVDtBQUtELE9BUG9DLEVBUXJDLENBUnFDLENBQXZDO0FBV0FQLG1CQUFhLENBQUNFLDhCQUFELENBQWI7QUFDQUwsaUJBQVcsQ0FBQ2pCLElBQUQsQ0FBWDtBQUNEOztBQUNELFdBQU8sTUFBTTtBQUNYcUIsZUFBUyxHQUFHLEtBQVo7QUFDRCxLQUZEO0FBR0QsR0F4QlEsRUF3Qk4sQ0FBQ3JCLElBQUQsYUFBQ0EsSUFBRCx1QkFBQ0EsSUFBSSxDQUFFUSxPQUFQLENBeEJNLENBQVQsQ0FoQndDLENBMEN4Qzs7QUFFRSxRQUFNb0IsV0FBVyxHQUFJQyxPQUFELElBQWE7QUFDakMsUUFBSUMsUUFBUSxHQUFHckMsWUFBWSxDQUFDc0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0osUUFBWCxDQUFoQjtBQUNBLFFBQUlLLFlBQVksR0FBR0gsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVHLFlBQTlCO0FBQ0EsVUFBTUMsVUFBVSxHQUFHRCxZQUFuQjtBQUNBOUMsV0FBTyxDQUFDQyxHQUFSLENBQVksd0NBQVosRUFBcUQ7QUFBQytDLHNGQUFVQTtBQUFYLEtBQXJEO0FBQ0FoRCxXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQzhDLFVBQXRDO0FBQ0EvQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQ2dELHFFQUF0QztBQUVBLFVBQU1DLElBQUksR0FBR0MsNENBQUssQ0FBQ0MsSUFBTixDQUNWLEdBQUVKLG9FQUFXLG9CQURILEVBRVg7QUFDRUYsa0JBQVksRUFBRUMsVUFEaEI7QUFFRU0sYUFBTyxFQUFDakQsWUFBWSxDQUFDc0MsT0FBYixDQUFxQixRQUFyQixDQUZWO0FBR0VZLGVBQVMsRUFBRUwscUVBSGI7QUFJRU0sY0FBUSxFQUFFLGlDQUpaO0FBS0VDLGFBQU8sRUFBRTtBQUxYLEtBRlcsRUFTVkMsSUFUVSxDQVNKQyxRQUFELElBQWNBLFFBQVEsQ0FBQ1IsSUFUbEIsRUFVVk8sSUFWVSxDQVVKUCxJQUFELElBQVU7QUFDZGxELGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaLEVBQW9EaUQsSUFBcEQsRUFEYyxDQUVsQjs7QUFDSSxVQUFJQSxJQUFJLENBQUNTLFFBQUwsSUFBaUIsR0FBakIsSUFBd0JULElBQUksQ0FBQ1UsTUFBTCxJQUFlLE9BQTNDLEVBQW9ELENBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7O0FBQ0QsVUFBSVYsSUFBSSxDQUFDUyxRQUFMLElBQWlCLEdBQWpCLElBQXdCVCxJQUFJLENBQUNVLE1BQUwsSUFBZSxTQUEzQyxFQUFzRDtBQUNwRGhDLG1CQUFXLENBQUNzQixJQUFJLENBQUNBLElBQU4sQ0FBWDtBQUNBbkIscUJBQWEsQ0FBQ21CLElBQUksQ0FBQ0EsSUFBTCxDQUFVVyxVQUFYLENBQWIsQ0FGb0QsQ0FHdkQ7QUFDQztBQUNFO0FBQ0E7QUFDQTtBQUNEOztBQUNDO0FBQ0Q7QUFDRixLQTlCVSxFQStCVkMsS0EvQlUsQ0ErQkhDLEtBQUQsSUFBVyxDQUNoQjtBQUNBO0FBQ0E7QUFDRCxLQW5DVSxDQUFiO0FBc0NDL0QsV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0NnRCxxRUFBdEMsRUEvQ2dDLENBZ0RsQztBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRCxHQXRFQzs7QUF1RUZ2RCx5REFBUyxDQUFDLE1BQU07QUFDZE0sV0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQlUsSUFBdEI7QUFDQTRCLGVBQVc7O0FBQ1gsUUFBSTVCLElBQUksSUFBSXFELFNBQVosRUFBdUI7QUFDdEI7QUFDQyxPQUFBakQsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUUrQixZQUFOLEtBQXNCakMsUUFBUSxDQUFDb0Qsa0VBQU8sRUFBUixDQUE5QjtBQUNEO0FBQ0YsR0FQUSxFQU9OLENBQUNsRCxJQUFJLENBQUMrQixZQUFOLEVBQW9CbkMsSUFBcEIsYUFBb0JBLElBQXBCLHVCQUFvQkEsSUFBSSxDQUFFUSxPQUExQixDQVBNLENBQVQ7O0FBU0EsTUFDRVEsUUFBUSxLQUFLLElBQWIsSUFDQUEsUUFBUSxLQUFLcUMsU0FEYixJQUVBckMsUUFGQSxhQUVBQSxRQUZBLG9DQUVBQSxRQUFRLENBQUVSLE9BRlYsOENBRUEsa0JBQW1CbUIsTUFGbkIsSUFHQSxDQUFBWCxRQUFRLFNBQVIsSUFBQUEsUUFBUSxXQUFSLGtDQUFBQSxRQUFRLENBQUVSLE9BQVYsMEVBQW1CbUIsTUFBbkIsTUFBOEIsQ0FKaEMsRUFLRTtBQUFBOztBQUNBMUIsaUJBQWEsZ0JBQ1g7QUFBSyxlQUFTLEVBQUMsa0JBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSxrQkFBaUNNO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLGlCQUFTLEVBQUMsaUJBQWY7QUFBQSxnQ0FDRTtBQUFBLGdEQUVFO0FBQUEsc0JBQ0dTLFFBQVEsSUFBSUEsUUFBUSxLQUFLLElBQXpCLElBQWlDLENBQUFBLFFBQVEsU0FBUixJQUFBQSxRQUFRLFdBQVIsa0NBQUFBLFFBQVEsQ0FBRVIsT0FBViwwRUFBbUJtQixNQUFuQixJQUE0QixDQUE3RCxHQUNHNEIsZ0dBQThCLENBQUN2QyxRQUFRLENBQUN3QyxXQUFWLENBRGpDLEdBRUc7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVNFO0FBQUEsa0NBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxnQkFBSSxFQUFDLHdCQUFYO0FBQUEsbUNBQ0U7QUFBRyx1QkFBUyxFQUFDLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUUscUVBQUMsZ0RBQUQ7QUFBTSxnQkFBSSxFQUFDLG1CQUFYO0FBQUEsbUNBQ0U7QUFBRyx1QkFBUyxFQUFDLFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBdUJELEdBN0JELE1BNkJPO0FBQ0x2RCxpQkFBYSxnQkFDWDtBQUFLLGVBQVMsRUFBQyxrQkFBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLCtCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFPRDs7QUFFRCxzQkFDRTtBQUFLLGFBQVMsRUFBQyxlQUFmO0FBQUEsNEJBQ0U7QUFBRyxlQUFTLEVBQUMsZUFBYjtBQUE2QixVQUFJLEVBQUMsR0FBbEM7QUFBQSw4QkFDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQSwrQkFDRTtBQUFBLG9CQUNHZSxRQUFRLEtBQUssSUFBYixJQUFxQkEsUUFBUSxLQUFLcUMsU0FBbEMsSUFBK0NsQyxVQUFVLEdBQUcsQ0FBNUQsR0FDR0EsVUFESCxHQUVHO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLEVBV0dsQixhQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FsTGdCO0FBQUEsVUFFRUUsdURBRkYsRUFHRkUsdURBSEU7QUFBQSxHQUFqQjtNQUFNUixRO0FBb0xTNEQsMEhBQU8sQ0FBRW5ELEtBQUQsSUFBV0EsS0FBSyxDQUFDTixJQUFsQixDQUFQLENBQStCSCxRQUEvQixDQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2FjY291bnQvbG9naW4uMjBjZGZhMTVmYWEyNTlhMThmM2UuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBMb2dvIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvY29tbW9uL0xvZ29cIjtcclxuaW1wb3J0IFNlYXJjaEhlYWRlciBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL21vZHVsZXMvU2VhcmNoSGVhZGVyXCI7XHJcbmltcG9ydCBOYXZpZ2F0aW9uRGVmYXVsdCBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9uYXZpZ2F0aW9uL05hdmlnYXRpb25EZWZhdWx0XCI7XHJcbmltcG9ydCBIZWFkZXJBY3Rpb25zIGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9IZWFkZXJBY3Rpb25zXCI7XHJcbmltcG9ydCB7IHN0aWNreUhlYWRlciB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgTWVudUNhdGVnb3JpZXNEcm9wZG93biBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9tZW51cy9NZW51Q2F0ZWdvcmllc0Ryb3Bkb3duXCI7XHJcbi8vIGltcG9ydCBEcm9wZG93biBmcm9tICdyZWFjdC1ib290c3RyYXAvRHJvcGRvd24nO1xyXG5cclxuY29uc3QgSGVhZGVyRGVmYXVsdCA9ICgpID0+IHtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHByb2Nlc3MuYnJvd3Nlcikge1xyXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBzdGlja3lIZWFkZXIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuICBjb25zdCBhYWEgPSAoZSkgPT4ge1xyXG5cclxuIC8vIGFsZXJ0KFwiZFwiKVxyXG5jb25zb2xlLmxvZyhcImdoZmhmaFwiLGUudGFyZ2V0LnZhbHVlKVxyXG5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhbmdJZFwiLGUudGFyZ2V0LnZhbHVlKTtcclxud2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG59O1xyXG4gIHJldHVybiAoXHJcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImhlYWRlciBoZWFkZXItLTFcIiBkYXRhLXN0aWNreT1cInRydWVcIiBpZD1cImhlYWRlclN0aWNreVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWQtdG9wXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtZW5kXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwidG9wLXVybFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3Qgb25DaGFuZ2U9eyhlKSA9PiBhYWEoZSl9IG5tZT1cImNhcnNcIiBpZD1cImNhcnNcIiA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gICB2YWx1ZT1cIjFcIiA+TGFuZzwvb3B0aW9uPlxyXG4gICAgPG9wdGlvbiAgIHZhbHVlPVwiMVwiID5FbmdsaXNoPC9vcHRpb24+XHJcbiAgICA8b3B0aW9uIHZhbHVlPVwiMlwiID7Yp9mE2LnYsdio2YrYqTwvb3B0aW9uPlxyXG4gIDwvc2VsZWN0PlxyXG4gIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cInRvcC1saVwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPGE+IEVuZyA8L2E+ICovfVxyXG4gICAgICAgICAgICAgICAgIHsvKiA8c3BhbiBvbkNsaWNrPXsoZSkgPT4gYWFhKGUpfT5mZmZmZmY8L3NwYW4+ICovfVxyXG4gICAgICAgICAgICAgICAgICB7LyogPERyb3Bkb3duPlxyXG4gICAgICA8RHJvcGRvd24uVG9nZ2xlIHZhcmlhbnQ9XCJzdWNjZXNzXCIgaWQ9XCJkcm9wZG93bi1iYXNpY1wiID5cclxuICAgICAgU2VsZWN0IExhbmd1YWdlXHJcbiAgICAgIDwvRHJvcGRvd24uVG9nZ2xlPlxyXG5cclxuICAgICAgPERyb3Bkb3duLk1lbnU+XHJcbiAgICAgICAgPERyb3Bkb3duLkl0ZW0gZXZlbnRLZXk9XCIxXCIgb25TZWxlY3Q9e2FhYX0+RW5nbGlzaDwvRHJvcGRvd24uSXRlbT5cclxuICAgICAgICA8RHJvcGRvd24uSXRlbSBldmVudEtleT1cIjJcIiBvblNlbGVjdD17YWFhfT7Yp9mE2LnYsdio2YrYqTwvRHJvcGRvd24uSXRlbT5cclxuICAgICAgPC9Ecm9wZG93bi5NZW51PlxyXG4gICAgPC9Ecm9wZG93bj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvbG9naW5cIj5cclxuICAgICAgICAgICAgPGE+IFNpZ24gSW48L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICB7LyogPExpbmsgaHJlZj1cIi9hY2NvdW50L2xvZ2luXCI+XHJcbiAgICAgICAgICAgIDxhPlJlZ2lzdGVyPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPiAqL31cclxuICAgICAgICAgICAgICAgICAgey8qIDxhIGhyZWY9XCJcIj4gU2lnbiBJbiA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJcIj4gUmVnaXN0ZXIgPC9hPiAqL31cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX190b3BcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX2xlZnRcIj5cclxuICAgICAgICAgICAgPExvZ28gLz5cclxuICAgICAgICAgICAgey8qIDxNZW51Q2F0ZWdvcmllc0Ryb3Bkb3duIC8+ICovfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fY2F0ZWdcIj5cclxuICAgICAgICAgICAgPE1lbnVDYXRlZ29yaWVzRHJvcGRvd24gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWNlbnRlciBhbGlnbi1pdGVtcy1jZW50ZXIgb2ZyXCI+XHJcbiAgICAgICAgICAgIDxhIGhyZWY9XCJcIj5PZmZlciBab25lPC9hPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxTZWFyY2hIZWFkZXIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX3JpZ2h0XCI+XHJcbiAgICAgICAgICAgIDxIZWFkZXJBY3Rpb25zIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiA8TmF2aWdhdGlvbkRlZmF1bHQgLz4gKi99XHJcbiAgICA8L2hlYWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyRGVmYXVsdDtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBjb25uZWN0LCB1c2VEaXNwYXRjaCwgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IGdldENhcnQsIHJlbW92ZUl0ZW0gfSBmcm9tIFwifi9zdG9yZS9jYXJ0L2FjdGlvblwiO1xyXG5pbXBvcnQgUHJvZHVjdE9uQ2FydCBmcm9tIFwifi9jb21wb25lbnRzL2VsZW1lbnRzL3Byb2R1Y3RzL1Byb2R1Y3RPbkNhcnRcIjtcclxuaW1wb3J0IFByb2R1Y3RSZXBvc2l0b3J5IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9Qcm9kdWN0UmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyBjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQgfSBmcm9tIFwifi91dGlsaXRpZXMvcHJvZHVjdC1oZWxwZXJcIjtcclxuaW1wb3J0IHsgZ2V0RGV2aWNlSWQgfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHsgYmFzZVVybCwgc2VyaWFsaXplUXVlcnksIGFwaWJhc2V1cmwgfSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5jb25zdCBNaW5pQ2FydCA9IFJlYWN0Lm1lbW8oKHsgY2FydCB9KSA9PiB7XHJcbiAgbGV0IGNhcnRJdGVtc1ZpZXc7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG4gIGNvbnN0IGF1dGggPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLmF1dGgpO1xyXG5cclxuICBjb25zdCBwcm9kdWN0SXRlbVdpdGhTZWxsZXIgPSBjYXJ0Py5wcm9kdWN0Py5tYXAoKHByb2R1Y3RJdGVtKSA9PiAoXHJcbiAgICA8ZGl2IGtleT17cHJvZHVjdEl0ZW0/LnNlbGxlcj8uc2VsbGVyX2lkfT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwic3Rvci10aXRcIj57cHJvZHVjdEl0ZW0/LnNlbGxlcj8uc2VsbGVyfTwvcD5cclxuICAgICAge3Byb2R1Y3RJdGVtPy5zZWxsZXI/LnByb2R1Y3RzPy5tYXAoKGNhcnRQcm9kdWN0KSA9PiAoXHJcbiAgICAgICAgPFByb2R1Y3RPbkNhcnQgcHJvZHVjdD17Y2FydFByb2R1Y3R9IGtleT17Y2FydFByb2R1Y3Q/LmNhcnRfaWR9IC8+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKSk7XHJcbiAgY29uc3QgW2NhcnRkYXRhLCBzZXRDYXJ0ZGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdG90YWxJdGVtcywgc2V0VG90YWxJdGVtc10gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLnByb2R1Y3RJdGVtTmV4dC4uLi4uLmNhcnQuLi4uLlwiLCBjYXJ0KVxyXG4gICAvLyBjb25zb2xlLmxvZyhcIi5wcm9kdWN0SXRlbU5leHQuLi4uLi4uLi4uLlwiLCBwcm9kdWN0SXRlbU5leHQpXHJcbiAgICBsZXQgaXNNb3VudGVkID0gdHJ1ZTtcclxuXHJcbiAgICBpZiAoaXNNb3VudGVkKSB7XHJcbiAgICAgIC8vYWxlcnQoXCJiaGJoaGJoaGhcIilcclxuICAgICAgY29uc3QgY2FydFRvdGFsUHJvZHVjdHNGcm9tQWxsU2VsbGVyID0gY2FydD8ucHJvZHVjdD8ucmVkdWNlKFxyXG4gICAgICAgIChwcm9kdWN0SXRlbVByZXYsIHByb2R1Y3RJdGVtTmV4dCkgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgTnVtYmVyKHByb2R1Y3RJdGVtUHJldikgXHJcbiAgICAgICAgICAgICArXHJcbiAgICAgICAgICAgICBOdW1iZXIocHJvZHVjdEl0ZW1OZXh0LnNlbGxlci5wcm9kdWN0cy5sZW5ndGgpXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0VG90YWxJdGVtcyhjYXJ0VG90YWxQcm9kdWN0c0Zyb21BbGxTZWxsZXIpO1xyXG4gICAgICBzZXRDYXJ0ZGF0YShjYXJ0KTtcclxuICAgIH1cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGlzTW91bnRlZCA9IGZhbHNlO1xyXG4gICAgfTtcclxuICB9LCBbY2FydD8ucHJvZHVjdF0pO1xyXG4gIFxyXG4gIC8vIGFzeW5jIGdldENhcnRJdGVtKHBheWxvYWQpIHtcclxuXHJcbiAgICBjb25zdCBnZXRDYXJ0SXRlbSA9IChwYXlsb2FkKSA9PiB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gJHthcGliYXNldXJsfS4uLlwiLHthcGliYXNldXJsfSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmFhYWFhYWFhYWFhYWFhYWEuLi5cIix1c2VyX3Rva2VuKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmJiYmJiYmJiYmJiYi4uLlwiLGdldERldmljZUlkKVxyXG5cclxuICAgIGNvbnN0IGRhdGEgPSBBeGlvcy5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsXHJcbiAgICAgIHtcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAgICAgbGFuZ19pZDpsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhbmdJZFwiKSxcclxuICAgICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgICAgICBvc190eXBlOiBcIldFQlwiLFxyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi5paWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWkuXCIsZGF0YSlcclxuICAgIC8vICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uIHJlc3BvbnNlLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gNDAwICYmIGRhdGEuc3RhdHVzID09IFwiZXJyb3JcIikge1xyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAvLyB9KTtcclxuICAgICAgICAgIC8vIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gMjAwICYmIGRhdGEuc3RhdHVzID09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICAgICBzZXRDYXJ0ZGF0YShkYXRhLmRhdGEpXHJcbiAgICAgICAgICBzZXRUb3RhbEl0ZW1zKGRhdGEuZGF0YS5jYXJ0X2NvdW50KVxyXG4gICAgICAgLy8gICBhbGVydChcInllc1wiKVxyXG4gICAgICAgIC8vICBzZXRPZmZlckRhdGEoZGF0YS5kYXRhKVxyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wic3VjY2Vzc1wiXSh7XHJcbiAgICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAvLyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgIC8vICAgbWVzc2FnZTogZXJyb3IsXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuY2NjY2MuLlwiLGdldERldmljZUlkKVxyXG4gICAvLyBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi4uLlwiLHBheWxvYWQpXHJcbiAgICAvLyBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAvLyBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAvLyBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAvLyBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIC8vIGNvbnN0IHJlc3BvbnNlID0gIFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsIHtcclxuICAgIC8vICAgYWNjZXNzX3Rva2VuOiB1c2VyX3Rva2VuLFxyXG4gICAgLy8gICBsYW5nX2lkOiAxLFxyXG4gICAgLy8gICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgLy8gICBwYWdlX3VybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvcHJvZHVjdC8yXCIsXHJcbiAgICAvLyAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICAvLyB9KVxyXG4gICAgLy8gY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuLjQ0NDQ0NDQ0NDQ0NC5cIixyZXNwb25zZSlcclxuICAgIC8vICAgLy8gLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAvLyAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgLy8gICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAvLyAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgLy8gICAvLyB9KVxyXG4gICAgLy8gICAvLyAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIC8vIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi41NTcuLlwiLGNhcnQpXHJcbiAgICBnZXRDYXJ0SXRlbSgpXHJcbiAgICBpZiAoY2FydCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAvLyBhbGVydChcImRkZmZmZFwiKVxyXG4gICAgICBhdXRoPy5hY2Nlc3NfdG9rZW4gJiYgZGlzcGF0Y2goZ2V0Q2FydCgpKTtcclxuICAgIH1cclxuICB9LCBbYXV0aC5hY2Nlc3NfdG9rZW4sIGNhcnQ/LnByb2R1Y3RdKTtcclxuXHJcbiAgaWYgKFxyXG4gICAgY2FydGRhdGEgIT09IG51bGwgJiZcclxuICAgIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggIT09IDBcclxuICApIHtcclxuICAgIGNhcnRJdGVtc1ZpZXcgPSAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9faXRlbXNcIj57cHJvZHVjdEl0ZW1XaXRoU2VsbGVyfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fZm9vdGVyXCI+XHJcbiAgICAgICAgICA8aDM+XHJcbiAgICAgICAgICAgIFN1YiBUb3RhbDpcclxuICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICB7Y2FydGRhdGEgJiYgY2FydGRhdGEgIT09IG51bGwgJiYgY2FydGRhdGE/LnByb2R1Y3Q/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgID8gY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0KGNhcnRkYXRhLmdyYW5kX3RvdGFsKVxyXG4gICAgICAgICAgICAgICAgOiAwfVxyXG4gICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvc2hvcHBpbmctY2FydFwiPlxyXG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLWJ0blwiPlZpZXcgQ2FydDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvY2hlY2tvdXRcIj5cclxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJwcy1idG5cIj5DaGVja291dDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2FydEl0ZW1zVmlldyA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19pdGVtc1wiPlxyXG4gICAgICAgICAgPHNwYW4+Tm8gcHJvZHVjdHMgaW4gY2FydDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydC0tbWluaVwiPlxyXG4gICAgICA8YSBjbGFzc05hbWU9XCJoZWFkZXJfX2V4dHJhXCIgaHJlZj1cIiNcIj5cclxuICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWJhZzJcIj48L2k+XHJcbiAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICA8aT5cclxuICAgICAgICAgICAge2NhcnRkYXRhICE9PSBudWxsICYmIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiYgdG90YWxJdGVtcyA+IDBcclxuICAgICAgICAgICAgICA/IHRvdGFsSXRlbXNcclxuICAgICAgICAgICAgICA6IDB9XHJcbiAgICAgICAgICA8L2k+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2E+XHJcbiAgICAgIHtjYXJ0SXRlbXNWaWV3fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KChzdGF0ZSkgPT4gc3RhdGUuY2FydCkoTWluaUNhcnQpO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9