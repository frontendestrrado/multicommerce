webpackHotUpdate_N_E("pages/account/login",{

/***/ "./components/elements/products/ProductOnCart.jsx":
/*!********************************************************!*\
  !*** ./components/elements/products/ProductOnCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");



var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductOnCart.jsx",
    _s = $RefreshSig$();







const ProductOnCart = ({
  product
}) => {
  _s();

  var _product$image$;

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"])();

  const handleRemoveCartItem = async product => {
    // e.preventDefault();
    let userdata = localStorage.getItem("user");

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_5__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      let parsedata = JSON.parse(userdata);
      let token = parsedata.access_token;
      let payload = {
        cart_id: [product.cart_id],
        access_token: token
      };
      antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].confirm({
        title: "Delete this product?",
        onOk: function (e) {
          dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_3__["removeProductFromCartNew"])(payload));
          antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].destroyAll();
        },
        onCancel: function (e) {
          antd__WEBPACK_IMPORTED_MODULE_5__["Modal"].destroyAll();
        },
        okButtonProps: {
          danger: true
        }
      });
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product--cart-mobile",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__thumbnail",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: (product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image) || "/static/img/not-found.jpg",
        onError: e => {
          e.target.onerror = null;
          e.target.src = "/static/img/not-found.jpg";
        },
        alt: "product",
        title: "product"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        className: "ps-product__remove",
        onClick: e => handleRemoveCartItem(product),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          className: "icon-cross"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.product_id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-product__title",
          children: [product.product_name, product.attr_name1 ? ` (${product.attr_name1}${product.attr_name2 ? ` ${product.attr_name2}` : ""})` : ""]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
          children: ["RM", " ", product.unit_discount_price !== false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
              children: product.unit_actual_price
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 17
            }, undefined), " ", product.unit_discount_price]
          }, void 0, true) : product.unit_actual_price, " ", "x ", product.quantity]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 5
  }, undefined);
};

_s(ProductOnCart, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"]];
});

_c = ProductOnCart;
/* harmony default export */ __webpack_exports__["default"] = (ProductOnCart);

var _c;

$RefreshReg$(_c, "ProductOnCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/products/ProductSearchResult.jsx":
/*!**************************************************************!*\
  !*** ./components/elements/products/ProductSearchResult.jsx ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/elements/Rating */ "./components/elements/Rating.jsx");

var _jsxFileName = "E:\\bigBasket\\components\\elements\\products\\ProductSearchResult.jsx";






const ProductSearchResult = ({
  product
}) => {
  var _product$image$, _product$image$2;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product ps-product--wide ps-product--search-result",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__thumbnail",
      children: product !== null && product !== void 0 && (_product$image$ = product.image[0]) !== null && _product$image$ !== void 0 && _product$image$.image ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
              alt: product.title
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/static/img/not-found.jpg",
              alt: "Kangtao"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
        href: "/product/[pid]",
        as: `/product/${product.id}`,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-product__title",
          children: product.product_name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__rating",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_5__["default"], {
          rating: product.rating
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), product.sale_price > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price sale",
        children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
          className: "ml-2",
          children: ["RM ", product.actual_price]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 11
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "ps-product__price sale",
        children: ["RM ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, undefined);
};

_c = ProductSearchResult;
/* harmony default export */ __webpack_exports__["default"] = (ProductSearchResult);

var _c;

$RefreshReg$(_c, "ProductSearchResult");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/partials/account/Login/index.jsx":
/*!*****************************************************!*\
  !*** ./components/partials/account/Login/index.jsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/repositories/AccountRepository */ "./repositories/AccountRepository.js");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/index.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var public_static_img_custom_images_log_bg_jpg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! public/static/img/custom_images/log-bg.jpg */ "./public/static/img/custom_images/log-bg.jpg");
/* harmony import */ var public_static_img_custom_images_log_bg_jpg__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(public_static_img_custom_images_log_bg_jpg__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var public_static_img_custom_images_logo_light_png__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! public/static/img/custom_images/logo_light.png */ "./public/static/img/custom_images/logo_light.png");
/* harmony import */ var public_static_img_custom_images_logo_light_png__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(public_static_img_custom_images_logo_light_png__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _store_auth_action__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/store/auth/action */ "./store/auth/action.js");
/* harmony import */ var _LoginWithSMS__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./LoginWithSMS */ "./components/partials/account/Login/LoginWithSMS.jsx");
/* harmony import */ var _LoginWithEmail__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./LoginWithEmail */ "./components/partials/account/Login/LoginWithEmail.jsx");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");




var _jsxFileName = "E:\\bigBasket\\components\\partials\\account\\Login\\index.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }







 // import $ from 'jquery'; 











const Login = props => {
  _s();

  const [form] = antd__WEBPACK_IMPORTED_MODULE_6__["Form"].useForm();
  const initStateOtpButton = {
    class: "primary",
    text: "Send OTP",
    verifyBox: false,
    verifiedNumber: "",
    registerBoxShow: false
  };
  const {
    0: loadingOTP,
    1: setLoadingOTP
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: otpButton,
    1: setOtpButton
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initStateOtpButton);
  const {
    0: user,
    1: setUser
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    input: "",
    password: ""
  });

  const antIcon = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_17__["LoadingOutlined"], {
    style: {
      fontSize: 24
    },
    spin: true
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 34,
    columnNumber: 19
  }, undefined);

  const {
    0: serverCountry,
    1: setCountry
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const {
    first_name,
    last_name,
    email,
    phone_number,
    password,
    password_confirmation,
    country_code
  } = user;
  const {
    0: rememberMe,
    1: setRemember
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: userOtp,
    1: setUserOtp
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])("");
  const {
    0: getCustomerId,
    1: setCustomerId
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])("");
  const {
    0: showLoginWithSMS,
    1: setShowLoginWithSMS
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(true);
  const {
    input
  } = user;

  const handleSubmit1 = async () => {
    // alert("2")
    let payload = {
      customer_id: getCustomerId,
      password: user.password,
      password_confirmation: user.password_confirmation
    };

    try {
      const values = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].changePassword(payload);
      console.log("....register submit.. user....", user);
      console.log("....register submit...finale...", values);

      if (values.httpcode == 200 && values.success) {
        antd__WEBPACK_IMPORTED_MODULE_6__["message"].success("Your Password Changed Successfully!"); //Router.push("/account/login");
      }

      if (values.error) {
        values.error.map(error => {
          antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["error"]({
            message: error
          });
        });
      }
    } catch (errorInfo) {
      console.log("Failed:", errorInfo);
    }
  };

  const handleSubmit = async () => {
    let payload = {
      first_name: user.first_name,
      last_name: user.last_name,
      country_code: user.country_code,
      phone_number: user.phone_number,
      email: user.email,
      password: user.password,
      password_confirmation: user.password_confirmation
    };

    try {
      const values = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].registerNewUser(user);
      console.log("....register submit.. user....", user);
      console.log("....register submit......", values);

      if (values.httpcode == 200 && values.success) {
        antd__WEBPACK_IMPORTED_MODULE_6__["message"].success("You are registered successfully!"); //Router.push("/account/login");
      }

      if (values.error) {
        values.error.map(error => {
          antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["error"]({
            message: error
          });
        });
      }
    } catch (errorInfo) {
      console.log("Failed:", errorInfo);
    }
  };

  const handleFeatureWillUpdate = e => {
    e.preventDefault();
    antd__WEBPACK_IMPORTED_MODULE_6__["notification"].open({
      message: "Opp! Something went wrong.",
      description: "This feature has been updated later!",
      duration: 500
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    fetchCountry();
  }, []);

  async function fetchCountry() {
    const countryDataFromServer = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].getCountry();
    setCountry([...countryDataFromServer.country]);
    return null;
  }

  const handleChange = name => event => {
    setUser(_objectSpread(_objectSpread({}, user), {}, {
      [name]: event.target.value
    }));
  };

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_7__["useDispatch"])();

  function verifyOtp(otpFromServer, inputFromServer) {
    let userOtpInput = "";
    antd__WEBPACK_IMPORTED_MODULE_6__["Modal"].info({
      title: "Please Enter OTP sent on Your phone & email.",
      content: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"], {
        form: form,
        onFinish: handleLoginSubmit,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "form-group",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
            name: "userOtp",
            rules: [{
              required: true,
              message: "Please input your OTP!"
            }],
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
              className: "form-control",
              type: "text",
              placeholder: "Input your OTP!",
              onChange: e => {
                userOtpInput = e.target.value;
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 147,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 138,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 137,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 136,
        columnNumber: 9
      }, this),

      onOk() {
        let deviceToken = Object(uuid__WEBPACK_IMPORTED_MODULE_10__["v4"])();
        let deviceId = Object(uuid__WEBPACK_IMPORTED_MODULE_10__["v4"])();
        let deviceName = "Chrome";
        let os = "WEB";
        let input = inputFromServer; // let otp = userOtpInput; change to this for production

        let otp = `${otpFromServer}`;
        const data = axios__WEBPACK_IMPORTED_MODULE_8___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_5__["apibaseurl"]}/api/customer/verify/otp`, {
          input,
          otp,
          deviceToken,
          deviceId,
          deviceName,
          os
        }, {
          headers: {
            "Content-Type": "application/json"
          }
        }).then(response => response.data).then(data => {
          if (data.httpcode == 400 && data.status == "error") {
            const args = {
              message: data.message,
              type: "error"
            };
            antd__WEBPACK_IMPORTED_MODULE_6__["notification"].open(args);
            return;
          }

          if (data.httpcode == 200 && data.status == "success") {
            antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["success"]({
              message: data.message
            });
            localStorage.setItem("user", JSON.stringify(data.data));
            dispatch(login(data.data));
            next_router__WEBPACK_IMPORTED_MODULE_4___default.a.push("/");
            return;
          }
        }).catch(error => {
          antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["error"]({
            message: error
          });
          setUserOtp("");
        });
      },

      okCancel() {
        antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["error"]({
          message: "Login Failed"
        });
      },

      closable: false,
      keyboard: false
    });
  }

  const login = () => {
    document.getElementById('loginId').style.display = 'block';
    document.getElementById('registerId').style.display = 'none';
    document.getElementById('registerId1').style.display = 'none';
  };

  const reg = () => {
    document.getElementById('registerId').style.display = 'block';
    document.getElementById('loginId').style.display = 'none';
    document.getElementById('registerId1').style.display = 'none';
  };

  const forgot = () => {
    document.getElementById('registerId1').style.display = 'block';
    document.getElementById('loginId').style.display = 'none';
    document.getElementById('registerId').style.display = 'none';
  };

  const handleVerifyOTP1 = async () => {
    setLoadingOTP(true);
    console.log("...user.country_code....", user.country_code);
    let payload = {
      country_code: user.country_code.split("+")[1],
      phone_number: user.phone_number,
      otp: user.otp_text
    };
    const response = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].verifyForgotOTP(payload);
    setCustomerId(response.customer_id);
    console.log("...verifyForgotOTP....", response);

    if (response.httpcode == 200) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setOtpButton({
        class: "success",
        text: "Verified",
        verifyBox: false,
        verifiedNumber: user.phone_number,
        registerBoxShow: true
      });
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    } else {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    }
  };

  const handleVerifyOTP = async () => {
    setLoadingOTP(true);
    let payload = {
      country_code: user.country_code,
      phone_number: user.phone_number,
      otp: user.otp_text
    };
    const response = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].verifyRegisterMobileOTP(payload);
    console.log("....veryfy otp.....", response);

    if (response.httpcode == 200) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setOtpButton({
        class: "success",
        text: "Verified",
        verifyBox: false,
        verifiedNumber: user.phone_number,
        registerBoxShow: true
      });
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    } else {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    }
  };

  const handleOTP = async () => {
    setLoadingOTP(true);
    let payload = {
      country_code: user.country_code,
      phone_number: user.phone_number
    };
    const response = await _repositories_AccountRepository__WEBPACK_IMPORTED_MODULE_9__["default"].sendRegisterMobileOTP(payload);

    if (response.httpcode == 200) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setOtpButton({
        class: "success",
        text: "OTP Sent",
        verifyBox: true
      });
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    } else {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_11__["displayNotification"])(response.status, response.status, response.message);
      setTimeout(() => {
        setLoadingOTP(false);
      }, 500);
    }
  };

  const handleSelectCountryCode = name => data => {
    setUser(_objectSpread(_objectSpread({}, user), {}, {
      [name]: data
    }));

    if (name == "country_code" && data !== user.country_code) {
      setOtpButton(initStateOtpButton);
    }
  };

  const handleLoginSubmit = async () => {
    try {
      const data = await axios__WEBPACK_IMPORTED_MODULE_8___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_5__["apibaseurl"]}/api/customer/login`, user, {
        headers: {
          "Content-Type": "application/json"
        }
      }).then(response => response.data);

      if (data.httpcode === 400 && data.status === "error") {
        antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["error"]({
          message: data.data.errors.error_msg
        });
        return;
      }

      if (data.httpcode === 200 && data.status === "success") {
        antd__WEBPACK_IMPORTED_MODULE_6__["notification"]["success"]({
          message: data.message
        }); // console.log(data.data);

        verifyOtp(data.data.otp, data.data.input);
      }
    } catch (errorInfo) {
      console.log("Failed:", errorInfo);
    }

    return false;
  }; // $('#myModal').on('shown.bs.modal', function () {
  //   $('#myInput').trigger('focus')
  // })
  // const handleLoginSubmit = async () => {
  // }


  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "log",
    style: {
      backgroundImage: `url(${public_static_img_custom_images_log_bg_jpg__WEBPACK_IMPORTED_MODULE_12___default.a})`,
      backgroundSize: "cover",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "left",
      height: "calc(100vh - 50px)"
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("nav", {
      className: "menyu",
      style: {
        backgroundColor: "#006fb4"
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "menyu_inner",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: "ps-logo",
            href: "/",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: public_static_img_custom_images_logo_light_png__WEBPACK_IMPORTED_MODULE_13___default.a,
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 392,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 391,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 390,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 389,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 383,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "log1 log2",
        style: {
          // backgroundImage: `url(${background})`,
          backgroundSize: "contain",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "left center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "logcard logcard1 logcard2",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "card",
            style: {
              border: "unset"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "card-body",
              style: {
                display: 'none'
              },
              id: "loginId",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "logcard_header_inner",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "logcard_header_title",
                  children: "Log In"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 422,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 421,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "card-body loginp",
                children: [showLoginWithSMS ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_LoginWithSMS__WEBPACK_IMPORTED_MODULE_15__["default"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 425,
                  columnNumber: 39
                }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_LoginWithEmail__WEBPACK_IMPORTED_MODULE_16__["default"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 425,
                  columnNumber: 58
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "forgt",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "frgt_link",
                    href: "#",
                    onClick: () => forgot(),
                    children: "Forgot Password"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 427,
                    columnNumber: 22
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    className: "frgt_link",
                    href: "#",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      style: {
                        cursor: "pointer"
                      },
                      onClick: () => setShowLoginWithSMS(!showLoginWithSMS),
                      children: showLoginWithSMS ? "Log in with Email" : "Log in with SMS"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 434,
                      columnNumber: 23
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 433,
                    columnNumber: 21
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 426,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "card-footer",
                  style: {
                    backgroundColor: `#ffffff`,
                    borderTop: `1px solid #ffffff`
                  },
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "fotr_txt",
                    children: ["Don't have an account?", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      onClick: () => reg(),
                      className: "ftr_link",
                      children: " Sign Up "
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 454,
                      columnNumber: 25
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 451,
                    columnNumber: 21
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 444,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 424,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 420,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"], {
              form: form,
              className: "ps-form--account",
              onFinish: otpButton.registerBoxShow ? handleSubmit : undefined,
              style: {
                paddingTop: "10px",
                display: 'block'
              },
              id: "registerId",
              size: "large",
              layout: "vertical",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "logcard_header_inner",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "logcard_header_title",
                  children: " Register "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 483,
                  columnNumber: 15
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 482,
                columnNumber: 11
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "ps-tab active",
                id: "register",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "ps-form__content",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "businessname",
                    rules: [{
                      required: true,
                      message: "Please input your businessname!"
                    }, {
                      pattern: new RegExp(/^[a-zA-Z]+$/i),
                      message: "Only Alphabets Accepted"
                    }, {
                      max: 50,
                      message: "Max 50 Charachters allowed."
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                      value: first_name,
                      type: "text",
                      placeholder: "Enter Business Name",
                      onChange: handleChange("first_name")
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 504,
                      columnNumber: 17
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 487,
                    columnNumber: 15
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "firstname",
                    rules: [{
                      required: true,
                      message: "Please input your firstname!"
                    }, {
                      pattern: new RegExp(/^[a-zA-Z]+$/i),
                      message: "Only Alphabets Accepted"
                    }, {
                      max: 50,
                      message: "Max 50 Charachters allowed."
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                      value: last_name,
                      type: "text",
                      placeholder: "Enter Name",
                      onChange: handleChange("last_name")
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 528,
                      columnNumber: 17
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 511,
                    columnNumber: 15
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "email",
                    rules: [{
                      required: true,
                      message: "Please input your email!"
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                      type: "email",
                      placeholder: "Email Address",
                      onChange: handleChange("email"),
                      value: email
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 568,
                      columnNumber: 17
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 559,
                    columnNumber: 15
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "phone_number",
                    rules: [{
                      required: false
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"].Group, {
                      compact: true,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                        name: ["phone_number", "countrycode"],
                        noStyle: true,
                        rules: [{
                          required: true,
                          message: "countrycode is required"
                        }],
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Select"], {
                          showSearch: true,
                          style: {
                            width: "25%"
                          },
                          placeholder: "Country Code",
                          optionFilterProp: "children",
                          onChange: handleSelectCountryCode("country_code"),
                          filterOption: (input, option) => option.children.toString().toLowerCase().indexOf(input.toString().toLowerCase()) >= 0,
                          children: serverCountry === null || serverCountry === void 0 ? void 0 : serverCountry.map((countryDetails, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Option, {
                            value: `+${countryDetails.phonecode}`,
                            children: ["+", countryDetails.phonecode]
                          }, index, true, {
                            fileName: _jsxFileName,
                            lineNumber: 606,
                            columnNumber: 25
                          }, undefined))
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 592,
                          columnNumber: 21
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 585,
                        columnNumber: 19
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                        name: ["phone_number", "phonenumber"],
                        noStyle: true,
                        rules: [{
                          required: true,
                          message: "phone number is required"
                        }, {
                          min: 7,
                          message: "Phone number should be 7-12 digit long!"
                        }, {
                          max: 12,
                          message: "Phone number should be 7-12 digit long!"
                        }, {
                          pattern: new RegExp(/^[0-9]+$/i),
                          message: "Only Numbers Accepted"
                        }],
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                          type: "text",
                          placeholder: "Enter Phone Number",
                          onChange: handleChange("phone_number"),
                          value: phone_number,
                          style: {
                            width: "75%",
                            height: "50px",
                            padding: "2px"
                          },
                          suffix: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Spin"], {
                            indicator: antIcon,
                            spinning: loadingOTP,
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                              style: {
                                cursor: "pointer"
                              },
                              className: `text-${otpButton.class}`,
                              onClick: handleOTP,
                              children: otpButton.text
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 642,
                              columnNumber: 27
                            }, undefined)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 641,
                            columnNumber: 25
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 634,
                          columnNumber: 21
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 615,
                        columnNumber: 19
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 584,
                      columnNumber: 17
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 576,
                    columnNumber: 15
                  }, undefined), otpButton.verifyBox && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "verify_otp",
                    rules: [{
                      required: true,
                      message: "OTP is required"
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                      type: "text",
                      placeholder: "Verify OTP",
                      onChange: handleChange("otp_text"),
                      suffix: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Spin"], {
                        indicator: antIcon,
                        spinning: loadingOTP,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          style: {
                            cursor: "pointer"
                          },
                          className: `text-primary`,
                          onClick: handleVerifyOTP,
                          children: "Verify"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 667,
                          columnNumber: 25
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 666,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 661,
                      columnNumber: 19
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 657,
                    columnNumber: 17
                  }, undefined), otpButton.text.toLowerCase() == "verified" && otpButton.registerBoxShow && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                      name: "password",
                      rules: [{
                        required: true,
                        message: "Please input your password!"
                      }],
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                        type: "password",
                        placeholder: "Enter Password",
                        onChange: handleChange("password"),
                        value: password
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 692,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 683,
                      columnNumber: 21
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                      name: "password_confirmation",
                      dependencies: ["password"],
                      rules: [{
                        required: true,
                        message: "Please input your password!"
                      }, ({
                        getFieldValue
                      }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("password") == value) {
                            return Promise.resolve();
                          }

                          return Promise.reject("The two passwords that you entered do not match!");
                        }

                      })],
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                        type: "password",
                        placeholder: "Re-Enter Password",
                        onChange: handleChange("password_confirmation"),
                        value: password_confirmation
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 719,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 699,
                      columnNumber: 21
                    }, undefined)]
                  }, void 0, true), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "form-group submit",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
                      type: "submit",
                      className: "ps-btn ps-btn--fullwidth" // onClick={otpButton.registerBoxShow ? handleSubmit : undefined}
                      ,
                      children: "Register"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 737,
                      columnNumber: 17
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-footer",
                      style: {
                        backgroundColor: `#ffffff`,
                        borderTop: `1px solid #ffffff`
                      },
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "fotr_txt",
                        children: ["Already have an account?", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          onClick: () => login(),
                          className: "ftr_link",
                          children: " Log In "
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 754,
                          columnNumber: 25
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 751,
                        columnNumber: 21
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 744,
                      columnNumber: 17
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 729,
                    columnNumber: 15
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 486,
                  columnNumber: 13
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 485,
                columnNumber: 11
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 461,
              columnNumber: 9
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"], {
              form: form,
              className: "ps-form--account",
              onFinish: otpButton.registerBoxShow ? handleSubmit1 : undefined,
              style: {
                paddingTop: "10px",
                display: 'none'
              },
              id: "registerId1",
              size: "large",
              layout: "vertical",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "logcard_header_inner",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "logcard_header_title",
                  children: " Forgot Password "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 792,
                  columnNumber: 15
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 791,
                columnNumber: 11
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "ps-tab active",
                id: "register",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "ps-form__content",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "phone_number",
                    rules: [{
                      required: false
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"].Group, {
                      compact: true,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                        name: ["phone_number", "countrycode"],
                        noStyle: true,
                        rules: [{
                          required: true,
                          message: "countrycode is required"
                        }],
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Select"], {
                          showSearch: true,
                          style: {
                            width: "25%"
                          },
                          placeholder: "Country Code",
                          optionFilterProp: "children",
                          onChange: handleSelectCountryCode("country_code"),
                          filterOption: (input, option) => option.children.toString().toLowerCase().indexOf(input.toString().toLowerCase()) >= 0,
                          children: serverCountry === null || serverCountry === void 0 ? void 0 : serverCountry.map((countryDetails, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Option, {
                            value: `+${countryDetails.phonecode}`,
                            children: ["+", countryDetails.phonecode]
                          }, index, true, {
                            fileName: _jsxFileName,
                            lineNumber: 830,
                            columnNumber: 25
                          }, undefined))
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 816,
                          columnNumber: 21
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 809,
                        columnNumber: 19
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                        name: ["phone_number", "phonenumber"],
                        noStyle: true,
                        rules: [{
                          required: true,
                          message: "phone number is required"
                        }, {
                          min: 7,
                          message: "Phone number should be 7-12 digit long!"
                        }, {
                          max: 12,
                          message: "Phone number should be 7-12 digit long!"
                        }, {
                          pattern: new RegExp(/^[0-9]+$/i),
                          message: "Only Numbers Accepted"
                        }],
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                          type: "text",
                          placeholder: "Enter Phone Number",
                          onChange: handleChange("phone_number"),
                          value: phone_number,
                          style: {
                            width: "75%",
                            height: "50px",
                            padding: "2px"
                          },
                          suffix: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Spin"], {
                            indicator: antIcon,
                            spinning: loadingOTP,
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                              style: {
                                cursor: "pointer"
                              },
                              className: `text-${otpButton.class}`,
                              onClick: handleOTP,
                              children: otpButton.text
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 866,
                              columnNumber: 27
                            }, undefined)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 865,
                            columnNumber: 25
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 858,
                          columnNumber: 21
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 839,
                        columnNumber: 19
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 808,
                      columnNumber: 17
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 800,
                    columnNumber: 15
                  }, undefined), otpButton.verifyBox && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                    name: "verify_otp",
                    rules: [{
                      required: true,
                      message: "OTP is required"
                    }],
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                      type: "text",
                      placeholder: "Verify OTP",
                      onChange: handleChange("otp_text"),
                      suffix: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Spin"], {
                        indicator: antIcon,
                        spinning: loadingOTP,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          style: {
                            cursor: "pointer"
                          },
                          className: `text-primary`,
                          onClick: handleVerifyOTP1,
                          children: "Verify"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 891,
                          columnNumber: 25
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 890,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 885,
                      columnNumber: 19
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 881,
                    columnNumber: 17
                  }, undefined), otpButton.text.toLowerCase() == "verified" && otpButton.registerBoxShow && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                      name: "password",
                      rules: [{
                        required: true,
                        message: "Please input your password!"
                      }],
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                        type: "password",
                        placeholder: "Enter Password",
                        onChange: handleChange("password"),
                        value: password
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 916,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 907,
                      columnNumber: 21
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Form"].Item, {
                      name: "password_confirmation",
                      dependencies: ["password"],
                      rules: [{
                        required: true,
                        message: "Please input your password!"
                      }, ({
                        getFieldValue
                      }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("password") == value) {
                            return Promise.resolve();
                          }

                          return Promise.reject("The two passwords that you entered do not match!");
                        }

                      })],
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_6__["Input"], {
                        type: "password",
                        placeholder: "Re-Enter Password",
                        onChange: handleChange("password_confirmation"),
                        value: password_confirmation
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 943,
                        columnNumber: 23
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 923,
                      columnNumber: 21
                    }, undefined)]
                  }, void 0, true), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "form-group submit",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
                      onClick: handleSubmit1,
                      className: "log_btn" // onClick={otpButton.registerBoxShow ? handleSubmit : undefined}
                      ,
                      children: "Change Password"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 961,
                      columnNumber: 17
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "card-footer",
                      style: {
                        backgroundColor: `#ffffff`,
                        borderTop: `1px solid #ffffff`
                      },
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "fotr_txt",
                        children: ["Already have an account?", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          onClick: () => login(),
                          className: "ftr_link",
                          children: " Log In "
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 978,
                          columnNumber: 25
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 975,
                        columnNumber: 21
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 968,
                      columnNumber: 17
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 953,
                    columnNumber: 15
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 795,
                  columnNumber: 13
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 794,
                columnNumber: 11
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 770,
              columnNumber: 9
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 413,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 412,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 403,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 402,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 373,
    columnNumber: 5
  }, undefined);
};

_s(Login, "OR80USESd5cnIKHCOdSOUvZNxH4=", false, function () {
  return [antd__WEBPACK_IMPORTED_MODULE_6__["Form"].useForm, react_redux__WEBPACK_IMPORTED_MODULE_7__["useDispatch"]];
});

_c = Login;
/* harmony default export */ __webpack_exports__["default"] = (Login);

var _c;

$RefreshReg$(_c, "Login");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/footers/modules/FooterCopyright.jsx":
/*!***************************************************************!*\
  !*** ./components/shared/footers/modules/FooterCopyright.jsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);


var _jsxFileName = "E:\\bigBasket\\components\\shared\\footers\\modules\\FooterCopyright.jsx";



const FooterCopyright = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "footer-bottom pt-80 pb-30",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget mx-w-400",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "footer-logo mb-35",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "index.html"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 14,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 13,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text mb-30",
              children: "We are a team of designers and developers that create high quality Magento, Prestashop, Opencart."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 18,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "address-widget mb-30",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "media",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "address-icon me-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 22,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "media-body",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    className: "help-text text-uppercase",
                    children: "NEED HELP?"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 35
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                    className: "title text-dark",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                      href: "tel:+1(123)8889999",
                      children: "(+800) 345 678"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 27,
                      columnNumber: 67
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 27,
                    columnNumber: 35
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 25,
                  columnNumber: 31
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 21,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "social-network",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
                className: "d-flex",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-facebook"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 34,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 34,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 34,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-twitter"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 36,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 36,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 36,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-youtube"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 38,
                      columnNumber: 73
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 38,
                    columnNumber: 35
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 38,
                  columnNumber: 31
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                  className: "me-0",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: "/page/blank",
                    target: "_blank",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "icon-social-instagram"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 40,
                      columnNumber: 90
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 40,
                    columnNumber: 52
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 40,
                  columnNumber: 31
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 12,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-2 mb-30 pl-40",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Information"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 50,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 49,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "footer-menu",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Delivery"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 55,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 55,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "About us"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Secure payment"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 57,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Contact us"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 58,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 58,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Sitemap"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Stores"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 60,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 60,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 54,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-2 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Custom Links"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 69,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 68,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "footer-menu",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Legal Notice"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 74,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 74,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Prices drop"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 75,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "New products"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 77,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Best sales"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 79,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 79,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "Login"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 81,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "/page/blank",
                  children: "My account"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 83,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4 mb-30",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "footer-widget",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "border-bottom cbb1 mb-25",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "section-title pb-20",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                  className: "title text-dark text-uppercase",
                  children: "Newsletter"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 91,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 90,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "text mb-20",
              children: "You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 95,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "nletter-form mb-35",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
                className: "form-inline position-relative",
                action: "/page/blank",
                target: "_blank",
                method: "post",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
                  className: "btn nletter-btn text-capitalize",
                  type: "submit",
                  children: "Sign up"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 102,
                  columnNumber: 31
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 98,
                columnNumber: 27
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 97,
              columnNumber: 23
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "store d-flex",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/page/blank",
                className: "d-inline-block me-3"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 27
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "/page/blank",
                className: "d-inline-block"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 27
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 23
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 15
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 3
  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "coppy-right pb-80",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-4",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-start",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "mb-3 mb-md-0",
              children: ["\xA9 2021 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "text-capitalize",
                children: "Junno"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 127,
                columnNumber: 18
              }, undefined), " Made with ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: "\u2764"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 16
              }, undefined), " by", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                target: "_blank",
                href: "https://hasthemes.com/",
                children: "HasThemes"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 129,
                columnNumber: 11
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 126,
              columnNumber: 23
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 15
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-md-6 col-lg-8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-start"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 15
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 122,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 121,
    columnNumber: 3
  }, undefined)]
}, void 0, true);

_c = FooterCopyright;
/* harmony default export */ __webpack_exports__["default"] = (FooterCopyright);

var _c;

$RefreshReg$(_c, "FooterCopyright");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/HeaderDefault.jsx":
/*!*****************************************************!*\
  !*** ./components/shared/headers/HeaderDefault.jsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/components/elements/common/Logo */ "./components/elements/common/Logo.js");
/* harmony import */ var _components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/components/shared/headers/modules/SearchHeader */ "./components/shared/headers/modules/SearchHeader.jsx");
/* harmony import */ var _components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/shared/navigation/NavigationDefault */ "./components/shared/navigation/NavigationDefault.jsx");
/* harmony import */ var _components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/components/shared/headers/modules/HeaderActions */ "./components/shared/headers/modules/HeaderActions.jsx");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/components/shared/menus/MenuCategoriesDropdown */ "./components/shared/menus/MenuCategoriesDropdown.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\HeaderDefault.jsx",
    _s = $RefreshSig$();











const HeaderDefault = () => {
  _s();

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (true) {
      window.addEventListener("scroll", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_8__["stickyHeader"]);
    }
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
    className: "header header--1",
    "data-sticky": "true",
    id: "headerSticky",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "head-top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "ps-container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "d-flex justify-content-end",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "top-content",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              className: "top-url",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "top-li",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  children: " Eng "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: " Sign In"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 29,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 28,
                  columnNumber: 20
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
                  href: "/account/login",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    children: "Register"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 32,
                    columnNumber: 13
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 11
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 25,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 24,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "header__top",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__left",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__categ",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "d-flex justify-content-center align-items-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "",
            children: "Offer Zone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "header__right",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 58,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 5
  }, undefined);
};

_s(HeaderDefault, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = HeaderDefault;
/* harmony default export */ __webpack_exports__["default"] = (HeaderDefault);

var _c;

$RefreshReg$(_c, "HeaderDefault");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/MiniCart.jsx":
/*!********************************************************!*\
  !*** ./components/shared/headers/modules/MiniCart.jsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductOnCart */ "./components/elements/products/ProductOnCart.jsx");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\MiniCart.jsx",
    _s = $RefreshSig$();











const MiniCart = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(_c = _s(({
  cart
}) => {
  var _cart$product, _cartdata$product, _cartdata$product2;

  _s();

  let cartItemsView;
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"])();
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"])(state => state.auth);
  const productItemWithSeller = cart === null || cart === void 0 ? void 0 : (_cart$product = cart.product) === null || _cart$product === void 0 ? void 0 : _cart$product.map(productItem => {
    var _productItem$seller, _productItem$seller2, _productItem$seller3, _productItem$seller3$;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "stor-tit",
        children: productItem === null || productItem === void 0 ? void 0 : (_productItem$seller2 = productItem.seller) === null || _productItem$seller2 === void 0 ? void 0 : _productItem$seller2.seller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }, undefined), productItem === null || productItem === void 0 ? void 0 : (_productItem$seller3 = productItem.seller) === null || _productItem$seller3 === void 0 ? void 0 : (_productItem$seller3$ = _productItem$seller3.products) === null || _productItem$seller3$ === void 0 ? void 0 : _productItem$seller3$.map(cartProduct => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductOnCart__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: cartProduct
      }, cartProduct === null || cartProduct === void 0 ? void 0 : cartProduct.cart_id, false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined))]
    }, productItem === null || productItem === void 0 ? void 0 : (_productItem$seller = productItem.seller) === null || _productItem$seller === void 0 ? void 0 : _productItem$seller.seller_id, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, undefined);
  });
  const {
    0: cartdata,
    1: setCartdata
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: totalItems,
    1: setTotalItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log(".productItemNext......cart.....", cart); // console.log(".productItemNext...........", productItemNext)

    let isMounted = true;

    if (isMounted) {
      var _cart$product2;

      //alert("bhbhhbhhh")
      const cartTotalProductsFromAllSeller = cart === null || cart === void 0 ? void 0 : (_cart$product2 = cart.product) === null || _cart$product2 === void 0 ? void 0 : _cart$product2.reduce((productItemPrev, productItemNext) => {
        return Number(productItemPrev) + Number(productItemNext.seller.products.length);
      }, 0);
      setTotalItems(cartTotalProductsFromAllSeller);
      setCartdata(cart);
    }

    return () => {
      isMounted = false;
    };
  }, [cart === null || cart === void 0 ? void 0 : cart.product]); // async getCartItem(payload) {

  const getCartItem = payload => {
    alert("7777767"); //alert("d")

    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const user_token = access_token;
    console.log("....email...login.... ${apibaseurl}...", {
      apibaseurl: _repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]
    });
    console.log("....aaaaaaaaaaaaaaaa...", user_token);
    console.log("....bbbbbbbbbbbbbbbb...", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]);
    const data = axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_10__["apibaseurl"]}/api/customer/cart`, {
      access_token: user_token,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"],
      page_url: "http://localhost:3000/product/2",
      os_type: "WEB"
    }).then(response => response.data).then(data => {
      console.log("...iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.", data); //    console.log("....email...login.... response...",response)

      if (data.httpcode == 400 && data.status == "error") {// notification["error"]({
        //   message: data.message,
        // });
        // return;
      }

      if (data.httpcode == 200 && data.status == "success") {
        setCartdata(data.data);
        setTotalItems(data.data.cart_count); //   alert("yes")
        //  setOfferData(data.data)
        // notification["success"]({
        //   message: data.message,
        // });
        // localStorage.setItem("user", JSON.stringify(data.data));

        return;
      }
    }).catch(error => {// notification["error"]({
      //   message: error,
      // });
    });
    console.log("....bbbbb...bbb.ccccc..", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__["getDeviceId"]); // console.log("....bbbbb...bbb...",payload)
    // let userdata = localStorage.getItem("user");
    // let parsedata = JSON.parse(userdata);
    // let access_token = parsedata?.access_token;
    // const user_token = access_token;
    // const response =  Repository.post(`${apibaseurl}/api/customer/cart`, {
    //   access_token: user_token,
    //   lang_id: 1,
    //   device_id: getDeviceId,
    //   page_url: "http://localhost:3000/product/2",
    //   os_type: "WEB",
    // })
    // console.log("....bbbbb...bbb..444444444444.",response)
    //   // .then((response) => {
    //     if (response.data.httpcode == "200") {
    //       return response.data;
    //     }
    //   //   return response.data;
    //   // })
    //   // .catch((error) => ({ error: JSON.stringify(error) }));
    // return response;
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("..557..", cart);
    getCartItem();

    if (cart == undefined) {
      // alert("ddfffd")
      (auth === null || auth === void 0 ? void 0 : auth.access_token) && dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
    }
  }, [auth.access_token, cart === null || cart === void 0 ? void 0 : cart.product]);

  if (cartdata !== null && cartdata !== undefined && cartdata !== null && cartdata !== void 0 && (_cartdata$product = cartdata.product) !== null && _cartdata$product !== void 0 && _cartdata$product.length && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product2 = cartdata.product) === null || _cartdata$product2 === void 0 ? void 0 : _cartdata$product2.length) !== 0) {
    var _cartdata$product3;

    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: productItemWithSeller
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 145,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__footer",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          children: ["Sub Total:", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            children: cartdata && cartdata !== null && (cartdata === null || cartdata === void 0 ? void 0 : (_cartdata$product3 = cartdata.product) === null || _cartdata$product3 === void 0 ? void 0 : _cartdata$product3.length) > 0 ? Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_8__["currencyHelperConvertToRinggit"])(cartdata.grand_total) : 0
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 149,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 147,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/shopping-cart",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "View Cart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 157,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 156,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/account/checkout",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              className: "ps-btn",
              children: "Checkout"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 160,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 159,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 155,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 144,
      columnNumber: 7
    }, undefined);
  } else {
    cartItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-cart__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-cart__items",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          children: "No products in cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 170,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 169,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 168,
      columnNumber: 7
    }, undefined);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-cart--mini",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "header__extra",
      href: "#",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-bag2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 179,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          children: cartdata !== null && cartdata !== undefined && totalItems > 0 ? totalItems : 0
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 178,
      columnNumber: 7
    }, undefined), cartItemsView]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 177,
    columnNumber: 5
  }, undefined);
}, "lT+bflo29ZWMxNMJEjF2ThtquLk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_2__["useDispatch"], react_redux__WEBPACK_IMPORTED_MODULE_2__["useSelector"]];
}));
_c2 = MiniCart;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(state => state.cart)(MiniCart));

var _c, _c2;

$RefreshReg$(_c, "MiniCart$React.memo");
$RefreshReg$(_c2, "MiniCart");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/headers/modules/SearchHeader.jsx":
/*!************************************************************!*\
  !*** ./components/shared/headers/modules/SearchHeader.jsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _components_elements_products_ProductSearchResult__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/components/elements/products/ProductSearchResult */ "./components/elements/products/ProductSearchResult.jsx");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\headers\\modules\\SearchHeader.jsx",
    _s = $RefreshSig$(),
    _s2 = $RefreshSig$();







const exampleCategories = [{
  id: "",
  category_name: "All"
}, {
  id: 4,
  category_name: "Grocery"
}, {
  id: 5,
  category_name: "Electronics"
}, {
  id: 6,
  category_name: "Bakery"
}, {
  id: 7,
  category_name: "Fashion"
}, {
  id: 8,
  category_name: "shoes"
}, {
  id: 10,
  category_name: "kids fashion"
}, {
  id: 11,
  category_name: "Dairy Products"
}, {
  id: 12,
  category_name: "Home"
}, {
  id: 13,
  category_name: "Appliances"
}, {
  id: 14,
  category_name: "Mobiles"
}, {
  id: 15,
  category_name: "Toys"
}, {
  id: 18,
  category_name: "Jewelleryy"
}];

function useDebounce(value, delay) {
  _s();

  const {
    0: debouncedValue,
    1: setDebouncedValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(value);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    // Update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

_s(useDebounce, "KDuPAtDOgxm8PU6legVJOb3oOmA=");

const SearchHeader = () => {
  _s2();

  const inputEl = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const {
    0: isSearch,
    1: setIsSearch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    0: keyword,
    1: setKeyword
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: category,
    1: setCategory
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: resultItems,
    1: setResultItems
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: loading,
    1: setLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const debouncedSearchTerm = useDebounce(keyword, 1500);

  function handleClearKeyword() {
    setKeyword("");
    setIsSearch(false);
    setLoading(false);
  }

  function handleSubmit(e) {
    e.preventDefault();
    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push(`/search?keyword=${keyword}`);
  }

  const {
    0: menuDataFromServer,
    1: setMenuDataFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([{
    category_id: "",
    category_name: "All"
  }]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let isSubscribed = true;

    const fetchMenuDataFromServer = async () => {
      try {
        const response = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__["default"].getProductCategories();
        isSubscribed ? setMenuDataFromServer([{
          category_id: "",
          category_name: "All"
        }, ...response.data.cat_subcat]) : null;
      } catch (error) {
        console.error(error);
      }
    };

    fetchMenuDataFromServer();
    return () => isSubscribed = false;
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (debouncedSearchTerm) {
      setLoading(true);

      if (keyword) {
        const queries = {
          _limit: 5,
          title_contains: keyword,
          category_id: category
        }; // const products = ProductRepository.getRecords(queries);

        const products = _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_5__["default"].getSearchedProducts(queries);
        products.then(result => {
          setLoading(false);
          setResultItems(result.items);
          setIsSearch(true);
        });
      } else {
        setIsSearch(false);
        setKeyword("");
      }

      if (loading) {
        setIsSearch(false);
      }
    } else {
      setLoading(false);
      setIsSearch(false);
    }
  }, [debouncedSearchTerm]); // Views

  let productItemsView, clearTextView, selectOptionView, loadingView, loadMoreView;

  if (!loading) {
    if (resultItems && resultItems.length > 0) {
      if (resultItems.length > 5) {
        loadMoreView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-panel__footer text-center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
            href: "/search",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              children: "See all results"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 169,
          columnNumber: 11
        }, undefined);
      }

      productItemsView = resultItems.map(product => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_products_ProductSearchResult__WEBPACK_IMPORTED_MODULE_6__["default"], {
        product: product
      }, product.id, false, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 9
      }, undefined));
    } else {
      productItemsView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: "No product found."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 180,
        columnNumber: 26
      }, undefined);
    }

    if (keyword !== "") {
      clearTextView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "ps-form__action",
        onClick: handleClearKeyword,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
          className: "icon icon-cross2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 9
      }, undefined);
    }
  } else {
    loadingView = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      className: "ps-form__action",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Spin"], {
        size: "small"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 192,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 191,
      columnNumber: 7
    }, undefined);
  }

  if ((menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : menuDataFromServer.length) > 0) {
    selectOptionView = menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : menuDataFromServer.map((option, index) => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
        value: option.category_id,
        children: option.category_name
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 200,
        columnNumber: 9
      }, undefined);
    });
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
    className: "ps-form--quick-search",
    method: "get",
    action: "/",
    onSubmit: handleSubmit,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-form__input",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        ref: inputEl,
        className: "form-control",
        type: "text",
        value: keyword,
        placeholder: "I'm shopping for...",
        onChange: e => setKeyword(e.target.value)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 225,
        columnNumber: 9
      }, undefined), clearTextView, loadingView]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 224,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: `ps-panel--search-result${isSearch ? " active " : ""}`,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-panel__content",
        children: productItemsView
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 238,
        columnNumber: 9
      }, undefined), loadMoreView]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 207,
    columnNumber: 5
  }, undefined);
};

_s2(SearchHeader, "GQPNfgs0fy5+VuJqVQjKSUl/sFg=", false, function () {
  return [useDebounce];
});

_c = SearchHeader;
/* harmony default export */ __webpack_exports__["default"] = (SearchHeader);

var _c;

$RefreshReg$(_c, "SearchHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/shared/menus/MenuCategoriesDropdown.js":
/*!***********************************************************!*\
  !*** ./components/shared/menus/MenuCategoriesDropdown.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/public/static/data/menu.json */ "./public/static/data/menu.json");
var _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! ~/public/static/data/menu.json */ "./public/static/data/menu.json", 1);
/* harmony import */ var _components_elements_menu_MenuShopBy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/components/elements/menu/MenuShopBy */ "./components/elements/menu/MenuShopBy.jsx");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");


var _jsxFileName = "E:\\bigBasket\\components\\shared\\menus\\MenuCategoriesDropdown.js",
    _s = $RefreshSig$();








const MenuCategoriesDropdown = () => {
  _s();

  var _menuDataFromServer$d;

  const {
    0: menuDataFromServer,
    1: setMenuDataFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);

  const fetchMenuDataFromServer = async () => {
    try {
      const response = await axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_5__["apibaseurl"]}/api/customer/cat-subcat`);
      setMenuDataFromServer(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const {
    homedata
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_6__["useSelector"])(state => state.home);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let handler;
    handler = setTimeout(async () => {
      await fetchMenuDataFromServer();
    }, 100);
    return () => {
      clearTimeout(handler);
    };
  }, [homedata]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "menu--product-categories",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "menu__toggle",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "icon-menu"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        children: "Shop by Category"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "menu__content",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_elements_menu_MenuShopBy__WEBPACK_IMPORTED_MODULE_3__["default"], {
        source: menuDataFromServer === null || menuDataFromServer === void 0 ? void 0 : (_menuDataFromServer$d = menuDataFromServer.data) === null || _menuDataFromServer$d === void 0 ? void 0 : _menuDataFromServer$d.cat_subcat,
        className: "menu--dropdown"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 5
  }, undefined);
};

_s(MenuCategoriesDropdown, "WtezKyIDxrDtIFdB+9B4q/fq25U=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_6__["useSelector"]];
});

_c = MenuCategoriesDropdown;
/* harmony default export */ __webpack_exports__["default"] = (MenuCategoriesDropdown);

var _c;

$RefreshReg$(_c, "MenuCategoriesDropdown");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/@popperjs/core/lib/createPopper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/contains.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getParentNode.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/instanceOf.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isLayoutViewport.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isTableElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js":
false,

/***/ "./node_modules/@popperjs/core/lib/enums.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/arrow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/computeStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/eventListeners.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/flip.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/hide.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/offset.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/popperOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/preventOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper-base.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/debounce.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/detectOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/expandToHashMap.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/format.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getAltAxis.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getBasePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getFreshSideObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getVariation.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/math.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergeByName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergePaddingObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/orderModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/rectToClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/uniqueBy.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/userAgent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/validateModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/within.js":
false,

/***/ "./node_modules/@react-aria/ssr/dist/module.js":
false,

/***/ "./node_modules/@restart/hooks/esm/index.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCallbackRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useCommittedRef.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventCallback.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useEventListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useForceUpdate.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useGlobalListener.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useImage.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useIsomorphicEffect.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeState.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergeStateFromProps.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMergedRefs.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useMounted.js":
false,

/***/ "./node_modules/@restart/hooks/esm/usePrevious.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useRafInterval.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useResizeObserver.js":
false,

/***/ "./node_modules/@restart/hooks/esm/useSafeState.js":
false,

/***/ "./node_modules/@restart/ui/esm/Anchor.js":
false,

/***/ "./node_modules/@restart/ui/esm/Button.js":
false,

/***/ "./node_modules/@restart/ui/esm/DataKey.js":
false,

/***/ "./node_modules/@restart/ui/esm/Dropdown.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownItem.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownMenu.js":
false,

/***/ "./node_modules/@restart/ui/esm/DropdownToggle.js":
false,

/***/ "./node_modules/@restart/ui/esm/NavContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/SelectableContext.js":
false,

/***/ "./node_modules/@restart/ui/esm/mergeOptionsWithPopperConfig.js":
false,

/***/ "./node_modules/@restart/ui/esm/popper.js":
false,

/***/ "./node_modules/@restart/ui/esm/ssr.js":
false,

/***/ "./node_modules/@restart/ui/esm/useClickOutside.js":
false,

/***/ "./node_modules/@restart/ui/esm/usePopper.js":
false,

/***/ "./node_modules/@restart/ui/esm/useWindow.js":
false,

/***/ "./node_modules/dequal/dist/index.mjs":
false,

/***/ "./node_modules/dom-helpers/esm/addEventListener.js":
false,

/***/ "./node_modules/dom-helpers/esm/camelize.js":
false,

/***/ "./node_modules/dom-helpers/esm/canUseDOM.js":
false,

/***/ "./node_modules/dom-helpers/esm/contains.js":
false,

/***/ "./node_modules/dom-helpers/esm/listen.js":
false,

/***/ "./node_modules/dom-helpers/esm/ownerDocument.js":
false,

/***/ "./node_modules/dom-helpers/esm/querySelectorAll.js":
false,

/***/ "./node_modules/dom-helpers/esm/removeEventListener.js":
false,

/***/ "./node_modules/invariant/browser.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Button.js":
false,

/***/ "./node_modules/react-bootstrap/esm/Dropdown.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownItem.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownMenu.js":
false,

/***/ "./node_modules/react-bootstrap/esm/DropdownToggle.js":
false,

/***/ "./node_modules/react-bootstrap/esm/InputGroupContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/NavbarContext.js":
false,

/***/ "./node_modules/react-bootstrap/esm/ThemeProvider.js":
false,

/***/ "./node_modules/react-bootstrap/esm/createWithBsPrefix.js":
false,

/***/ "./node_modules/react-bootstrap/esm/types.js":
false,

/***/ "./node_modules/react-bootstrap/esm/useWrappedRefWithWarning.js":
false,

/***/ "./node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js":
false,

/***/ "./node_modules/react/cjs/react-jsx-runtime.development.js":
false,

/***/ "./node_modules/react/jsx-runtime.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/hook.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/index.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/uncontrollable.js":
false,

/***/ "./node_modules/uncontrollable/lib/esm/utils.js":
false,

/***/ "./node_modules/warning/warning.js":
false,

/***/ "./repositories/AccountRepository.js":
/*!*******************************************!*\
  !*** ./repositories/AccountRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");





const modalOpen = (type, message, description) => {
  antd__WEBPACK_IMPORTED_MODULE_3__["notification"][type]({
    message,
    description
  });
};

class AccountRepository {
  async getUserPurchaseYears(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/year`, payload).then(response => {
      return response.data;
    }).catch(err => {
      modalOpen("error", "Error", "Error Fetching Years from Server");
    });
    return response;
  }

  async changePassword(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/password/change`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async registerNewUser(payload) {
    alert("d");
    console.log("....555...", payload);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register`, payload).then(response => {
      if (response.data.httpcode == 200) {
        return response.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async editCustomerProfile(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(function (response) {
      return response.data;
    }).catch(function (response) {
      console.log(response);
      return response.data;
    });
    return response;
  }

  async getCountry() {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/country`).then(response => {
      if (response.data.httpcode == 200) {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getChatList(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/list`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getChatMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/message`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendMessage(payload) {
    const response = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/chat/send`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getState(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/state`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getCity(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/city`, payload).then(response => {
      if (response.data.httpcode == "200") {
        return response.data.data;
      }

      return response.data;
    }).catch(err => console.log(err));
    return response;
  }

  async getMyOrders(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/mypurchase`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async cancelOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/response/cancel/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getOrderDetails(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getCustomerProfileDetail({ access_token }) {


  async getCustomerProfileDetail() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/profile`, {
      access_token,
      lang_id: 1
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateCustomerProfileDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/profile`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerRecentViews(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/recent/views`, {
      access_token,
      lang_id: 1
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCustomerAddresses() {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/address`, {
      access_token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async makeDefaultAddresses(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    userUpdateFormData.append("is_default", payload.default);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/default/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteAddress(payload) {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    var userUpdateFormData = new FormData();
    userUpdateFormData.append("access_token", access_token);
    userUpdateFormData.append("address_id", payload.address_id);
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/remove/address`,
      data: userUpdateFormData,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async updateAddress(payload) {
    const reponse = await axios__WEBPACK_IMPORTED_MODULE_2___default()({
      method: "post",
      url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/edit/address`,
      data: payload,
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnOrderRequest(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/return/request`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async returnShipmentDetail(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/return/shipment`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => response.error);
    return response;
  }

  async listSupportToken(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/list-ticket`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async supportMessageByID(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/support-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async addTicketMessage(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-ticket-message`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getWalletDetails(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/wallet/amount`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionCartData(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getUserNotification(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/view/notifications`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getAuctionOrderList(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/order/list`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async sendRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/send/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyRegisterMobileOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/register/verify/otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async verifyForgotOTP(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/login/forgot/verify-otp`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new AccountRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Homeapi.js":
/*!*********************************!*\
  !*** ./repositories/Homeapi.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");




class Homeapi {
  async getHomedata(pathName) {
    let payload = {
      access_token: "",
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["getDeviceId"],
      page_url: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["makePageUrl"])("/"),
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_2__["osType"])()
    };
    const CancelToken = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken;
    let source = CancelToken.source();
    source && source.cancel("Operation canceled due to new request."); // save the new request for cancellation

    source = axios__WEBPACK_IMPORTED_MODULE_1___default.a.CancelToken.source();
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/home`, payload, {
      cancelToken: source.token
    }).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    })); // cancel the request (the message parameter is optional)

    source.cancel("Operation canceled by the user.");
    return reponse;
  }

  async submitReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-product-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async submitSellerReview(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_0__["apibaseurl"]}/api/customer/post-seller-review`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  } // async getHomedata() {
  //   const response = await axios
  //     .get(`https://estrradoweb.com/kangtao/api/customer/home`, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     })
  //     .then((response) => response.data)
  //     .catch((error) => error);
  //   return response;
  // }


}

/* harmony default export */ __webpack_exports__["default"] = (new Homeapi());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/ProductRepository.js":
/*!*******************************************!*\
  !*** ./repositories/ProductRepository.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Repository */ "./repositories/Repository.js");



class ProductRepository {
  async getRecords(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(params)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getSearchedProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-search`, {
      lang_id: "",
      category_id: params.category_id,
      keyword: params.title_contains
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.no_of_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list?page=` + params.page, {
      lang_id: 1,
      access_token: "",
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: "https://abc.com/products/us/img",
      os_type: "WEB"
    }).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProducts(payload, params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + params.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-list-filter?page=` + payload.page, payload).then(response => {
      console.log("############", response);
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getNewDealsProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-deals?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingSaleProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getFeaturedProductsbyFilter(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-featured?page=` + payload.page, payload).then(response => {
      return {
        items: response.data.data.products,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShockingProducts(params) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale-products?page=` + params.page).then(response => {
      return {
        items: response.data.data.shock_sale,
        totalItems: response.data.data.total_products
      };
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getBrands() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/brand`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductCategories() {
    // const reponse = await Repository.get(`${baseUrl}/product-categories`)
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cat-subcat`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getTotalRecords() {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products/count`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsById(id) {
    console.log("....dddddd..1..", id);
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let access_token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("....dddddd..1.userdata.", userdata);
    console.log("....dddddd..1..parsedata", parsedata);
    console.log("....dddddd..1.access_token.", access_token);
    console.log("....dddddd..1.getDeviceId.", _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"]);
    console.log("....dddddd..1.access_token.", access_token);
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/product-detail`, {
      access_token,
      id,
      lang_id: 1,
      device_id: _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["getDeviceId"],
      page_url: `${_Repository__WEBPACK_IMPORTED_MODULE_1__["basePathUrl"]}/product/${id}`,
      os_type: Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_0__["osType"])()
    }).then(response => {
      console.log("....dddddd....", response);
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getShockSaleByid(payload) {
    const response = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shock-sale`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return response;
  }

  async getProductsByCategory(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/product-categories?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrand(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?slug=${payload}`).then(response => {
      if (response.data) {
        if (response.data.length > 0) {
          return response.data[0];
        }
      } else {
        return null;
      }
    }).catch(() => {
      return null;
    });
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByBrands(payload) {
    let query = "";
    payload.forEach(item => {
      if (query === "") {
        query = `id_in=${item}`;
      } else {
        query = query + `&id_in=${item}`;
      }
    });
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/brands?${query}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getProductsByPriceRange(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].get(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["baseUrl"]}/products?${Object(_Repository__WEBPACK_IMPORTED_MODULE_1__["serializeQuery"])(payload)}`).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async addProductToCart(payload) {
    console.log(".....56565656565656...", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/add-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async changeQty(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart/change-qty`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeOrder(payload) {
    console.log("......3333333333.......", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/placeorder`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCart(payload) {
    console.log("....aaaa....", payload);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async deleteCart(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/delete-cart`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getAuctionProductByAuctionId(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async createBid(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/create-bid`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getShopDetailById(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/shop-detail`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async getCheckoutInfo(payload) {
    console.log("...getCheckoutInfo... apyload..", payload);
    console.log("...getCheckoutInfo... apibaseurl..", _Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]);
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/order/checkout-info`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

  async placeAuctionOrder(payload) {
    const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_1__["default"].post(`${_Repository__WEBPACK_IMPORTED_MODULE_1__["apibaseurl"]}/api/customer/auction/checkout`, payload).then(response => {
      return response.data;
    }).catch(error => ({
      error: JSON.stringify(error)
    }));
    return reponse;
  }

}

/* harmony default export */ __webpack_exports__["default"] = (new ProductRepository());

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./repositories/Repository.js":
/*!************************************!*\
  !*** ./repositories/Repository.js ***!
  \************************************/
/*! exports provided: basePostUrl, baseStoreURL, apibaseurl, basePathUrl, customHeaders, baseUrl, default, serializeQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePostUrl", function() { return basePostUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseStoreURL", function() { return baseStoreURL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "apibaseurl", function() { return apibaseurl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "basePathUrl", function() { return basePathUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customHeaders", function() { return customHeaders; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "serializeQuery", function() { return serializeQuery; });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseDomain = "https://beta.apinouthemes.com"; // API for products

const basePostUrl = "https://beta.apinouthemes.com"; // API for post

const baseStoreURL = "https://beta.apinouthemes.com"; // API for vendor(store)

let apibaseurlCustom = "https://dev-bigbasket.estrradoweb.com";
let basePath = "https://dev-kangtao.vercel.app";

if (true) {
  if (window.location.hostname == "uat-kangtao.vercel.app") {
    apibaseurlCustom = "https://uat-kt.estrradoweb.com";
    basePath = "https://uat-kangtao.vercel.app";
  }

  if (window.location.hostname == "qa-kangtao.vercel.app") {
    apibaseurlCustom = "https://qa-kt.estrradoweb.com";
    basePath = "https://qa-kangtao.vercel.app";
  }
}

const apibaseurl = apibaseurlCustom;
const basePathUrl = basePath;
const customHeaders = {
  Accept: "application/json"
};
const baseUrl = `${baseDomain}`;
/* harmony default export */ __webpack_exports__["default"] = (axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseUrl,
  headers: customHeaders
}));
const serializeQuery = query => {
  return Object.keys(query).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`).join("&");
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./store/cart/action.js":
/*!******************************!*\
  !*** ./store/cart/action.js ***!
  \******************************/
/*! exports provided: actionTypes, removeProductFromCartNew, selectedPaymentOption, sellerWiseMessage, usedWalletAmount, sellerWiseDiscount, grandTotalWithDiscountValue, appliedSellerVoucher, appliedPlatformVoucher, totalDiscount, fetchPlatformVoucherAction, fetchPlatformVoucherActionSuccess, getCart, getCartSuccess, getCartError, updateSelectedAddress, addItem, removeItem, increaseItemQty, decreaseItemQty, updateCartSuccess, updateCartError, clearCart, clearCartSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "actionTypes", function() { return actionTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeProductFromCartNew", function() { return removeProductFromCartNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedPaymentOption", function() { return selectedPaymentOption; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseMessage", function() { return sellerWiseMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "usedWalletAmount", function() { return usedWalletAmount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sellerWiseDiscount", function() { return sellerWiseDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "grandTotalWithDiscountValue", function() { return grandTotalWithDiscountValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedSellerVoucher", function() { return appliedSellerVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appliedPlatformVoucher", function() { return appliedPlatformVoucher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "totalDiscount", function() { return totalDiscount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherAction", function() { return fetchPlatformVoucherAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlatformVoucherActionSuccess", function() { return fetchPlatformVoucherActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCart", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartSuccess", function() { return getCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCartError", function() { return getCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateSelectedAddress", function() { return updateSelectedAddress; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addItem", function() { return addItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeItem", function() { return removeItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "increaseItemQty", function() { return increaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decreaseItemQty", function() { return decreaseItemQty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartSuccess", function() { return updateCartSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCartError", function() { return updateCartError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCart", function() { return clearCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearCartSuccess", function() { return clearCartSuccess; });
const actionTypes = {
  GET_CART: "GET_CART",
  GET_CART_SUCCESS: "GET_CART_SUCCESS",
  GET_CART_ERROR: "GET_CART_ERROR",
  GET_CART_TOTAL_QUANTITY: "GET_CART_TOTAL_QUANTITY",
  GET_CART_TOTAL_QUANTITY_SUCCESS: "GET_CART_TOTAL_QUANTITY_SUCCESS",
  ADD_ITEM: "ADD_ITEM",
  REMOVE_ITEM: "REMOVE_ITEM",
  REMOVE_PRODUCT_FROM_CART_NEW: "REMOVE_PRODUCT_FROM_CART_NEW",
  CLEAR_CART: "CLEAR_CART",
  CLEAR_CART_SUCCESS: "CLEAR_CART_SUCCESS",
  CLEAR_CART_ERROR: "CLEAR_CART_ERROR",
  INCREASE_QTY: "INCREASE_QTY",
  INCREASE_QTY_SUCCESS: "INCREASE_QTY_SUCCESS",
  INCREASE_QTY_ERROR: "INCREASE_QTY_ERROR",
  DECREASE_QTY: "DECREASE_QTY",
  UPDATE_CART: "UPDATE_CART",
  UPDATE_CART_SUCCESS: "UPDATE_CART_SUCCESS",
  UPDATE_CART_ERROR: "UPDATE_CART_ERROR",
  UPDATE_SELECTED_ADDRESS: "UPDATE_SELECTED_ADDRESS",
  FETCH_PLATFORM_VOUCHER: "FETCH_PLATFORM_VOUCHER",
  FETCH_PLATFORM_VOUCHER_SUCCESS: "FETCH_PLATFORM_VOUCHER_SUCCESS",
  TOTAL_DISCOUNT: "TOTAL_DISCOUNT",
  APPLIED_SELLER_VOUCHER: "APPLIED_SELLER_VOUCHER",
  APPLIED_PLATFORM_VOUCHER: "APPLIED_PLATFORM_VOUCHER",
  GRAND_TOTAL_WITH_DISCOUNT_VALUE: "GRAND_TOTAL_WITH_DISCOUNT_VALUE",
  SELLER_WISE_DISCOUNT: "SELLER_WISE_DISCOUNT",
  SELLER_WISE_MESSAGES: "SELLER_WISEMESSAGES",
  USED_WALLET_AMOUNT: "USED_WALLET_AMOUNT",
  SELECTED_PAYMENT_OPTION_BY_USER: "SELECTED_PAYMENT_OPTION_BY_USER"
};
function removeProductFromCartNew(payload) {
  return {
    type: actionTypes.REMOVE_PRODUCT_FROM_CART_NEW,
    payload
  };
}
function selectedPaymentOption(payload) {
  return {
    type: actionTypes.SELECTED_PAYMENT_OPTION_BY_USER,
    payload
  };
}
function sellerWiseMessage(payload) {
  return {
    type: actionTypes.SELLER_WISE_MESSAGES,
    payload
  };
}
function usedWalletAmount(payload) {
  return {
    type: actionTypes.USED_WALLET_AMOUNT,
    payload
  };
}
function sellerWiseDiscount(payload) {
  return {
    type: actionTypes.SELLER_WISE_DISCOUNT,
    payload
  };
}
function grandTotalWithDiscountValue(payload) {
  return {
    type: actionTypes.GRAND_TOTAL_WITH_DISCOUNT_VALUE,
    payload
  };
}
function appliedSellerVoucher(payload) {
  return {
    type: actionTypes.APPLIED_SELLER_VOUCHER,
    payload
  };
}
function appliedPlatformVoucher(payload) {
  return {
    type: actionTypes.APPLIED_PLATFORM_VOUCHER,
    payload
  };
}
function totalDiscount(payload) {
  return {
    type: actionTypes.TOTAL_DISCOUNT,
    payload
  };
}
function fetchPlatformVoucherAction() {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER
  };
}
function fetchPlatformVoucherActionSuccess(payload) {
  return {
    type: actionTypes.FETCH_PLATFORM_VOUCHER_SUCCESS,
    payload
  };
}
function getCart() {
  alert("getCart");
  return {
    type: actionTypes.GET_CART
  };
}
function getCartSuccess(payload) {
  return {
    type: actionTypes.GET_CART_SUCCESS,
    payload
  };
}
function getCartError(error) {
  return {
    type: actionTypes.GET_CART_ERROR,
    error
  };
}
function updateSelectedAddress(payload) {
  alert("call");
  console.log("..555555....", payload);
  return {
    type: actionTypes.UPDATE_SELECTED_ADDRESS,
    payload
  };
}
function addItem(payload) {
  return {
    type: actionTypes.ADD_ITEM,
    payload
  };
}
function removeItem(product) {
  return {
    type: actionTypes.REMOVE_ITEM,
    product
  };
}
function increaseItemQty(product) {
  return {
    type: actionTypes.INCREASE_QTY,
    product
  };
}
function decreaseItemQty(product) {
  return {
    type: actionTypes.DECREASE_QTY,
    product
  };
}
function updateCartSuccess(payload) {
  return {
    type: actionTypes.UPDATE_CART_SUCCESS,
    payload
  };
}
function updateCartError(payload) {
  return {
    type: actionTypes.UPDATE_CART_ERROR,
    payload
  };
}
function clearCart() {
  return {
    type: actionTypes.CLEAR_CART
  };
}
function clearCartSuccess() {
  return {
    type: actionTypes.CLEAR_CART_SUCCESS
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./utilities/product-helper.js":
/*!*************************************!*\
  !*** ./utilities/product-helper.js ***!
  \*************************************/
/*! exports provided: routeWithoutRefresh, homePageProductPriceHelper, returnTotalOfCartValue, returnTotalCommission, returnTotalOfCartTaxValue, priceHelper, currencyHelperConvertToRinggit, mathFormula, divCurrency, mulCurrency, addCurrency, subCurrency, formatCurrency, getColletionBySlug, getItemBySlug, convertSlugsQueryString, StrapiProductBadge, StrapiProductPrice, StrapiProductPrice_New, featureproductprice, StrapiProductPriceExpanded, StrapiProductPriceExpandedOther, StrapiProductPriceExpandedOther1, StrapiProductThumbnail, StrapiProductThumbnailOther, StrapiProductThumbnailDetail, Shockingproductthumbnail, colorHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routeWithoutRefresh", function() { return routeWithoutRefresh; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "homePageProductPriceHelper", function() { return homePageProductPriceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartValue", function() { return returnTotalOfCartValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalCommission", function() { return returnTotalCommission; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "returnTotalOfCartTaxValue", function() { return returnTotalOfCartTaxValue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "priceHelper", function() { return priceHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currencyHelperConvertToRinggit", function() { return currencyHelperConvertToRinggit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mathFormula", function() { return mathFormula; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "divCurrency", function() { return divCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mulCurrency", function() { return mulCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addCurrency", function() { return addCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subCurrency", function() { return subCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatCurrency", function() { return formatCurrency; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColletionBySlug", function() { return getColletionBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getItemBySlug", function() { return getItemBySlug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertSlugsQueryString", function() { return convertSlugsQueryString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductBadge", function() { return StrapiProductBadge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice", function() { return StrapiProductPrice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPrice_New", function() { return StrapiProductPrice_New; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "featureproductprice", function() { return featureproductprice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpanded", function() { return StrapiProductPriceExpanded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther", function() { return StrapiProductPriceExpandedOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductPriceExpandedOther1", function() { return StrapiProductPriceExpandedOther1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnail", function() { return StrapiProductThumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailOther", function() { return StrapiProductThumbnailOther; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrapiProductThumbnailDetail", function() { return StrapiProductThumbnailDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Shockingproductthumbnail", function() { return Shockingproductthumbnail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorHelper", function() { return colorHelper; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-lazyload */ "./node_modules/react-lazyload/lib/index.js");
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/repositories/Repository */ "./repositories/Repository.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "E:\\bigBasket\\utilities\\product-helper.js";

/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */






const exactMath = __webpack_require__(/*! exact-math */ "./node_modules/exact-math/dist/exact-math.node.js");

function routeWithoutRefresh(routeLink) {
  next_router__WEBPACK_IMPORTED_MODULE_5___default.a.replace(routeLink, undefined, {
    shallow: true
  });
}
function homePageProductPriceHelper(product) {
  if (product.offer_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.offer_price ? product.offer_price : 0, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this);
  }

  if (product.shock_sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.shock_sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this);
  }

  if (product.sale_price !== false) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price offer",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price ? product.actual_price : 0]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", product.actual_price ? product.actual_price : 0]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
function returnTotalOfCartValue(products) {
  let cart_total_price = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_discount_price == 0 ? next.total_actual_price : next.total_discount_price));
  }, 0);
  return cart_total_price;
}
function returnTotalCommission(products) {
  let cart_total_commission = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.commission));
  }, 0);
  return cart_total_commission;
}
function returnTotalOfCartTaxValue(products) {
  let cart_total_tax = products.reduce((prev, next) => {
    return Number(priceHelper(prev)) + Number(priceHelper(next.total_tax_value));
  }, 0);
  return cart_total_tax;
}
function priceHelper(num) {
  let numberArray = num === null || num === void 0 ? void 0 : num.toString().split(",");

  if (numberArray && (numberArray === null || numberArray === void 0 ? void 0 : numberArray.length) > 0) {
    return numberArray.reduce((prev, next) => prev + next);
  } else {
    return 0;
  }
}
function currencyHelperConvertToRinggit(currencyVal) {
  return new Intl.NumberFormat("ms-MY", {
    style: "currency",
    currency: "MYR"
  }).format(priceHelper(currencyVal));
}
function mathFormula(formulaText) {
  let result = exactMath.formula(formulaText);
}
function divCurrency(firstVal, secondVal) {
  let divData = exactMath.div(priceHelper(firstVal || 0), priceHelper(secondVal || 1));
  return divData;
}
function mulCurrency(firstVal, secondVal) {
  let mulData = exactMath.mul(priceHelper(firstVal || 1), priceHelper(secondVal || 1));
  return mulData;
}
function addCurrency(currencyValFirst, currencyValSecond) {
  let addData = exactMath.add(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return addData;
}
function subCurrency(currencyValFirst, currencyValSecond) {
  let subData = exactMath.sub(priceHelper(currencyValFirst || 0), priceHelper(currencyValSecond || 0));
  return subData;
}
function formatCurrency(num) {
  if (num !== undefined) {
    return parseFloat(num).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
  } else {}
}
function getColletionBySlug(collections, slug) {
  if (collections.length > 0) {
    const result = collections.find(item => item.slug === slug.toString());

    if (result !== undefined) {
      return result.products;
    } else {
      return [];
    }
  } else {
    return [];
  }
}
function getItemBySlug(banners, slug) {
  if (banners.length > 0) {
    const banner = banners.find(item => item.slug === slug.toString());

    if (banner !== undefined) {
      return banner;
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function convertSlugsQueryString(payload) {
  let query = "";

  if (payload.length > 0) {
    payload.forEach(item => {
      if (query === "") {
        query = `slug_in=${item}`;
      } else {
        query = query + `&slug_in=${item}`;
      }
    });
  }

  return query;
}
function StrapiProductBadge(product) {
  let view;

  if (product.badge && product.badge !== null) {
    view = product.badge.map(badge => {
      if (badge.type === "sale") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 16
        }, this);
      } else if (badge.type === "outStock") {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge out-stock",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 16
        }, this);
      } else {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__badge hot",
          children: badge.value
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 16
        }, this);
      }
    });
  }

  return view;
}
_c = StrapiProductBadge;
function StrapiProductPrice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 216,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 223,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c2 = StrapiProductPrice;
function StrapiProductPrice_New(product) {
  let view;

  if (product.sale_price !== false) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", product.sale_price, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", product.actual_price]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 235,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", product.actual_price]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 239,
      columnNumber: 12
    }, this);
  }

  return view;
}
_c3 = StrapiProductPrice_New;
function featureproductprice(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.sale_price), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "lin-prdt",
        children: ["RM ", formatCurrency(product.actual_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 259,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 7
    }, this);
  }

  return view;
}
function StrapiProductPriceExpanded(product) {
  let view;

  if (product.is_sale === true) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price sale",
      children: ["RM ", formatCurrency(product.price), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
        className: "ml-2",
        children: ["RM ", formatCurrency(product.sale_price)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 274,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
        children: "18% off"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 275,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 272,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
      className: "ps-product__price",
      children: ["RM ", formatCurrency(product.price)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 280,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c4 = StrapiProductPriceExpanded;
function StrapiProductPriceExpandedOther(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.offer_price ? product.offer_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.actual_price ? product.actual_price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 292,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 295,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 290,
    columnNumber: 5
  }, this);
  return view;
}
_c5 = StrapiProductPriceExpandedOther;
function StrapiProductPriceExpandedOther1(product) {
  let view;
  view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
    className: "ps-product__price",
    children: ["RM ", formatCurrency(product.sale_price ? product.sale_price : 0), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
      className: "ml-2",
      children: ["RM ", formatCurrency(product.price ? product.price : 0)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 307,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
      children: product.offer ? product.offer : 0
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 310,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 305,
    columnNumber: 5
  }, this);
  return view;
}
_c6 = StrapiProductPriceExpandedOther1;
function StrapiProductThumbnail(product) {
  let view;

  if (product.thumbnail) {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: `${_repositories_Repository__WEBPACK_IMPORTED_MODULE_3__["baseUrl"]}${product.thumbnail.url}`,
            alt: product.title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 323,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 322,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 338,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 337,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 336,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 335,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c7 = StrapiProductThumbnail;
function StrapiProductThumbnailOther(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$ = product.image[0]) === null || _product$image$ === void 0 ? void 0 : _product$image$.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 356,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 355,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 353,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 371,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 370,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 368,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c8 = StrapiProductThumbnailOther;
function StrapiProductThumbnailDetail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$2;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$2 = product.image[0]) === null || _product$image$2 === void 0 ? void 0 : _product$image$2.image,
            alt: product.product_name,
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 393,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 392,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 391,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "50px",
            height: "50px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 409,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 408,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 407,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 406,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c9 = StrapiProductThumbnailDetail;
function Shockingproductthumbnail(product) {
  let view;

  if (product.image.length > 0) {
    var _product$image$3;

    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: product === null || product === void 0 ? void 0 : (_product$image$3 = product.image[0]) === null || _product$image$3 === void 0 ? void 0 : _product$image$3.image,
            alt: product.product_name,
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 432,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 431,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 430,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 429,
      columnNumber: 7
    }, this);
  } else {
    view = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
      href: "/product/[pid]",
      as: `/product/${product.product_id}`,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_lazyload__WEBPACK_IMPORTED_MODULE_2___default.a, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/static/img/not-found.jpg",
            alt: "Kangtao",
            width: "300px",
            height: "200px"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 447,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 446,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 445,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 444,
      columnNumber: 7
    }, this);
  }

  return view;
}
_c10 = Shockingproductthumbnail;
function colorHelper() {
  console.log("hello");
}

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;

$RefreshReg$(_c, "StrapiProductBadge");
$RefreshReg$(_c2, "StrapiProductPrice");
$RefreshReg$(_c3, "StrapiProductPrice_New");
$RefreshReg$(_c4, "StrapiProductPriceExpanded");
$RefreshReg$(_c5, "StrapiProductPriceExpandedOther");
$RefreshReg$(_c6, "StrapiProductPriceExpandedOther1");
$RefreshReg$(_c7, "StrapiProductThumbnail");
$RefreshReg$(_c8, "StrapiProductThumbnailOther");
$RefreshReg$(_c9, "StrapiProductThumbnailDetail");
$RefreshReg$(_c10, "Shockingproductthumbnail");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0T25DYXJ0LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2VhcmNoUmVzdWx0LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYXJ0aWFscy9hY2NvdW50L0xvZ2luL2luZGV4LmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9zaGFyZWQvZm9vdGVycy9tb2R1bGVzL0Zvb3RlckNvcHlyaWdodC5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvSGVhZGVyRGVmYXVsdC5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9NaW5pQ2FydC5qc3giLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9TZWFyY2hIZWFkZXIuanN4Iiwid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3NoYXJlZC9tZW51cy9NZW51Q2F0ZWdvcmllc0Ryb3Bkb3duLmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvQWNjb3VudFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9Ib21lYXBpLmpzIiwid2VicGFjazovL19OX0UvLi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnkuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5LmpzIiwid2VicGFjazovL19OX0UvLi9zdG9yZS9jYXJ0L2FjdGlvbi5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyLmpzIl0sIm5hbWVzIjpbIlByb2R1Y3RPbkNhcnQiLCJwcm9kdWN0IiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsImhhbmRsZVJlbW92ZUNhcnRJdGVtIiwidXNlcmRhdGEiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidW5kZWZpbmVkIiwibm90aWZpY2F0aW9uIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwiZHVyYXRpb24iLCJwYXJzZWRhdGEiLCJKU09OIiwicGFyc2UiLCJ0b2tlbiIsImFjY2Vzc190b2tlbiIsInBheWxvYWQiLCJjYXJ0X2lkIiwiTW9kYWwiLCJjb25maXJtIiwidGl0bGUiLCJvbk9rIiwiZSIsInJlbW92ZVByb2R1Y3RGcm9tQ2FydE5ldyIsImRlc3Ryb3lBbGwiLCJvbkNhbmNlbCIsIm9rQnV0dG9uUHJvcHMiLCJkYW5nZXIiLCJpbWFnZSIsInRhcmdldCIsIm9uZXJyb3IiLCJzcmMiLCJwcm9kdWN0X2lkIiwicHJvZHVjdF9uYW1lIiwiYXR0cl9uYW1lMSIsImF0dHJfbmFtZTIiLCJ1bml0X2Rpc2NvdW50X3ByaWNlIiwidW5pdF9hY3R1YWxfcHJpY2UiLCJxdWFudGl0eSIsIlByb2R1Y3RTZWFyY2hSZXN1bHQiLCJpZCIsInJhdGluZyIsInNhbGVfcHJpY2UiLCJhY3R1YWxfcHJpY2UiLCJMb2dpbiIsInByb3BzIiwiZm9ybSIsIkZvcm0iLCJ1c2VGb3JtIiwiaW5pdFN0YXRlT3RwQnV0dG9uIiwiY2xhc3MiLCJ0ZXh0IiwidmVyaWZ5Qm94IiwidmVyaWZpZWROdW1iZXIiLCJyZWdpc3RlckJveFNob3ciLCJsb2FkaW5nT1RQIiwic2V0TG9hZGluZ09UUCIsInVzZVN0YXRlIiwib3RwQnV0dG9uIiwic2V0T3RwQnV0dG9uIiwidXNlciIsInNldFVzZXIiLCJpbnB1dCIsInBhc3N3b3JkIiwiYW50SWNvbiIsImZvbnRTaXplIiwic2VydmVyQ291bnRyeSIsInNldENvdW50cnkiLCJmaXJzdF9uYW1lIiwibGFzdF9uYW1lIiwiZW1haWwiLCJwaG9uZV9udW1iZXIiLCJwYXNzd29yZF9jb25maXJtYXRpb24iLCJjb3VudHJ5X2NvZGUiLCJyZW1lbWJlck1lIiwic2V0UmVtZW1iZXIiLCJ1c2VyT3RwIiwic2V0VXNlck90cCIsImdldEN1c3RvbWVySWQiLCJzZXRDdXN0b21lcklkIiwic2hvd0xvZ2luV2l0aFNNUyIsInNldFNob3dMb2dpbldpdGhTTVMiLCJoYW5kbGVTdWJtaXQxIiwiY3VzdG9tZXJfaWQiLCJ2YWx1ZXMiLCJBY2NvdW50UmVwb3NpdG9yeSIsImNoYW5nZVBhc3N3b3JkIiwiY29uc29sZSIsImxvZyIsImh0dHBjb2RlIiwic3VjY2VzcyIsImVycm9yIiwibWFwIiwiZXJyb3JJbmZvIiwiaGFuZGxlU3VibWl0IiwicmVnaXN0ZXJOZXdVc2VyIiwiaGFuZGxlRmVhdHVyZVdpbGxVcGRhdGUiLCJwcmV2ZW50RGVmYXVsdCIsIm9wZW4iLCJ1c2VFZmZlY3QiLCJmZXRjaENvdW50cnkiLCJjb3VudHJ5RGF0YUZyb21TZXJ2ZXIiLCJnZXRDb3VudHJ5IiwiY291bnRyeSIsImhhbmRsZUNoYW5nZSIsIm5hbWUiLCJldmVudCIsInZhbHVlIiwidmVyaWZ5T3RwIiwib3RwRnJvbVNlcnZlciIsImlucHV0RnJvbVNlcnZlciIsInVzZXJPdHBJbnB1dCIsImluZm8iLCJjb250ZW50IiwiaGFuZGxlTG9naW5TdWJtaXQiLCJyZXF1aXJlZCIsImRldmljZVRva2VuIiwidXVpZHY0IiwiZGV2aWNlSWQiLCJkZXZpY2VOYW1lIiwib3MiLCJvdHAiLCJkYXRhIiwiQXhpb3MiLCJwb3N0IiwiYXBpYmFzZXVybCIsImhlYWRlcnMiLCJ0aGVuIiwicmVzcG9uc2UiLCJzdGF0dXMiLCJhcmdzIiwidHlwZSIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJsb2dpbiIsIlJvdXRlciIsInB1c2giLCJjYXRjaCIsIm9rQ2FuY2VsIiwiY2xvc2FibGUiLCJrZXlib2FyZCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJzdHlsZSIsImRpc3BsYXkiLCJyZWciLCJmb3Jnb3QiLCJoYW5kbGVWZXJpZnlPVFAxIiwic3BsaXQiLCJvdHBfdGV4dCIsInZlcmlmeUZvcmdvdE9UUCIsImRpc3BsYXlOb3RpZmljYXRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlVmVyaWZ5T1RQIiwidmVyaWZ5UmVnaXN0ZXJNb2JpbGVPVFAiLCJoYW5kbGVPVFAiLCJzZW5kUmVnaXN0ZXJNb2JpbGVPVFAiLCJoYW5kbGVTZWxlY3RDb3VudHJ5Q29kZSIsImVycm9ycyIsImVycm9yX21zZyIsImJhY2tncm91bmRJbWFnZSIsImJhY2tncm91bmQiLCJiYWNrZ3JvdW5kU2l6ZSIsImJhY2tncm91bmRSZXBlYXQiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJoZWlnaHQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJsb2dvX2ltYWdlIiwiYm9yZGVyIiwiY3Vyc29yIiwiYm9yZGVyVG9wIiwicGFkZGluZ1RvcCIsInBhdHRlcm4iLCJSZWdFeHAiLCJtYXgiLCJ3aWR0aCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluZGV4T2YiLCJjb3VudHJ5RGV0YWlscyIsImluZGV4IiwicGhvbmVjb2RlIiwibWluIiwicGFkZGluZyIsImdldEZpZWxkVmFsdWUiLCJ2YWxpZGF0b3IiLCJydWxlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJGb290ZXJDb3B5cmlnaHQiLCJIZWFkZXJEZWZhdWx0Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInN0aWNreUhlYWRlciIsIk1pbmlDYXJ0IiwiUmVhY3QiLCJtZW1vIiwiY2FydCIsImNhcnRJdGVtc1ZpZXciLCJhdXRoIiwidXNlU2VsZWN0b3IiLCJzdGF0ZSIsInByb2R1Y3RJdGVtV2l0aFNlbGxlciIsInByb2R1Y3RJdGVtIiwic2VsbGVyIiwicHJvZHVjdHMiLCJjYXJ0UHJvZHVjdCIsInNlbGxlcl9pZCIsImNhcnRkYXRhIiwic2V0Q2FydGRhdGEiLCJ0b3RhbEl0ZW1zIiwic2V0VG90YWxJdGVtcyIsImlzTW91bnRlZCIsImNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlciIsInJlZHVjZSIsInByb2R1Y3RJdGVtUHJldiIsInByb2R1Y3RJdGVtTmV4dCIsIk51bWJlciIsImxlbmd0aCIsImdldENhcnRJdGVtIiwiYWxlcnQiLCJ1c2VyX3Rva2VuIiwiZ2V0RGV2aWNlSWQiLCJsYW5nX2lkIiwiZGV2aWNlX2lkIiwicGFnZV91cmwiLCJvc190eXBlIiwiY2FydF9jb3VudCIsImdldENhcnQiLCJjdXJyZW5jeUhlbHBlckNvbnZlcnRUb1JpbmdnaXQiLCJncmFuZF90b3RhbCIsImNvbm5lY3QiLCJleGFtcGxlQ2F0ZWdvcmllcyIsImNhdGVnb3J5X25hbWUiLCJ1c2VEZWJvdW5jZSIsImRlbGF5IiwiZGVib3VuY2VkVmFsdWUiLCJzZXREZWJvdW5jZWRWYWx1ZSIsImhhbmRsZXIiLCJjbGVhclRpbWVvdXQiLCJTZWFyY2hIZWFkZXIiLCJpbnB1dEVsIiwidXNlUmVmIiwiaXNTZWFyY2giLCJzZXRJc1NlYXJjaCIsImtleXdvcmQiLCJzZXRLZXl3b3JkIiwiY2F0ZWdvcnkiLCJzZXRDYXRlZ29yeSIsInJlc3VsdEl0ZW1zIiwic2V0UmVzdWx0SXRlbXMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImRlYm91bmNlZFNlYXJjaFRlcm0iLCJoYW5kbGVDbGVhcktleXdvcmQiLCJtZW51RGF0YUZyb21TZXJ2ZXIiLCJzZXRNZW51RGF0YUZyb21TZXJ2ZXIiLCJjYXRlZ29yeV9pZCIsImlzU3Vic2NyaWJlZCIsImZldGNoTWVudURhdGFGcm9tU2VydmVyIiwiUHJvZHVjdFJlcG9zaXRvcnkiLCJnZXRQcm9kdWN0Q2F0ZWdvcmllcyIsImNhdF9zdWJjYXQiLCJxdWVyaWVzIiwiX2xpbWl0IiwidGl0bGVfY29udGFpbnMiLCJnZXRTZWFyY2hlZFByb2R1Y3RzIiwicmVzdWx0IiwiaXRlbXMiLCJwcm9kdWN0SXRlbXNWaWV3IiwiY2xlYXJUZXh0VmlldyIsInNlbGVjdE9wdGlvblZpZXciLCJsb2FkaW5nVmlldyIsImxvYWRNb3JlVmlldyIsIk1lbnVDYXRlZ29yaWVzRHJvcGRvd24iLCJob21lZGF0YSIsImhvbWUiLCJtb2RhbE9wZW4iLCJnZXRVc2VyUHVyY2hhc2VZZWFycyIsIlJlcG9zaXRvcnkiLCJlcnIiLCJlZGl0Q3VzdG9tZXJQcm9maWxlIiwiZ2V0Q2hhdExpc3QiLCJtZXRob2QiLCJ1cmwiLCJnZXRDaGF0TWVzc2FnZSIsInNlbmRNZXNzYWdlIiwiZ2V0U3RhdGUiLCJnZXRDaXR5IiwiZ2V0TXlPcmRlcnMiLCJyZXBvbnNlIiwiY2FuY2VsT3JkZXJSZXF1ZXN0IiwiZ2V0T3JkZXJEZXRhaWxzIiwiZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsIiwidXBkYXRlQ3VzdG9tZXJQcm9maWxlRGV0YWlsIiwiZ2V0Q3VzdG9tZXJSZWNlbnRWaWV3cyIsImdldEN1c3RvbWVyQWRkcmVzc2VzIiwibWFrZURlZmF1bHRBZGRyZXNzZXMiLCJ1c2VyVXBkYXRlRm9ybURhdGEiLCJGb3JtRGF0YSIsImFwcGVuZCIsImFkZHJlc3NfaWQiLCJkZWZhdWx0IiwiZGVsZXRlQWRkcmVzcyIsImFkZEFkZHJlc3MiLCJ1cGRhdGVBZGRyZXNzIiwicmV0dXJuT3JkZXJSZXF1ZXN0IiwicmV0dXJuU2hpcG1lbnREZXRhaWwiLCJjcmVhdGVTdXBwb3J0VG9rZW4iLCJsaXN0U3VwcG9ydFRva2VuIiwic3VwcG9ydE1lc3NhZ2VCeUlEIiwiYWRkVGlja2V0TWVzc2FnZSIsImdldFdhbGxldERldGFpbHMiLCJnZXRBdWN0aW9uQ2FydERhdGEiLCJnZXRVc2VyTm90aWZpY2F0aW9uIiwiZ2V0QXVjdGlvbk9yZGVyTGlzdCIsIkhvbWVhcGkiLCJnZXRIb21lZGF0YSIsInBhdGhOYW1lIiwibWFrZVBhZ2VVcmwiLCJvc1R5cGUiLCJDYW5jZWxUb2tlbiIsImF4aW9zIiwic291cmNlIiwiY2FuY2VsIiwiY2FuY2VsVG9rZW4iLCJzdWJtaXRSZXZpZXciLCJzdWJtaXRTZWxsZXJSZXZpZXciLCJnZXRSZWNvcmRzIiwicGFyYW1zIiwiZ2V0IiwiYmFzZVVybCIsInNlcmlhbGl6ZVF1ZXJ5Iiwibm9fb2ZfcHJvZHVjdHMiLCJnZXRQcm9kdWN0cyIsInBhZ2UiLCJ0b3RhbF9wcm9kdWN0cyIsImdldE5ld0RlYWxzUHJvZHVjdHMiLCJnZXRTaG9ja2luZ1NhbGVQcm9kdWN0cyIsInNob2NrX3NhbGUiLCJnZXRGZWF0dXJlZFByb2R1Y3RzIiwiZ2V0UHJvZHVjdHNieUZpbHRlciIsImdldE5ld0RlYWxzUHJvZHVjdHNieUZpbHRlciIsImdldFNob2NraW5nU2FsZVByb2R1Y3RzYnlGaWx0ZXIiLCJnZXRGZWF0dXJlZFByb2R1Y3RzYnlGaWx0ZXIiLCJnZXRTaG9ja2luZ1Byb2R1Y3RzIiwiZ2V0QnJhbmRzIiwiZ2V0VG90YWxSZWNvcmRzIiwiZ2V0UHJvZHVjdHNCeUlkIiwiYmFzZVBhdGhVcmwiLCJnZXRTaG9ja1NhbGVCeWlkIiwiZ2V0UHJvZHVjdHNCeUNhdGVnb3J5IiwiZ2V0UHJvZHVjdHNCeUJyYW5kIiwiZ2V0UHJvZHVjdHNCeUJyYW5kcyIsInF1ZXJ5IiwiZm9yRWFjaCIsIml0ZW0iLCJnZXRQcm9kdWN0c0J5UHJpY2VSYW5nZSIsImFkZFByb2R1Y3RUb0NhcnQiLCJjaGFuZ2VRdHkiLCJwbGFjZU9yZGVyIiwiZGVsZXRlQ2FydCIsImdldEF1Y3Rpb25Qcm9kdWN0QnlBdWN0aW9uSWQiLCJjcmVhdGVCaWQiLCJnZXRTaG9wRGV0YWlsQnlJZCIsImdldENoZWNrb3V0SW5mbyIsInBsYWNlQXVjdGlvbk9yZGVyIiwiYmFzZURvbWFpbiIsImJhc2VQb3N0VXJsIiwiYmFzZVN0b3JlVVJMIiwiYXBpYmFzZXVybEN1c3RvbSIsImJhc2VQYXRoIiwibG9jYXRpb24iLCJob3N0bmFtZSIsImN1c3RvbUhlYWRlcnMiLCJBY2NlcHQiLCJjcmVhdGUiLCJPYmplY3QiLCJrZXlzIiwia2V5IiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwiam9pbiIsImFjdGlvblR5cGVzIiwiR0VUX0NBUlQiLCJHRVRfQ0FSVF9TVUNDRVNTIiwiR0VUX0NBUlRfRVJST1IiLCJHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWSIsIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZX1NVQ0NFU1MiLCJBRERfSVRFTSIsIlJFTU9WRV9JVEVNIiwiUkVNT1ZFX1BST0RVQ1RfRlJPTV9DQVJUX05FVyIsIkNMRUFSX0NBUlQiLCJDTEVBUl9DQVJUX1NVQ0NFU1MiLCJDTEVBUl9DQVJUX0VSUk9SIiwiSU5DUkVBU0VfUVRZIiwiSU5DUkVBU0VfUVRZX1NVQ0NFU1MiLCJJTkNSRUFTRV9RVFlfRVJST1IiLCJERUNSRUFTRV9RVFkiLCJVUERBVEVfQ0FSVCIsIlVQREFURV9DQVJUX1NVQ0NFU1MiLCJVUERBVEVfQ0FSVF9FUlJPUiIsIlVQREFURV9TRUxFQ1RFRF9BRERSRVNTIiwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUiIsIkZFVENIX1BMQVRGT1JNX1ZPVUNIRVJfU1VDQ0VTUyIsIlRPVEFMX0RJU0NPVU5UIiwiQVBQTElFRF9TRUxMRVJfVk9VQ0hFUiIsIkFQUExJRURfUExBVEZPUk1fVk9VQ0hFUiIsIkdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUUiLCJTRUxMRVJfV0lTRV9ESVNDT1VOVCIsIlNFTExFUl9XSVNFX01FU1NBR0VTIiwiVVNFRF9XQUxMRVRfQU1PVU5UIiwiU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUiIsInNlbGVjdGVkUGF5bWVudE9wdGlvbiIsInNlbGxlcldpc2VNZXNzYWdlIiwidXNlZFdhbGxldEFtb3VudCIsInNlbGxlcldpc2VEaXNjb3VudCIsImdyYW5kVG90YWxXaXRoRGlzY291bnRWYWx1ZSIsImFwcGxpZWRTZWxsZXJWb3VjaGVyIiwiYXBwbGllZFBsYXRmb3JtVm91Y2hlciIsInRvdGFsRGlzY291bnQiLCJmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbiIsImZldGNoUGxhdGZvcm1Wb3VjaGVyQWN0aW9uU3VjY2VzcyIsImdldENhcnRTdWNjZXNzIiwiZ2V0Q2FydEVycm9yIiwidXBkYXRlU2VsZWN0ZWRBZGRyZXNzIiwiYWRkSXRlbSIsInJlbW92ZUl0ZW0iLCJpbmNyZWFzZUl0ZW1RdHkiLCJkZWNyZWFzZUl0ZW1RdHkiLCJ1cGRhdGVDYXJ0U3VjY2VzcyIsInVwZGF0ZUNhcnRFcnJvciIsImNsZWFyQ2FydCIsImNsZWFyQ2FydFN1Y2Nlc3MiLCJleGFjdE1hdGgiLCJyZXF1aXJlIiwicm91dGVXaXRob3V0UmVmcmVzaCIsInJvdXRlTGluayIsInJlcGxhY2UiLCJzaGFsbG93IiwiaG9tZVBhZ2VQcm9kdWN0UHJpY2VIZWxwZXIiLCJvZmZlcl9wcmljZSIsInNob2NrX3NhbGVfcHJpY2UiLCJyZXR1cm5Ub3RhbE9mQ2FydFZhbHVlIiwiY2FydF90b3RhbF9wcmljZSIsInByZXYiLCJuZXh0IiwicHJpY2VIZWxwZXIiLCJ0b3RhbF9kaXNjb3VudF9wcmljZSIsInRvdGFsX2FjdHVhbF9wcmljZSIsInJldHVyblRvdGFsQ29tbWlzc2lvbiIsImNhcnRfdG90YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJyZXR1cm5Ub3RhbE9mQ2FydFRheFZhbHVlIiwiY2FydF90b3RhbF90YXgiLCJ0b3RhbF90YXhfdmFsdWUiLCJudW0iLCJudW1iZXJBcnJheSIsImN1cnJlbmN5VmFsIiwiSW50bCIsIk51bWJlckZvcm1hdCIsImN1cnJlbmN5IiwiZm9ybWF0IiwibWF0aEZvcm11bGEiLCJmb3JtdWxhVGV4dCIsImZvcm11bGEiLCJkaXZDdXJyZW5jeSIsImZpcnN0VmFsIiwic2Vjb25kVmFsIiwiZGl2RGF0YSIsImRpdiIsIm11bEN1cnJlbmN5IiwibXVsRGF0YSIsIm11bCIsImFkZEN1cnJlbmN5IiwiY3VycmVuY3lWYWxGaXJzdCIsImN1cnJlbmN5VmFsU2Vjb25kIiwiYWRkRGF0YSIsImFkZCIsInN1YkN1cnJlbmN5Iiwic3ViRGF0YSIsInN1YiIsImZvcm1hdEN1cnJlbmN5IiwicGFyc2VGbG9hdCIsImdldENvbGxldGlvbkJ5U2x1ZyIsImNvbGxlY3Rpb25zIiwic2x1ZyIsImZpbmQiLCJnZXRJdGVtQnlTbHVnIiwiYmFubmVycyIsImJhbm5lciIsImNvbnZlcnRTbHVnc1F1ZXJ5U3RyaW5nIiwiU3RyYXBpUHJvZHVjdEJhZGdlIiwidmlldyIsImJhZGdlIiwiU3RyYXBpUHJvZHVjdFByaWNlIiwiaXNfc2FsZSIsInByaWNlIiwiU3RyYXBpUHJvZHVjdFByaWNlX05ldyIsImZlYXR1cmVwcm9kdWN0cHJpY2UiLCJTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZCIsIlN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIiLCJvZmZlciIsIlN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIxIiwiU3RyYXBpUHJvZHVjdFRodW1ibmFpbCIsInRodW1ibmFpbCIsIlN0cmFwaVByb2R1Y3RUaHVtYm5haWxPdGhlciIsIlN0cmFwaVByb2R1Y3RUaHVtYm5haWxEZXRhaWwiLCJTaG9ja2luZ3Byb2R1Y3R0aHVtYm5haWwiLCJjb2xvckhlbHBlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1BLGFBQWEsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFpQjtBQUFBOztBQUFBOztBQUNyQyxRQUFNQyxRQUFRLEdBQUdDLCtEQUFXLEVBQTVCOztBQUNBLFFBQU1DLG9CQUFvQixHQUFHLE1BQU9ILE9BQVAsSUFBbUI7QUFDOUM7QUFDQSxRQUFJSSxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmOztBQUNBLFFBQUlGLFFBQVEsS0FBS0csU0FBYixJQUEwQkgsUUFBUSxLQUFLLElBQTNDLEVBQWlEO0FBQy9DSSx1REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsZUFBTyxFQUFFLE9BRFc7QUFFcEJDLG1CQUFXLEVBQUUsb0JBRk87QUFHcEJDLGdCQUFRLEVBQUU7QUFIVSxPQUF0QjtBQUtBLGFBQU8sS0FBUDtBQUNELEtBUEQsTUFPTztBQUNMLFVBQUlDLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdWLFFBQVgsQ0FBaEI7QUFDQSxVQUFJVyxLQUFLLEdBQUdILFNBQVMsQ0FBQ0ksWUFBdEI7QUFDQSxVQUFJQyxPQUFPLEdBQUc7QUFDWkMsZUFBTyxFQUFFLENBQUNsQixPQUFPLENBQUNrQixPQUFULENBREc7QUFFWkYsb0JBQVksRUFBRUQ7QUFGRixPQUFkO0FBSUFJLGdEQUFLLENBQUNDLE9BQU4sQ0FBYztBQUNaQyxhQUFLLEVBQUUsc0JBREs7QUFFWkMsWUFBSSxFQUFFLFVBQVVDLENBQVYsRUFBYTtBQUNqQnRCLGtCQUFRLENBQUN1QixtRkFBd0IsQ0FBQ1AsT0FBRCxDQUF6QixDQUFSO0FBQ0FFLG9EQUFLLENBQUNNLFVBQU47QUFDRCxTQUxXO0FBTVpDLGdCQUFRLEVBQUUsVUFBVUgsQ0FBVixFQUFhO0FBQ3JCSixvREFBSyxDQUFDTSxVQUFOO0FBQ0QsU0FSVztBQVNaRSxxQkFBYSxFQUFFO0FBQ2JDLGdCQUFNLEVBQUU7QUFESztBQVRILE9BQWQ7QUFhRDtBQUNGLEdBL0JEOztBQWlDQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyx5QkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLHVCQUFmO0FBQUEsNkJBRUU7QUFDRSxXQUFHLEVBQUUsQ0FBQTVCLE9BQU8sU0FBUCxJQUFBQSxPQUFPLFdBQVAsK0JBQUFBLE9BQU8sQ0FBRTZCLEtBQVQsQ0FBZSxDQUFmLHFFQUFtQkEsS0FBbkIsS0FBNEIsMkJBRG5DO0FBRUUsZUFBTyxFQUFHTixDQUFELElBQU87QUFDZEEsV0FBQyxDQUFDTyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQVIsV0FBQyxDQUFDTyxNQUFGLENBQVNFLEdBQVQsR0FBZSwyQkFBZjtBQUNELFNBTEg7QUFNRSxXQUFHLEVBQUMsU0FOTjtBQU9FLGFBQUssRUFBQztBQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBYUU7QUFBSyxlQUFTLEVBQUMscUJBQWY7QUFBQSw4QkFDRTtBQUNFLGlCQUFTLEVBQUMsb0JBRFo7QUFFRSxlQUFPLEVBQUdULENBQUQsSUFBT3BCLG9CQUFvQixDQUFDSCxPQUFELENBRnRDO0FBQUEsK0JBSUU7QUFBRyxtQkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFPRSxxRUFBQyxnREFBRDtBQUFNLFlBQUksRUFBQyxnQkFBWDtBQUE0QixVQUFFLEVBQUcsWUFBV0EsT0FBTyxDQUFDaUMsVUFBVyxFQUEvRDtBQUFBLCtCQUNFO0FBQUcsbUJBQVMsRUFBQyxtQkFBYjtBQUFBLHFCQUNHakMsT0FBTyxDQUFDa0MsWUFEWCxFQUVHbEMsT0FBTyxDQUFDbUMsVUFBUixHQUNJLEtBQUluQyxPQUFPLENBQUNtQyxVQUFXLEdBQ3RCbkMsT0FBTyxDQUFDb0MsVUFBUixHQUFzQixJQUFHcEMsT0FBTyxDQUFDb0MsVUFBVyxFQUE1QyxHQUFnRCxFQUNqRCxHQUhKLEdBSUcsRUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGLGVBaUJFO0FBQUEsK0JBQ0U7QUFBQSwyQkFDSyxHQURMLEVBRUdwQyxPQUFPLENBQUNxQyxtQkFBUixLQUFnQyxLQUFoQyxnQkFDQztBQUFBLHVCQUNHLEdBREgsZUFFRTtBQUFBLHdCQUFNckMsT0FBTyxDQUFDc0M7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGLEVBRXlDLEdBRnpDLEVBR0d0QyxPQUFPLENBQUNxQyxtQkFIWDtBQUFBLDBCQURELEdBT0NyQyxPQUFPLENBQUNzQyxpQkFUWixFQVVLLEdBVkwsUUFXS3RDLE9BQU8sQ0FBQ3VDLFFBWGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBaURELENBcEZEOztHQUFNeEMsYTtVQUNhRyx1RDs7O0tBRGJILGE7QUFzRlNBLDRFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVGQTtBQUNBO0FBQ0E7QUFFQTtBQUlBOztBQUVBLE1BQU15QyxtQkFBbUIsR0FBRyxDQUFDO0FBQUV4QztBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFDM0Msc0JBQ0U7QUFBSyxhQUFTLEVBQUMsdURBQWY7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyx1QkFBZjtBQUFBLGdCQUdHQSxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLHVCQUFBQSxPQUFPLENBQUU2QixLQUFULENBQWUsQ0FBZiw2REFBbUJBLEtBQW5CLGdCQUNDLHFFQUFDLGdEQUFEO0FBQU0sWUFBSSxFQUFDLGdCQUFYO0FBQTRCLFVBQUUsRUFBRyxZQUFXN0IsT0FBTyxDQUFDeUMsRUFBRyxFQUF2RDtBQUFBLCtCQUNFO0FBQUEsaUNBQ0UscUVBQUMscURBQUQ7QUFBQSxtQ0FDRTtBQUFLLGlCQUFHLEVBQUV6QyxPQUFGLGFBQUVBLE9BQUYsMkNBQUVBLE9BQU8sQ0FBRTZCLEtBQVQsQ0FBZSxDQUFmLENBQUYscURBQUUsaUJBQW1CQSxLQUE3QjtBQUFvQyxpQkFBRyxFQUFFN0IsT0FBTyxDQUFDcUI7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERCxnQkFTQyxxRUFBQyxnREFBRDtBQUFNLFlBQUksRUFBQyxnQkFBWDtBQUE0QixVQUFFLEVBQUcsWUFBV3JCLE9BQU8sQ0FBQ3lDLEVBQUcsRUFBdkQ7QUFBQSwrQkFDRTtBQUFBLGlDQUNFLHFFQUFDLHFEQUFEO0FBQUEsbUNBQ0U7QUFBSyxpQkFBRyxFQUFDLDJCQUFUO0FBQXFDLGlCQUFHLEVBQUM7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFzQkU7QUFBSyxlQUFTLEVBQUMscUJBQWY7QUFBQSw4QkFDRSxxRUFBQyxnREFBRDtBQUFNLFlBQUksRUFBQyxnQkFBWDtBQUE0QixVQUFFLEVBQUcsWUFBV3pDLE9BQU8sQ0FBQ3lDLEVBQUcsRUFBdkQ7QUFBQSwrQkFDRTtBQUFHLG1CQUFTLEVBQUMsbUJBQWI7QUFBQSxvQkFBa0N6QyxPQUFPLENBQUNrQztBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQUssaUJBQVMsRUFBQyxvQkFBZjtBQUFBLCtCQUNFLHFFQUFDLG1FQUFEO0FBQVEsZ0JBQU0sRUFBRWxDLE9BQU8sQ0FBQzBDO0FBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLEVBUUcxQyxPQUFPLENBQUMyQyxVQUFSLEdBQXFCLENBQXJCLGdCQUNDO0FBQUcsaUJBQVMsRUFBQyx3QkFBYjtBQUFBLDBCQUNNM0MsT0FBTyxDQUFDMkMsVUFEZCxlQUVFO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUEsNEJBQTBCM0MsT0FBTyxDQUFDNEMsWUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERCxnQkFNQztBQUFHLGlCQUFTLEVBQUMsd0JBQWI7QUFBQSwwQkFBMEM1QyxPQUFPLENBQUM0QyxZQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTBDRCxDQTNDRDs7S0FBTUosbUI7QUE0Q1NBLGtGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3REQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0FFQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUssS0FBSyxHQUFJQyxLQUFELElBQVc7QUFBQTs7QUFDdkIsUUFBTSxDQUFDQyxJQUFELElBQVNDLHlDQUFJLENBQUNDLE9BQUwsRUFBZjtBQUNBLFFBQU1DLGtCQUFrQixHQUFHO0FBQ3pCQyxTQUFLLEVBQUUsU0FEa0I7QUFFekJDLFFBQUksRUFBRSxVQUZtQjtBQUd6QkMsYUFBUyxFQUFFLEtBSGM7QUFJekJDLGtCQUFjLEVBQUUsRUFKUztBQUt6QkMsbUJBQWUsRUFBRTtBQUxRLEdBQTNCO0FBT0EsUUFBTTtBQUFBLE9BQUNDLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCQyxzREFBUSxDQUFDLEtBQUQsQ0FBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJGLHNEQUFRLENBQUNSLGtCQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNXLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCSixzREFBUSxDQUFDO0FBQy9CSyxTQUFLLEVBQUUsRUFEd0I7QUFFL0JDLFlBQVEsRUFBRTtBQUZxQixHQUFELENBQWhDOztBQUlBLFFBQU1DLE9BQU8sZ0JBQUcscUVBQUMsa0VBQUQ7QUFBaUIsU0FBSyxFQUFFO0FBQUVDLGNBQVEsRUFBRTtBQUFaLEtBQXhCO0FBQTBDLFFBQUk7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFoQjs7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUE4QlYsc0RBQVEsQ0FBQyxFQUFELENBQTVDO0FBQ0EsUUFBTTtBQUNKVyxjQURJO0FBRUpDLGFBRkk7QUFHSkMsU0FISTtBQUlKQyxnQkFKSTtBQUtKUixZQUxJO0FBTUpTLHlCQU5JO0FBT0pDO0FBUEksTUFRRmIsSUFSSjtBQVNBLFFBQU07QUFBQSxPQUFDYyxVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUE0QmxCLHNEQUFRLENBQUMsS0FBRCxDQUExQztBQUNBLFFBQU07QUFBQSxPQUFDbUIsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0JwQixzREFBUSxDQUFDLEVBQUQsQ0FBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3FCLGFBQUQ7QUFBQSxPQUFnQkM7QUFBaEIsTUFBaUN0QixzREFBUSxDQUFDLEVBQUQsQ0FBL0M7QUFDQSxRQUFNO0FBQUEsT0FBQ3VCLGdCQUFEO0FBQUEsT0FBbUJDO0FBQW5CLE1BQTBDeEIsc0RBQVEsQ0FBQyxJQUFELENBQXhEO0FBQ0EsUUFBTTtBQUFFSztBQUFGLE1BQVlGLElBQWxCOztBQUVBLFFBQU1zQixhQUFhLEdBQUcsWUFBWTtBQUNqQztBQUNDLFFBQUlsRSxPQUFPLEdBQUc7QUFFWm1FLGlCQUFXLEVBQUVMLGFBRkQ7QUFHWmYsY0FBUSxFQUFFSCxJQUFJLENBQUNHLFFBSEg7QUFJWlMsMkJBQXFCLEVBQUVaLElBQUksQ0FBQ1k7QUFKaEIsS0FBZDs7QUFPQSxRQUFJO0FBQ0YsWUFBTVksTUFBTSxHQUFHLE1BQU1DLHVFQUFpQixDQUFDQyxjQUFsQixDQUFpQ3RFLE9BQWpDLENBQXJCO0FBQ0F1RSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWixFQUE2QzVCLElBQTdDO0FBQ04yQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUE4Q0osTUFBOUM7O0FBQ00sVUFBSUEsTUFBTSxDQUFDSyxRQUFQLElBQW1CLEdBQW5CLElBQTBCTCxNQUFNLENBQUNNLE9BQXJDLEVBQThDO0FBQzVDbEYsb0RBQU8sQ0FBQ2tGLE9BQVIsQ0FBZ0IscUNBQWhCLEVBRDRDLENBRTVDO0FBQ0Q7O0FBQ0QsVUFBSU4sTUFBTSxDQUFDTyxLQUFYLEVBQWtCO0FBQ2hCUCxjQUFNLENBQUNPLEtBQVAsQ0FBYUMsR0FBYixDQUFrQkQsS0FBRCxJQUFXO0FBQzFCcEYsMkRBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLG1CQUFPLEVBQUVtRjtBQURXLFdBQXRCO0FBR0QsU0FKRDtBQUtEO0FBQ0YsS0FmRCxDQWVFLE9BQU9FLFNBQVAsRUFBa0I7QUFDbEJOLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJLLFNBQXZCO0FBQ0Q7QUFDRixHQTNCRDs7QUE0QkEsUUFBTUMsWUFBWSxHQUFHLFlBQVk7QUFDL0IsUUFBSTlFLE9BQU8sR0FBRztBQUNab0QsZ0JBQVUsRUFBRVIsSUFBSSxDQUFDUSxVQURMO0FBRVpDLGVBQVMsRUFBRVQsSUFBSSxDQUFDUyxTQUZKO0FBR1pJLGtCQUFZLEVBQUViLElBQUksQ0FBQ2EsWUFIUDtBQUlaRixrQkFBWSxFQUFFWCxJQUFJLENBQUNXLFlBSlA7QUFLWkQsV0FBSyxFQUFFVixJQUFJLENBQUNVLEtBTEE7QUFNWlAsY0FBUSxFQUFFSCxJQUFJLENBQUNHLFFBTkg7QUFPWlMsMkJBQXFCLEVBQUVaLElBQUksQ0FBQ1k7QUFQaEIsS0FBZDs7QUFVQSxRQUFJO0FBQ0YsWUFBTVksTUFBTSxHQUFHLE1BQU1DLHVFQUFpQixDQUFDVSxlQUFsQixDQUFrQ25DLElBQWxDLENBQXJCO0FBQ0EyQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQ0FBWixFQUE2QzVCLElBQTdDO0FBQ04yQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwyQkFBWixFQUF3Q0osTUFBeEM7O0FBQ00sVUFBSUEsTUFBTSxDQUFDSyxRQUFQLElBQW1CLEdBQW5CLElBQTBCTCxNQUFNLENBQUNNLE9BQXJDLEVBQThDO0FBQzVDbEYsb0RBQU8sQ0FBQ2tGLE9BQVIsQ0FBZ0Isa0NBQWhCLEVBRDRDLENBRTVDO0FBQ0Q7O0FBQ0QsVUFBSU4sTUFBTSxDQUFDTyxLQUFYLEVBQWtCO0FBQ2hCUCxjQUFNLENBQUNPLEtBQVAsQ0FBYUMsR0FBYixDQUFrQkQsS0FBRCxJQUFXO0FBQzFCcEYsMkRBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLG1CQUFPLEVBQUVtRjtBQURXLFdBQXRCO0FBR0QsU0FKRDtBQUtEO0FBQ0YsS0FmRCxDQWVFLE9BQU9FLFNBQVAsRUFBa0I7QUFDbEJOLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJLLFNBQXZCO0FBQ0Q7QUFDRixHQTdCRDs7QUE4QkEsUUFBTUcsdUJBQXVCLEdBQUkxRSxDQUFELElBQU87QUFDckNBLEtBQUMsQ0FBQzJFLGNBQUY7QUFDQTFGLHFEQUFZLENBQUMyRixJQUFiLENBQWtCO0FBQ2hCMUYsYUFBTyxFQUFFLDRCQURPO0FBRWhCQyxpQkFBVyxFQUFFLHNDQUZHO0FBR2hCQyxjQUFRLEVBQUU7QUFITSxLQUFsQjtBQUtELEdBUEQ7O0FBUUF5Rix5REFBUyxDQUFDLE1BQU07QUFDZEMsZ0JBQVk7QUFDYixHQUZRLEVBRU4sRUFGTSxDQUFUOztBQUdBLGlCQUFlQSxZQUFmLEdBQThCO0FBQzVCLFVBQU1DLHFCQUFxQixHQUFHLE1BQU1oQix1RUFBaUIsQ0FBQ2lCLFVBQWxCLEVBQXBDO0FBQ0FuQyxjQUFVLENBQUMsQ0FBQyxHQUFHa0MscUJBQXFCLENBQUNFLE9BQTFCLENBQUQsQ0FBVjtBQUNBLFdBQU8sSUFBUDtBQUNEOztBQUNELFFBQU1DLFlBQVksR0FBSUMsSUFBRCxJQUFXQyxLQUFELElBQVc7QUFDeEM3QyxXQUFPLGlDQUFNRCxJQUFOO0FBQVksT0FBQzZDLElBQUQsR0FBUUMsS0FBSyxDQUFDN0UsTUFBTixDQUFhOEU7QUFBakMsT0FBUDtBQUNELEdBRkQ7O0FBSUEsUUFBTTNHLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7O0FBRUEsV0FBUzJHLFNBQVQsQ0FBbUJDLGFBQW5CLEVBQWtDQyxlQUFsQyxFQUFtRDtBQUNqRCxRQUFJQyxZQUFZLEdBQUcsRUFBbkI7QUFDQTdGLDhDQUFLLENBQUM4RixJQUFOLENBQVc7QUFDVDVGLFdBQUssRUFBRSw4Q0FERTtBQUVUNkYsYUFBTyxlQUNMLHFFQUFDLHlDQUFEO0FBQU0sWUFBSSxFQUFFbkUsSUFBWjtBQUFrQixnQkFBUSxFQUFFb0UsaUJBQTVCO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFlBQWY7QUFBQSxpQ0FDRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFLENBQ0w7QUFDRUMsc0JBQVEsRUFBRSxJQURaO0FBRUUzRyxxQkFBTyxFQUFFO0FBRlgsYUFESyxDQUZUO0FBQUEsbUNBU0UscUVBQUMsMENBQUQ7QUFDRSx1QkFBUyxFQUFDLGNBRFo7QUFFRSxrQkFBSSxFQUFDLE1BRlA7QUFHRSx5QkFBVyxFQUFDLGlCQUhkO0FBSUUsc0JBQVEsRUFBR2MsQ0FBRCxJQUFPO0FBQ2Z5Riw0QkFBWSxHQUFHekYsQ0FBQyxDQUFDTyxNQUFGLENBQVM4RSxLQUF4QjtBQUNEO0FBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhPOztBQTBCVHRGLFVBQUksR0FBRztBQUNMLFlBQUkrRixXQUFXLEdBQUdDLGdEQUFNLEVBQXhCO0FBQ0EsWUFBSUMsUUFBUSxHQUFHRCxnREFBTSxFQUFyQjtBQUNBLFlBQUlFLFVBQVUsR0FBRyxRQUFqQjtBQUNBLFlBQUlDLEVBQUUsR0FBRyxLQUFUO0FBQ0EsWUFBSTFELEtBQUssR0FBR2dELGVBQVosQ0FMSyxDQU1MOztBQUNBLFlBQUlXLEdBQUcsR0FBSSxHQUFFWixhQUFjLEVBQTNCO0FBRUEsY0FBTWEsSUFBSSxHQUFHQyw0Q0FBSyxDQUFDQyxJQUFOLENBQ1YsR0FBRUMsbUVBQVcsMEJBREgsRUFFWDtBQUNFL0QsZUFERjtBQUVFMkQsYUFGRjtBQUdFTCxxQkFIRjtBQUlFRSxrQkFKRjtBQUtFQyxvQkFMRjtBQU1FQztBQU5GLFNBRlcsRUFVWDtBQUNFTSxpQkFBTyxFQUFFO0FBQ1AsNEJBQWdCO0FBRFQ7QUFEWCxTQVZXLEVBZ0JWQyxJQWhCVSxDQWdCSkMsUUFBRCxJQUFjQSxRQUFRLENBQUNOLElBaEJsQixFQWlCVkssSUFqQlUsQ0FpQkpMLElBQUQsSUFBVTtBQUNkLGNBQUlBLElBQUksQ0FBQ2pDLFFBQUwsSUFBaUIsR0FBakIsSUFBd0JpQyxJQUFJLENBQUNPLE1BQUwsSUFBZSxPQUEzQyxFQUFvRDtBQUNsRCxrQkFBTUMsSUFBSSxHQUFHO0FBQ1gxSCxxQkFBTyxFQUFFa0gsSUFBSSxDQUFDbEgsT0FESDtBQUVYMkgsa0JBQUksRUFBRTtBQUZLLGFBQWI7QUFJQTVILDZEQUFZLENBQUMyRixJQUFiLENBQWtCZ0MsSUFBbEI7QUFDQTtBQUNEOztBQUNELGNBQUlSLElBQUksQ0FBQ2pDLFFBQUwsSUFBaUIsR0FBakIsSUFBd0JpQyxJQUFJLENBQUNPLE1BQUwsSUFBZSxTQUEzQyxFQUFzRDtBQUNwRDFILDZEQUFZLENBQUMsU0FBRCxDQUFaLENBQXdCO0FBQ3RCQyxxQkFBTyxFQUFFa0gsSUFBSSxDQUFDbEg7QUFEUSxhQUF4QjtBQUdBSix3QkFBWSxDQUFDZ0ksT0FBYixDQUFxQixNQUFyQixFQUE2QnhILElBQUksQ0FBQ3lILFNBQUwsQ0FBZVgsSUFBSSxDQUFDQSxJQUFwQixDQUE3QjtBQUNBMUgsb0JBQVEsQ0FBQ3NJLEtBQUssQ0FBQ1osSUFBSSxDQUFDQSxJQUFOLENBQU4sQ0FBUjtBQUNBYSw4REFBTSxDQUFDQyxJQUFQLENBQVksR0FBWjtBQUNBO0FBQ0Q7QUFDRixTQW5DVSxFQW9DVkMsS0FwQ1UsQ0FvQ0g5QyxLQUFELElBQVc7QUFDaEJwRiwyREFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsbUJBQU8sRUFBRW1GO0FBRFcsV0FBdEI7QUFHQWQsb0JBQVUsQ0FBQyxFQUFELENBQVY7QUFDRCxTQXpDVSxDQUFiO0FBMENELE9BN0VROztBQThFVDZELGNBQVEsR0FBRztBQUNUbkkseURBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJDLGlCQUFPLEVBQUU7QUFEVyxTQUF0QjtBQUdELE9BbEZROztBQW1GVG1JLGNBQVEsRUFBRSxLQW5GRDtBQW9GVEMsY0FBUSxFQUFFO0FBcEZELEtBQVg7QUFzRkQ7O0FBR0QsUUFBTU4sS0FBSyxHQUFJLE1BQU07QUFDdkJPLFlBQVEsQ0FBQ0MsY0FBVCxDQUF3QixTQUF4QixFQUFtQ0MsS0FBbkMsQ0FBeUNDLE9BQXpDLEdBQWlELE9BQWpEO0FBQ0FILFlBQVEsQ0FBQ0MsY0FBVCxDQUF3QixZQUF4QixFQUFzQ0MsS0FBdEMsQ0FBNENDLE9BQTVDLEdBQW9ELE1BQXBEO0FBQ0FILFlBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixFQUF1Q0MsS0FBdkMsQ0FBNkNDLE9BQTdDLEdBQXFELE1BQXJEO0FBQ0csR0FKRDs7QUFLQSxRQUFNQyxHQUFHLEdBQUksTUFBTTtBQUNqQkosWUFBUSxDQUFDQyxjQUFULENBQXdCLFlBQXhCLEVBQXNDQyxLQUF0QyxDQUE0Q0MsT0FBNUMsR0FBb0QsT0FBcEQ7QUFDQUgsWUFBUSxDQUFDQyxjQUFULENBQXdCLFNBQXhCLEVBQW1DQyxLQUFuQyxDQUF5Q0MsT0FBekMsR0FBaUQsTUFBakQ7QUFFRUgsWUFBUSxDQUFDQyxjQUFULENBQXdCLGFBQXhCLEVBQXVDQyxLQUF2QyxDQUE2Q0MsT0FBN0MsR0FBcUQsTUFBckQ7QUFHQyxHQVBMOztBQVFJLFFBQU1FLE1BQU0sR0FBSSxNQUFNO0FBQ3BCTCxZQUFRLENBQUNDLGNBQVQsQ0FBd0IsYUFBeEIsRUFBdUNDLEtBQXZDLENBQTZDQyxPQUE3QyxHQUFxRCxPQUFyRDtBQUNBSCxZQUFRLENBQUNDLGNBQVQsQ0FBd0IsU0FBeEIsRUFBbUNDLEtBQW5DLENBQXlDQyxPQUF6QyxHQUFpRCxNQUFqRDtBQUNBSCxZQUFRLENBQUNDLGNBQVQsQ0FBd0IsWUFBeEIsRUFBc0NDLEtBQXRDLENBQTRDQyxPQUE1QyxHQUFvRCxNQUFwRDtBQUNHLEdBSkw7O0FBTUksUUFBTUcsZ0JBQWdCLEdBQUcsWUFBWTtBQUNuQzNGLGlCQUFhLENBQUMsSUFBRCxDQUFiO0FBQ0UrQixXQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWixFQUF3QzVCLElBQUksQ0FBQ2EsWUFBN0M7QUFDRixRQUFJekQsT0FBTyxHQUFHO0FBQ1p5RCxrQkFBWSxFQUFFYixJQUFJLENBQUNhLFlBQUwsQ0FBa0IyRSxLQUFsQixDQUF3QixHQUF4QixFQUE2QixDQUE3QixDQURGO0FBRVo3RSxrQkFBWSxFQUFFWCxJQUFJLENBQUNXLFlBRlA7QUFHWmtELFNBQUcsRUFBRTdELElBQUksQ0FBQ3lGO0FBSEUsS0FBZDtBQU1BLFVBQU1yQixRQUFRLEdBQUcsTUFBTTNDLHVFQUFpQixDQUFDaUUsZUFBbEIsQ0FBa0N0SSxPQUFsQyxDQUF2QjtBQUNBK0QsaUJBQWEsQ0FBQ2lELFFBQVEsQ0FBQzdDLFdBQVYsQ0FBYjtBQUNKSSxXQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFzQ3dDLFFBQXRDOztBQUNJLFFBQUlBLFFBQVEsQ0FBQ3ZDLFFBQVQsSUFBcUIsR0FBekIsRUFBOEI7QUFDNUI4RCw0RkFBbUIsQ0FBQ3ZCLFFBQVEsQ0FBQ0MsTUFBVixFQUFrQkQsUUFBUSxDQUFDQyxNQUEzQixFQUFtQ0QsUUFBUSxDQUFDeEgsT0FBNUMsQ0FBbkI7QUFDQW1ELGtCQUFZLENBQUM7QUFDWFQsYUFBSyxFQUFFLFNBREk7QUFFWEMsWUFBSSxFQUFFLFVBRks7QUFHWEMsaUJBQVMsRUFBRSxLQUhBO0FBSVhDLHNCQUFjLEVBQUVPLElBQUksQ0FBQ1csWUFKVjtBQUtYakIsdUJBQWUsRUFBRTtBQUxOLE9BQUQsQ0FBWjtBQVFBa0csZ0JBQVUsQ0FBQyxNQUFNO0FBQ2ZoRyxxQkFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNELE9BRlMsRUFFUCxHQUZPLENBQVY7QUFHRCxLQWJELE1BYU87QUFDTCtGLDRGQUFtQixDQUFDdkIsUUFBUSxDQUFDQyxNQUFWLEVBQWtCRCxRQUFRLENBQUNDLE1BQTNCLEVBQW1DRCxRQUFRLENBQUN4SCxPQUE1QyxDQUFuQjtBQUNBZ0osZ0JBQVUsQ0FBQyxNQUFNO0FBQ2ZoRyxxQkFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNELE9BRlMsRUFFUCxHQUZPLENBQVY7QUFHRDtBQUNGLEdBL0JEOztBQWdDSixRQUFNaUcsZUFBZSxHQUFHLFlBQVk7QUFDbENqRyxpQkFBYSxDQUFDLElBQUQsQ0FBYjtBQUNBLFFBQUl4QyxPQUFPLEdBQUc7QUFDWnlELGtCQUFZLEVBQUViLElBQUksQ0FBQ2EsWUFEUDtBQUVaRixrQkFBWSxFQUFFWCxJQUFJLENBQUNXLFlBRlA7QUFHWmtELFNBQUcsRUFBRTdELElBQUksQ0FBQ3lGO0FBSEUsS0FBZDtBQU1BLFVBQU1yQixRQUFRLEdBQUcsTUFBTTNDLHVFQUFpQixDQUFDcUUsdUJBQWxCLENBQTBDMUksT0FBMUMsQ0FBdkI7QUFFSnVFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaLEVBQW1Dd0MsUUFBbkM7O0FBQ0ksUUFBSUEsUUFBUSxDQUFDdkMsUUFBVCxJQUFxQixHQUF6QixFQUE4QjtBQUM1QjhELDRGQUFtQixDQUFDdkIsUUFBUSxDQUFDQyxNQUFWLEVBQWtCRCxRQUFRLENBQUNDLE1BQTNCLEVBQW1DRCxRQUFRLENBQUN4SCxPQUE1QyxDQUFuQjtBQUNBbUQsa0JBQVksQ0FBQztBQUNYVCxhQUFLLEVBQUUsU0FESTtBQUVYQyxZQUFJLEVBQUUsVUFGSztBQUdYQyxpQkFBUyxFQUFFLEtBSEE7QUFJWEMsc0JBQWMsRUFBRU8sSUFBSSxDQUFDVyxZQUpWO0FBS1hqQix1QkFBZSxFQUFFO0FBTE4sT0FBRCxDQUFaO0FBUUFrRyxnQkFBVSxDQUFDLE1BQU07QUFDZmhHLHFCQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0QsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdELEtBYkQsTUFhTztBQUNMK0YsNEZBQW1CLENBQUN2QixRQUFRLENBQUNDLE1BQVYsRUFBa0JELFFBQVEsQ0FBQ0MsTUFBM0IsRUFBbUNELFFBQVEsQ0FBQ3hILE9BQTVDLENBQW5CO0FBQ0FnSixnQkFBVSxDQUFDLE1BQU07QUFDZmhHLHFCQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0QsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdEO0FBQ0YsR0E5QkQ7O0FBK0JKLFFBQU1tRyxTQUFTLEdBQUcsWUFBWTtBQUM1Qm5HLGlCQUFhLENBQUMsSUFBRCxDQUFiO0FBQ0EsUUFBSXhDLE9BQU8sR0FBRztBQUNaeUQsa0JBQVksRUFBRWIsSUFBSSxDQUFDYSxZQURQO0FBRVpGLGtCQUFZLEVBQUVYLElBQUksQ0FBQ1c7QUFGUCxLQUFkO0FBSUEsVUFBTXlELFFBQVEsR0FBRyxNQUFNM0MsdUVBQWlCLENBQUN1RSxxQkFBbEIsQ0FBd0M1SSxPQUF4QyxDQUF2Qjs7QUFFQSxRQUFJZ0gsUUFBUSxDQUFDdkMsUUFBVCxJQUFxQixHQUF6QixFQUE4QjtBQUM1QjhELDRGQUFtQixDQUFDdkIsUUFBUSxDQUFDQyxNQUFWLEVBQWtCRCxRQUFRLENBQUNDLE1BQTNCLEVBQW1DRCxRQUFRLENBQUN4SCxPQUE1QyxDQUFuQjtBQUNBbUQsa0JBQVksQ0FBQztBQUNYVCxhQUFLLEVBQUUsU0FESTtBQUVYQyxZQUFJLEVBQUUsVUFGSztBQUdYQyxpQkFBUyxFQUFFO0FBSEEsT0FBRCxDQUFaO0FBTUFvRyxnQkFBVSxDQUFDLE1BQU07QUFDZmhHLHFCQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0QsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdELEtBWEQsTUFXTztBQUNMK0YsNEZBQW1CLENBQUN2QixRQUFRLENBQUNDLE1BQVYsRUFBa0JELFFBQVEsQ0FBQ0MsTUFBM0IsRUFBbUNELFFBQVEsQ0FBQ3hILE9BQTVDLENBQW5CO0FBQ0FnSixnQkFBVSxDQUFDLE1BQU07QUFDZmhHLHFCQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0QsT0FGUyxFQUVQLEdBRk8sQ0FBVjtBQUdEO0FBQ0YsR0F6QkQ7O0FBMkJBLFFBQU1xRyx1QkFBdUIsR0FBSXBELElBQUQsSUFBV2lCLElBQUQsSUFBVTtBQUNsRDdELFdBQU8saUNBQU1ELElBQU47QUFBWSxPQUFDNkMsSUFBRCxHQUFRaUI7QUFBcEIsT0FBUDs7QUFDQSxRQUFJakIsSUFBSSxJQUFJLGNBQVIsSUFBMEJpQixJQUFJLEtBQUs5RCxJQUFJLENBQUNhLFlBQTVDLEVBQTBEO0FBQ3hEZCxrQkFBWSxDQUFDVixrQkFBRCxDQUFaO0FBQ0Q7QUFDRixHQUxEOztBQU1BLFFBQU1pRSxpQkFBaUIsR0FBRyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNUSxJQUFJLEdBQUcsTUFBTUMsNENBQUssQ0FBQ0MsSUFBTixDQUFZLEdBQUVDLG1FQUFXLHFCQUF6QixFQUErQ2pFLElBQS9DLEVBQXFEO0FBQ3RFa0UsZUFBTyxFQUFFO0FBQ1AsMEJBQWdCO0FBRFQ7QUFENkQsT0FBckQsRUFJaEJDLElBSmdCLENBSVZDLFFBQUQsSUFBY0EsUUFBUSxDQUFDTixJQUpaLENBQW5COztBQU1BLFVBQUlBLElBQUksQ0FBQ2pDLFFBQUwsS0FBa0IsR0FBbEIsSUFBeUJpQyxJQUFJLENBQUNPLE1BQUwsS0FBZ0IsT0FBN0MsRUFBc0Q7QUFDcEQxSCx5REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQkMsaUJBQU8sRUFBRWtILElBQUksQ0FBQ0EsSUFBTCxDQUFVb0MsTUFBVixDQUFpQkM7QUFETixTQUF0QjtBQUdBO0FBQ0Q7O0FBQ0QsVUFBSXJDLElBQUksQ0FBQ2pDLFFBQUwsS0FBa0IsR0FBbEIsSUFBeUJpQyxJQUFJLENBQUNPLE1BQUwsS0FBZ0IsU0FBN0MsRUFBd0Q7QUFDdEQxSCx5REFBWSxDQUFDLFNBQUQsQ0FBWixDQUF3QjtBQUN0QkMsaUJBQU8sRUFBRWtILElBQUksQ0FBQ2xIO0FBRFEsU0FBeEIsRUFEc0QsQ0FJdEQ7O0FBQ0FvRyxpQkFBUyxDQUFDYyxJQUFJLENBQUNBLElBQUwsQ0FBVUQsR0FBWCxFQUFnQkMsSUFBSSxDQUFDQSxJQUFMLENBQVU1RCxLQUExQixDQUFUO0FBQ0Q7QUFDRixLQXBCRCxDQW9CRSxPQUFPK0IsU0FBUCxFQUFrQjtBQUNsQk4sYUFBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUF1QkssU0FBdkI7QUFDRDs7QUFDRCxXQUFPLEtBQVA7QUFDRCxHQXpCRCxDQTlUdUIsQ0F5VnZCO0FBQ0E7QUFDQTtBQUNBO0FBR0E7OztBQUNBLHNCQUVFO0FBQ0UsYUFBUyxFQUFDLEtBRFo7QUFFRSxTQUFLLEVBQUU7QUFDTG1FLHFCQUFlLEVBQUcsT0FBTUMsa0ZBQVcsR0FEOUI7QUFFTEMsb0JBQWMsRUFBRSxPQUZYO0FBR0xDLHNCQUFnQixFQUFFLFdBSGI7QUFJTEMsd0JBQWtCLEVBQUUsTUFKZjtBQUtMQyxZQUFNLEVBQUU7QUFMSCxLQUZUO0FBQUEsNEJBVUU7QUFDRSxlQUFTLEVBQUMsT0FEWjtBQUVFLFdBQUssRUFBRTtBQUNMQyx1QkFBZSxFQUFFO0FBRFosT0FGVDtBQUFBLDZCQU1FO0FBQUssaUJBQVMsRUFBQyxhQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLEVBQWY7QUFBQSxpQ0FDRTtBQUFHLHFCQUFTLEVBQUMsU0FBYjtBQUF1QixnQkFBSSxFQUFDLEdBQTVCO0FBQUEsbUNBQ0U7QUFBSyxpQkFBRyxFQUFFQyxzRkFBVjtBQUFzQixpQkFBRyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVZGLGVBNkJFO0FBQUssZUFBUyxFQUFDLFdBQWY7QUFBQSw2QkFDRTtBQUNFLGlCQUFTLEVBQUMsV0FEWjtBQUVFLGFBQUssRUFBRTtBQUNMO0FBQ0FMLHdCQUFjLEVBQUUsU0FGWDtBQUdMQywwQkFBZ0IsRUFBRSxXQUhiO0FBSUxDLDRCQUFrQixFQUFFO0FBSmYsU0FGVDtBQUFBLCtCQVNFO0FBQUssbUJBQVMsRUFBQywyQkFBZjtBQUFBLGlDQUNFO0FBQ0UscUJBQVMsRUFBQyxNQURaO0FBRUUsaUJBQUssRUFBRTtBQUNMSSxvQkFBTSxFQUFFO0FBREgsYUFGVDtBQUFBLG9DQU9FO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQTJCLG1CQUFLLEVBQUU7QUFBQ3hCLHVCQUFPLEVBQUM7QUFBVCxlQUFsQztBQUFvRCxnQkFBRSxFQUFDLFNBQXZEO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLHNCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUlFO0FBQUsseUJBQVMsRUFBQyxrQkFBZjtBQUFBLDJCQUNHaEUsZ0JBQWdCLGdCQUFHLHFFQUFDLHNEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQUgsZ0JBQXNCLHFFQUFDLHdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRHpDLGVBRUU7QUFBSywyQkFBUyxFQUFDLE9BQWY7QUFBQSwwQ0FDRztBQUFHLDZCQUFTLEVBQUMsV0FBYjtBQUF5Qix3QkFBSSxFQUFDLEdBQTlCO0FBQXFDLDJCQUFPLEVBQUUsTUFBTWtFLE1BQU0sRUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREgsZUFPRTtBQUFHLDZCQUFTLEVBQUMsV0FBYjtBQUF5Qix3QkFBSSxFQUFDLEdBQTlCO0FBQUEsMkNBQ0U7QUFDRSwyQkFBSyxFQUFFO0FBQUV1Qiw4QkFBTSxFQUFFO0FBQVYsdUJBRFQ7QUFFRSw2QkFBTyxFQUFFLE1BQU14RixtQkFBbUIsQ0FBQyxDQUFDRCxnQkFBRixDQUZwQztBQUFBLGdDQUlHQSxnQkFBZ0IsR0FDYixtQkFEYSxHQUViO0FBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUZGLGVBb0JFO0FBQ0UsMkJBQVMsRUFBQyxhQURaO0FBRUUsdUJBQUssRUFBRTtBQUNMc0YsbUNBQWUsRUFBRyxTQURiO0FBRUxJLDZCQUFTLEVBQUc7QUFGUCxtQkFGVDtBQUFBLHlDQU9FO0FBQUssNkJBQVMsRUFBQyxVQUFmO0FBQUEsc0VBR0k7QUFBRyw2QkFBTyxFQUFFLE1BQU16QixHQUFHLEVBQXJCO0FBQXlCLCtCQUFTLEVBQUMsVUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFQRixlQWdESixxRUFBQyx5Q0FBRDtBQUNFLGtCQUFJLEVBQUVuRyxJQURSO0FBRUUsdUJBQVMsRUFBQyxrQkFGWjtBQUdFLHNCQUFRLEVBQUVZLFNBQVMsQ0FBQ0osZUFBVixHQUE0QndDLFlBQTVCLEdBQTJDeEYsU0FIdkQ7QUFJRSxtQkFBSyxFQUFFO0FBQUVxSywwQkFBVSxFQUFFLE1BQWQ7QUFBdUIzQix1QkFBTyxFQUFDO0FBQS9CLGVBSlQ7QUFLRSxnQkFBRSxFQUFDLFlBTEw7QUFNRSxrQkFBSSxFQUFDLE9BTlA7QUFPRSxvQkFBTSxFQUFDLFVBUFQ7QUFBQSxzQ0FxQkU7QUFBSyx5QkFBUyxFQUFDLHNCQUFmO0FBQUEsdUNBQ0k7QUFBSywyQkFBUyxFQUFDLHNCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFyQkYsZUF3QkU7QUFBSyx5QkFBUyxFQUFDLGVBQWY7QUFBK0Isa0JBQUUsRUFBQyxVQUFsQztBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxrQkFBZjtBQUFBLDBDQUNFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUNFLHdCQUFJLEVBQUMsY0FEUDtBQUVFLHlCQUFLLEVBQUUsQ0FDTDtBQUNFN0IsOEJBQVEsRUFBRSxJQURaO0FBRUUzRyw2QkFBTyxFQUFFO0FBRlgscUJBREssRUFLTDtBQUNFb0ssNkJBQU8sRUFBRSxJQUFJQyxNQUFKLENBQVcsY0FBWCxDQURYO0FBRUVySyw2QkFBTyxFQUFFO0FBRlgscUJBTEssRUFTTDtBQUNFc0sseUJBQUcsRUFBRSxFQURQO0FBRUV0Syw2QkFBTyxFQUFFO0FBRlgscUJBVEssQ0FGVDtBQUFBLDJDQWlCRSxxRUFBQywwQ0FBRDtBQUNFLDJCQUFLLEVBQUU0RCxVQURUO0FBRUUsMEJBQUksRUFBQyxNQUZQO0FBR0UsaUNBQVcsRUFBQyxxQkFIZDtBQUlFLDhCQUFRLEVBQUVvQyxZQUFZLENBQUMsWUFBRDtBQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsZUF5QkUscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0Usd0JBQUksRUFBQyxXQURQO0FBRUUseUJBQUssRUFBRSxDQUNMO0FBQ0VXLDhCQUFRLEVBQUUsSUFEWjtBQUVFM0csNkJBQU8sRUFBRTtBQUZYLHFCQURLLEVBS0w7QUFDRW9LLDZCQUFPLEVBQUUsSUFBSUMsTUFBSixDQUFXLGNBQVgsQ0FEWDtBQUVFckssNkJBQU8sRUFBRTtBQUZYLHFCQUxLLEVBU0w7QUFDRXNLLHlCQUFHLEVBQUUsRUFEUDtBQUVFdEssNkJBQU8sRUFBRTtBQUZYLHFCQVRLLENBRlQ7QUFBQSwyQ0FpQkUscUVBQUMsMENBQUQ7QUFDRSwyQkFBSyxFQUFFNkQsU0FEVDtBQUVFLDBCQUFJLEVBQUMsTUFGUDtBQUdFLGlDQUFXLEVBQUMsWUFIZDtBQUlFLDhCQUFRLEVBQUVtQyxZQUFZLENBQUMsV0FBRDtBQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBekJGLGVBeUVFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUNFLHdCQUFJLEVBQUMsT0FEUDtBQUVFLHlCQUFLLEVBQUUsQ0FDTDtBQUNFVyw4QkFBUSxFQUFFLElBRFo7QUFFRTNHLDZCQUFPLEVBQUU7QUFGWCxxQkFESyxDQUZUO0FBQUEsMkNBU0UscUVBQUMsMENBQUQ7QUFDRSwwQkFBSSxFQUFDLE9BRFA7QUFFRSxpQ0FBVyxFQUFDLGVBRmQ7QUFHRSw4QkFBUSxFQUFFZ0csWUFBWSxDQUFDLE9BQUQsQ0FIeEI7QUFJRSwyQkFBSyxFQUFFbEM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkF6RUYsZUEwRkUscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0Usd0JBQUksRUFBQyxjQURQO0FBRUUseUJBQUssRUFBRSxDQUNMO0FBQ0U2Qyw4QkFBUSxFQUFFO0FBRFoscUJBREssQ0FGVDtBQUFBLDJDQVFFLHFFQUFDLDBDQUFELENBQU8sS0FBUDtBQUFhLDZCQUFPLE1BQXBCO0FBQUEsOENBQ0UscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0UsNEJBQUksRUFBRSxDQUFDLGNBQUQsRUFBaUIsYUFBakIsQ0FEUjtBQUVFLCtCQUFPLE1BRlQ7QUFHRSw2QkFBSyxFQUFFLENBQ0w7QUFBRUEsa0NBQVEsRUFBRSxJQUFaO0FBQWtCM0csaUNBQU8sRUFBRTtBQUEzQix5QkFESyxDQUhUO0FBQUEsK0NBT0UscUVBQUMsMkNBQUQ7QUFDRSxvQ0FBVSxNQURaO0FBRUUsK0JBQUssRUFBRTtBQUFFdUssaUNBQUssRUFBRTtBQUFULDJCQUZUO0FBR0UscUNBQVcsRUFBQyxjQUhkO0FBSUUsMENBQWdCLEVBQUMsVUFKbkI7QUFLRSxrQ0FBUSxFQUFFbEIsdUJBQXVCLENBQUMsY0FBRCxDQUxuQztBQU1FLHNDQUFZLEVBQUUsQ0FBQy9GLEtBQUQsRUFBUWtILE1BQVIsS0FDWkEsTUFBTSxDQUFDQyxRQUFQLENBQ0dDLFFBREgsR0FFR0MsV0FGSCxHQUdHQyxPQUhILENBR1d0SCxLQUFLLENBQUNvSCxRQUFOLEdBQWlCQyxXQUFqQixFQUhYLEtBRzhDLENBVmxEO0FBQUEsb0NBYUdqSCxhQWJILGFBYUdBLGFBYkgsdUJBYUdBLGFBQWEsQ0FBRTBCLEdBQWYsQ0FBbUIsQ0FBQ3lGLGNBQUQsRUFBaUJDLEtBQWpCLGtCQUNsQixxRUFBQyxNQUFEO0FBQ0UsaUNBQUssRUFBRyxJQUFHRCxjQUFjLENBQUNFLFNBQVUsRUFEdEM7QUFBQSw0Q0FJSUYsY0FBYyxDQUFDRSxTQUpuQjtBQUFBLDZCQUVPRCxLQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBREQ7QUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERixlQStCRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSw0QkFBSSxFQUFFLENBQUMsY0FBRCxFQUFpQixhQUFqQixDQURSO0FBRUUsK0JBQU8sTUFGVDtBQUdFLDZCQUFLLEVBQUUsQ0FDTDtBQUFFbkUsa0NBQVEsRUFBRSxJQUFaO0FBQWtCM0csaUNBQU8sRUFBRTtBQUEzQix5QkFESyxFQUVMO0FBQ0VnTCw2QkFBRyxFQUFFLENBRFA7QUFFRWhMLGlDQUFPLEVBQUU7QUFGWCx5QkFGSyxFQU1MO0FBQ0VzSyw2QkFBRyxFQUFFLEVBRFA7QUFFRXRLLGlDQUFPLEVBQUU7QUFGWCx5QkFOSyxFQVVMO0FBQ0VvSyxpQ0FBTyxFQUFFLElBQUlDLE1BQUosQ0FBVyxXQUFYLENBRFg7QUFFRXJLLGlDQUFPLEVBQUU7QUFGWCx5QkFWSyxDQUhUO0FBQUEsK0NBbUJFLHFFQUFDLDBDQUFEO0FBQ0UsOEJBQUksRUFBQyxNQURQO0FBRUUscUNBQVcsRUFBQyxvQkFGZDtBQUdFLGtDQUFRLEVBQUVnRyxZQUFZLENBQUMsY0FBRCxDQUh4QjtBQUlFLCtCQUFLLEVBQUVqQyxZQUpUO0FBS0UsK0JBQUssRUFBRTtBQUFFd0csaUNBQUssRUFBRSxLQUFUO0FBQWdCVixrQ0FBTSxFQUFFLE1BQXhCO0FBQWdDb0IsbUNBQU8sRUFBRTtBQUF6QywyQkFMVDtBQU1FLGdDQUFNLGVBQ0oscUVBQUMseUNBQUQ7QUFBTSxxQ0FBUyxFQUFFekgsT0FBakI7QUFBMEIsb0NBQVEsRUFBRVQsVUFBcEM7QUFBQSxtREFDRTtBQUNFLG1DQUFLLEVBQUU7QUFBRWtILHNDQUFNLEVBQUU7QUFBViwrQkFEVDtBQUVFLHVDQUFTLEVBQUcsUUFBTy9HLFNBQVMsQ0FBQ1IsS0FBTSxFQUZyQztBQUdFLHFDQUFPLEVBQUV5RyxTQUhYO0FBQUEsd0NBS0dqRyxTQUFTLENBQUNQO0FBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBMUZGLEVBMEtJTyxTQUFTLENBQUNOLFNBQVYsaUJBQ0EscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0Usd0JBQUksRUFBRSxZQURSO0FBRUUseUJBQUssRUFBRSxDQUFDO0FBQUUrRCw4QkFBUSxFQUFFLElBQVo7QUFBa0IzRyw2QkFBTyxFQUFFO0FBQTNCLHFCQUFELENBRlQ7QUFBQSwyQ0FJRSxxRUFBQywwQ0FBRDtBQUNFLDBCQUFJLEVBQUMsTUFEUDtBQUVFLGlDQUFXLEVBQUMsWUFGZDtBQUdFLDhCQUFRLEVBQUVnRyxZQUFZLENBQUMsVUFBRCxDQUh4QjtBQUlFLDRCQUFNLGVBQ0oscUVBQUMseUNBQUQ7QUFBTSxpQ0FBUyxFQUFFeEMsT0FBakI7QUFBMEIsZ0NBQVEsRUFBRVQsVUFBcEM7QUFBQSwrQ0FDRTtBQUNFLCtCQUFLLEVBQUU7QUFBRWtILGtDQUFNLEVBQUU7QUFBViwyQkFEVDtBQUVFLG1DQUFTLEVBQUcsY0FGZDtBQUdFLGlDQUFPLEVBQUVoQixlQUhYO0FBQUEsb0NBS0c7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQTNLSixFQWtNRy9GLFNBQVMsQ0FBQ1AsSUFBVixDQUFlZ0ksV0FBZixNQUFnQyxVQUFoQyxJQUNDekgsU0FBUyxDQUFDSixlQURYLGlCQUVHO0FBQUEsNENBQ0UscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0UsMEJBQUksRUFBQyxVQURQO0FBRUUsMkJBQUssRUFBRSxDQUNMO0FBQ0U2RCxnQ0FBUSxFQUFFLElBRFo7QUFFRTNHLCtCQUFPLEVBQUU7QUFGWCx1QkFESyxDQUZUO0FBQUEsNkNBU0UscUVBQUMsMENBQUQ7QUFDRSw0QkFBSSxFQUFDLFVBRFA7QUFFRSxtQ0FBVyxFQUFDLGdCQUZkO0FBR0UsZ0NBQVEsRUFBRWdHLFlBQVksQ0FBQyxVQUFELENBSHhCO0FBSUUsNkJBQUssRUFBRXpDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREYsZUFpQkUscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQ0UsMEJBQUksRUFBQyx1QkFEUDtBQUVFLGtDQUFZLEVBQUUsQ0FBQyxVQUFELENBRmhCO0FBR0UsMkJBQUssRUFBRSxDQUNMO0FBQ0VvRCxnQ0FBUSxFQUFFLElBRFo7QUFFRTNHLCtCQUFPLEVBQUU7QUFGWCx1QkFESyxFQUtMLENBQUM7QUFBRWtMO0FBQUYsdUJBQUQsTUFBd0I7QUFDdEJDLGlDQUFTLENBQUNDLElBQUQsRUFBT2pGLEtBQVAsRUFBYztBQUNyQiw4QkFBSSxDQUFDQSxLQUFELElBQVUrRSxhQUFhLENBQUMsVUFBRCxDQUFiLElBQTZCL0UsS0FBM0MsRUFBa0Q7QUFDaEQsbUNBQU9rRixPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNEOztBQUNELGlDQUFPRCxPQUFPLENBQUNFLE1BQVIsQ0FDTCxrREFESyxDQUFQO0FBR0Q7O0FBUnFCLHVCQUF4QixDQUxLLENBSFQ7QUFBQSw2Q0FvQkUscUVBQUMsMENBQUQ7QUFDRSw0QkFBSSxFQUFDLFVBRFA7QUFFRSxtQ0FBVyxFQUFDLG1CQUZkO0FBR0UsZ0NBQVEsRUFBRXZGLFlBQVksQ0FBQyx1QkFBRCxDQUh4QjtBQUlFLDZCQUFLLEVBQUVoQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FqQkY7QUFBQSxrQ0FwTU4sZUFtUEU7QUFBSyw2QkFBUyxFQUFDLG1CQUFmO0FBQUEsNENBUUU7QUFDRSwwQkFBSSxFQUFDLFFBRFA7QUFFRSwrQkFBUyxFQUFDLDBCQUZaLENBR0U7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FSRixlQWVFO0FBQ0ksK0JBQVMsRUFBQyxhQURkO0FBRUksMkJBQUssRUFBRTtBQUNMOEYsdUNBQWUsRUFBRyxTQURiO0FBRUxJLGlDQUFTLEVBQUc7QUFGUCx1QkFGWDtBQUFBLDZDQU9JO0FBQUssaUNBQVMsRUFBQyxVQUFmO0FBQUEsNEVBR0k7QUFBRyxpQ0FBTyxFQUFFLE1BQU1wQyxLQUFLLEVBQXZCO0FBQTJCLG1DQUFTLEVBQUMsVUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBblBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFoREksZUFxV0oscUVBQUMseUNBQUQ7QUFDRSxrQkFBSSxFQUFFeEYsSUFEUjtBQUVFLHVCQUFTLEVBQUMsa0JBRlo7QUFHRSxzQkFBUSxFQUFFWSxTQUFTLENBQUNKLGVBQVYsR0FBNEI0QixhQUE1QixHQUE0QzVFLFNBSHhEO0FBSUUsbUJBQUssRUFBRTtBQUFFcUssMEJBQVUsRUFBRSxNQUFkO0FBQXVCM0IsdUJBQU8sRUFBQztBQUEvQixlQUpUO0FBS0UsZ0JBQUUsRUFBQyxhQUxMO0FBTUUsa0JBQUksRUFBQyxPQU5QO0FBT0Usb0JBQU0sRUFBQyxVQVBUO0FBQUEsc0NBcUJFO0FBQUsseUJBQVMsRUFBQyxzQkFBZjtBQUFBLHVDQUNJO0FBQUssMkJBQVMsRUFBQyxzQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBckJGLGVBd0JFO0FBQUsseUJBQVMsRUFBQyxlQUFmO0FBQStCLGtCQUFFLEVBQUMsVUFBbEM7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsa0JBQWY7QUFBQSwwQ0FLRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSx3QkFBSSxFQUFDLGNBRFA7QUFFRSx5QkFBSyxFQUFFLENBQ0w7QUFDRTdCLDhCQUFRLEVBQUU7QUFEWixxQkFESyxDQUZUO0FBQUEsMkNBUUUscUVBQUMsMENBQUQsQ0FBTyxLQUFQO0FBQWEsNkJBQU8sTUFBcEI7QUFBQSw4Q0FDRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSw0QkFBSSxFQUFFLENBQUMsY0FBRCxFQUFpQixhQUFqQixDQURSO0FBRUUsK0JBQU8sTUFGVDtBQUdFLDZCQUFLLEVBQUUsQ0FDTDtBQUFFQSxrQ0FBUSxFQUFFLElBQVo7QUFBa0IzRyxpQ0FBTyxFQUFFO0FBQTNCLHlCQURLLENBSFQ7QUFBQSwrQ0FPRSxxRUFBQywyQ0FBRDtBQUNFLG9DQUFVLE1BRFo7QUFFRSwrQkFBSyxFQUFFO0FBQUV1SyxpQ0FBSyxFQUFFO0FBQVQsMkJBRlQ7QUFHRSxxQ0FBVyxFQUFDLGNBSGQ7QUFJRSwwQ0FBZ0IsRUFBQyxVQUpuQjtBQUtFLGtDQUFRLEVBQUVsQix1QkFBdUIsQ0FBQyxjQUFELENBTG5DO0FBTUUsc0NBQVksRUFBRSxDQUFDL0YsS0FBRCxFQUFRa0gsTUFBUixLQUNaQSxNQUFNLENBQUNDLFFBQVAsQ0FDR0MsUUFESCxHQUVHQyxXQUZILEdBR0dDLE9BSEgsQ0FHV3RILEtBQUssQ0FBQ29ILFFBQU4sR0FBaUJDLFdBQWpCLEVBSFgsS0FHOEMsQ0FWbEQ7QUFBQSxvQ0FhR2pILGFBYkgsYUFhR0EsYUFiSCx1QkFhR0EsYUFBYSxDQUFFMEIsR0FBZixDQUFtQixDQUFDeUYsY0FBRCxFQUFpQkMsS0FBakIsa0JBQ2xCLHFFQUFDLE1BQUQ7QUFDRSxpQ0FBSyxFQUFHLElBQUdELGNBQWMsQ0FBQ0UsU0FBVSxFQUR0QztBQUFBLDRDQUlJRixjQUFjLENBQUNFLFNBSm5CO0FBQUEsNkJBRU9ELEtBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FERDtBQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURGLGVBK0JFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUNFLDRCQUFJLEVBQUUsQ0FBQyxjQUFELEVBQWlCLGFBQWpCLENBRFI7QUFFRSwrQkFBTyxNQUZUO0FBR0UsNkJBQUssRUFBRSxDQUNMO0FBQUVuRSxrQ0FBUSxFQUFFLElBQVo7QUFBa0IzRyxpQ0FBTyxFQUFFO0FBQTNCLHlCQURLLEVBRUw7QUFDRWdMLDZCQUFHLEVBQUUsQ0FEUDtBQUVFaEwsaUNBQU8sRUFBRTtBQUZYLHlCQUZLLEVBTUw7QUFDRXNLLDZCQUFHLEVBQUUsRUFEUDtBQUVFdEssaUNBQU8sRUFBRTtBQUZYLHlCQU5LLEVBVUw7QUFDRW9LLGlDQUFPLEVBQUUsSUFBSUMsTUFBSixDQUFXLFdBQVgsQ0FEWDtBQUVFckssaUNBQU8sRUFBRTtBQUZYLHlCQVZLLENBSFQ7QUFBQSwrQ0FtQkUscUVBQUMsMENBQUQ7QUFDRSw4QkFBSSxFQUFDLE1BRFA7QUFFRSxxQ0FBVyxFQUFDLG9CQUZkO0FBR0Usa0NBQVEsRUFBRWdHLFlBQVksQ0FBQyxjQUFELENBSHhCO0FBSUUsK0JBQUssRUFBRWpDLFlBSlQ7QUFLRSwrQkFBSyxFQUFFO0FBQUV3RyxpQ0FBSyxFQUFFLEtBQVQ7QUFBZ0JWLGtDQUFNLEVBQUUsTUFBeEI7QUFBZ0NvQixtQ0FBTyxFQUFFO0FBQXpDLDJCQUxUO0FBTUUsZ0NBQU0sZUFDSixxRUFBQyx5Q0FBRDtBQUFNLHFDQUFTLEVBQUV6SCxPQUFqQjtBQUEwQixvQ0FBUSxFQUFFVCxVQUFwQztBQUFBLG1EQUNFO0FBQ0UsbUNBQUssRUFBRTtBQUFFa0gsc0NBQU0sRUFBRTtBQUFWLCtCQURUO0FBRUUsdUNBQVMsRUFBRyxRQUFPL0csU0FBUyxDQUFDUixLQUFNLEVBRnJDO0FBR0UscUNBQU8sRUFBRXlHLFNBSFg7QUFBQSx3Q0FLR2pHLFNBQVMsQ0FBQ1A7QUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFMRixFQXFGSU8sU0FBUyxDQUFDTixTQUFWLGlCQUNBLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUNFLHdCQUFJLEVBQUUsWUFEUjtBQUVFLHlCQUFLLEVBQUUsQ0FBQztBQUFFK0QsOEJBQVEsRUFBRSxJQUFaO0FBQWtCM0csNkJBQU8sRUFBRTtBQUEzQixxQkFBRCxDQUZUO0FBQUEsMkNBSUUscUVBQUMsMENBQUQ7QUFDRSwwQkFBSSxFQUFDLE1BRFA7QUFFRSxpQ0FBVyxFQUFDLFlBRmQ7QUFHRSw4QkFBUSxFQUFFZ0csWUFBWSxDQUFDLFVBQUQsQ0FIeEI7QUFJRSw0QkFBTSxlQUNKLHFFQUFDLHlDQUFEO0FBQU0saUNBQVMsRUFBRXhDLE9BQWpCO0FBQTBCLGdDQUFRLEVBQUVULFVBQXBDO0FBQUEsK0NBQ0U7QUFDRSwrQkFBSyxFQUFFO0FBQUVrSCxrQ0FBTSxFQUFFO0FBQVYsMkJBRFQ7QUFFRSxtQ0FBUyxFQUFHLGNBRmQ7QUFHRSxpQ0FBTyxFQUFFdEIsZ0JBSFg7QUFBQSxvQ0FLRztBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBdEZKLEVBNkdHekYsU0FBUyxDQUFDUCxJQUFWLENBQWVnSSxXQUFmLE1BQWdDLFVBQWhDLElBQ0N6SCxTQUFTLENBQUNKLGVBRFgsaUJBRUc7QUFBQSw0Q0FDRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSwwQkFBSSxFQUFDLFVBRFA7QUFFRSwyQkFBSyxFQUFFLENBQ0w7QUFDRTZELGdDQUFRLEVBQUUsSUFEWjtBQUVFM0csK0JBQU8sRUFBRTtBQUZYLHVCQURLLENBRlQ7QUFBQSw2Q0FTRSxxRUFBQywwQ0FBRDtBQUNFLDRCQUFJLEVBQUMsVUFEUDtBQUVFLG1DQUFXLEVBQUMsZ0JBRmQ7QUFHRSxnQ0FBUSxFQUFFZ0csWUFBWSxDQUFDLFVBQUQsQ0FIeEI7QUFJRSw2QkFBSyxFQUFFekM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixlQWlCRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFDRSwwQkFBSSxFQUFDLHVCQURQO0FBRUUsa0NBQVksRUFBRSxDQUFDLFVBQUQsQ0FGaEI7QUFHRSwyQkFBSyxFQUFFLENBQ0w7QUFDRW9ELGdDQUFRLEVBQUUsSUFEWjtBQUVFM0csK0JBQU8sRUFBRTtBQUZYLHVCQURLLEVBS0wsQ0FBQztBQUFFa0w7QUFBRix1QkFBRCxNQUF3QjtBQUN0QkMsaUNBQVMsQ0FBQ0MsSUFBRCxFQUFPakYsS0FBUCxFQUFjO0FBQ3JCLDhCQUFJLENBQUNBLEtBQUQsSUFBVStFLGFBQWEsQ0FBQyxVQUFELENBQWIsSUFBNkIvRSxLQUEzQyxFQUFrRDtBQUNoRCxtQ0FBT2tGLE9BQU8sQ0FBQ0MsT0FBUixFQUFQO0FBQ0Q7O0FBQ0QsaUNBQU9ELE9BQU8sQ0FBQ0UsTUFBUixDQUNMLGtEQURLLENBQVA7QUFHRDs7QUFScUIsdUJBQXhCLENBTEssQ0FIVDtBQUFBLDZDQW9CRSxxRUFBQywwQ0FBRDtBQUNFLDRCQUFJLEVBQUMsVUFEUDtBQUVFLG1DQUFXLEVBQUMsbUJBRmQ7QUFHRSxnQ0FBUSxFQUFFdkYsWUFBWSxDQUFDLHVCQUFELENBSHhCO0FBSUUsNkJBQUssRUFBRWhDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQWpCRjtBQUFBLGtDQS9HTixlQThKRTtBQUFLLDZCQUFTLEVBQUMsbUJBQWY7QUFBQSw0Q0FRRTtBQUNFLDZCQUFPLEVBQUVVLGFBRFg7QUFFRSwrQkFBUyxFQUFDLFNBRlosQ0FHRTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVJGLGVBZUU7QUFDSSwrQkFBUyxFQUFDLGFBRGQ7QUFFSSwyQkFBSyxFQUFFO0FBQ0xvRix1Q0FBZSxFQUFHLFNBRGI7QUFFTEksaUNBQVMsRUFBRztBQUZQLHVCQUZYO0FBQUEsNkNBT0k7QUFBSyxpQ0FBUyxFQUFDLFVBQWY7QUFBQSw0RUFHSTtBQUFHLGlDQUFPLEVBQUUsTUFBTXBDLEtBQUssRUFBdkI7QUFBMkIsbUNBQVMsRUFBQyxVQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkE5SkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXJXSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBOG5CRCxDQTk5QkQ7O0dBQU0xRixLO1VBQ1dHLHlDQUFJLENBQUNDLE8sRUE2R0gvQyx1RDs7O0tBOUdiMkMsSztBQWcrQlNBLG9FQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2wvQkE7QUFDQTs7QUFFQSxNQUFNb0osZUFBZSxHQUFHLG1CQUV0QjtBQUFBLDBCQUVBO0FBQUssYUFBUyxFQUFDLDJCQUFmO0FBQUEsMkJBQ0k7QUFBSyxlQUFTLEVBQUMsY0FBZjtBQUFBLDZCQUNJO0FBQUssaUJBQVMsRUFBQyxLQUFmO0FBQUEsZ0NBQ0k7QUFBSyxtQkFBUyxFQUFDLGdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHdCQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLG1CQUFmO0FBQUEscUNBQ0k7QUFBRyxvQkFBSSxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFNSTtBQUFHLHVCQUFTLEVBQUMsWUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFOSixlQVFJO0FBQUssdUJBQVMsRUFBQyxzQkFBZjtBQUFBLHFDQUNJO0FBQUsseUJBQVMsRUFBQyxPQUFmO0FBQUEsd0NBQ0k7QUFBTSwyQkFBUyxFQUFDO0FBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFJSTtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUFBLDBDQUNJO0FBQUcsNkJBQVMsRUFBQywwQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFESixlQUVJO0FBQUksNkJBQVMsRUFBQyxpQkFBZDtBQUFBLDJDQUFnQztBQUFHLDBCQUFJLEVBQUMsb0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFSSixlQW9CSTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQSxxQ0FDSTtBQUFJLHlCQUFTLEVBQUMsUUFBZDtBQUFBLHdDQUNJO0FBQUEseUNBQUk7QUFBRyx3QkFBSSxFQUFDLGFBQVI7QUFBc0IsMEJBQU0sRUFBQyxRQUE3QjtBQUFBLDJDQUFzQztBQUM5QiwrQkFBUyxFQUFDO0FBRG9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFHSTtBQUFBLHlDQUFJO0FBQUcsd0JBQUksRUFBQyxhQUFSO0FBQXNCLDBCQUFNLEVBQUMsUUFBN0I7QUFBQSwyQ0FBc0M7QUFDOUIsK0JBQVMsRUFBQztBQURvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUhKLGVBS0k7QUFBQSx5Q0FBSTtBQUFHLHdCQUFJLEVBQUMsYUFBUjtBQUFzQiwwQkFBTSxFQUFDLFFBQTdCO0FBQUEsMkNBQXNDO0FBQzlCLCtCQUFTLEVBQUM7QUFEb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFMSixlQU9JO0FBQUksMkJBQVMsRUFBQyxNQUFkO0FBQUEseUNBQXFCO0FBQUcsd0JBQUksRUFBQyxhQUFSO0FBQXNCLDBCQUFNLEVBQUMsUUFBN0I7QUFBQSwyQ0FBc0M7QUFDL0MsK0JBQVMsRUFBQztBQURxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBb0NJO0FBQUssbUJBQVMsRUFBQyxzQ0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBCQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLHFCQUFmO0FBQUEsdUNBQ0k7QUFBSSwyQkFBUyxFQUFDLGdDQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSTtBQUFJLHVCQUFTLEVBQUMsYUFBZDtBQUFBLHNDQUNJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBRUk7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRkosZUFHSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFISixlQUlJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUpKLGVBS0k7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEosZUFNSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFwQ0osZUF1REk7QUFBSyxtQkFBUyxFQUFDLGdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsMEJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMscUJBQWY7QUFBQSx1Q0FDSTtBQUFJLDJCQUFTLEVBQUMsZ0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQU9JO0FBQUksdUJBQVMsRUFBQyxhQUFkO0FBQUEsc0NBQ0k7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGSixlQUlJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUpKLGVBTUk7QUFBQSx1Q0FBSTtBQUFHLHNCQUFJLEVBQUMsYUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkosZUFRSTtBQUFBLHVDQUFJO0FBQUcsc0JBQUksRUFBQyxhQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFSSixlQVVJO0FBQUEsdUNBQUk7QUFBRyxzQkFBSSxFQUFDLGFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXZESixlQThFSTtBQUFLLG1CQUFTLEVBQUMsZ0NBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQywwQkFBZjtBQUFBLHFDQUNJO0FBQUsseUJBQVMsRUFBQyxxQkFBZjtBQUFBLHVDQUNJO0FBQUksMkJBQVMsRUFBQyxnQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBTUk7QUFBRyx1QkFBUyxFQUFDLFlBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTkosZUFRSTtBQUFLLHVCQUFTLEVBQUMsb0JBQWY7QUFBQSxxQ0FDSTtBQUFNLHlCQUFTLEVBQUMsK0JBQWhCO0FBQ0ksc0JBQU0sRUFBQyxhQURYO0FBRUksc0JBQU0sRUFBQyxRQUZYO0FBRW9CLHNCQUFNLEVBQUMsTUFGM0I7QUFBQSx1Q0FJSTtBQUFRLDJCQUFTLEVBQUMsaUNBQWxCO0FBQW9ELHNCQUFJLEVBQUMsUUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFSSixlQWtCSTtBQUFLLHVCQUFTLEVBQUMsY0FBZjtBQUFBLHNDQUNJO0FBQUcsb0JBQUksRUFBQyxhQUFSO0FBQXNCLHlCQUFTLEVBQUM7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQUlJO0FBQUcsb0JBQUksRUFBQyxhQUFSO0FBQXNCLHlCQUFTLEVBQUM7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOUVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkEsZUFtSEE7QUFBSyxhQUFTLEVBQUMsbUJBQWY7QUFBQSwyQkFDSTtBQUFLLGVBQVMsRUFBQyxXQUFmO0FBQUEsNkJBQ0k7QUFBSyxpQkFBUyxFQUFDLEtBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsMEJBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsWUFBZjtBQUFBLG1DQUNJO0FBQUcsdUJBQVMsRUFBQyxjQUFiO0FBQUEsb0RBQ0w7QUFBTSx5QkFBUyxFQUFDLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESyw4QkFFUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGTyxzQkFHWjtBQUFHLHNCQUFNLEVBQUMsUUFBVjtBQUFtQixvQkFBSSxFQUFDLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFIWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVVJO0FBQUssbUJBQVMsRUFBQywwQkFBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbkhBO0FBQUEsZ0JBRkY7O0tBQU1BLGU7QUE4SVNBLDhFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLE1BQU07QUFBQTs7QUFDMUI5Rix5REFBUyxDQUFDLE1BQU07QUFDZCxjQUFxQjtBQUNuQitGLFlBQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NDLHNFQUFsQztBQUNEO0FBQ0YsR0FKUSxFQUlOLEVBSk0sQ0FBVDtBQU1BLHNCQUNFO0FBQVEsYUFBUyxFQUFDLGtCQUFsQjtBQUFxQyxtQkFBWSxNQUFqRDtBQUF3RCxNQUFFLEVBQUMsY0FBM0Q7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsY0FBWDtBQUFBLCtCQUNFO0FBQUssZUFBSyxFQUFDLDRCQUFYO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGFBQWY7QUFBQSxtQ0FDRTtBQUFJLHVCQUFTLEVBQUMsU0FBZDtBQUFBLHFDQUNFO0FBQUkseUJBQVMsRUFBQyxRQUFkO0FBQUEsd0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFHRyxxRUFBQyxnREFBRDtBQUFNLHNCQUFJLEVBQUMsZ0JBQVg7QUFBQSx5Q0FDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURPO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSEgsZUFNTixxRUFBQyxnREFBRDtBQUFNLHNCQUFJLEVBQUMsZ0JBQVg7QUFBQSx5Q0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBTk07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUF1QkU7QUFBSyxlQUFTLEVBQUMsYUFBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxjQUFmO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLGNBQWY7QUFBQSxpQ0FDRSxxRUFBQyx3RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUtFO0FBQUssbUJBQVMsRUFBQyxlQUFmO0FBQUEsaUNBQ0UscUVBQUMsdUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEYsZUFRRTtBQUFLLG1CQUFTLEVBQUMsa0RBQWY7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsRUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkYsZUFXRTtBQUFLLG1CQUFTLEVBQUMsZ0JBQWY7QUFBQSxpQ0FDRSxxRUFBQyx1RkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFYRixlQWNFO0FBQUssbUJBQVMsRUFBQyxlQUFmO0FBQUEsaUNBQ0UscUVBQUMsd0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUErQ0QsQ0F0REQ7O0dBQU1ILGE7O0tBQUFBLGE7QUF3RFNBLDRFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUksUUFBUSxnQkFBR0MsNENBQUssQ0FBQ0MsSUFBTixTQUFXLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWM7QUFBQTs7QUFBQTs7QUFDeEMsTUFBSUMsYUFBSjtBQUNBLFFBQU16TSxRQUFRLEdBQUdDLCtEQUFXLEVBQTVCO0FBQ0EsUUFBTXlNLElBQUksR0FBR0MsK0RBQVcsQ0FBRUMsS0FBRCxJQUFXQSxLQUFLLENBQUNGLElBQWxCLENBQXhCO0FBRUEsUUFBTUcscUJBQXFCLEdBQUdMLElBQUgsYUFBR0EsSUFBSCx3Q0FBR0EsSUFBSSxDQUFFek0sT0FBVCxrREFBRyxjQUFlNkYsR0FBZixDQUFvQmtILFdBQUQ7QUFBQTs7QUFBQSx3QkFDL0M7QUFBQSw4QkFDRTtBQUFHLGlCQUFTLEVBQUMsVUFBYjtBQUFBLGtCQUF5QkEsV0FBekIsYUFBeUJBLFdBQXpCLCtDQUF5QkEsV0FBVyxDQUFFQyxNQUF0Qyx5REFBeUIscUJBQXFCQTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLEVBRUdELFdBRkgsYUFFR0EsV0FGSCwrQ0FFR0EsV0FBVyxDQUFFQyxNQUZoQixrRkFFRyxxQkFBcUJDLFFBRnhCLDBEQUVHLHNCQUErQnBILEdBQS9CLENBQW9DcUgsV0FBRCxpQkFDbEMscUVBQUMsbUZBQUQ7QUFBZSxlQUFPLEVBQUVBO0FBQXhCLFNBQTBDQSxXQUExQyxhQUEwQ0EsV0FBMUMsdUJBQTBDQSxXQUFXLENBQUVoTSxPQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURELENBRkg7QUFBQSxPQUFVNkwsV0FBVixhQUFVQSxXQUFWLDhDQUFVQSxXQUFXLENBQUVDLE1BQXZCLHdEQUFVLG9CQUFxQkcsU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEK0M7QUFBQSxHQUFuQixDQUE5QjtBQVFBLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQjNKLHNEQUFRLENBQUMsSUFBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDNEosVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEI3SixzREFBUSxDQUFDLENBQUQsQ0FBNUM7QUFFQTBDLHlEQUFTLENBQUMsTUFBTTtBQUNkWixXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWixFQUErQ2dILElBQS9DLEVBRGMsQ0FFZjs7QUFDQyxRQUFJZSxTQUFTLEdBQUcsSUFBaEI7O0FBRUEsUUFBSUEsU0FBSixFQUFlO0FBQUE7O0FBQ2I7QUFDQSxZQUFNQyw4QkFBOEIsR0FBR2hCLElBQUgsYUFBR0EsSUFBSCx5Q0FBR0EsSUFBSSxDQUFFek0sT0FBVCxtREFBRyxlQUFlME4sTUFBZixDQUNyQyxDQUFDQyxlQUFELEVBQWtCQyxlQUFsQixLQUFzQztBQUNwQyxlQUNFQyxNQUFNLENBQUNGLGVBQUQsQ0FBTixHQUVDRSxNQUFNLENBQUNELGVBQWUsQ0FBQ1osTUFBaEIsQ0FBdUJDLFFBQXZCLENBQWdDYSxNQUFqQyxDQUhUO0FBS0QsT0FQb0MsRUFRckMsQ0FScUMsQ0FBdkM7QUFXQVAsbUJBQWEsQ0FBQ0UsOEJBQUQsQ0FBYjtBQUNBSixpQkFBVyxDQUFDWixJQUFELENBQVg7QUFDRDs7QUFDRCxXQUFPLE1BQU07QUFDWGUsZUFBUyxHQUFHLEtBQVo7QUFDRCxLQUZEO0FBR0QsR0F4QlEsRUF3Qk4sQ0FBQ2YsSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUV6TSxPQUFQLENBeEJNLENBQVQsQ0FoQndDLENBMEN4Qzs7QUFFRSxRQUFNK04sV0FBVyxHQUFJOU0sT0FBRCxJQUFhO0FBQy9CK00sU0FBSyxDQUFDLFNBQUQsQ0FBTCxDQUQrQixDQUVqQzs7QUFDQSxRQUFJNU4sUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlNLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdWLFFBQVgsQ0FBaEI7QUFDQSxRQUFJWSxZQUFZLEdBQUdKLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUE5QjtBQUNBLFVBQU1pTixVQUFVLEdBQUdqTixZQUFuQjtBQUNBd0UsV0FBTyxDQUFDQyxHQUFSLENBQVksd0NBQVosRUFBcUQ7QUFBQ3FDLHNGQUFVQTtBQUFYLEtBQXJEO0FBQ0F0QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQ3dJLFVBQXRDO0FBQ0F6SSxXQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUFzQ3lJLHFFQUF0QztBQUVBLFVBQU12RyxJQUFJLEdBQUdDLDRDQUFLLENBQUNDLElBQU4sQ0FDVixHQUFFQyxvRUFBVyxvQkFESCxFQUVYO0FBQ0U5RyxrQkFBWSxFQUFFaU4sVUFEaEI7QUFFRUUsYUFBTyxFQUFFLENBRlg7QUFHRUMsZUFBUyxFQUFFRixxRUFIYjtBQUlFRyxjQUFRLEVBQUUsaUNBSlo7QUFLRUMsYUFBTyxFQUFFO0FBTFgsS0FGVyxFQVNWdEcsSUFUVSxDQVNKQyxRQUFELElBQWNBLFFBQVEsQ0FBQ04sSUFUbEIsRUFVVkssSUFWVSxDQVVKTCxJQUFELElBQVU7QUFDZG5DLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaLEVBQW9Ea0MsSUFBcEQsRUFEYyxDQUVsQjs7QUFDSSxVQUFJQSxJQUFJLENBQUNqQyxRQUFMLElBQWlCLEdBQWpCLElBQXdCaUMsSUFBSSxDQUFDTyxNQUFMLElBQWUsT0FBM0MsRUFBb0QsQ0FDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFDRCxVQUFJUCxJQUFJLENBQUNqQyxRQUFMLElBQWlCLEdBQWpCLElBQXdCaUMsSUFBSSxDQUFDTyxNQUFMLElBQWUsU0FBM0MsRUFBc0Q7QUFDcERtRixtQkFBVyxDQUFDMUYsSUFBSSxDQUFDQSxJQUFOLENBQVg7QUFDQTRGLHFCQUFhLENBQUM1RixJQUFJLENBQUNBLElBQUwsQ0FBVTRHLFVBQVgsQ0FBYixDQUZvRCxDQUd2RDtBQUNDO0FBQ0U7QUFDQTtBQUNBO0FBQ0Q7O0FBQ0M7QUFDRDtBQUNGLEtBOUJVLEVBK0JWN0YsS0EvQlUsQ0ErQkg5QyxLQUFELElBQVcsQ0FDaEI7QUFDQTtBQUNBO0FBQ0QsS0FuQ1UsQ0FBYjtBQXNDQ0osV0FBTyxDQUFDQyxHQUFSLENBQVkseUJBQVosRUFBc0N5SSxxRUFBdEMsRUFqRGdDLENBa0RsQztBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRCxHQXhFQzs7QUF5RUY5SCx5REFBUyxDQUFDLE1BQU07QUFDZFosV0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQmdILElBQXRCO0FBQ0FzQixlQUFXOztBQUNYLFFBQUl0QixJQUFJLElBQUlsTSxTQUFaLEVBQXVCO0FBQ3RCO0FBQ0MsT0FBQW9NLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFM0wsWUFBTixLQUFzQmYsUUFBUSxDQUFDdU8sa0VBQU8sRUFBUixDQUE5QjtBQUNEO0FBQ0YsR0FQUSxFQU9OLENBQUM3QixJQUFJLENBQUMzTCxZQUFOLEVBQW9CeUwsSUFBcEIsYUFBb0JBLElBQXBCLHVCQUFvQkEsSUFBSSxDQUFFek0sT0FBMUIsQ0FQTSxDQUFUOztBQVNBLE1BQ0VvTixRQUFRLEtBQUssSUFBYixJQUNBQSxRQUFRLEtBQUs3TSxTQURiLElBRUE2TSxRQUZBLGFBRUFBLFFBRkEsb0NBRUFBLFFBQVEsQ0FBRXBOLE9BRlYsOENBRUEsa0JBQW1COE4sTUFGbkIsSUFHQSxDQUFBVixRQUFRLFNBQVIsSUFBQUEsUUFBUSxXQUFSLGtDQUFBQSxRQUFRLENBQUVwTixPQUFWLDBFQUFtQjhOLE1BQW5CLE1BQThCLENBSmhDLEVBS0U7QUFBQTs7QUFDQXBCLGlCQUFhLGdCQUNYO0FBQUssZUFBUyxFQUFDLGtCQUFmO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFDLGdCQUFmO0FBQUEsa0JBQWlDSTtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBSyxpQkFBUyxFQUFDLGlCQUFmO0FBQUEsZ0NBQ0U7QUFBQSxnREFFRTtBQUFBLHNCQUNHTSxRQUFRLElBQUlBLFFBQVEsS0FBSyxJQUF6QixJQUFpQyxDQUFBQSxRQUFRLFNBQVIsSUFBQUEsUUFBUSxXQUFSLGtDQUFBQSxRQUFRLENBQUVwTixPQUFWLDBFQUFtQjhOLE1BQW5CLElBQTRCLENBQTdELEdBQ0dXLGdHQUE4QixDQUFDckIsUUFBUSxDQUFDc0IsV0FBVixDQURqQyxHQUVHO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFTRTtBQUFBLGtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksRUFBQyx3QkFBWDtBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksRUFBQyxtQkFBWDtBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQyxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQXVCRCxHQTdCRCxNQTZCTztBQUNMaEMsaUJBQWEsZ0JBQ1g7QUFBSyxlQUFTLEVBQUMsa0JBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsZ0JBQWY7QUFBQSwrQkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBT0Q7O0FBRUQsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsZUFBZjtBQUFBLDRCQUNFO0FBQUcsZUFBUyxFQUFDLGVBQWI7QUFBNkIsVUFBSSxFQUFDLEdBQWxDO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUEsK0JBQ0U7QUFBQSxvQkFDR1UsUUFBUSxLQUFLLElBQWIsSUFBcUJBLFFBQVEsS0FBSzdNLFNBQWxDLElBQStDK00sVUFBVSxHQUFHLENBQTVELEdBQ0dBLFVBREgsR0FFRztBQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixFQVdHWixhQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FwTGdCO0FBQUEsVUFFRXhNLHVEQUZGLEVBR0YwTSx1REFIRTtBQUFBLEdBQWpCO01BQU1OLFE7QUFzTFNxQywwSEFBTyxDQUFFOUIsS0FBRCxJQUFXQSxLQUFLLENBQUNKLElBQWxCLENBQVAsQ0FBK0JILFFBQS9CLENBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaE1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU1zQyxpQkFBaUIsR0FBRyxDQUN4QjtBQUNFbk0sSUFBRSxFQUFFLEVBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQUR3QixFQUt4QjtBQUNFcE0sSUFBRSxFQUFFLENBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQUx3QixFQVN4QjtBQUNFcE0sSUFBRSxFQUFFLENBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQVR3QixFQWF4QjtBQUNFcE0sSUFBRSxFQUFFLENBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQWJ3QixFQWlCeEI7QUFDRXBNLElBQUUsRUFBRSxDQUROO0FBRUVvTSxlQUFhLEVBQUU7QUFGakIsQ0FqQndCLEVBcUJ4QjtBQUNFcE0sSUFBRSxFQUFFLENBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQXJCd0IsRUF5QnhCO0FBQ0VwTSxJQUFFLEVBQUUsRUFETjtBQUVFb00sZUFBYSxFQUFFO0FBRmpCLENBekJ3QixFQTZCeEI7QUFDRXBNLElBQUUsRUFBRSxFQUROO0FBRUVvTSxlQUFhLEVBQUU7QUFGakIsQ0E3QndCLEVBaUN4QjtBQUNFcE0sSUFBRSxFQUFFLEVBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQWpDd0IsRUFxQ3hCO0FBQ0VwTSxJQUFFLEVBQUUsRUFETjtBQUVFb00sZUFBYSxFQUFFO0FBRmpCLENBckN3QixFQXlDeEI7QUFDRXBNLElBQUUsRUFBRSxFQUROO0FBRUVvTSxlQUFhLEVBQUU7QUFGakIsQ0F6Q3dCLEVBNkN4QjtBQUNFcE0sSUFBRSxFQUFFLEVBRE47QUFFRW9NLGVBQWEsRUFBRTtBQUZqQixDQTdDd0IsRUFpRHhCO0FBQ0VwTSxJQUFFLEVBQUUsRUFETjtBQUVFb00sZUFBYSxFQUFFO0FBRmpCLENBakR3QixDQUExQjs7QUF1REEsU0FBU0MsV0FBVCxDQUFxQmxJLEtBQXJCLEVBQTRCbUksS0FBNUIsRUFBbUM7QUFBQTs7QUFDakMsUUFBTTtBQUFBLE9BQUNDLGNBQUQ7QUFBQSxPQUFpQkM7QUFBakIsTUFBc0N2TCxzREFBUSxDQUFDa0QsS0FBRCxDQUFwRDtBQUNBUix5REFBUyxDQUFDLE1BQU07QUFDZDtBQUNBLFVBQU04SSxPQUFPLEdBQUd6RixVQUFVLENBQUMsTUFBTTtBQUMvQndGLHVCQUFpQixDQUFDckksS0FBRCxDQUFqQjtBQUNELEtBRnlCLEVBRXZCbUksS0FGdUIsQ0FBMUI7QUFJQSxXQUFPLE1BQU07QUFDWEksa0JBQVksQ0FBQ0QsT0FBRCxDQUFaO0FBQ0QsS0FGRDtBQUdELEdBVFEsRUFTTixDQUFDdEksS0FBRCxFQUFRbUksS0FBUixDQVRNLENBQVQ7QUFXQSxTQUFPQyxjQUFQO0FBQ0Q7O0dBZFFGLFc7O0FBZ0JULE1BQU1NLFlBQVksR0FBRyxNQUFNO0FBQUE7O0FBQ3pCLFFBQU1DLE9BQU8sR0FBR0Msb0RBQU0sQ0FBQyxJQUFELENBQXRCO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCOUwsc0RBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUMrTCxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QmhNLHNEQUFRLENBQUMsRUFBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDaU0sUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJsTSxzREFBUSxDQUFDLEVBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ21NLFdBQUQ7QUFBQSxPQUFjQztBQUFkLE1BQWdDcE0sc0RBQVEsQ0FBQyxJQUFELENBQTlDO0FBQ0EsUUFBTTtBQUFBLE9BQUNxTSxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QnRNLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU11TSxtQkFBbUIsR0FBR25CLFdBQVcsQ0FBQ1csT0FBRCxFQUFVLElBQVYsQ0FBdkM7O0FBRUEsV0FBU1Msa0JBQVQsR0FBOEI7QUFDNUJSLGNBQVUsQ0FBQyxFQUFELENBQVY7QUFDQUYsZUFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNBUSxjQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0Q7O0FBRUQsV0FBU2pLLFlBQVQsQ0FBc0J4RSxDQUF0QixFQUF5QjtBQUN2QkEsS0FBQyxDQUFDMkUsY0FBRjtBQUNBc0Msc0RBQU0sQ0FBQ0MsSUFBUCxDQUFhLG1CQUFrQmdILE9BQVEsRUFBdkM7QUFDRDs7QUFDRCxRQUFNO0FBQUEsT0FBQ1Usa0JBQUQ7QUFBQSxPQUFxQkM7QUFBckIsTUFBOEMxTSxzREFBUSxDQUFDLENBQzNEO0FBQ0UyTSxlQUFXLEVBQUUsRUFEZjtBQUVFeEIsaUJBQWEsRUFBRTtBQUZqQixHQUQyRCxDQUFELENBQTVEO0FBT0F6SSx5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJa0ssWUFBWSxHQUFHLElBQW5COztBQUNBLFVBQU1DLHVCQUF1QixHQUFHLFlBQVk7QUFDMUMsVUFBSTtBQUNGLGNBQU10SSxRQUFRLEdBQUcsTUFBTXVJLHVFQUFpQixDQUFDQyxvQkFBbEIsRUFBdkI7QUFDQUgsb0JBQVksR0FDUkYscUJBQXFCLENBQUMsQ0FDcEI7QUFDRUMscUJBQVcsRUFBRSxFQURmO0FBRUV4Qix1QkFBYSxFQUFFO0FBRmpCLFNBRG9CLEVBS3BCLEdBQUc1RyxRQUFRLENBQUNOLElBQVQsQ0FBYytJLFVBTEcsQ0FBRCxDQURiLEdBUVIsSUFSSjtBQVNELE9BWEQsQ0FXRSxPQUFPOUssS0FBUCxFQUFjO0FBQ2RKLGVBQU8sQ0FBQ0ksS0FBUixDQUFjQSxLQUFkO0FBQ0Q7QUFDRixLQWZEOztBQWlCQTJLLDJCQUF1QjtBQUV2QixXQUFPLE1BQU9ELFlBQVksR0FBRyxLQUE3QjtBQUNELEdBdEJRLEVBc0JOLEVBdEJNLENBQVQ7QUF3QkFsSyx5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJNkosbUJBQUosRUFBeUI7QUFDdkJELGdCQUFVLENBQUMsSUFBRCxDQUFWOztBQUNBLFVBQUlQLE9BQUosRUFBYTtBQUNYLGNBQU1rQixPQUFPLEdBQUc7QUFDZEMsZ0JBQU0sRUFBRSxDQURNO0FBRWRDLHdCQUFjLEVBQUVwQixPQUZGO0FBR2RZLHFCQUFXLEVBQUVWO0FBSEMsU0FBaEIsQ0FEVyxDQU1YOztBQUNBLGNBQU0xQyxRQUFRLEdBQUd1RCx1RUFBaUIsQ0FBQ00sbUJBQWxCLENBQXNDSCxPQUF0QyxDQUFqQjtBQUVBMUQsZ0JBQVEsQ0FBQ2pGLElBQVQsQ0FBZStJLE1BQUQsSUFBWTtBQUN4QmYsb0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDQUYsd0JBQWMsQ0FBQ2lCLE1BQU0sQ0FBQ0MsS0FBUixDQUFkO0FBQ0F4QixxQkFBVyxDQUFDLElBQUQsQ0FBWDtBQUNELFNBSkQ7QUFLRCxPQWRELE1BY087QUFDTEEsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDQUUsa0JBQVUsQ0FBQyxFQUFELENBQVY7QUFDRDs7QUFDRCxVQUFJSyxPQUFKLEVBQWE7QUFDWFAsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGLEtBdkJELE1BdUJPO0FBQ0xRLGdCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0FSLGlCQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0Q7QUFDRixHQTVCUSxFQTRCTixDQUFDUyxtQkFBRCxDQTVCTSxDQUFULENBbER5QixDQWdGekI7O0FBQ0EsTUFBSWdCLGdCQUFKLEVBQ0VDLGFBREYsRUFFRUMsZ0JBRkYsRUFHRUMsV0FIRixFQUlFQyxZQUpGOztBQUtBLE1BQUksQ0FBQ3RCLE9BQUwsRUFBYztBQUNaLFFBQUlGLFdBQVcsSUFBSUEsV0FBVyxDQUFDL0IsTUFBWixHQUFxQixDQUF4QyxFQUEyQztBQUN6QyxVQUFJK0IsV0FBVyxDQUFDL0IsTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQnVELG9CQUFZLGdCQUNWO0FBQUssbUJBQVMsRUFBQyw4QkFBZjtBQUFBLGlDQUNFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksRUFBQyxTQUFYO0FBQUEsbUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQU9EOztBQUNESixzQkFBZ0IsR0FBR3BCLFdBQVcsQ0FBQ2hLLEdBQVosQ0FBaUI3RixPQUFELGlCQUNqQyxxRUFBQyx5RkFBRDtBQUFxQixlQUFPLEVBQUVBO0FBQTlCLFNBQTRDQSxPQUFPLENBQUN5QyxFQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURpQixDQUFuQjtBQUdELEtBYkQsTUFhTztBQUNMd08sc0JBQWdCLGdCQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFuQjtBQUNEOztBQUNELFFBQUl4QixPQUFPLEtBQUssRUFBaEIsRUFBb0I7QUFDbEJ5QixtQkFBYSxnQkFDWDtBQUFNLGlCQUFTLEVBQUMsaUJBQWhCO0FBQWtDLGVBQU8sRUFBRWhCLGtCQUEzQztBQUFBLCtCQUNFO0FBQUcsbUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGO0FBS0Q7QUFDRixHQXhCRCxNQXdCTztBQUNMa0IsZUFBVyxnQkFDVDtBQUFNLGVBQVMsRUFBQyxpQkFBaEI7QUFBQSw2QkFDRSxxRUFBQyx5Q0FBRDtBQUFNLFlBQUksRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBS0Q7O0FBRUQsTUFBSSxDQUFBakIsa0JBQWtCLFNBQWxCLElBQUFBLGtCQUFrQixXQUFsQixZQUFBQSxrQkFBa0IsQ0FBRXJDLE1BQXBCLElBQTZCLENBQWpDLEVBQW9DO0FBQ2xDcUQsb0JBQWdCLEdBQUdoQixrQkFBSCxhQUFHQSxrQkFBSCx1QkFBR0Esa0JBQWtCLENBQUV0SyxHQUFwQixDQUF3QixDQUFDb0YsTUFBRCxFQUFTTSxLQUFULEtBQW1CO0FBQzVELDBCQUNFO0FBQVEsYUFBSyxFQUFFTixNQUFNLENBQUNvRixXQUF0QjtBQUFBLGtCQUNHcEYsTUFBTSxDQUFDNEQ7QUFEVixTQUF3Q3RELEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREY7QUFLRCxLQU5rQixDQUFuQjtBQU9EOztBQUNELHNCQUNFO0FBQ0UsYUFBUyxFQUFDLHVCQURaO0FBRUUsVUFBTSxFQUFDLEtBRlQ7QUFHRSxVQUFNLEVBQUMsR0FIVDtBQUlFLFlBQVEsRUFBRXhGLFlBSlo7QUFBQSw0QkFpQkU7QUFBSyxlQUFTLEVBQUMsZ0JBQWY7QUFBQSw4QkFDRTtBQUNFLFdBQUcsRUFBRXNKLE9BRFA7QUFFRSxpQkFBUyxFQUFDLGNBRlo7QUFHRSxZQUFJLEVBQUMsTUFIUDtBQUlFLGFBQUssRUFBRUksT0FKVDtBQUtFLG1CQUFXLEVBQUMscUJBTGQ7QUFNRSxnQkFBUSxFQUFHbE8sQ0FBRCxJQUFPbU8sVUFBVSxDQUFDbk8sQ0FBQyxDQUFDTyxNQUFGLENBQVM4RSxLQUFWO0FBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsRUFTR3NLLGFBVEgsRUFVR0UsV0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBakJGLGVBOEJFO0FBQUssZUFBUyxFQUFHLDBCQUF5QjdCLFFBQVEsR0FBRyxVQUFILEdBQWdCLEVBQUcsRUFBckU7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBQSxrQkFBb0MwQjtBQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLEVBRUdJLFlBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFDRCxDQXBLRDs7SUFBTWpDLFk7VUFPd0JOLFc7OztLQVB4Qk0sWTtBQXNLU0EsMkVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTWtDLHNCQUFzQixHQUFHLE1BQU07QUFBQTs7QUFBQTs7QUFDbkMsUUFBTTtBQUFBLE9BQUNuQixrQkFBRDtBQUFBLE9BQXFCQztBQUFyQixNQUE4QzFNLHNEQUFRLENBQUMsRUFBRCxDQUE1RDs7QUFFQSxRQUFNNk0sdUJBQXVCLEdBQUcsWUFBWTtBQUMxQyxRQUFJO0FBQ0YsWUFBTXRJLFFBQVEsR0FBRyxNQUFNTCw0Q0FBSyxDQUFDQyxJQUFOLENBQ3BCLEdBQUVDLG1FQUFXLDBCQURPLENBQXZCO0FBR0FzSSwyQkFBcUIsQ0FBQ25JLFFBQVEsQ0FBQ04sSUFBVixDQUFyQjtBQUNELEtBTEQsQ0FLRSxPQUFPL0IsS0FBUCxFQUFjO0FBQ2RKLGFBQU8sQ0FBQ0ksS0FBUixDQUFjQSxLQUFkO0FBQ0Q7QUFDRixHQVREOztBQVdBLFFBQU07QUFBRTJMO0FBQUYsTUFBZTNFLCtEQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDMkUsSUFBbEIsQ0FBaEM7QUFFQXBMLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUk4SSxPQUFKO0FBQ0FBLFdBQU8sR0FBR3pGLFVBQVUsQ0FBQyxZQUFZO0FBQy9CLFlBQU04Ryx1QkFBdUIsRUFBN0I7QUFDRCxLQUZtQixFQUVqQixHQUZpQixDQUFwQjtBQUdBLFdBQU8sTUFBTTtBQUNYcEIsa0JBQVksQ0FBQ0QsT0FBRCxDQUFaO0FBQ0QsS0FGRDtBQUdELEdBUlEsRUFRTixDQUFDcUMsUUFBRCxDQVJNLENBQVQ7QUFVQSxzQkFDRTtBQUFLLGFBQVMsRUFBQywwQkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLGNBQWY7QUFBQSw4QkFDRTtBQUFHLGlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBS0U7QUFBSyxlQUFTLEVBQUMsZUFBZjtBQUFBLDZCQUNFLHFFQUFDLDRFQUFEO0FBQ0UsY0FBTSxFQUFFcEIsa0JBQUYsYUFBRUEsa0JBQUYsZ0RBQUVBLGtCQUFrQixDQUFFeEksSUFBdEIsMERBQUUsc0JBQTBCK0ksVUFEcEM7QUFFRSxpQkFBUyxFQUFDO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFjRCxDQXhDRDs7R0FBTVksc0I7VUFjaUIxRSx1RDs7O0tBZGpCMEUsc0I7QUEwQ1NBLHFGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakRBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1HLFNBQVMsR0FBRyxDQUFDckosSUFBRCxFQUFPM0gsT0FBUCxFQUFnQkMsV0FBaEIsS0FBZ0M7QUFDaERGLG1EQUFZLENBQUM0SCxJQUFELENBQVosQ0FBbUI7QUFDakIzSCxXQURpQjtBQUVqQkM7QUFGaUIsR0FBbkI7QUFJRCxDQUxEOztBQU9BLE1BQU00RSxpQkFBTixDQUF3QjtBQUN0QixRQUFNb00sb0JBQU4sQ0FBMkJ6USxPQUEzQixFQUFvQztBQUNsQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVywwQkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYmtKLEdBQUQsSUFBUztBQUNkSCxlQUFTLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsa0NBQW5CLENBQVQ7QUFDRCxLQVRvQixDQUF2QjtBQVVBLFdBQU94SixRQUFQO0FBQ0Q7O0FBR0QsUUFBTTFDLGNBQU4sQ0FBcUJ0RSxPQUFyQixFQUE4QjtBQUM1QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVywrQkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ04sSUFBVCxDQUFjakMsUUFBZCxJQUEwQixHQUE5QixFQUFtQztBQUNqQyxlQUFPdUMsUUFBUSxDQUFDTixJQUFoQjtBQUNEOztBQUNELGFBQU9NLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQVRvQixFQVVwQmUsS0FWb0IsQ0FVYmtKLEdBQUQsSUFBU3BNLE9BQU8sQ0FBQ0MsR0FBUixDQUFZbU0sR0FBWixDQVZLLENBQXZCO0FBV0EsV0FBTzNKLFFBQVA7QUFDRDs7QUFFRCxRQUFNakMsZUFBTixDQUFzQi9FLE9BQXRCLEVBQStCO0FBQzdCK00sU0FBSyxDQUFDLEdBQUQsQ0FBTDtBQUNBeEksV0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWixFQUF5QnhFLE9BQXpCO0FBQ0EsVUFBTWdILFFBQVEsR0FBRyxNQUFNMEosbURBQVUsQ0FBQzlKLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsd0JBRE8sRUFFckI3RyxPQUZxQixFQUlwQitHLElBSm9CLENBSWRDLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNOLElBQVQsQ0FBY2pDLFFBQWQsSUFBMEIsR0FBOUIsRUFBbUM7QUFDakMsZUFBT3VDLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRDs7QUFDRCxhQUFPTSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FUb0IsRUFVcEJlLEtBVm9CLENBVWJrSixHQUFELElBQVNwTSxPQUFPLENBQUNDLEdBQVIsQ0FBWW1NLEdBQVosQ0FWSyxDQUF2QjtBQVdBLFdBQU8zSixRQUFQO0FBQ0Q7O0FBRUQsUUFBTTRKLG1CQUFOLENBQTBCNVEsT0FBMUIsRUFBbUM7QUFDakMsVUFBTWdILFFBQVEsR0FBRyxNQUFNMEosbURBQVUsQ0FBQzlKLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsNEJBRE8sRUFFckI3RyxPQUZxQixFQUlwQitHLElBSm9CLENBSWYsVUFBVUMsUUFBVixFQUFvQjtBQUN4QixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJlLEtBUG9CLENBT2QsVUFBVVQsUUFBVixFQUFvQjtBQUN6QnpDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZd0MsUUFBWjtBQUNBLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQVZvQixDQUF2QjtBQVdBLFdBQU9NLFFBQVA7QUFDRDs7QUFFRCxRQUFNMUIsVUFBTixHQUFtQjtBQUNqQixVQUFNMEIsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUFpQixHQUFFQyxzREFBVyx1QkFBOUIsRUFDcEJFLElBRG9CLENBQ2RDLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNOLElBQVQsQ0FBY2pDLFFBQWQsSUFBMEIsR0FBOUIsRUFBbUM7QUFDakMsZUFBT3VDLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFyQjtBQUNEOztBQUNELGFBQU9NLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYmtKLEdBQUQsSUFBU3BNLE9BQU8sQ0FBQ0MsR0FBUixDQUFZbU0sR0FBWixDQVBLLENBQXZCO0FBUUEsV0FBTzNKLFFBQVA7QUFDRDs7QUFFRCxRQUFNNkosV0FBTixDQUFrQjdRLE9BQWxCLEVBQTJCO0FBQ3pCLFVBQU1nSCxRQUFRLEdBQUcsTUFBTUwsNENBQUssQ0FBQztBQUMzQm1LLFlBQU0sRUFBRSxNQURtQjtBQUUzQkMsU0FBRyxFQUFHLEdBQUVsSyxzREFBVyx5QkFGUTtBQUczQkgsVUFBSSxFQUFFMUcsT0FIcUI7QUFJM0I4RyxhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKa0IsS0FBRCxDQUFMLENBTXBCQyxJQU5vQixDQU1kQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBUm9CLEVBU3BCZSxLQVRvQixDQVNiOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBVGMsQ0FBdkI7QUFXQSxXQUFPcUMsUUFBUDtBQUNEOztBQUVELFFBQU1nSyxjQUFOLENBQXFCaFIsT0FBckIsRUFBOEI7QUFDNUIsVUFBTWdILFFBQVEsR0FBRyxNQUFNTCw0Q0FBSyxDQUFDO0FBQzNCbUssWUFBTSxFQUFFLE1BRG1CO0FBRTNCQyxTQUFHLEVBQUcsR0FBRWxLLHNEQUFXLDRCQUZRO0FBRzNCSCxVQUFJLEVBQUUxRyxPQUhxQjtBQUkzQjhHLGFBQU8sRUFBRTtBQUFFLHdCQUFnQjtBQUFsQjtBQUprQixLQUFELENBQUwsQ0FNcEJDLElBTm9CLENBTWRDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FSb0IsRUFTcEJlLEtBVG9CLENBU2I5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FUYyxDQUF2QjtBQVdBLFdBQU9xQyxRQUFQO0FBQ0Q7O0FBRUQsUUFBTWlLLFdBQU4sQ0FBa0JqUixPQUFsQixFQUEyQjtBQUN6QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU1MLDRDQUFLLENBQUM7QUFDM0JtSyxZQUFNLEVBQUUsTUFEbUI7QUFFM0JDLFNBQUcsRUFBRyxHQUFFbEssc0RBQVcseUJBRlE7QUFHM0JILFVBQUksRUFBRTFHLE9BSHFCO0FBSTNCOEcsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmtCLEtBQUQsQ0FBTCxDQU1wQkMsSUFOb0IsQ0FNZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQVJvQixFQVNwQmUsS0FUb0IsQ0FTYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVRjLENBQXZCO0FBV0EsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNa0ssUUFBTixDQUFlbFIsT0FBZixFQUF3QjtBQUN0QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxxQkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ04sSUFBVCxDQUFjakMsUUFBZCxJQUEwQixLQUE5QixFQUFxQztBQUNuQyxlQUFPdUMsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQXJCO0FBQ0Q7O0FBQ0QsYUFBT00sUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBVG9CLEVBVXBCZSxLQVZvQixDQVVia0osR0FBRCxJQUFTcE0sT0FBTyxDQUFDQyxHQUFSLENBQVltTSxHQUFaLENBVkssQ0FBdkI7QUFXQSxXQUFPM0osUUFBUDtBQUNEOztBQUVELFFBQU1tSyxPQUFOLENBQWNuUixPQUFkLEVBQXVCO0FBQ3JCLFVBQU1nSCxRQUFRLEdBQUcsTUFBTTBKLG1EQUFVLENBQUM5SixJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLG9CQURPLEVBRXJCN0csT0FGcUIsRUFJcEIrRyxJQUpvQixDQUlkQyxRQUFELElBQWM7QUFDbEIsVUFBSUEsUUFBUSxDQUFDTixJQUFULENBQWNqQyxRQUFkLElBQTBCLEtBQTlCLEVBQXFDO0FBQ25DLGVBQU91QyxRQUFRLENBQUNOLElBQVQsQ0FBY0EsSUFBckI7QUFDRDs7QUFDRCxhQUFPTSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FUb0IsRUFVcEJlLEtBVm9CLENBVWJrSixHQUFELElBQVNwTSxPQUFPLENBQUNDLEdBQVIsQ0FBWW1NLEdBQVosQ0FWSyxDQUF2QjtBQVdBLFdBQU8zSixRQUFQO0FBQ0Q7O0FBRUQsUUFBTW9LLFdBQU4sQ0FBa0JwUixPQUFsQixFQUEyQjtBQUN6QixVQUFNcVIsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDBCQURNLEVBRXBCN0csT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm1CLEVBT25CZSxLQVBtQixDQU9aOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1DLGtCQUFOLENBQXlCdFIsT0FBekIsRUFBa0M7QUFDaEMsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1Q0FETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNRSxlQUFOLENBQXNCdlIsT0FBdEIsRUFBK0I7QUFDN0IsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyw0QkFETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRCxHQXhMcUIsQ0EwTHRCOzs7QUFDQSxRQUFNRyx3QkFBTixHQUFpQztBQUMvQixRQUFJclMsUUFBUSxHQUFHQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsQ0FBZjtBQUNBLFFBQUlNLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdWLFFBQVgsQ0FBaEI7QUFDQSxRQUFJWSxZQUFZLEdBQUdKLFNBQUgsYUFBR0EsU0FBSCx1QkFBR0EsU0FBUyxDQUFFSSxZQUE5QjtBQUVBLFVBQU1zUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsdUJBRE0sRUFFcEI7QUFBRTlHLGtCQUFGO0FBQWdCbU4sYUFBTyxFQUFFO0FBQXpCLEtBRm9CLEVBSW5CbkcsSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNSSwyQkFBTixDQUFrQ3pSLE9BQWxDLEVBQTJDO0FBQ3pDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsNEJBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTUssc0JBQU4sQ0FBNkIxUixPQUE3QixFQUFzQztBQUNwQyxRQUFJYixRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSU0sU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV1YsUUFBWCxDQUFoQjtBQUNBLFFBQUlZLFlBQVksR0FBR0osU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQTlCO0FBRUEsVUFBTXNSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyw0QkFETSxFQUVwQjtBQUFFOUcsa0JBQUY7QUFBZ0JtTixhQUFPLEVBQUU7QUFBekIsS0FGb0IsRUFJbkJuRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm1CLEVBT25CZSxLQVBtQixDQU9aOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1NLG9CQUFOLEdBQTZCO0FBQzNCLFFBQUl4UyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSU0sU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV1YsUUFBWCxDQUFoQjtBQUNBLFFBQUlZLFlBQVksR0FBR0osU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQTlCO0FBRUEsVUFBTXNSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQjtBQUFFOUc7QUFBRixLQUZvQixFQUluQmdILElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBQ0QsUUFBTU8sb0JBQU4sQ0FBMkI1UixPQUEzQixFQUFvQztBQUNsQyxRQUFJYixRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSU0sU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV1YsUUFBWCxDQUFoQjtBQUNBLFFBQUlZLFlBQVksR0FBR0osU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQTlCO0FBRUEsUUFBSThSLGtCQUFrQixHQUFHLElBQUlDLFFBQUosRUFBekI7QUFFQUQsc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLGNBQTFCLEVBQTBDaFMsWUFBMUM7QUFDQThSLHNCQUFrQixDQUFDRSxNQUFuQixDQUEwQixZQUExQixFQUF3Qy9SLE9BQU8sQ0FBQ2dTLFVBQWhEO0FBQ0FILHNCQUFrQixDQUFDRSxNQUFuQixDQUEwQixZQUExQixFQUF3Qy9SLE9BQU8sQ0FBQ2lTLE9BQWhEO0FBRUEsVUFBTVosT0FBTyxHQUFHLE1BQU0xSyw0Q0FBSyxDQUFDO0FBQzFCbUssWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWxLLHNEQUFXLCtCQUZPO0FBRzFCSCxVQUFJLEVBQUVtTCxrQkFIb0I7QUFJMUIvSyxhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKaUIsS0FBRCxDQUFMLENBTW5CQyxJQU5tQixDQU1iQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBUm1CLEVBU25CZSxLQVRtQixDQVNaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1hLGFBQU4sQ0FBb0JsUyxPQUFwQixFQUE2QjtBQUMzQixRQUFJYixRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSU0sU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV1YsUUFBWCxDQUFoQjtBQUNBLFFBQUlZLFlBQVksR0FBR0osU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQTlCO0FBRUEsUUFBSThSLGtCQUFrQixHQUFHLElBQUlDLFFBQUosRUFBekI7QUFFQUQsc0JBQWtCLENBQUNFLE1BQW5CLENBQTBCLGNBQTFCLEVBQTBDaFMsWUFBMUM7QUFDQThSLHNCQUFrQixDQUFDRSxNQUFuQixDQUEwQixZQUExQixFQUF3Qy9SLE9BQU8sQ0FBQ2dTLFVBQWhEO0FBRUEsVUFBTVgsT0FBTyxHQUFHLE1BQU0xSyw0Q0FBSyxDQUFDO0FBQzFCbUssWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWxLLHNEQUFXLDhCQUZPO0FBRzFCSCxVQUFJLEVBQUVtTCxrQkFIb0I7QUFJMUIvSyxhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFKaUIsS0FBRCxDQUFMLENBTW5CQyxJQU5tQixDQU1iQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBUm1CLEVBU25CZSxLQVRtQixDQVNaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBVGEsQ0FBdEI7QUFVQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1jLFVBQU4sQ0FBaUJuUyxPQUFqQixFQUEwQjtBQUN4QixVQUFNcVIsT0FBTyxHQUFHLE1BQU0xSyw0Q0FBSyxDQUFDO0FBQzFCbUssWUFBTSxFQUFFLE1BRGtCO0FBRTFCQyxTQUFHLEVBQUcsR0FBRWxLLHNEQUFXLDJCQUZPO0FBRzFCSCxVQUFJLEVBQUUxRyxPQUhvQjtBQUkxQjhHLGFBQU8sRUFBRTtBQUFFLHdCQUFnQjtBQUFsQjtBQUppQixLQUFELENBQUwsQ0FNbkJDLElBTm1CLENBTWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FSbUIsRUFTbkJlLEtBVG1CLENBU1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FUYSxDQUF0QjtBQVVBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWUsYUFBTixDQUFvQnBTLE9BQXBCLEVBQTZCO0FBQzNCLFVBQU1xUixPQUFPLEdBQUcsTUFBTTFLLDRDQUFLLENBQUM7QUFDMUJtSyxZQUFNLEVBQUUsTUFEa0I7QUFFMUJDLFNBQUcsRUFBRyxHQUFFbEssc0RBQVcsNEJBRk87QUFHMUJILFVBQUksRUFBRTFHLE9BSG9CO0FBSTFCOEcsYUFBTyxFQUFFO0FBQUUsd0JBQWdCO0FBQWxCO0FBSmlCLEtBQUQsQ0FBTCxDQU1uQkMsSUFObUIsQ0FNYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQVJtQixFQVNuQmUsS0FUbUIsQ0FTWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVRhLENBQXRCO0FBVUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNZ0Isa0JBQU4sQ0FBeUJyUyxPQUF6QixFQUFrQztBQUNoQyxVQUFNcVIsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDhCQURNLEVBRXBCN0csT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm1CLEVBT25CZSxLQVBtQixDQU9aOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1pQixvQkFBTixDQUEyQnRTLE9BQTNCLEVBQW9DO0FBQ2xDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcscUNBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTWtCLGtCQUFOLENBQXlCdlMsT0FBekIsRUFBa0M7QUFDaEMsVUFBTWdILFFBQVEsR0FBRyxNQUFNMEosbURBQVUsQ0FBQzlKLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsNkJBRE8sRUFFckI3RyxPQUZxQixFQUlwQitHLElBSm9CLENBSWRDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJlLEtBUG9CLENBT2I5QyxLQUFELElBQVdxQyxRQUFRLENBQUNyQyxLQVBOLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNd0wsZ0JBQU4sQ0FBdUJ4UyxPQUF2QixFQUFnQztBQUM5QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVywyQkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNeUwsa0JBQU4sQ0FBeUJ6UyxPQUF6QixFQUFrQztBQUNoQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVywrQkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNMEwsZ0JBQU4sQ0FBdUIxUyxPQUF2QixFQUFnQztBQUM5QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNMkwsZ0JBQU4sQ0FBdUIzUyxPQUF2QixFQUFnQztBQUM5QixVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyw2QkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNNEwsa0JBQU4sQ0FBeUI1UyxPQUF6QixFQUFrQztBQUNoQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyw4QkFETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNNkwsbUJBQU4sQ0FBMEI3UyxPQUExQixFQUFtQztBQUNqQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNOEwsbUJBQU4sQ0FBMEI5UyxPQUExQixFQUFtQztBQUNqQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxrQ0FETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNNEIscUJBQU4sQ0FBNEI1SSxPQUE1QixFQUFxQztBQUNuQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxpQ0FETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNMEIsdUJBQU4sQ0FBOEIxSSxPQUE5QixFQUF1QztBQUNyQyxVQUFNZ0gsUUFBUSxHQUFHLE1BQU0wSixtREFBVSxDQUFDOUosSUFBWCxDQUNwQixHQUFFQyxzREFBVyxtQ0FETyxFQUVyQjdHLE9BRnFCLEVBSXBCK0csSUFKb0IsQ0FJZEMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5vQixFQU9wQmUsS0FQb0IsQ0FPYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBjLENBQXZCO0FBUUEsV0FBT3FDLFFBQVA7QUFDRDs7QUFFRCxRQUFNc0IsZUFBTixDQUFzQnRJLE9BQXRCLEVBQStCO0FBQzdCLFVBQU1nSCxRQUFRLEdBQUcsTUFBTTBKLG1EQUFVLENBQUM5SixJQUFYLENBQ3BCLEdBQUVDLHNEQUFXLHVDQURPLEVBRXJCN0csT0FGcUIsRUFJcEIrRyxJQUpvQixDQUlkQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm9CLEVBT3BCZSxLQVBvQixDQU9iOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGMsQ0FBdkI7QUFRQSxXQUFPcUMsUUFBUDtBQUNEOztBQTNkcUI7O0FBZ2VULG1FQUFJM0MsaUJBQUosRUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNWVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTTBPLE9BQU4sQ0FBYztBQUNaLFFBQU1DLFdBQU4sQ0FBa0JDLFFBQWxCLEVBQTRCO0FBQzFCLFFBQUlqVCxPQUFPLEdBQUc7QUFDWkQsa0JBQVksRUFBRSxFQURGO0FBRVptTixhQUFPLEVBQUUsQ0FGRztBQUdaQyxlQUFTLEVBQUVGLHFFQUhDO0FBSVpHLGNBQVEsRUFBRThGLDZFQUFXLENBQUMsR0FBRCxDQUpUO0FBS1o3RixhQUFPLEVBQUU4Rix3RUFBTTtBQUxILEtBQWQ7QUFRQSxVQUFNQyxXQUFXLEdBQUdDLDRDQUFLLENBQUNELFdBQTFCO0FBQ0EsUUFBSUUsTUFBTSxHQUFHRixXQUFXLENBQUNFLE1BQVosRUFBYjtBQUVBQSxVQUFNLElBQUlBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjLHdDQUFkLENBQVYsQ0FaMEIsQ0FhMUI7O0FBQ0FELFVBQU0sR0FBR0QsNENBQUssQ0FBQ0QsV0FBTixDQUFrQkUsTUFBbEIsRUFBVDtBQUVBLFVBQU1qQyxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsb0JBRE0sRUFFcEI3RyxPQUZvQixFQUdwQjtBQUNFd1QsaUJBQVcsRUFBRUYsTUFBTSxDQUFDeFQ7QUFEdEIsS0FIb0IsRUFPbkJpSCxJQVBtQixDQU9iQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBVG1CLEVBVW5CZSxLQVZtQixDQVVaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBVmEsQ0FBdEIsQ0FoQjBCLENBMkIxQjs7QUFDQTJPLFVBQU0sQ0FBQ0MsTUFBUCxDQUFjLGlDQUFkO0FBQ0EsV0FBT2xDLE9BQVA7QUFDRDs7QUFFRCxRQUFNb0MsWUFBTixDQUFtQnpULE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsbUNBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXFDLGtCQUFOLENBQXlCMVQsT0FBekIsRUFBa0M7QUFDaEMsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyxrQ0FETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRCxHQXZEVyxDQXdEWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFsRVk7O0FBcUVDLG1FQUFJMEIsT0FBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6RUE7QUFBQTtBQUFBO0FBQUE7QUFDQTs7QUFPQSxNQUFNeEQsaUJBQU4sQ0FBd0I7QUFDdEIsUUFBTW9FLFVBQU4sQ0FBaUJDLE1BQWpCLEVBQXlCO0FBQ3ZCLFVBQU12QyxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQ21ELEdBQVgsQ0FDbkIsR0FBRUMsbURBQVEsYUFBWUMsa0VBQWMsQ0FBQ0gsTUFBRCxDQUFTLEVBRDFCLEVBR25CN00sSUFIbUIsQ0FHYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQUxtQixFQU1uQmUsS0FObUIsQ0FNWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQU5hLENBQXRCO0FBT0EsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNeEIsbUJBQU4sQ0FBMEIrRCxNQUExQixFQUFrQztBQUNoQyxVQUFNdkMsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLDhCQURNLEVBRXBCO0FBQ0VxRyxhQUFPLEVBQUUsRUFEWDtBQUVFa0MsaUJBQVcsRUFBRXdFLE1BQU0sQ0FBQ3hFLFdBRnRCO0FBR0VaLGFBQU8sRUFBRW9GLE1BQU0sQ0FBQ2hFO0FBSGxCLEtBRm9CLEVBUW5CN0ksSUFSbUIsQ0FRYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTCtJLGFBQUssRUFBRS9JLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1Cc0YsUUFEckI7QUFFTEssa0JBQVUsRUFBRXJGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1Cc047QUFGMUIsT0FBUDtBQUlELEtBYm1CLEVBZW5Cdk0sS0FmbUIsQ0FlWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQWZhLENBQXRCO0FBZ0JBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTRDLFdBQU4sQ0FBa0JMLE1BQWxCLEVBQTBCO0FBQ3hCLFVBQU12QyxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsa0NBQWQsR0FBa0QrTSxNQUFNLENBQUNNLElBRHJDLEVBRXBCO0FBQ0VoSCxhQUFPLEVBQUUsQ0FEWDtBQUVFbk4sa0JBQVksRUFBRSxFQUZoQjtBQUdFb04sZUFBUyxFQUFFRixxRUFIYjtBQUlFRyxjQUFRLEVBQUUsaUNBSlo7QUFLRUMsYUFBTyxFQUFFO0FBTFgsS0FGb0IsRUFVbkJ0RyxJQVZtQixDQVViQyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMK0ksYUFBSyxFQUFFL0ksUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJzRixRQURyQjtBQUVMSyxrQkFBVSxFQUFFckYsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJ5TjtBQUYxQixPQUFQO0FBSUQsS0FmbUIsRUFpQm5CMU0sS0FqQm1CLENBaUJaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBakJhLENBQXRCO0FBa0JBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTStDLG1CQUFOLENBQTBCcFUsT0FBMUIsRUFBbUM0VCxNQUFuQyxFQUEyQztBQUN6QyxVQUFNdkMsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG1DQUFkLEdBQW1EK00sTUFBTSxDQUFDTSxJQUR0QyxFQUVwQmxVLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTCtJLGFBQUssRUFBRS9JLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1Cc0YsUUFEckI7QUFFTEssa0JBQVUsRUFBRXJGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1CeU47QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMU0sS0FYbUIsQ0FXWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNZ0QsdUJBQU4sQ0FBOEJyVSxPQUE5QixFQUF1QzRULE1BQXZDLEVBQStDO0FBQzdDLFVBQU12QyxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcseUNBQWQsR0FBeUQrTSxNQUFNLENBQUNNLElBRDVDLEVBRXBCbFUsT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMK0ksYUFBSyxFQUFFL0ksUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUI0TixVQURyQjtBQUVMakksa0JBQVUsRUFBRXJGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1CeU47QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMU0sS0FYbUIsQ0FXWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNa0QsbUJBQU4sQ0FBMEJ2VSxPQUExQixFQUFtQzRULE1BQW5DLEVBQTJDO0FBQ3pDLFVBQU12QyxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsc0NBQWQsR0FBc0QrTSxNQUFNLENBQUNNLElBRHpDLEVBRXBCbFUsT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBTztBQUNMK0ksYUFBSyxFQUFFL0ksUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJzRixRQURyQjtBQUVMSyxrQkFBVSxFQUFFckYsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJ5TjtBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkIxTSxLQVhtQixDQVdaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1tRCxtQkFBTixDQUEwQnhVLE9BQTFCLEVBQW1DO0FBQ2pDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcseUNBQWQsR0FBeUQ3RyxPQUFPLENBQUNrVSxJQUQ3QyxFQUVwQmxVLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCekMsYUFBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQndDLFFBQTNCO0FBQ0EsYUFBTztBQUNMK0ksYUFBSyxFQUFFL0ksUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJzRixRQURyQjtBQUVMSyxrQkFBVSxFQUFFckYsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJ5TjtBQUYxQixPQUFQO0FBSUQsS0FWbUIsRUFZbkIxTSxLQVptQixDQVlaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBWmEsQ0FBdEI7QUFhQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1vRCwyQkFBTixDQUFrQ3pVLE9BQWxDLEVBQTJDO0FBQ3pDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsbUNBQWQsR0FBbUQ3RyxPQUFPLENBQUNrVSxJQUR2QyxFQUVwQmxVLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTCtJLGFBQUssRUFBRS9JLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1Cc0YsUUFEckI7QUFFTEssa0JBQVUsRUFBRXJGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1CeU47QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMU0sS0FYbUIsQ0FXWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNcUQsK0JBQU4sQ0FBc0MxVSxPQUF0QyxFQUErQztBQUM3QyxVQUFNcVIsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHlDQUFkLEdBQXlEN0csT0FBTyxDQUFDa1UsSUFEN0MsRUFFcEJsVSxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0wrSSxhQUFLLEVBQUUvSSxRQUFRLENBQUNOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQjROLFVBRHJCO0FBRUxqSSxrQkFBVSxFQUFFckYsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJ5TjtBQUYxQixPQUFQO0FBSUQsS0FUbUIsRUFXbkIxTSxLQVhtQixDQVdaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBWGEsQ0FBdEI7QUFZQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1zRCwyQkFBTixDQUFrQzNVLE9BQWxDLEVBQTJDO0FBQ3pDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsc0NBQWQsR0FBc0Q3RyxPQUFPLENBQUNrVSxJQUQxQyxFQUVwQmxVLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU87QUFDTCtJLGFBQUssRUFBRS9JLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1Cc0YsUUFEckI7QUFFTEssa0JBQVUsRUFBRXJGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjQSxJQUFkLENBQW1CeU47QUFGMUIsT0FBUDtBQUlELEtBVG1CLEVBV25CMU0sS0FYbUIsQ0FXWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVhhLENBQXRCO0FBWUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNdUQsbUJBQU4sQ0FBMEJoQixNQUExQixFQUFrQztBQUNoQyxVQUFNdkMsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLHlDQUFkLEdBQXlEK00sTUFBTSxDQUFDTSxJQUQ1QyxFQUduQm5OLElBSG1CLENBR2JDLFFBQUQsSUFBYztBQUNsQixhQUFPO0FBQ0wrSSxhQUFLLEVBQUUvSSxRQUFRLENBQUNOLElBQVQsQ0FBY0EsSUFBZCxDQUFtQjROLFVBRHJCO0FBRUxqSSxrQkFBVSxFQUFFckYsUUFBUSxDQUFDTixJQUFULENBQWNBLElBQWQsQ0FBbUJ5TjtBQUYxQixPQUFQO0FBSUQsS0FSbUIsRUFVbkIxTSxLQVZtQixDQVVaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBVmEsQ0FBdEI7QUFXQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU13RCxTQUFOLEdBQWtCO0FBQ2hCLFVBQU14RCxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FBaUIsR0FBRUMsc0RBQVcscUJBQTlCLEVBQ25CRSxJQURtQixDQUNiQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBSG1CLEVBSW5CZSxLQUptQixDQUlaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU03QixvQkFBTixHQUE2QjtBQUMzQjtBQUNBLFVBQU02QixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsMEJBRE0sRUFHbkJFLElBSG1CLENBR2JDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FMbUIsRUFNbkJlLEtBTm1CLENBTVo5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXlELGVBQU4sR0FBd0I7QUFDdEIsVUFBTXpELE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDbUQsR0FBWCxDQUFnQixHQUFFQyxtREFBUSxpQkFBMUIsRUFDbkIvTSxJQURtQixDQUNiQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBSG1CLEVBSW5CZSxLQUptQixDQUlaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU0wRCxlQUFOLENBQXNCdlQsRUFBdEIsRUFBMEI7QUFDeEIrQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QmhELEVBQTlCO0FBQ0EsUUFBSXJDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJTSxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXVixRQUFYLENBQWhCO0FBQ0EsUUFBSVksWUFBWSxHQUFHSixTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUksWUFBOUI7QUFDQXdFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDckYsUUFBdEM7QUFDQW9GLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaLEVBQXVDN0UsU0FBdkM7QUFDQTRFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUFaLEVBQTBDekUsWUFBMUM7QUFDQXdFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQXlDeUkscUVBQXpDO0FBQ0ExSSxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEwQ3pFLFlBQTFDO0FBQ0EsVUFBTWlILFFBQVEsR0FBRyxNQUFNMEosbURBQVUsQ0FBQzlKLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsOEJBRE8sRUFFckI7QUFDRTlHLGtCQURGO0FBRUV5QixRQUZGO0FBR0UwTCxhQUFPLEVBQUUsQ0FIWDtBQUlFQyxlQUFTLEVBQUVGLHFFQUpiO0FBS0VHLGNBQVEsRUFBRyxHQUFFNEgsdURBQVksWUFBV3hULEVBQUcsRUFMekM7QUFNRTZMLGFBQU8sRUFBRThGLHdFQUFNO0FBTmpCLEtBRnFCLEVBV3BCcE0sSUFYb0IsQ0FXZEMsUUFBRCxJQUFjO0FBQ2xCekMsYUFBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVosRUFBNkJ3QyxRQUE3QjtBQUNBLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQWRvQixFQWVwQmUsS0Fmb0IsQ0FlYjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQWZjLENBQXZCO0FBZ0JBLFdBQU9xQyxRQUFQO0FBQ0Q7O0FBRUQsUUFBTWlPLGdCQUFOLENBQXVCalYsT0FBdkIsRUFBZ0M7QUFDOUIsVUFBTWdILFFBQVEsR0FBRyxNQUFNMEosbURBQVUsQ0FBQzlKLElBQVgsQ0FDcEIsR0FBRUMsc0RBQVcsMEJBRE8sRUFFckI3RyxPQUZxQixFQUlwQitHLElBSm9CLENBSWRDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FOb0IsRUFPcEJlLEtBUG9CLENBT2I5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYyxDQUF2QjtBQVFBLFdBQU9xQyxRQUFQO0FBQ0Q7O0FBRUQsUUFBTWtPLHFCQUFOLENBQTRCbFYsT0FBNUIsRUFBcUM7QUFDbkMsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDbUQsR0FBWCxDQUNuQixHQUFFQyxtREFBUSw0QkFBMkI5VCxPQUFRLEVBRDFCLEVBR25CK0csSUFIbUIsQ0FHYkMsUUFBRCxJQUFjO0FBQ2xCLFVBQUlBLFFBQVEsQ0FBQ04sSUFBYixFQUFtQjtBQUNqQixZQUFJTSxRQUFRLENBQUNOLElBQVQsQ0FBY21HLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUIsaUJBQU83RixRQUFRLENBQUNOLElBQVQsQ0FBYyxDQUFkLENBQVA7QUFDRDtBQUNGLE9BSkQsTUFJTztBQUNMLGVBQU8sSUFBUDtBQUNEO0FBQ0YsS0FYbUIsRUFZbkJlLEtBWm1CLENBWWIsTUFBTTtBQUNYLGFBQU8sSUFBUDtBQUNELEtBZG1CLENBQXRCO0FBZUEsV0FBTzRKLE9BQVA7QUFDRDs7QUFDRCxRQUFNOEQsa0JBQU4sQ0FBeUJuVixPQUF6QixFQUFrQztBQUNoQyxVQUFNcVIsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUNtRCxHQUFYLENBQWdCLEdBQUVDLG1EQUFRLGdCQUFlOVQsT0FBUSxFQUFqRCxFQUNuQitHLElBRG1CLENBQ2JDLFFBQUQsSUFBYztBQUNsQixVQUFJQSxRQUFRLENBQUNOLElBQWIsRUFBbUI7QUFDakIsWUFBSU0sUUFBUSxDQUFDTixJQUFULENBQWNtRyxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQzVCLGlCQUFPN0YsUUFBUSxDQUFDTixJQUFULENBQWMsQ0FBZCxDQUFQO0FBQ0Q7QUFDRixPQUpELE1BSU87QUFDTCxlQUFPLElBQVA7QUFDRDtBQUNGLEtBVG1CLEVBVW5CZSxLQVZtQixDQVViLE1BQU07QUFDWCxhQUFPLElBQVA7QUFDRCxLQVptQixDQUF0QjtBQWFBLFdBQU80SixPQUFQO0FBQ0Q7O0FBRUQsUUFBTStELG1CQUFOLENBQTBCcFYsT0FBMUIsRUFBbUM7QUFDakMsUUFBSXFWLEtBQUssR0FBRyxFQUFaO0FBQ0FyVixXQUFPLENBQUNzVixPQUFSLENBQWlCQyxJQUFELElBQVU7QUFDeEIsVUFBSUYsS0FBSyxLQUFLLEVBQWQsRUFBa0I7QUFDaEJBLGFBQUssR0FBSSxTQUFRRSxJQUFLLEVBQXRCO0FBQ0QsT0FGRCxNQUVPO0FBQ0xGLGFBQUssR0FBR0EsS0FBSyxHQUFJLFVBQVNFLElBQUssRUFBL0I7QUFDRDtBQUNGLEtBTkQ7QUFPQSxVQUFNbEUsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUNtRCxHQUFYLENBQWdCLEdBQUVDLG1EQUFRLFdBQVV1QixLQUFNLEVBQTFDLEVBQ25CdE8sSUFEbUIsQ0FDYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQUhtQixFQUluQmUsS0FKbUIsQ0FJWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQUphLENBQXRCO0FBS0EsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNK0QsbUJBQU4sQ0FBMEJwVixPQUExQixFQUFtQztBQUNqQyxRQUFJcVYsS0FBSyxHQUFHLEVBQVo7QUFDQXJWLFdBQU8sQ0FBQ3NWLE9BQVIsQ0FBaUJDLElBQUQsSUFBVTtBQUN4QixVQUFJRixLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUNoQkEsYUFBSyxHQUFJLFNBQVFFLElBQUssRUFBdEI7QUFDRCxPQUZELE1BRU87QUFDTEYsYUFBSyxHQUFHQSxLQUFLLEdBQUksVUFBU0UsSUFBSyxFQUEvQjtBQUNEO0FBQ0YsS0FORDtBQU9BLFVBQU1sRSxPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQ21ELEdBQVgsQ0FBZ0IsR0FBRUMsbURBQVEsV0FBVXVCLEtBQU0sRUFBMUMsRUFDbkJ0TyxJQURtQixDQUNiQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBSG1CLEVBSW5CZSxLQUptQixDQUlaOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBSmEsQ0FBdEI7QUFLQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU1tRSx1QkFBTixDQUE4QnhWLE9BQTlCLEVBQXVDO0FBQ3JDLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQ21ELEdBQVgsQ0FDbkIsR0FBRUMsbURBQVEsYUFBWUMsa0VBQWMsQ0FBQy9ULE9BQUQsQ0FBVSxFQUQzQixFQUduQitHLElBSG1CLENBR2JDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FMbUIsRUFNbkJlLEtBTm1CLENBTVo5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FOYSxDQUF0QjtBQU9BLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTW9FLGdCQUFOLENBQXVCelYsT0FBdkIsRUFBZ0M7QUFDOUJ1RSxXQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFxQ3hFLE9BQXJDO0FBQ0EsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyx3QkFETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFDRCxRQUFNcUUsU0FBTixDQUFnQjFWLE9BQWhCLEVBQXlCO0FBQ3ZCLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsK0JBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXNFLFVBQU4sQ0FBaUIzVixPQUFqQixFQUEwQjtBQUN4QnVFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXNDeEUsT0FBdEM7QUFDQSxVQUFNcVIsT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLGdDQURNLEVBRXBCN0csT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm1CLEVBT25CZSxLQVBtQixDQU9aOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU05RCxPQUFOLENBQWN2TixPQUFkLEVBQXVCO0FBQ3JCdUUsV0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQnhFLE9BQTNCO0FBQ0EsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyxvQkFETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNdUUsVUFBTixDQUFpQjVWLE9BQWpCLEVBQTBCO0FBQ3hCLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsMkJBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTXdFLDRCQUFOLENBQW1DN1YsT0FBbkMsRUFBNEM7QUFDMUMsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVyx1QkFETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNeUUsU0FBTixDQUFnQjlWLE9BQWhCLEVBQXlCO0FBQ3ZCLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsMEJBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBRUQsUUFBTTBFLGlCQUFOLENBQXdCL1YsT0FBeEIsRUFBaUM7QUFDL0IsVUFBTXFSLE9BQU8sR0FBRyxNQUFNWCxtREFBVSxDQUFDOUosSUFBWCxDQUNuQixHQUFFQyxzREFBVywyQkFETSxFQUVwQjdHLE9BRm9CLEVBSW5CK0csSUFKbUIsQ0FJYkMsUUFBRCxJQUFjO0FBQ2xCLGFBQU9BLFFBQVEsQ0FBQ04sSUFBaEI7QUFDRCxLQU5tQixFQU9uQmUsS0FQbUIsQ0FPWjlDLEtBQUQsS0FBWTtBQUFFQSxXQUFLLEVBQUUvRSxJQUFJLENBQUN5SCxTQUFMLENBQWUxQyxLQUFmO0FBQVQsS0FBWixDQVBhLENBQXRCO0FBUUEsV0FBTzBNLE9BQVA7QUFDRDs7QUFFRCxRQUFNMkUsZUFBTixDQUFzQmhXLE9BQXRCLEVBQStCO0FBQzdCdUUsV0FBTyxDQUFDQyxHQUFSLENBQVksaUNBQVosRUFBOEN4RSxPQUE5QztBQUNBdUUsV0FBTyxDQUFDQyxHQUFSLENBQVksb0NBQVosRUFBaURxQyxzREFBakQ7QUFDQSxVQUFNd0ssT0FBTyxHQUFHLE1BQU1YLG1EQUFVLENBQUM5SixJQUFYLENBQ25CLEdBQUVDLHNEQUFXLG1DQURNLEVBRXBCN0csT0FGb0IsRUFJbkIrRyxJQUptQixDQUliQyxRQUFELElBQWM7QUFDbEIsYUFBT0EsUUFBUSxDQUFDTixJQUFoQjtBQUNELEtBTm1CLEVBT25CZSxLQVBtQixDQU9aOUMsS0FBRCxLQUFZO0FBQUVBLFdBQUssRUFBRS9FLElBQUksQ0FBQ3lILFNBQUwsQ0FBZTFDLEtBQWY7QUFBVCxLQUFaLENBUGEsQ0FBdEI7QUFRQSxXQUFPME0sT0FBUDtBQUNEOztBQUVELFFBQU00RSxpQkFBTixDQUF3QmpXLE9BQXhCLEVBQWlDO0FBQy9CLFVBQU1xUixPQUFPLEdBQUcsTUFBTVgsbURBQVUsQ0FBQzlKLElBQVgsQ0FDbkIsR0FBRUMsc0RBQVcsZ0NBRE0sRUFFcEI3RyxPQUZvQixFQUluQitHLElBSm1CLENBSWJDLFFBQUQsSUFBYztBQUNsQixhQUFPQSxRQUFRLENBQUNOLElBQWhCO0FBQ0QsS0FObUIsRUFPbkJlLEtBUG1CLENBT1o5QyxLQUFELEtBQVk7QUFBRUEsV0FBSyxFQUFFL0UsSUFBSSxDQUFDeUgsU0FBTCxDQUFlMUMsS0FBZjtBQUFULEtBQVosQ0FQYSxDQUF0QjtBQVFBLFdBQU8wTSxPQUFQO0FBQ0Q7O0FBdmNxQjs7QUEwY1QsbUVBQUk5QixpQkFBSixFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsZEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLE1BQU0yRyxVQUFVLEdBQUcsK0JBQW5CLEMsQ0FBb0Q7O0FBQzdDLE1BQU1DLFdBQVcsR0FBRywrQkFBcEIsQyxDQUFxRDs7QUFDckQsTUFBTUMsWUFBWSxHQUFHLCtCQUFyQixDLENBQXNEOztBQUU3RCxJQUFJQyxnQkFBZ0IsR0FBRyx1Q0FBdkI7QUFDQSxJQUFJQyxRQUFRLEdBQUcsZ0NBQWY7O0FBQ0EsVUFBbUM7QUFDakMsTUFBSXBMLE1BQU0sQ0FBQ3FMLFFBQVAsQ0FBZ0JDLFFBQWhCLElBQTRCLHdCQUFoQyxFQUEwRDtBQUN4REgsb0JBQWdCLEdBQUcsZ0NBQW5CO0FBQ0FDLFlBQVEsR0FBRyxnQ0FBWDtBQUNEOztBQUNELE1BQUlwTCxNQUFNLENBQUNxTCxRQUFQLENBQWdCQyxRQUFoQixJQUE0Qix1QkFBaEMsRUFBeUQ7QUFDdkRILG9CQUFnQixHQUFHLCtCQUFuQjtBQUNBQyxZQUFRLEdBQUcsK0JBQVg7QUFDRDtBQUNGOztBQUVNLE1BQU16UCxVQUFVLEdBQUd3UCxnQkFBbkI7QUFDQSxNQUFNckIsV0FBVyxHQUFHc0IsUUFBcEI7QUFFQSxNQUFNRyxhQUFhLEdBQUc7QUFDM0JDLFFBQU0sRUFBRTtBQURtQixDQUF0QjtBQUlBLE1BQU01QyxPQUFPLEdBQUksR0FBRW9DLFVBQVcsRUFBOUI7QUFFUTdDLDJHQUFLLENBQUNzRCxNQUFOLENBQWE7QUFDMUI3QyxTQUQwQjtBQUUxQmhOLFNBQU8sRUFBRTJQO0FBRmlCLENBQWIsQ0FBZjtBQUtPLE1BQU0xQyxjQUFjLEdBQUlzQixLQUFELElBQVc7QUFDdkMsU0FBT3VCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZeEIsS0FBWixFQUNKelEsR0FESSxDQUVGa1MsR0FBRCxJQUFVLEdBQUVDLGtCQUFrQixDQUFDRCxHQUFELENBQU0sSUFBR0Msa0JBQWtCLENBQUMxQixLQUFLLENBQUN5QixHQUFELENBQU4sQ0FBYSxFQUZuRSxFQUlKRSxJQUpJLENBSUMsR0FKRCxDQUFQO0FBS0QsQ0FOTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaENQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU8sTUFBTUMsV0FBVyxHQUFHO0FBQ3pCQyxVQUFRLEVBQUUsVUFEZTtBQUV6QkMsa0JBQWdCLEVBQUUsa0JBRk87QUFHekJDLGdCQUFjLEVBQUUsZ0JBSFM7QUFLekJDLHlCQUF1QixFQUFFLHlCQUxBO0FBTXpCQyxpQ0FBK0IsRUFBRSxpQ0FOUjtBQVF6QkMsVUFBUSxFQUFFLFVBUmU7QUFTekJDLGFBQVcsRUFBRSxhQVRZO0FBVXpCQyw4QkFBNEIsRUFBRSw4QkFWTDtBQVl6QkMsWUFBVSxFQUFFLFlBWmE7QUFhekJDLG9CQUFrQixFQUFFLG9CQWJLO0FBY3pCQyxrQkFBZ0IsRUFBRSxrQkFkTztBQWdCekJDLGNBQVksRUFBRSxjQWhCVztBQWlCekJDLHNCQUFvQixFQUFFLHNCQWpCRztBQWtCekJDLG9CQUFrQixFQUFFLG9CQWxCSztBQW9CekJDLGNBQVksRUFBRSxjQXBCVztBQXFCekJDLGFBQVcsRUFBRSxhQXJCWTtBQXVCekJDLHFCQUFtQixFQUFFLHFCQXZCSTtBQXdCekJDLG1CQUFpQixFQUFFLG1CQXhCTTtBQTBCekJDLHlCQUF1QixFQUFFLHlCQTFCQTtBQTRCekJDLHdCQUFzQixFQUFFLHdCQTVCQztBQTZCekJDLGdDQUE4QixFQUFFLGdDQTdCUDtBQStCekJDLGdCQUFjLEVBQUUsZ0JBL0JTO0FBaUN6QkMsd0JBQXNCLEVBQUUsd0JBakNDO0FBbUN6QkMsMEJBQXdCLEVBQUUsMEJBbkNEO0FBcUN6QkMsaUNBQStCLEVBQUUsaUNBckNSO0FBdUN6QkMsc0JBQW9CLEVBQUUsc0JBdkNHO0FBeUN6QkMsc0JBQW9CLEVBQUUscUJBekNHO0FBMkN6QkMsb0JBQWtCLEVBQUUsb0JBM0NLO0FBNkN6QkMsaUNBQStCLEVBQUU7QUE3Q1IsQ0FBcEI7QUFnREEsU0FBU3ZZLHdCQUFULENBQWtDUCxPQUFsQyxFQUEyQztBQUNoRCxTQUFPO0FBQUVtSCxRQUFJLEVBQUU4UCxXQUFXLENBQUNRLDRCQUFwQjtBQUFrRHpYO0FBQWxELEdBQVA7QUFDRDtBQUVNLFNBQVMrWSxxQkFBVCxDQUErQi9ZLE9BQS9CLEVBQXdDO0FBQzdDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQzZCLCtCQUFwQjtBQUFxRDlZO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVNnWixpQkFBVCxDQUEyQmhaLE9BQTNCLEVBQW9DO0FBQ3pDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQzJCLG9CQUFwQjtBQUEwQzVZO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVNpWixnQkFBVCxDQUEwQmpaLE9BQTFCLEVBQW1DO0FBQ3hDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQzRCLGtCQUFwQjtBQUF3QzdZO0FBQXhDLEdBQVA7QUFDRDtBQUVNLFNBQVNrWixrQkFBVCxDQUE0QmxaLE9BQTVCLEVBQXFDO0FBQzFDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQzBCLG9CQUFwQjtBQUEwQzNZO0FBQTFDLEdBQVA7QUFDRDtBQUVNLFNBQVNtWiwyQkFBVCxDQUFxQ25aLE9BQXJDLEVBQThDO0FBQ25ELFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQ3lCLCtCQUFwQjtBQUFxRDFZO0FBQXJELEdBQVA7QUFDRDtBQUVNLFNBQVNvWixvQkFBVCxDQUE4QnBaLE9BQTlCLEVBQXVDO0FBQzVDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQ3VCLHNCQUFwQjtBQUE0Q3hZO0FBQTVDLEdBQVA7QUFDRDtBQUVNLFNBQVNxWixzQkFBVCxDQUFnQ3JaLE9BQWhDLEVBQXlDO0FBQzlDLFNBQU87QUFBRW1ILFFBQUksRUFBRThQLFdBQVcsQ0FBQ3dCLHdCQUFwQjtBQUE4Q3pZO0FBQTlDLEdBQVA7QUFDRDtBQUVNLFNBQVNzWixhQUFULENBQXVCdFosT0FBdkIsRUFBZ0M7QUFDckMsU0FBTztBQUFFbUgsUUFBSSxFQUFFOFAsV0FBVyxDQUFDc0IsY0FBcEI7QUFBb0N2WTtBQUFwQyxHQUFQO0FBQ0Q7QUFFTSxTQUFTdVosMEJBQVQsR0FBc0M7QUFDM0MsU0FBTztBQUNMcFMsUUFBSSxFQUFFOFAsV0FBVyxDQUFDb0I7QUFEYixHQUFQO0FBR0Q7QUFFTSxTQUFTbUIsaUNBQVQsQ0FBMkN4WixPQUEzQyxFQUFvRDtBQUN6RCxTQUFPO0FBQ0xtSCxRQUFJLEVBQUU4UCxXQUFXLENBQUNxQiw4QkFEYjtBQUVMdFk7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTdU4sT0FBVCxHQUFtQjtBQUN4QlIsT0FBSyxDQUFDLFNBQUQsQ0FBTDtBQUNBLFNBQU87QUFBRTVGLFFBQUksRUFBRThQLFdBQVcsQ0FBQ0M7QUFBcEIsR0FBUDtBQUNEO0FBRU0sU0FBU3VDLGNBQVQsQ0FBd0J6WixPQUF4QixFQUFpQztBQUN0QyxTQUFPO0FBQ0xtSCxRQUFJLEVBQUU4UCxXQUFXLENBQUNFLGdCQURiO0FBRUxuWDtBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVMwWixZQUFULENBQXNCL1UsS0FBdEIsRUFBNkI7QUFDbEMsU0FBTztBQUNMd0MsUUFBSSxFQUFFOFAsV0FBVyxDQUFDRyxjQURiO0FBRUx6UztBQUZLLEdBQVA7QUFJRDtBQUVNLFNBQVNnVixxQkFBVCxDQUErQjNaLE9BQS9CLEVBQXdDO0FBQzdDK00sT0FBSyxDQUFDLE1BQUQsQ0FBTDtBQUNBeEksU0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQnhFLE9BQTNCO0FBRUEsU0FBTztBQUNMbUgsUUFBSSxFQUFFOFAsV0FBVyxDQUFDbUIsdUJBRGI7QUFFTHBZO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBUzRaLE9BQVQsQ0FBaUI1WixPQUFqQixFQUEwQjtBQUMvQixTQUFPO0FBQUVtSCxRQUFJLEVBQUU4UCxXQUFXLENBQUNNLFFBQXBCO0FBQThCdlg7QUFBOUIsR0FBUDtBQUNEO0FBRU0sU0FBUzZaLFVBQVQsQ0FBb0I5YSxPQUFwQixFQUE2QjtBQUNsQyxTQUFPO0FBQUVvSSxRQUFJLEVBQUU4UCxXQUFXLENBQUNPLFdBQXBCO0FBQWlDelk7QUFBakMsR0FBUDtBQUNEO0FBRU0sU0FBUythLGVBQVQsQ0FBeUIvYSxPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQUVvSSxRQUFJLEVBQUU4UCxXQUFXLENBQUNZLFlBQXBCO0FBQWtDOVk7QUFBbEMsR0FBUDtBQUNEO0FBRU0sU0FBU2diLGVBQVQsQ0FBeUJoYixPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQUVvSSxRQUFJLEVBQUU4UCxXQUFXLENBQUNlLFlBQXBCO0FBQWtDalo7QUFBbEMsR0FBUDtBQUNEO0FBRU0sU0FBU2liLGlCQUFULENBQTJCaGEsT0FBM0IsRUFBb0M7QUFDekMsU0FBTztBQUNMbUgsUUFBSSxFQUFFOFAsV0FBVyxDQUFDaUIsbUJBRGI7QUFFTGxZO0FBRkssR0FBUDtBQUlEO0FBRU0sU0FBU2lhLGVBQVQsQ0FBeUJqYSxPQUF6QixFQUFrQztBQUN2QyxTQUFPO0FBQ0xtSCxRQUFJLEVBQUU4UCxXQUFXLENBQUNrQixpQkFEYjtBQUVMblk7QUFGSyxHQUFQO0FBSUQ7QUFFTSxTQUFTa2EsU0FBVCxHQUFxQjtBQUMxQixTQUFPO0FBQUUvUyxRQUFJLEVBQUU4UCxXQUFXLENBQUNTO0FBQXBCLEdBQVA7QUFDRDtBQUVNLFNBQVN5QyxnQkFBVCxHQUE0QjtBQUNqQyxTQUFPO0FBQUVoVCxRQUFJLEVBQUU4UCxXQUFXLENBQUNVO0FBQXBCLEdBQVA7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xLRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNeUMsU0FBUyxHQUFHQyxtQkFBTyxDQUFDLHFFQUFELENBQXpCOztBQUVPLFNBQVNDLG1CQUFULENBQTZCQyxTQUE3QixFQUF3QztBQUM3Q2hULG9EQUFNLENBQUNpVCxPQUFQLENBQWVELFNBQWYsRUFBMEJqYixTQUExQixFQUFxQztBQUNuQ21iLFdBQU8sRUFBRTtBQUQwQixHQUFyQztBQUdEO0FBRU0sU0FBU0MsMEJBQVQsQ0FBb0MzYixPQUFwQyxFQUE2QztBQUNsRCxNQUFJQSxPQUFPLENBQUM0YixXQUFSLEtBQXdCLEtBQTVCLEVBQW1DO0FBQ2pDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEsd0JBQ001YixPQUFPLENBQUM0YixXQUFSLEdBQXNCNWIsT0FBTyxDQUFDNGIsV0FBOUIsR0FBNEMsQ0FEbEQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUNNNWIsT0FBTyxDQUFDNEMsWUFBUixHQUF1QjVDLE9BQU8sQ0FBQzRDLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQ7O0FBQ0QsTUFBSTVDLE9BQU8sQ0FBQzZiLGdCQUFSLEtBQTZCLEtBQWpDLEVBQXdDO0FBQ3RDLHdCQUNFO0FBQUcsZUFBUyxFQUFDLHlCQUFiO0FBQUEsd0JBQ003YixPQUFPLENBQUM2YixnQkFEZCxlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQ003YixPQUFPLENBQUM0QyxZQUFSLEdBQXVCNUMsT0FBTyxDQUFDNEMsWUFBL0IsR0FBOEMsQ0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxNQUFJNUMsT0FBTyxDQUFDMkMsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQyx3QkFDRTtBQUFHLGVBQVMsRUFBQyx5QkFBYjtBQUFBLHdCQUNNM0MsT0FBTyxDQUFDMkMsVUFEZCxlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsMEJBQ00zQyxPQUFPLENBQUM0QyxZQUFSLEdBQXVCNUMsT0FBTyxDQUFDNEMsWUFBL0IsR0FBOEMsQ0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxzQkFDRTtBQUFHLGFBQVMsRUFBQyxtQkFBYjtBQUFBLHNCQUNNNUMsT0FBTyxDQUFDNEMsWUFBUixHQUF1QjVDLE9BQU8sQ0FBQzRDLFlBQS9CLEdBQThDLENBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBS0Q7QUFFTSxTQUFTa1osc0JBQVQsQ0FBZ0M3TyxRQUFoQyxFQUEwQztBQUMvQyxNQUFJOE8sZ0JBQWdCLEdBQUc5TyxRQUFRLENBQUNTLE1BQVQsQ0FBZ0IsQ0FBQ3NPLElBQUQsRUFBT0MsSUFBUCxLQUFnQjtBQUNyRCxXQUNFcE8sTUFBTSxDQUFDcU8sV0FBVyxDQUFDRixJQUFELENBQVosQ0FBTixHQUNBbk8sTUFBTSxDQUNKcU8sV0FBVyxDQUNURCxJQUFJLENBQUNFLG9CQUFMLElBQTZCLENBQTdCLEdBQ0lGLElBQUksQ0FBQ0csa0JBRFQsR0FFSUgsSUFBSSxDQUFDRSxvQkFIQSxDQURQLENBRlI7QUFVRCxHQVhzQixFQVdwQixDQVhvQixDQUF2QjtBQWFBLFNBQU9KLGdCQUFQO0FBQ0Q7QUFFTSxTQUFTTSxxQkFBVCxDQUErQnBQLFFBQS9CLEVBQXlDO0FBQzlDLE1BQUlxUCxxQkFBcUIsR0FBR3JQLFFBQVEsQ0FBQ1MsTUFBVCxDQUFnQixDQUFDc08sSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQzFELFdBQU9wTyxNQUFNLENBQUNxTyxXQUFXLENBQUNGLElBQUQsQ0FBWixDQUFOLEdBQTRCbk8sTUFBTSxDQUFDcU8sV0FBVyxDQUFDRCxJQUFJLENBQUNNLFVBQU4sQ0FBWixDQUF6QztBQUNELEdBRjJCLEVBRXpCLENBRnlCLENBQTVCO0FBSUEsU0FBT0QscUJBQVA7QUFDRDtBQUVNLFNBQVNFLHlCQUFULENBQW1DdlAsUUFBbkMsRUFBNkM7QUFDbEQsTUFBSXdQLGNBQWMsR0FBR3hQLFFBQVEsQ0FBQ1MsTUFBVCxDQUFnQixDQUFDc08sSUFBRCxFQUFPQyxJQUFQLEtBQWdCO0FBQ25ELFdBQ0VwTyxNQUFNLENBQUNxTyxXQUFXLENBQUNGLElBQUQsQ0FBWixDQUFOLEdBQTRCbk8sTUFBTSxDQUFDcU8sV0FBVyxDQUFDRCxJQUFJLENBQUNTLGVBQU4sQ0FBWixDQURwQztBQUdELEdBSm9CLEVBSWxCLENBSmtCLENBQXJCO0FBTUEsU0FBT0QsY0FBUDtBQUNEO0FBRU0sU0FBU1AsV0FBVCxDQUFxQlMsR0FBckIsRUFBMEI7QUFDL0IsTUFBSUMsV0FBVyxHQUFHRCxHQUFILGFBQUdBLEdBQUgsdUJBQUdBLEdBQUcsQ0FBRXhSLFFBQUwsR0FBZ0I5QixLQUFoQixDQUFzQixHQUF0QixDQUFsQjs7QUFDQSxNQUFJdVQsV0FBVyxJQUFJLENBQUFBLFdBQVcsU0FBWCxJQUFBQSxXQUFXLFdBQVgsWUFBQUEsV0FBVyxDQUFFOU8sTUFBYixJQUFzQixDQUF6QyxFQUE0QztBQUMxQyxXQUFPOE8sV0FBVyxDQUFDbFAsTUFBWixDQUFtQixDQUFDc08sSUFBRCxFQUFPQyxJQUFQLEtBQWdCRCxJQUFJLEdBQUdDLElBQTFDLENBQVA7QUFDRCxHQUZELE1BRU87QUFDTCxXQUFPLENBQVA7QUFDRDtBQUNGO0FBRU0sU0FBU3hOLDhCQUFULENBQXdDb08sV0FBeEMsRUFBcUQ7QUFDMUQsU0FBTyxJQUFJQyxJQUFJLENBQUNDLFlBQVQsQ0FBc0IsT0FBdEIsRUFBK0I7QUFDcEMvVCxTQUFLLEVBQUUsVUFENkI7QUFFcENnVSxZQUFRLEVBQUU7QUFGMEIsR0FBL0IsRUFHSkMsTUFISSxDQUdHZixXQUFXLENBQUNXLFdBQUQsQ0FIZCxDQUFQO0FBSUQ7QUFFTSxTQUFTSyxXQUFULENBQXFCQyxXQUFyQixFQUFrQztBQUN2QyxNQUFJcE0sTUFBTSxHQUFHc0ssU0FBUyxDQUFDK0IsT0FBVixDQUFrQkQsV0FBbEIsQ0FBYjtBQUNEO0FBRU0sU0FBU0UsV0FBVCxDQUFxQkMsUUFBckIsRUFBK0JDLFNBQS9CLEVBQTBDO0FBQy9DLE1BQUlDLE9BQU8sR0FBR25DLFNBQVMsQ0FBQ29DLEdBQVYsQ0FDWnZCLFdBQVcsQ0FBQ29CLFFBQVEsSUFBSSxDQUFiLENBREMsRUFFWnBCLFdBQVcsQ0FBQ3FCLFNBQVMsSUFBSSxDQUFkLENBRkMsQ0FBZDtBQUlBLFNBQU9DLE9BQVA7QUFDRDtBQUVNLFNBQVNFLFdBQVQsQ0FBcUJKLFFBQXJCLEVBQStCQyxTQUEvQixFQUEwQztBQUMvQyxNQUFJSSxPQUFPLEdBQUd0QyxTQUFTLENBQUN1QyxHQUFWLENBQ1oxQixXQUFXLENBQUNvQixRQUFRLElBQUksQ0FBYixDQURDLEVBRVpwQixXQUFXLENBQUNxQixTQUFTLElBQUksQ0FBZCxDQUZDLENBQWQ7QUFJQSxTQUFPSSxPQUFQO0FBQ0Q7QUFFTSxTQUFTRSxXQUFULENBQXFCQyxnQkFBckIsRUFBdUNDLGlCQUF2QyxFQUEwRDtBQUMvRCxNQUFJQyxPQUFPLEdBQUczQyxTQUFTLENBQUM0QyxHQUFWLENBQ1ovQixXQUFXLENBQUM0QixnQkFBZ0IsSUFBSSxDQUFyQixDQURDLEVBRVo1QixXQUFXLENBQUM2QixpQkFBaUIsSUFBSSxDQUF0QixDQUZDLENBQWQ7QUFLQSxTQUFPQyxPQUFQO0FBQ0Q7QUFDTSxTQUFTRSxXQUFULENBQXFCSixnQkFBckIsRUFBdUNDLGlCQUF2QyxFQUEwRDtBQUMvRCxNQUFJSSxPQUFPLEdBQUc5QyxTQUFTLENBQUMrQyxHQUFWLENBQ1psQyxXQUFXLENBQUM0QixnQkFBZ0IsSUFBSSxDQUFyQixDQURDLEVBRVo1QixXQUFXLENBQUM2QixpQkFBaUIsSUFBSSxDQUF0QixDQUZDLENBQWQ7QUFLQSxTQUFPSSxPQUFQO0FBQ0Q7QUFFTSxTQUFTRSxjQUFULENBQXdCMUIsR0FBeEIsRUFBNkI7QUFDbEMsTUFBSUEsR0FBRyxLQUFLcGMsU0FBWixFQUF1QjtBQUNyQixXQUFPK2QsVUFBVSxDQUFDM0IsR0FBRCxDQUFWLENBQ0p4UixRQURJLEdBRUpzUSxPQUZJLENBRUkseUJBRkosRUFFK0IsS0FGL0IsQ0FBUDtBQUdELEdBSkQsTUFJTyxDQUNOO0FBQ0Y7QUFFTSxTQUFTOEMsa0JBQVQsQ0FBNEJDLFdBQTVCLEVBQXlDQyxJQUF6QyxFQUErQztBQUNwRCxNQUFJRCxXQUFXLENBQUMxUSxNQUFaLEdBQXFCLENBQXpCLEVBQTRCO0FBQzFCLFVBQU1pRCxNQUFNLEdBQUd5TixXQUFXLENBQUNFLElBQVosQ0FBa0JsSSxJQUFELElBQVVBLElBQUksQ0FBQ2lJLElBQUwsS0FBY0EsSUFBSSxDQUFDdFQsUUFBTCxFQUF6QyxDQUFmOztBQUNBLFFBQUk0RixNQUFNLEtBQUt4USxTQUFmLEVBQTBCO0FBQ3hCLGFBQU93USxNQUFNLENBQUM5RCxRQUFkO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBTyxFQUFQO0FBQ0Q7QUFDRixHQVBELE1BT087QUFDTCxXQUFPLEVBQVA7QUFDRDtBQUNGO0FBRU0sU0FBUzBSLGFBQVQsQ0FBdUJDLE9BQXZCLEVBQWdDSCxJQUFoQyxFQUFzQztBQUMzQyxNQUFJRyxPQUFPLENBQUM5USxNQUFSLEdBQWlCLENBQXJCLEVBQXdCO0FBQ3RCLFVBQU0rUSxNQUFNLEdBQUdELE9BQU8sQ0FBQ0YsSUFBUixDQUFjbEksSUFBRCxJQUFVQSxJQUFJLENBQUNpSSxJQUFMLEtBQWNBLElBQUksQ0FBQ3RULFFBQUwsRUFBckMsQ0FBZjs7QUFDQSxRQUFJMFQsTUFBTSxLQUFLdGUsU0FBZixFQUEwQjtBQUN4QixhQUFPc2UsTUFBUDtBQUNELEtBRkQsTUFFTztBQUNMLGFBQU8sSUFBUDtBQUNEO0FBQ0YsR0FQRCxNQU9PO0FBQ0wsV0FBTyxJQUFQO0FBQ0Q7QUFDRjtBQUVNLFNBQVNDLHVCQUFULENBQWlDN2QsT0FBakMsRUFBMEM7QUFDL0MsTUFBSXFWLEtBQUssR0FBRyxFQUFaOztBQUNBLE1BQUlyVixPQUFPLENBQUM2TSxNQUFSLEdBQWlCLENBQXJCLEVBQXdCO0FBQ3RCN00sV0FBTyxDQUFDc1YsT0FBUixDQUFpQkMsSUFBRCxJQUFVO0FBQ3hCLFVBQUlGLEtBQUssS0FBSyxFQUFkLEVBQWtCO0FBQ2hCQSxhQUFLLEdBQUksV0FBVUUsSUFBSyxFQUF4QjtBQUNELE9BRkQsTUFFTztBQUNMRixhQUFLLEdBQUdBLEtBQUssR0FBSSxZQUFXRSxJQUFLLEVBQWpDO0FBQ0Q7QUFDRixLQU5EO0FBT0Q7O0FBQ0QsU0FBT0YsS0FBUDtBQUNEO0FBRU0sU0FBU3lJLGtCQUFULENBQTRCL2UsT0FBNUIsRUFBcUM7QUFDMUMsTUFBSWdmLElBQUo7O0FBQ0EsTUFBSWhmLE9BQU8sQ0FBQ2lmLEtBQVIsSUFBaUJqZixPQUFPLENBQUNpZixLQUFSLEtBQWtCLElBQXZDLEVBQTZDO0FBQzNDRCxRQUFJLEdBQUdoZixPQUFPLENBQUNpZixLQUFSLENBQWNwWixHQUFkLENBQW1Cb1osS0FBRCxJQUFXO0FBQ2xDLFVBQUlBLEtBQUssQ0FBQzdXLElBQU4sS0FBZSxNQUFuQixFQUEyQjtBQUN6Qiw0QkFBTztBQUFLLG1CQUFTLEVBQUMsbUJBQWY7QUFBQSxvQkFBb0M2VyxLQUFLLENBQUNyWTtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFQO0FBQ0QsT0FGRCxNQUVPLElBQUlxWSxLQUFLLENBQUM3VyxJQUFOLEtBQWUsVUFBbkIsRUFBK0I7QUFDcEMsNEJBQU87QUFBSyxtQkFBUyxFQUFDLDZCQUFmO0FBQUEsb0JBQThDNlcsS0FBSyxDQUFDclk7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFBUDtBQUNELE9BRk0sTUFFQTtBQUNMLDRCQUFPO0FBQUssbUJBQVMsRUFBQyx1QkFBZjtBQUFBLG9CQUF3Q3FZLEtBQUssQ0FBQ3JZO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQVA7QUFDRDtBQUNGLEtBUk0sQ0FBUDtBQVNEOztBQUNELFNBQU9vWSxJQUFQO0FBQ0Q7S0FkZUQsa0I7QUFnQlQsU0FBU0csa0JBQVQsQ0FBNEJsZixPQUE1QixFQUFxQztBQUMxQyxNQUFJZ2YsSUFBSjs7QUFDQSxNQUFJaGYsT0FBTyxDQUFDbWYsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkgsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyx3QkFBYjtBQUFBLHdCQUNNWCxjQUFjLENBQUNyZSxPQUFPLENBQUNvZixLQUFULENBRHBCLGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwwQkFBMEJmLGNBQWMsQ0FBQ3JlLE9BQU8sQ0FBQzJDLFVBQVQsQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFNRCxHQVBELE1BT087QUFDTHFjLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsbUJBQWI7QUFBQSx3QkFBcUNYLGNBQWMsQ0FBQ3JlLE9BQU8sQ0FBQ29mLEtBQVQsQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFHRDs7QUFDRCxTQUFPSixJQUFQO0FBQ0Q7TUFmZUUsa0I7QUFpQlQsU0FBU0csc0JBQVQsQ0FBZ0NyZixPQUFoQyxFQUF5QztBQUM5QyxNQUFJZ2YsSUFBSjs7QUFDQSxNQUFJaGYsT0FBTyxDQUFDMkMsVUFBUixLQUF1QixLQUEzQixFQUFrQztBQUNoQ3FjLFFBQUksZ0JBQ0Y7QUFBRyxlQUFTLEVBQUMsd0JBQWI7QUFBQSx3QkFDTWhmLE9BQU8sQ0FBQzJDLFVBRGQsZUFFRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLDBCQUEwQjNDLE9BQU8sQ0FBQzRDLFlBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBTUQsR0FQRCxNQU9PO0FBQ0xvYyxRQUFJLGdCQUFHO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEsd0JBQXFDaGYsT0FBTyxDQUFDNEMsWUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQVA7QUFDRDs7QUFDRCxTQUFPb2MsSUFBUDtBQUNEO01BYmVLLHNCO0FBZVQsU0FBU0MsbUJBQVQsQ0FBNkJ0ZixPQUE3QixFQUFzQztBQUMzQyxNQUFJZ2YsSUFBSjs7QUFDQSxNQUFJaGYsT0FBTyxDQUFDbWYsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkgsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyxtQkFBYjtBQUFBLHdCQUNNWCxjQUFjLENBQUNyZSxPQUFPLENBQUMyQyxVQUFULENBRHBCLEVBQzBDLEdBRDFDLGVBRUU7QUFBTSxpQkFBUyxFQUFDLFVBQWhCO0FBQUEsMEJBQ00wYixjQUFjLENBQUNyZSxPQUFPLENBQUM0QyxZQUFULENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBUUQsR0FURCxNQVNPO0FBQ0xvYyxRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEsd0JBQ01YLGNBQWMsQ0FBQ3JlLE9BQU8sQ0FBQzJDLFVBQVQsQ0FEcEIsRUFDMEMsR0FEMUMsZUFFRTtBQUFNLGlCQUFTLEVBQUMsVUFBaEI7QUFBQSwwQkFDTTBiLGNBQWMsQ0FBQ3JlLE9BQU8sQ0FBQzRDLFlBQVQsQ0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFRRDs7QUFDRCxTQUFPb2MsSUFBUDtBQUNEO0FBRU0sU0FBU08sMEJBQVQsQ0FBb0N2ZixPQUFwQyxFQUE2QztBQUNsRCxNQUFJZ2YsSUFBSjs7QUFDQSxNQUFJaGYsT0FBTyxDQUFDbWYsT0FBUixLQUFvQixJQUF4QixFQUE4QjtBQUM1QkgsUUFBSSxnQkFDRjtBQUFHLGVBQVMsRUFBQyx3QkFBYjtBQUFBLHdCQUNNWCxjQUFjLENBQUNyZSxPQUFPLENBQUNvZixLQUFULENBRHBCLGVBRUU7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwwQkFBMEJmLGNBQWMsQ0FBQ3JlLE9BQU8sQ0FBQzJDLFVBQVQsQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBT0QsR0FSRCxNQVFPO0FBQ0xxYyxRQUFJLGdCQUNGO0FBQUcsZUFBUyxFQUFDLG1CQUFiO0FBQUEsd0JBQXFDWCxjQUFjLENBQUNyZSxPQUFPLENBQUNvZixLQUFULENBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBR0Q7O0FBQ0QsU0FBT0osSUFBUDtBQUNEO01BaEJlTywwQjtBQWtCVCxTQUFTQywrQkFBVCxDQUF5Q3hmLE9BQXpDLEVBQWtEO0FBQ3ZELE1BQUlnZixJQUFKO0FBRUFBLE1BQUksZ0JBQ0Y7QUFBRyxhQUFTLEVBQUMsbUJBQWI7QUFBQSxzQkFDTVgsY0FBYyxDQUFDcmUsT0FBTyxDQUFDNGIsV0FBUixHQUFzQjViLE9BQU8sQ0FBQzRiLFdBQTlCLEdBQTRDLENBQTdDLENBRHBCLGVBRUU7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLHdCQUNNeUMsY0FBYyxDQUFDcmUsT0FBTyxDQUFDNEMsWUFBUixHQUF1QjVDLE9BQU8sQ0FBQzRDLFlBQS9CLEdBQThDLENBQS9DLENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBQSxnQkFBUTVDLE9BQU8sQ0FBQ3lmLEtBQVIsR0FBZ0J6ZixPQUFPLENBQUN5ZixLQUF4QixHQUFnQztBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFVQSxTQUFPVCxJQUFQO0FBQ0Q7TUFkZVEsK0I7QUFlVCxTQUFTRSxnQ0FBVCxDQUEwQzFmLE9BQTFDLEVBQW1EO0FBQ3hELE1BQUlnZixJQUFKO0FBRUFBLE1BQUksZ0JBQ0Y7QUFBRyxhQUFTLEVBQUMsbUJBQWI7QUFBQSxzQkFDTVgsY0FBYyxDQUFDcmUsT0FBTyxDQUFDMkMsVUFBUixHQUFxQjNDLE9BQU8sQ0FBQzJDLFVBQTdCLEdBQTBDLENBQTNDLENBRHBCLGVBRUU7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLHdCQUNNMGIsY0FBYyxDQUFDcmUsT0FBTyxDQUFDb2YsS0FBUixHQUFnQnBmLE9BQU8sQ0FBQ29mLEtBQXhCLEdBQWdDLENBQWpDLENBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBQSxnQkFBUXBmLE9BQU8sQ0FBQ3lmLEtBQVIsR0FBZ0J6ZixPQUFPLENBQUN5ZixLQUF4QixHQUFnQztBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFVQSxTQUFPVCxJQUFQO0FBQ0Q7TUFkZVUsZ0M7QUFnQlQsU0FBU0Msc0JBQVQsQ0FBZ0MzZixPQUFoQyxFQUF5QztBQUM5QyxNQUFJZ2YsSUFBSjs7QUFFQSxNQUFJaGYsT0FBTyxDQUFDNGYsU0FBWixFQUF1QjtBQUNyQlosUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV2hmLE9BQU8sQ0FBQ3lDLEVBQUcsRUFBdkQ7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUcsR0FBRXNTLGdFQUFRLEdBQUUvVSxPQUFPLENBQUM0ZixTQUFSLENBQWtCNU4sR0FBSSxFQUQxQztBQUVFLGVBQUcsRUFBRWhTLE9BQU8sQ0FBQ3FCO0FBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBWUQsR0FiRCxNQWFPO0FBQ0wyZCxRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGYsT0FBTyxDQUFDeUMsRUFBRyxFQUF2RDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUFLLGVBQUcsRUFBQywyQkFBVDtBQUFxQyxlQUFHLEVBQUM7QUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBU0Q7O0FBRUQsU0FBT3VjLElBQVA7QUFDRDtNQTdCZVcsc0I7QUErQlQsU0FBU0UsMkJBQVQsQ0FBcUM3ZixPQUFyQyxFQUE4QztBQUNuRCxNQUFJZ2YsSUFBSjs7QUFFQSxNQUFJaGYsT0FBTyxDQUFDNkIsS0FBUixDQUFjaU0sTUFBZCxHQUF1QixDQUEzQixFQUE4QjtBQUFBOztBQUM1QmtSLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdoZixPQUFPLENBQUNpQyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFFakMsT0FBRixhQUFFQSxPQUFGLDBDQUFFQSxPQUFPLENBQUU2QixLQUFULENBQWUsQ0FBZixDQUFGLG9EQUFFLGdCQUFtQkEsS0FEMUI7QUFFRSxlQUFHLEVBQUU3QixPQUFPLENBQUNrQyxZQUZmO0FBR0UsaUJBQUssRUFBQyxPQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNELEdBZkQsTUFlTztBQUNMOGMsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV2hmLE9BQU8sQ0FBQ2lDLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUMsMkJBRE47QUFFRSxlQUFHLEVBQUMsU0FGTjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRDs7QUFFRCxTQUFPK2MsSUFBUDtBQUNEO01BcENlYSwyQjtBQXNDVCxTQUFTQyw0QkFBVCxDQUFzQzlmLE9BQXRDLEVBQStDO0FBQ3BELE1BQUlnZixJQUFKOztBQUVBLE1BQUloZixPQUFPLENBQUM2QixLQUFSLENBQWNpTSxNQUFkLEdBQXVCLENBQTNCLEVBQThCO0FBQUE7O0FBQzVCa1IsUUFBSSxnQkFDRixxRUFBQyxnREFBRDtBQUFNLFVBQUksRUFBQyxnQkFBWDtBQUE0QixRQUFFLEVBQUcsWUFBV2hmLE9BQU8sQ0FBQ2lDLFVBQVcsRUFBL0Q7QUFBQSw2QkFDRTtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0U7QUFDRSxlQUFHLEVBQUVqQyxPQUFGLGFBQUVBLE9BQUYsMkNBQUVBLE9BQU8sQ0FBRTZCLEtBQVQsQ0FBZSxDQUFmLENBQUYscURBQUUsaUJBQW1CQSxLQUQxQjtBQUVFLGVBQUcsRUFBRTdCLE9BQU8sQ0FBQ2tDLFlBRmY7QUFHRSxpQkFBSyxFQUFDLE1BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0QsR0FmRCxNQWVPO0FBQ0w4YyxRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGYsT0FBTyxDQUFDaUMsVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBQywyQkFETjtBQUVFLGVBQUcsRUFBQyxTQUZOO0FBR0UsaUJBQUssRUFBQyxNQUhSO0FBSUUsa0JBQU0sRUFBQztBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQWNEOztBQUVELFNBQU8rYyxJQUFQO0FBQ0Q7TUFwQ2VjLDRCO0FBc0NULFNBQVNDLHdCQUFULENBQWtDL2YsT0FBbEMsRUFBMkM7QUFDaEQsTUFBSWdmLElBQUo7O0FBRUEsTUFBSWhmLE9BQU8sQ0FBQzZCLEtBQVIsQ0FBY2lNLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFBQTs7QUFDNUJrUixRQUFJLGdCQUNGLHFFQUFDLGdEQUFEO0FBQU0sVUFBSSxFQUFDLGdCQUFYO0FBQTRCLFFBQUUsRUFBRyxZQUFXaGYsT0FBTyxDQUFDaUMsVUFBVyxFQUEvRDtBQUFBLDZCQUNFO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBQSxpQ0FDRTtBQUNFLGVBQUcsRUFBRWpDLE9BQUYsYUFBRUEsT0FBRiwyQ0FBRUEsT0FBTyxDQUFFNkIsS0FBVCxDQUFlLENBQWYsQ0FBRixxREFBRSxpQkFBbUJBLEtBRDFCO0FBRUUsZUFBRyxFQUFFN0IsT0FBTyxDQUFDa0MsWUFGZjtBQUdFLGlCQUFLLEVBQUMsT0FIUjtBQUlFLGtCQUFNLEVBQUM7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFjRCxHQWZELE1BZU87QUFDTDhjLFFBQUksZ0JBQ0YscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUMsZ0JBQVg7QUFBNEIsUUFBRSxFQUFHLFlBQVdoZixPQUFPLENBQUNpQyxVQUFXLEVBQS9EO0FBQUEsNkJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxxREFBRDtBQUFBLGlDQUNFO0FBQ0UsZUFBRyxFQUFDLDJCQUROO0FBRUUsZUFBRyxFQUFDLFNBRk47QUFHRSxpQkFBSyxFQUFDLE9BSFI7QUFJRSxrQkFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBY0Q7O0FBRUQsU0FBTytjLElBQVA7QUFDRDtPQXBDZWUsd0I7QUFzQ1QsU0FBU0MsV0FBVCxHQUF1QjtBQUM1QnhhLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDRCIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hY2NvdW50L2xvZ2luLjIzNmVjN2VkZDJjZTIxYzkyNzczLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgcmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3IH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uLCBNb2RhbCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBQcm9kdWN0T25DYXJ0ID0gKHsgcHJvZHVjdCB9KSA9PiB7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUNhcnRJdGVtID0gYXN5bmMgKHByb2R1Y3QpID0+IHtcclxuICAgIC8vIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIsXHJcbiAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAgIGxldCB0b2tlbiA9IHBhcnNlZGF0YS5hY2Nlc3NfdG9rZW47XHJcbiAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGNhcnRfaWQ6IFtwcm9kdWN0LmNhcnRfaWRdLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjogdG9rZW4sXHJcbiAgICAgIH07XHJcbiAgICAgIE1vZGFsLmNvbmZpcm0oe1xyXG4gICAgICAgIHRpdGxlOiBcIkRlbGV0ZSB0aGlzIHByb2R1Y3Q/XCIsXHJcbiAgICAgICAgb25PazogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgIGRpc3BhdGNoKHJlbW92ZVByb2R1Y3RGcm9tQ2FydE5ldyhwYXlsb2FkKSk7XHJcbiAgICAgICAgICBNb2RhbC5kZXN0cm95QWxsKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbkNhbmNlbDogZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgIE1vZGFsLmRlc3Ryb3lBbGwoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9rQnV0dG9uUHJvcHM6IHtcclxuICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0LS1jYXJ0LW1vYmlsZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3RodW1ibmFpbFwiPlxyXG4gICAgICAgIHsvKiB7U3RyYXBpUHJvZHVjdFRodW1ibmFpbChwcm9kdWN0KX0gKi99XHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2UgfHwgXCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCJ9XHJcbiAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgZS50YXJnZXQuc3JjID0gXCIvc3RhdGljL2ltZy9ub3QtZm91bmQuanBnXCI7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgYWx0PVwicHJvZHVjdFwiXHJcbiAgICAgICAgICB0aXRsZT1cInByb2R1Y3RcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2NvbnRlbnRcIj5cclxuICAgICAgICA8YVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcmVtb3ZlXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBoYW5kbGVSZW1vdmVDYXJ0SXRlbShwcm9kdWN0KX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWNyb3NzXCI+PC9pPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGl0bGVcIj5cclxuICAgICAgICAgICAge3Byb2R1Y3QucHJvZHVjdF9uYW1lfVxyXG4gICAgICAgICAgICB7cHJvZHVjdC5hdHRyX25hbWUxXHJcbiAgICAgICAgICAgICAgPyBgICgke3Byb2R1Y3QuYXR0cl9uYW1lMX0ke1xyXG4gICAgICAgICAgICAgICAgICBwcm9kdWN0LmF0dHJfbmFtZTIgPyBgICR7cHJvZHVjdC5hdHRyX25hbWUyfWAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICB9KWBcclxuICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICBSTXtcIiBcIn1cclxuICAgICAgICAgICAge3Byb2R1Y3QudW5pdF9kaXNjb3VudF9wcmljZSAhPT0gZmFsc2UgPyAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgIDxkZWw+e3Byb2R1Y3QudW5pdF9hY3R1YWxfcHJpY2V9PC9kZWw+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAge3Byb2R1Y3QudW5pdF9kaXNjb3VudF9wcmljZX1cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICBwcm9kdWN0LnVuaXRfYWN0dWFsX3ByaWNlXHJcbiAgICAgICAgICAgICl9e1wiIFwifVxyXG4gICAgICAgICAgICB4IHtwcm9kdWN0LnF1YW50aXR5fVxyXG4gICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2R1Y3RPbkNhcnQ7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgTGF6eUxvYWQgZnJvbSBcInJlYWN0LWxhenlsb2FkXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIFN0cmFwaVByb2R1Y3RQcmljZSxcclxuICBTdHJhcGlQcm9kdWN0VGh1bWJuYWlsLFxyXG59IGZyb20gXCJ+L3V0aWxpdGllcy9wcm9kdWN0LWhlbHBlclwiO1xyXG5pbXBvcnQgUmF0aW5nIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvUmF0aW5nXCI7XHJcblxyXG5jb25zdCBQcm9kdWN0U2VhcmNoUmVzdWx0ID0gKHsgcHJvZHVjdCB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdCBwcy1wcm9kdWN0LS13aWRlIHBzLXByb2R1Y3QtLXNlYXJjaC1yZXN1bHRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X190aHVtYm5haWxcIj5cclxuICAgICAgICB7Lyoge1N0cmFwaVByb2R1Y3RUaHVtYm5haWwocHJvZHVjdCl9ICovfVxyXG5cclxuICAgICAgICB7cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlID8gKFxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QuaWR9YH0+XHJcbiAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9IGFsdD17cHJvZHVjdC50aXRsZX0gLz5cclxuICAgICAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICA8TGF6eUxvYWQ+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIiBhbHQ9XCJLYW5ndGFvXCIgLz5cclxuICAgICAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fY29udGVudFwiPlxyXG4gICAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fdGl0bGVcIj57cHJvZHVjdC5wcm9kdWN0X25hbWV9PC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3JhdGluZ1wiPlxyXG4gICAgICAgICAgPFJhdGluZyByYXRpbmc9e3Byb2R1Y3QucmF0aW5nfSAvPlxyXG4gICAgICAgICAgey8qIDxzcGFuPntwcm9kdWN0LnJhdGluZ0NvdW50fTwvc3Bhbj4gKi99XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge3Byb2R1Y3Quc2FsZV9wcmljZSA+IDAgPyAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBzYWxlXCI+XHJcbiAgICAgICAgICAgIFJNIHtwcm9kdWN0LnNhbGVfcHJpY2V9XHJcbiAgICAgICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L2RlbD5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2Ugc2FsZVwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0U2VhcmNoUmVzdWx0O1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBSb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7IGFwaWJhc2V1cmwgfSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyBGb3JtLCBJbnB1dCwgbm90aWZpY2F0aW9uLCBNb2RhbCwgU2VsZWN0LCBTcGluICxtZXNzYWdlfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBjb25uZWN0LCB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgQXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbi8vIGltcG9ydCAkIGZyb20gJ2pxdWVyeSc7IFxyXG5pbXBvcnQgQWNjb3VudFJlcG9zaXRvcnkgZnJvbSBcIn4vcmVwb3NpdG9yaWVzL0FjY291bnRSZXBvc2l0b3J5XCI7XHJcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XHJcbmltcG9ydCB7IGRpc3BsYXlOb3RpZmljYXRpb24gfSBmcm9tIFwifi91dGlsaXRpZXMvY29tbW9uLWhlbHBlcnNcIjtcclxuaW1wb3J0IGJhY2tncm91bmQgZnJvbSBcInB1YmxpYy9zdGF0aWMvaW1nL2N1c3RvbV9pbWFnZXMvbG9nLWJnLmpwZ1wiO1xyXG5pbXBvcnQgbG9nb19pbWFnZSBmcm9tIFwicHVibGljL3N0YXRpYy9pbWcvY3VzdG9tX2ltYWdlcy9sb2dvX2xpZ2h0LnBuZ1wiO1xyXG5pbXBvcnQgeyBsb2dpbiB9IGZyb20gXCJ+L3N0b3JlL2F1dGgvYWN0aW9uXCI7XHJcbmltcG9ydCBMb2dpbldpdGhTTVMgZnJvbSBcIi4vTG9naW5XaXRoU01TXCI7XHJcbmltcG9ydCBMb2dpbldpdGhFbWFpbCBmcm9tIFwiLi9Mb2dpbldpdGhFbWFpbFwiO1xyXG5pbXBvcnQgeyBMb2FkaW5nT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IExvZ2luID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgW2Zvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgaW5pdFN0YXRlT3RwQnV0dG9uID0ge1xyXG4gICAgY2xhc3M6IFwicHJpbWFyeVwiLFxyXG4gICAgdGV4dDogXCJTZW5kIE9UUFwiLFxyXG4gICAgdmVyaWZ5Qm94OiBmYWxzZSxcclxuICAgIHZlcmlmaWVkTnVtYmVyOiBcIlwiLFxyXG4gICAgcmVnaXN0ZXJCb3hTaG93OiBmYWxzZSxcclxuICB9O1xyXG4gIGNvbnN0IFtsb2FkaW5nT1RQLCBzZXRMb2FkaW5nT1RQXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbb3RwQnV0dG9uLCBzZXRPdHBCdXR0b25dID0gdXNlU3RhdGUoaW5pdFN0YXRlT3RwQnV0dG9uKTtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZSh7XHJcbiAgICBpbnB1dDogXCJcIixcclxuICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGFudEljb24gPSA8TG9hZGluZ091dGxpbmVkIHN0eWxlPXt7IGZvbnRTaXplOiAyNCB9fSBzcGluIC8+O1xyXG4gIGNvbnN0IFtzZXJ2ZXJDb3VudHJ5LCBzZXRDb3VudHJ5XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCB7XHJcbiAgICBmaXJzdF9uYW1lLFxyXG4gICAgbGFzdF9uYW1lLFxyXG4gICAgZW1haWwsXHJcbiAgICBwaG9uZV9udW1iZXIsXHJcbiAgICBwYXNzd29yZCxcclxuICAgIHBhc3N3b3JkX2NvbmZpcm1hdGlvbixcclxuICAgIGNvdW50cnlfY29kZVxyXG4gIH0gPSB1c2VyO1xyXG4gIGNvbnN0IFtyZW1lbWJlck1lLCBzZXRSZW1lbWJlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VzZXJPdHAsIHNldFVzZXJPdHBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2dldEN1c3RvbWVySWQsIHNldEN1c3RvbWVySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dMb2dpbldpdGhTTVMsIHNldFNob3dMb2dpbldpdGhTTVNdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgeyBpbnB1dCB9ID0gdXNlcjtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0MSA9IGFzeW5jICgpID0+IHtcclxuICAgLy8gYWxlcnQoXCIyXCIpXHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuIFxyXG4gICAgICBjdXN0b21lcl9pZDogZ2V0Q3VzdG9tZXJJZCxcclxuICAgICAgcGFzc3dvcmQ6IHVzZXIucGFzc3dvcmQsXHJcbiAgICAgIHBhc3N3b3JkX2NvbmZpcm1hdGlvbjogdXNlci5wYXNzd29yZF9jb25maXJtYXRpb24sXHJcbiAgICB9O1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHZhbHVlcyA9IGF3YWl0IEFjY291bnRSZXBvc2l0b3J5LmNoYW5nZVBhc3N3b3JkKHBheWxvYWQpO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLi5yZWdpc3RlciBzdWJtaXQuLiB1c2VyLi4uLlwiLHVzZXIpXHJcbmNvbnNvbGUubG9nKFwiLi4uLnJlZ2lzdGVyIHN1Ym1pdC4uLmZpbmFsZS4uLlwiLHZhbHVlcylcclxuICAgICAgaWYgKHZhbHVlcy5odHRwY29kZSA9PSAyMDAgJiYgdmFsdWVzLnN1Y2Nlc3MpIHtcclxuICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJZb3VyIFBhc3N3b3JkIENoYW5nZWQgU3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgICAvL1JvdXRlci5wdXNoKFwiL2FjY291bnQvbG9naW5cIik7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHZhbHVlcy5lcnJvcikge1xyXG4gICAgICAgIHZhbHVlcy5lcnJvci5tYXAoKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9ySW5mbykge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZDpcIiwgZXJyb3JJbmZvKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBmaXJzdF9uYW1lOiB1c2VyLmZpcnN0X25hbWUsXHJcbiAgICAgIGxhc3RfbmFtZTogdXNlci5sYXN0X25hbWUsXHJcbiAgICAgIGNvdW50cnlfY29kZTogdXNlci5jb3VudHJ5X2NvZGUsXHJcbiAgICAgIHBob25lX251bWJlcjogdXNlci5waG9uZV9udW1iZXIsXHJcbiAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxyXG4gICAgICBwYXNzd29yZDogdXNlci5wYXNzd29yZCxcclxuICAgICAgcGFzc3dvcmRfY29uZmlybWF0aW9uOiB1c2VyLnBhc3N3b3JkX2NvbmZpcm1hdGlvbixcclxuICAgIH07XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdmFsdWVzID0gYXdhaXQgQWNjb3VudFJlcG9zaXRvcnkucmVnaXN0ZXJOZXdVc2VyKHVzZXIpO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLi5yZWdpc3RlciBzdWJtaXQuLiB1c2VyLi4uLlwiLHVzZXIpXHJcbmNvbnNvbGUubG9nKFwiLi4uLnJlZ2lzdGVyIHN1Ym1pdC4uLi4uLlwiLHZhbHVlcylcclxuICAgICAgaWYgKHZhbHVlcy5odHRwY29kZSA9PSAyMDAgJiYgdmFsdWVzLnN1Y2Nlc3MpIHtcclxuICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJZb3UgYXJlIHJlZ2lzdGVyZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgICAvL1JvdXRlci5wdXNoKFwiL2FjY291bnQvbG9naW5cIik7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHZhbHVlcy5lcnJvcikge1xyXG4gICAgICAgIHZhbHVlcy5lcnJvci5tYXAoKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9ySW5mbykge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZDpcIiwgZXJyb3JJbmZvKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUZlYXR1cmVXaWxsVXBkYXRlID0gKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIG5vdGlmaWNhdGlvbi5vcGVuKHtcclxuICAgICAgbWVzc2FnZTogXCJPcHAhIFNvbWV0aGluZyB3ZW50IHdyb25nLlwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJUaGlzIGZlYXR1cmUgaGFzIGJlZW4gdXBkYXRlZCBsYXRlciFcIixcclxuICAgICAgZHVyYXRpb246IDUwMCxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQ291bnRyeSgpO1xyXG4gIH0sIFtdKTtcclxuICBhc3luYyBmdW5jdGlvbiBmZXRjaENvdW50cnkoKSB7XHJcbiAgICBjb25zdCBjb3VudHJ5RGF0YUZyb21TZXJ2ZXIgPSBhd2FpdCBBY2NvdW50UmVwb3NpdG9yeS5nZXRDb3VudHJ5KCk7XHJcbiAgICBzZXRDb3VudHJ5KFsuLi5jb3VudHJ5RGF0YUZyb21TZXJ2ZXIuY291bnRyeV0pO1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChuYW1lKSA9PiAoZXZlbnQpID0+IHtcclxuICAgIHNldFVzZXIoeyAuLi51c2VyLCBbbmFtZV06IGV2ZW50LnRhcmdldC52YWx1ZSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcblxyXG4gIGZ1bmN0aW9uIHZlcmlmeU90cChvdHBGcm9tU2VydmVyLCBpbnB1dEZyb21TZXJ2ZXIpIHtcclxuICAgIGxldCB1c2VyT3RwSW5wdXQgPSBcIlwiO1xyXG4gICAgTW9kYWwuaW5mbyh7XHJcbiAgICAgIHRpdGxlOiBcIlBsZWFzZSBFbnRlciBPVFAgc2VudCBvbiBZb3VyIHBob25lICYgZW1haWwuXCIsXHJcbiAgICAgIGNvbnRlbnQ6IChcclxuICAgICAgICA8Rm9ybSBmb3JtPXtmb3JtfSBvbkZpbmlzaD17aGFuZGxlTG9naW5TdWJtaXR9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwidXNlck90cFwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHlvdXIgT1RQIVwiLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbnB1dCB5b3VyIE9UUCFcIlxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJPdHBJbnB1dCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvRm9ybT5cclxuICAgICAgKSxcclxuICAgICAgb25PaygpIHtcclxuICAgICAgICBsZXQgZGV2aWNlVG9rZW4gPSB1dWlkdjQoKTtcclxuICAgICAgICBsZXQgZGV2aWNlSWQgPSB1dWlkdjQoKTtcclxuICAgICAgICBsZXQgZGV2aWNlTmFtZSA9IFwiQ2hyb21lXCI7XHJcbiAgICAgICAgbGV0IG9zID0gXCJXRUJcIjtcclxuICAgICAgICBsZXQgaW5wdXQgPSBpbnB1dEZyb21TZXJ2ZXI7XHJcbiAgICAgICAgLy8gbGV0IG90cCA9IHVzZXJPdHBJbnB1dDsgY2hhbmdlIHRvIHRoaXMgZm9yIHByb2R1Y3Rpb25cclxuICAgICAgICBsZXQgb3RwID0gYCR7b3RwRnJvbVNlcnZlcn1gO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gQXhpb3MucG9zdChcclxuICAgICAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci92ZXJpZnkvb3RwYCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaW5wdXQsXHJcbiAgICAgICAgICAgIG90cCxcclxuICAgICAgICAgICAgZGV2aWNlVG9rZW4sXHJcbiAgICAgICAgICAgIGRldmljZUlkLFxyXG4gICAgICAgICAgICBkZXZpY2VOYW1lLFxyXG4gICAgICAgICAgICBvcyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZGF0YS5odHRwY29kZSA9PSA0MDAgJiYgZGF0YS5zdGF0dXMgPT0gXCJlcnJvclwiKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgYXJncyA9IHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIG5vdGlmaWNhdGlvbi5vcGVuKGFyZ3MpO1xyXG4gICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoZGF0YS5odHRwY29kZSA9PSAyMDAgJiYgZGF0YS5zdGF0dXMgPT0gXCJzdWNjZXNzXCIpIHtcclxuICAgICAgICAgICAgICBub3RpZmljYXRpb25bXCJzdWNjZXNzXCJdKHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICAgICAgZGlzcGF0Y2gobG9naW4oZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICAgICAgUm91dGVyLnB1c2goXCIvXCIpO1xyXG4gICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgICAgIG1lc3NhZ2U6IGVycm9yLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0VXNlck90cChcIlwiKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBva0NhbmNlbCgpIHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkxvZ2luIEZhaWxlZFwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBjbG9zYWJsZTogZmFsc2UsXHJcbiAgICAgIGtleWJvYXJkOiBmYWxzZSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcblxyXG4gIGNvbnN0IGxvZ2luID0gICgpID0+IHtcclxuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luSWQnKS5zdHlsZS5kaXNwbGF5PSdibG9jaydcclxuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZ2lzdGVySWQnKS5zdHlsZS5kaXNwbGF5PSdub25lJ1xyXG5kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVnaXN0ZXJJZDEnKS5zdHlsZS5kaXNwbGF5PSdub25lJ1xyXG4gIH1cclxuICBjb25zdCByZWcgPSAgKCkgPT4ge1xyXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZ2lzdGVySWQnKS5zdHlsZS5kaXNwbGF5PSdibG9jaydcclxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dpbklkJykuc3R5bGUuZGlzcGxheT0nbm9uZSdcclxuIFxyXG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVnaXN0ZXJJZDEnKS5zdHlsZS5kaXNwbGF5PSdub25lJ1xyXG4gICBcclxuXHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgZm9yZ290ID0gICgpID0+IHtcclxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVnaXN0ZXJJZDEnKS5zdHlsZS5kaXNwbGF5PSdibG9jaydcclxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW5JZCcpLnN0eWxlLmRpc3BsYXk9J25vbmUnXHJcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZ2lzdGVySWQnKS5zdHlsZS5kaXNwbGF5PSdub25lJ1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGNvbnN0IGhhbmRsZVZlcmlmeU9UUDEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmdPVFAodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIuLi51c2VyLmNvdW50cnlfY29kZS4uLi5cIiwgdXNlci5jb3VudHJ5X2NvZGUpXHJcbiAgICAgICAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgIGNvdW50cnlfY29kZTogdXNlci5jb3VudHJ5X2NvZGUuc3BsaXQoXCIrXCIpWzFdLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogdXNlci5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgb3RwOiB1c2VyLm90cF90ZXh0LFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFjY291bnRSZXBvc2l0b3J5LnZlcmlmeUZvcmdvdE9UUChwYXlsb2FkKTtcclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJJZChyZXNwb25zZS5jdXN0b21lcl9pZClcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLnZlcmlmeUZvcmdvdE9UUC4uLi5cIiwgcmVzcG9uc2UpXHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICBzZXRPdHBCdXR0b24oe1xyXG4gICAgICAgICAgICAgICAgY2xhc3M6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgdGV4dDogXCJWZXJpZmllZFwiLFxyXG4gICAgICAgICAgICAgICAgdmVyaWZ5Qm94OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIHZlcmlmaWVkTnVtYmVyOiB1c2VyLnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgIHJlZ2lzdGVyQm94U2hvdzogdHJ1ZSxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldExvYWRpbmdPVFAoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihyZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UubWVzc2FnZSk7XHJcbiAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRMb2FkaW5nT1RQKGZhbHNlKTtcclxuICAgICAgICAgICAgICB9LCA1MDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9O1xyXG4gICAgICBjb25zdCBoYW5kbGVWZXJpZnlPVFAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZ09UUCh0cnVlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIGNvdW50cnlfY29kZTogdXNlci5jb3VudHJ5X2NvZGUsXHJcbiAgICAgICAgICBwaG9uZV9udW1iZXI6IHVzZXIucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgb3RwOiB1c2VyLm90cF90ZXh0LFxyXG4gICAgICAgIH07XHJcbiAgICBcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFjY291bnRSZXBvc2l0b3J5LnZlcmlmeVJlZ2lzdGVyTW9iaWxlT1RQKHBheWxvYWQpO1xyXG5cclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLnZlcnlmeSBvdHAuLi4uLlwiLCByZXNwb25zZSlcclxuICAgICAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5tZXNzYWdlKTtcclxuICAgICAgICAgIHNldE90cEJ1dHRvbih7XHJcbiAgICAgICAgICAgIGNsYXNzOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgdGV4dDogXCJWZXJpZmllZFwiLFxyXG4gICAgICAgICAgICB2ZXJpZnlCb3g6IGZhbHNlLFxyXG4gICAgICAgICAgICB2ZXJpZmllZE51bWJlcjogdXNlci5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIHJlZ2lzdGVyQm94U2hvdzogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgXHJcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZ09UUChmYWxzZSk7XHJcbiAgICAgICAgICB9LCA1MDApO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5tZXNzYWdlKTtcclxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nT1RQKGZhbHNlKTtcclxuICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gIGNvbnN0IGhhbmRsZU9UUCA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldExvYWRpbmdPVFAodHJ1ZSk7XHJcbiAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgY291bnRyeV9jb2RlOiB1c2VyLmNvdW50cnlfY29kZSxcclxuICAgICAgcGhvbmVfbnVtYmVyOiB1c2VyLnBob25lX251bWJlcixcclxuICAgIH07XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFjY291bnRSZXBvc2l0b3J5LnNlbmRSZWdpc3Rlck1vYmlsZU9UUChwYXlsb2FkKTtcclxuXHJcbiAgICBpZiAocmVzcG9uc2UuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24ocmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLm1lc3NhZ2UpO1xyXG4gICAgICBzZXRPdHBCdXR0b24oe1xyXG4gICAgICAgIGNsYXNzOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB0ZXh0OiBcIk9UUCBTZW50XCIsXHJcbiAgICAgICAgdmVyaWZ5Qm94OiB0cnVlLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldExvYWRpbmdPVFAoZmFsc2UpO1xyXG4gICAgICB9LCA1MDApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihyZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UubWVzc2FnZSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldExvYWRpbmdPVFAoZmFsc2UpO1xyXG4gICAgICB9LCA1MDApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdENvdW50cnlDb2RlID0gKG5hbWUpID0+IChkYXRhKSA9PiB7XHJcbiAgICBzZXRVc2VyKHsgLi4udXNlciwgW25hbWVdOiBkYXRhIH0pO1xyXG4gICAgaWYgKG5hbWUgPT0gXCJjb3VudHJ5X2NvZGVcIiAmJiBkYXRhICE9PSB1c2VyLmNvdW50cnlfY29kZSkge1xyXG4gICAgICBzZXRPdHBCdXR0b24oaW5pdFN0YXRlT3RwQnV0dG9uKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUxvZ2luU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IEF4aW9zLnBvc3QoYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2xvZ2luYCwgdXNlciwge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLnRoZW4oKHJlc3BvbnNlKSA9PiByZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgIGlmIChkYXRhLmh0dHBjb2RlID09PSA0MDAgJiYgZGF0YS5zdGF0dXMgPT09IFwiZXJyb3JcIikge1xyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IGRhdGEuZGF0YS5lcnJvcnMuZXJyb3JfbXNnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoZGF0YS5odHRwY29kZSA9PT0gMjAwICYmIGRhdGEuc3RhdHVzID09PSBcInN1Y2Nlc3NcIikge1xyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcInN1Y2Nlc3NcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGRhdGEuZGF0YSk7XHJcbiAgICAgICAgdmVyaWZ5T3RwKGRhdGEuZGF0YS5vdHAsIGRhdGEuZGF0YS5pbnB1dCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9ySW5mbykge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZDpcIiwgZXJyb3JJbmZvKTtcclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9O1xyXG4gIFxyXG4gIC8vICQoJyNteU1vZGFsJykub24oJ3Nob3duLmJzLm1vZGFsJywgZnVuY3Rpb24gKCkge1xyXG4gIC8vICAgJCgnI215SW5wdXQnKS50cmlnZ2VyKCdmb2N1cycpXHJcbiAgLy8gfSlcclxuICAvLyBjb25zdCBoYW5kbGVMb2dpblN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuXHJcblxyXG4gIC8vIH1cclxuICByZXR1cm4gKFxyXG4gICAgXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cImxvZ1wiXHJcbiAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCR7YmFja2dyb3VuZH0pYCxcclxuICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogXCJjb3ZlclwiLFxyXG4gICAgICAgIGJhY2tncm91bmRSZXBlYXQ6IFwibm8tcmVwZWF0XCIsXHJcbiAgICAgICAgYmFja2dyb3VuZFBvc2l0aW9uOiBcImxlZnRcIixcclxuICAgICAgICBoZWlnaHQ6IFwiY2FsYygxMDB2aCAtIDUwcHgpXCIsXHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIDxuYXZcclxuICAgICAgICBjbGFzc05hbWU9XCJtZW55dVwiXHJcbiAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjMDA2ZmI0XCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVueXVfaW5uZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCI+XHJcbiAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLWxvZ29cIiBocmVmPVwiL1wiPlxyXG4gICAgICAgICAgICAgIDxpbWcgc3JjPXtsb2dvX2ltYWdlfSBhbHQ9XCJcIiAvPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9uYXY+XHJcbiAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTEyXCI+XHJcbiAgICAgICAgICA8aDM+TG9nIEluPC9oMz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImxvZzEgbG9nMlwiXHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAvLyBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoJHtiYWNrZ3JvdW5kfSlgLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogXCJjb250YWluXCIsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRSZXBlYXQ6IFwibm8tcmVwZWF0XCIsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogXCJsZWZ0IGNlbnRlclwiLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2NhcmQgbG9nY2FyZDEgbG9nY2FyZDJcIj5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmRcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwidW5zZXRcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ib2R5XCIgc3R5bGU9e3tkaXNwbGF5Oidub25lJ319IGlkPVwibG9naW5JZFwiPiAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2NhcmRfaGVhZGVyX2lubmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nY2FyZF9oZWFkZXJfdGl0bGVcIj5Mb2cgSW48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJvZHkgbG9naW5wXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzaG93TG9naW5XaXRoU01TID8gPExvZ2luV2l0aFNNUyAvPiA6IDxMb2dpbldpdGhFbWFpbCAvPn1cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JndFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJmcmd0X2xpbmtcIiBocmVmPVwiI1wiICAgIG9uQ2xpY2s9eygpID0+IGZvcmdvdCgpfSA+IFxyXG4gICAgICAgICAgICAgICAgICAgICAgRm9yZ290IFBhc3N3b3JkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgXHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJmcmd0X2xpbmtcIiBocmVmPVwiI1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TG9naW5XaXRoU01TKCFzaG93TG9naW5XaXRoU01TKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dMb2dpbldpdGhTTVNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiTG9nIGluIHdpdGggRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJMb2cgaW4gd2l0aCBTTVNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2FyZC1mb290ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGAjZmZmZmZmYCxcclxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclRvcDogYDFweCBzb2xpZCAjZmZmZmZmYCxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3RyX3R4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRG9uJ3QgaGF2ZSBhbiBhY2NvdW50P1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIG9uQ2xpY2s9eygpID0+IHJlZygpfSBjbGFzc05hbWU9XCJmdHJfbGlua1wiPiBTaWduIFVwIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8Rm9ybVxyXG4gICAgICAgICAgZm9ybT17Zm9ybX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInBzLWZvcm0tLWFjY291bnRcIlxyXG4gICAgICAgICAgb25GaW5pc2g9e290cEJ1dHRvbi5yZWdpc3RlckJveFNob3cgPyBoYW5kbGVTdWJtaXQgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nVG9wOiBcIjEwcHhcIiAsIGRpc3BsYXk6J2Jsb2NrJ319XHJcbiAgICAgICAgICBpZD1cInJlZ2lzdGVySWRcIlxyXG4gICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgIGxheW91dD1cInZlcnRpY2FsXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7LyogPHVsIGNsYXNzTmFtZT1cInBzLXRhYi1saXN0XCI+XHJcbiAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvbG9naW5cIj5cclxuICAgICAgICAgICAgICAgIDxhPkxvZ2luPC9hPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImFjdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWNjb3VudC9yZWdpc3RlclwiPlxyXG4gICAgICAgICAgICAgICAgPGE+UmVnaXN0ZXI8L2E+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPC91bD4gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2NhcmRfaGVhZGVyX2lubmVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2djYXJkX2hlYWRlcl90aXRsZVwiPiBSZWdpc3RlciA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy10YWIgYWN0aXZlXCIgaWQ9XCJyZWdpc3RlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWZvcm1fX2NvbnRlbnRcIj5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiYnVzaW5lc3NuYW1lXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBpbnB1dCB5b3VyIGJ1c2luZXNzbmFtZSFcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhdHRlcm46IG5ldyBSZWdFeHAoL15bYS16QS1aXSskL2kpLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiT25seSBBbHBoYWJldHMgQWNjZXB0ZWRcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIG1heDogNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJNYXggNTAgQ2hhcmFjaHRlcnMgYWxsb3dlZC5cIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaXJzdF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQnVzaW5lc3MgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJmaXJzdF9uYW1lXCIpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiZmlyc3RuYW1lXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBpbnB1dCB5b3VyIGZpcnN0bmFtZSFcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhdHRlcm46IG5ldyBSZWdFeHAoL15bYS16QS1aXSskL2kpLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiT25seSBBbHBoYWJldHMgQWNjZXB0ZWRcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIG1heDogNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJNYXggNTAgQ2hhcmFjaHRlcnMgYWxsb3dlZC5cIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtsYXN0X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZShcImxhc3RfbmFtZVwiKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgey8qIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIG5hbWU9XCJsYXN0bmFtZVwiXHJcbiAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgaW5wdXQgeW91ciBsYXN0bmFtZSFcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhdHRlcm46IG5ldyBSZWdFeHAoL15bYS16QS1aXSskL2kpLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiT25seSBBbHBoYWJldHMgQWNjZXB0ZWRcIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIG1heDogNTAsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJNYXggNTAgQ2hhcmFjaHRlcnMgYWxsb3dlZC5cIixcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBMYXN0bmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJsYXN0X25hbWVcIil9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtsYXN0X25hbWV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPiAqL31cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHlvdXIgZW1haWwhXCIsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVtYWlsIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKFwiZW1haWxcIil9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0Lkdyb3VwIGNvbXBhY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtbXCJwaG9uZV9udW1iZXJcIiwgXCJjb3VudHJ5Y29kZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICBub1N0eWxlXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiY291bnRyeWNvZGUgaXMgcmVxdWlyZWRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIyNSVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb3VudHJ5IENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RDb3VudHJ5Q29kZShcImNvdW50cnlfY29kZVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5kZXhPZihpbnB1dC50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkpID49IDBcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VydmVyQ291bnRyeT8ubWFwKChjb3VudHJ5RGV0YWlscywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgKyR7Y291bnRyeURldGFpbHMucGhvbmVjb2RlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICt7Y291bnRyeURldGFpbHMucGhvbmVjb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9e1tcInBob25lX251bWJlclwiLCBcInBob25lbnVtYmVyXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIG5vU3R5bGVcclxuICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJwaG9uZSBudW1iZXIgaXMgcmVxdWlyZWRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW46IDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGhvbmUgbnVtYmVyIHNob3VsZCBiZSA3LTEyIGRpZ2l0IGxvbmchXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg6IDEyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBob25lIG51bWJlciBzaG91bGQgYmUgNy0xMiBkaWdpdCBsb25nIVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogbmV3IFJlZ0V4cCgvXlswLTldKyQvaSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiT25seSBOdW1iZXJzIEFjY2VwdGVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJwaG9uZV9udW1iZXJcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiNzUlXCIsIGhlaWdodDogXCI1MHB4XCIsIHBhZGRpbmc6IFwiMnB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGluIGluZGljYXRvcj17YW50SWNvbn0gc3Bpbm5pbmc9e2xvYWRpbmdPVFB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjdXJzb3I6IFwicG9pbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LSR7b3RwQnV0dG9uLmNsYXNzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPVFB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge290cEJ1dHRvbi50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPC9JbnB1dC5Hcm91cD5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgIHtvdHBCdXR0b24udmVyaWZ5Qm94ICYmICggXHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1widmVyaWZ5X290cFwifVxyXG4gICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiT1RQIGlzIHJlcXVpcmVkXCIgfV19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlZlcmlmeSBPVFBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJvdHBfdGV4dFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBzdWZmaXg9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgPFNwaW4gaW5kaWNhdG9yPXthbnRJY29ufSBzcGlubmluZz17bG9hZGluZ09UUH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtcHJpbWFyeWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVmVyaWZ5T1RQfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1wiVmVyaWZ5XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU3Bpbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgKX0gXHJcblxyXG4gICAgICAgICAgICAgIHtvdHBCdXR0b24udGV4dC50b0xvd2VyQ2FzZSgpID09IFwidmVyaWZpZWRcIiAmJlxyXG4gICAgICAgICAgICAgICAgb3RwQnV0dG9uLnJlZ2lzdGVyQm94U2hvdyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBpbnB1dCB5b3VyIHBhc3N3b3JkIVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJwYXNzd29yZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRfY29uZmlybWF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGRlcGVuZGVuY2llcz17W1wicGFzc3dvcmRcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgaW5wdXQgeW91ciBwYXNzd29yZCFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKHsgZ2V0RmllbGRWYWx1ZSB9KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvcihydWxlLCB2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2YWx1ZSB8fCBnZXRGaWVsZFZhbHVlKFwicGFzc3dvcmRcIikgPT0gdmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRoZSB0d28gcGFzc3dvcmRzIHRoYXQgeW91IGVudGVyZWQgZG8gbm90IG1hdGNoIVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZS1FbnRlciBQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJwYXNzd29yZF9jb25maXJtYXRpb25cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZF9jb25maXJtYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCBzdWJtaXRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgaHRtbFR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcy1idG4gcHMtYnRuLS1mdWxsd2lkdGhcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBSZWdpc3RlclxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+ICovfVxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtYnRuIHBzLWJ0bi0tZnVsbHdpZHRoXCJcclxuICAgICAgICAgICAgICAgICAgLy8gb25DbGljaz17b3RwQnV0dG9uLnJlZ2lzdGVyQm94U2hvdyA/IGhhbmRsZVN1Ym1pdCA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUmVnaXN0ZXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQtZm9vdGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgI2ZmZmZmZmAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJUb3A6IGAxcHggc29saWQgI2ZmZmZmZmAsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm90cl90eHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFscmVhZHkgaGF2ZSBhbiBhY2NvdW50P1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIG9uQ2xpY2s9eygpID0+IGxvZ2luKCl9IGNsYXNzTmFtZT1cImZ0cl9saW5rXCI+IExvZyBJbiA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7LyogPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGxvZ2luKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgTG9nIEluXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+ICovfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvRm9ybT5cclxuXHJcblxyXG4gICAgICAgIDxGb3JtXHJcbiAgICAgICAgICBmb3JtPXtmb3JtfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHMtZm9ybS0tYWNjb3VudFwiXHJcbiAgICAgICAgICBvbkZpbmlzaD17b3RwQnV0dG9uLnJlZ2lzdGVyQm94U2hvdyA/IGhhbmRsZVN1Ym1pdDEgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nVG9wOiBcIjEwcHhcIiAsIGRpc3BsYXk6J25vbmUnfX1cclxuICAgICAgICAgIGlkPVwicmVnaXN0ZXJJZDFcIlxyXG4gICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgIGxheW91dD1cInZlcnRpY2FsXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7LyogPHVsIGNsYXNzTmFtZT1cInBzLXRhYi1saXN0XCI+XHJcbiAgICAgICAgICAgIDxsaT5cclxuICAgICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvbG9naW5cIj5cclxuICAgICAgICAgICAgICAgIDxhPkxvZ2luPC9hPlxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImFjdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvYWNjb3VudC9yZWdpc3RlclwiPlxyXG4gICAgICAgICAgICAgICAgPGE+UmVnaXN0ZXI8L2E+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgPC91bD4gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2NhcmRfaGVhZGVyX2lubmVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2djYXJkX2hlYWRlcl90aXRsZVwiPiBGb3Jnb3QgUGFzc3dvcmQgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtdGFiIGFjdGl2ZVwiIGlkPVwicmVnaXN0ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1mb3JtX19jb250ZW50XCI+XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0Lkdyb3VwIGNvbXBhY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtbXCJwaG9uZV9udW1iZXJcIiwgXCJjb3VudHJ5Y29kZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICBub1N0eWxlXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiY291bnRyeWNvZGUgaXMgcmVxdWlyZWRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIyNSVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDb3VudHJ5IENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTZWxlY3RDb3VudHJ5Q29kZShcImNvdW50cnlfY29kZVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5kZXhPZihpbnB1dC50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkpID49IDBcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VydmVyQ291bnRyeT8ubWFwKChjb3VudHJ5RGV0YWlscywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgKyR7Y291bnRyeURldGFpbHMucGhvbmVjb2RlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICt7Y291bnRyeURldGFpbHMucGhvbmVjb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9e1tcInBob25lX251bWJlclwiLCBcInBob25lbnVtYmVyXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIG5vU3R5bGVcclxuICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJwaG9uZSBudW1iZXIgaXMgcmVxdWlyZWRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW46IDcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGhvbmUgbnVtYmVyIHNob3VsZCBiZSA3LTEyIGRpZ2l0IGxvbmchXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg6IDEyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBob25lIG51bWJlciBzaG91bGQgYmUgNy0xMiBkaWdpdCBsb25nIVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogbmV3IFJlZ0V4cCgvXlswLTldKyQvaSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiT25seSBOdW1iZXJzIEFjY2VwdGVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJwaG9uZV9udW1iZXJcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiNzUlXCIsIGhlaWdodDogXCI1MHB4XCIsIHBhZGRpbmc6IFwiMnB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGluIGluZGljYXRvcj17YW50SWNvbn0gc3Bpbm5pbmc9e2xvYWRpbmdPVFB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjdXJzb3I6IFwicG9pbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LSR7b3RwQnV0dG9uLmNsYXNzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPVFB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge290cEJ1dHRvbi50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPC9JbnB1dC5Hcm91cD5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgIHtvdHBCdXR0b24udmVyaWZ5Qm94ICYmICggXHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1widmVyaWZ5X290cFwifVxyXG4gICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiT1RQIGlzIHJlcXVpcmVkXCIgfV19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlZlcmlmeSBPVFBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2UoXCJvdHBfdGV4dFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBzdWZmaXg9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgPFNwaW4gaW5kaWNhdG9yPXthbnRJY29ufSBzcGlubmluZz17bG9hZGluZ09UUH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtcHJpbWFyeWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVmVyaWZ5T1RQMX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcIlZlcmlmeVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NwaW4+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICl9IFxyXG5cclxuICAgICAgICAgICAgICB7b3RwQnV0dG9uLnRleHQudG9Mb3dlckNhc2UoKSA9PSBcInZlcmlmaWVkXCIgJiZcclxuICAgICAgICAgICAgICAgIG90cEJ1dHRvbi5yZWdpc3RlckJveFNob3cgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgaW5wdXQgeW91ciBwYXNzd29yZCFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKFwicGFzc3dvcmRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkX2NvbmZpcm1hdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkZXBlbmRlbmNpZXM9e1tcInBhc3N3b3JkXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHlvdXIgcGFzc3dvcmQhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICh7IGdldEZpZWxkVmFsdWUgfSkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IocnVsZSwgdmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsdWUgfHwgZ2V0RmllbGRWYWx1ZShcInBhc3N3b3JkXCIpID09IHZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUaGUgdHdvIHBhc3N3b3JkcyB0aGF0IHlvdSBlbnRlcmVkIGRvIG5vdCBtYXRjaCFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmUtRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlKFwicGFzc3dvcmRfY29uZmlybWF0aW9uXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmRfY29uZmlybWF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAgc3VibWl0XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxUeXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtYnRuIHBzLWJ0bi0tZnVsbHdpZHRoXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUmVnaXN0ZXJcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPiAqL31cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0MX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibG9nX2J0blwiXHJcbiAgICAgICAgICAgICAgICAgIC8vIG9uQ2xpY2s9e290cEJ1dHRvbi5yZWdpc3RlckJveFNob3cgPyBoYW5kbGVTdWJtaXQgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENoYW5nZSBQYXNzd29yZFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2FyZC1mb290ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGAjZmZmZmZmYCxcclxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclRvcDogYDFweCBzb2xpZCAjZmZmZmZmYCxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3RyX3R4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgb25DbGljaz17KCkgPT4gbG9naW4oKX0gY2xhc3NOYW1lPVwiZnRyX2xpbmtcIj4gTG9nIEluIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHsvKiA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbG9naW4oKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICBMb2cgSW5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj4gKi99XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Gb3JtPlxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgIFxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgXHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExvZ2luO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuXHJcbmNvbnN0IEZvb3RlckNvcHlyaWdodCA9ICgpID0+IChcclxuXHJcbiAgPD4gIFxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ib3R0b20gcHQtODAgcGItMzBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTIgY29sLW1kLTYgY29sLWxnLTQgbWItMzBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItd2lkZ2V0IG14LXctNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1sb2dvIG1iLTM1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImluZGV4Lmh0bWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgc3JjPVwiYXNzZXRzL2ltZy9sb2dvL2xvZ28tZGFyay5qcGdcIiBhbHQ9XCJmb290ZXIgbG9nb1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQgbWItMzBcIj5XZSBhcmUgYSB0ZWFtIG9mIGRlc2lnbmVycyBhbmQgZGV2ZWxvcGVycyB0aGF0IGNyZWF0ZSBoaWdoIHF1YWxpdHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBNYWdlbnRvLCBQcmVzdGFzaG9wLCBPcGVuY2FydC48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkZHJlc3Mtd2lkZ2V0IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhZGRyZXNzLWljb24gbWUtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxpbWcgc3JjPVwiYXNzZXRzL2ltZy9pY29uL3Bob25lLnBuZ1wiIGFsdD1cInBob25lXCI+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaGVscC10ZXh0IHRleHQtdXBwZXJjYXNlXCI+TkVFRCBIRUxQPzwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmtcIj48YSBocmVmPVwidGVsOisxKDEyMyk4ODg5OTk5XCI+KCs4MDApIDM0NSA2Nzg8L2E+PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbC1uZXR3b3JrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImQtZmxleFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgdGFyZ2V0PVwiX2JsYW5rXCI+PHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaWNvbi1zb2NpYWwtZmFjZWJvb2tcIj48L3NwYW4+PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIj48c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpY29uLXNvY2lhbC10d2l0dGVyXCI+PC9zcGFuPjwvYT48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgdGFyZ2V0PVwiX2JsYW5rXCI+PHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaWNvbi1zb2NpYWwteW91dHViZVwiPjwvc3Bhbj48L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm1lLTBcIj48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIj48c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpY29uLXNvY2lhbC1pbnN0YWdyYW1cIj48L3NwYW4+PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctMiBtYi0zMCBwbC00MFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci13aWRnZXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWJvdHRvbSBjYmIxIG1iLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlIHBiLTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmsgdGV4dC11cHBlcmNhc2VcIj5JbmZvcm1hdGlvbjwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZvb3Rlci1tZW51XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkRlbGl2ZXJ5PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkFib3V0IHVzPC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPlNlY3VyZSBwYXltZW50PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkNvbnRhY3QgdXM8L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCI+U2l0ZW1hcDwvYT48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5TdG9yZXM8L2E+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctMiBtYi0zMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci13aWRnZXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWJvdHRvbSBjYmIxIG1iLTI1XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlIHBiLTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0aXRsZSB0ZXh0LWRhcmsgdGV4dC11cHBlcmNhc2VcIj5DdXN0b20gTGlua3M8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZm9vdGVyLW1lbnVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIi9wYWdlL2JsYW5rXCI+TGVnYWwgTm90aWNlPC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPlByaWNlcyBkcm9wPC9hPjwvbGk+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5OZXcgcHJvZHVjdHM8L2E+PC9saT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkJlc3Qgc2FsZXM8L2E+PC9saT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIvcGFnZS9ibGFua1wiPkxvZ2luPC9hPjwvbGk+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiL3BhZ2UvYmxhbmtcIj5NeSBhY2NvdW50PC9hPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC02IGNvbC1sZy00IG1iLTMwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLXdpZGdldFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYm90dG9tIGNiYjEgbWItMjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGUgcGItMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRpdGxlIHRleHQtZGFyayB0ZXh0LXVwcGVyY2FzZVwiPk5ld3NsZXR0ZXI8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0IG1iLTIwXCI+WW91IG1heSB1bnN1YnNjcmliZSBhdCBhbnkgbW9tZW50LiBGb3IgdGhhdCBwdXJwb3NlLCBwbGVhc2UgZmluZCBvdXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWN0IGluZm8gaW4gdGhlIGxlZ2FsIG5vdGljZS48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5sZXR0ZXItZm9ybSBtYi0zNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImZvcm0taW5saW5lIHBvc2l0aW9uLXJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uPVwiL3BhZ2UvYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIiBtZXRob2Q9XCJwb3N0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW5wdXQgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIllvdXIgZW1haWwgYWRkcmVzc1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gbmxldHRlci1idG4gdGV4dC1jYXBpdGFsaXplXCIgdHlwZT1cInN1Ym1pdFwiPlNpZ25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9yZSBkLWZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiL3BhZ2UvYmxhbmtcIiBjbGFzc05hbWU9XCJkLWlubGluZS1ibG9jayBtZS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGltZyByYz1cImFzc2V0cy9pbWcvaWNvbi9hcHBsZS5wbmdcIiBhbHQ9XCJhcHBsZSBpY29uXCI+ICAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi9wYWdlL2JsYW5rXCIgY2xhc3NOYW1lPVwiZC1pbmxpbmUtYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW1nIHNyYz1cImFzc2V0cy9pbWcvaWNvbi9wbGF5LnBuZ1wiIGFsdD1cImFwcGxlIGljb25cIj4gICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICBcclxuICA8ZGl2IGNsYXNzTmFtZT1cImNvcHB5LXJpZ2h0IHBiLTgwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1tZC02IGNvbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMyBtYi1tZC0wXCI+XHJcbiAgICAgICAgICDCqSAyMDIxIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtY2FwaXRhbGl6ZVwiPkp1bm5vPC9zcGFuPiBNYWRlXHJcbiAgICAgICAgICB3aXRoIDxzcGFuPiYjMTAwODQ7PC9zcGFuPiBieVxyXG4gICAgICAgICAgPGEgdGFyZ2V0PVwiX2JsYW5rXCIgaHJlZj1cImh0dHBzOi8vaGFzdGhlbWVzLmNvbS9cIj5IYXNUaGVtZXM8L2E+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMiBjb2wtbWQtNiBjb2wtbGctOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aW1nIHNyYz1cImFzc2V0cy9pbWcvcGF5bWVudC8xLnBuZ1wiIGFsdD1cImltZ1wiPiAqL31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiBcclxuICA8Lz5cclxuXHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb290ZXJDb3B5cmlnaHQ7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBMb2dvIGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvY29tbW9uL0xvZ29cIjtcclxuaW1wb3J0IFNlYXJjaEhlYWRlciBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9oZWFkZXJzL21vZHVsZXMvU2VhcmNoSGVhZGVyXCI7XHJcbmltcG9ydCBOYXZpZ2F0aW9uRGVmYXVsdCBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9uYXZpZ2F0aW9uL05hdmlnYXRpb25EZWZhdWx0XCI7XHJcbmltcG9ydCBIZWFkZXJBY3Rpb25zIGZyb20gXCJ+L2NvbXBvbmVudHMvc2hhcmVkL2hlYWRlcnMvbW9kdWxlcy9IZWFkZXJBY3Rpb25zXCI7XHJcbmltcG9ydCB7IHN0aWNreUhlYWRlciB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgTWVudUNhdGVnb3JpZXNEcm9wZG93biBmcm9tIFwifi9jb21wb25lbnRzL3NoYXJlZC9tZW51cy9NZW51Q2F0ZWdvcmllc0Ryb3Bkb3duXCI7XHJcblxyXG5jb25zdCBIZWFkZXJEZWZhdWx0ID0gKCkgPT4ge1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocHJvY2Vzcy5icm93c2VyKSB7XHJcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIHN0aWNreUhlYWRlcik7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJoZWFkZXIgaGVhZGVyLS0xXCIgZGF0YS1zdGlja3k9XCJ0cnVlXCIgaWQ9XCJoZWFkZXJTdGlja3lcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkLXRvcFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwcy1jb250YWluZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJkLWZsZXgganVzdGlmeS1jb250ZW50LWVuZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInRvcC11cmxcIj5cclxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJ0b3AtbGlcIj5cclxuICAgICAgICAgICAgICAgICAgPGE+IEVuZyA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9hY2NvdW50L2xvZ2luXCI+XHJcbiAgICAgICAgICAgIDxhPiBTaWduIEluPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9hY2NvdW50L2xvZ2luXCI+XHJcbiAgICAgICAgICAgIDxhPlJlZ2lzdGVyPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPGEgaHJlZj1cIlwiPiBTaWduIEluIDwvYT5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIlwiPiBSZWdpc3RlciA8L2E+ICovfVxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX3RvcFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlcl9fbGVmdFwiPlxyXG4gICAgICAgICAgICA8TG9nbyAvPlxyXG4gICAgICAgICAgICB7LyogPE1lbnVDYXRlZ29yaWVzRHJvcGRvd24gLz4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19jYXRlZ1wiPlxyXG4gICAgICAgICAgICA8TWVudUNhdGVnb3JpZXNEcm9wZG93biAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8YSBocmVmPVwiXCI+T2ZmZXIgWm9uZTwvYT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXJfX2NlbnRlclwiPlxyXG4gICAgICAgICAgICA8U2VhcmNoSGVhZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyX19yaWdodFwiPlxyXG4gICAgICAgICAgICA8SGVhZGVyQWN0aW9ucyAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICB7LyogPE5hdmlnYXRpb25EZWZhdWx0IC8+ICovfVxyXG4gICAgPC9oZWFkZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWRlckRlZmF1bHQ7XHJcbiIsImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgY29ubmVjdCwgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IEF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXRDYXJ0LCByZW1vdmVJdGVtIH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IFByb2R1Y3RPbkNhcnQgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0T25DYXJ0XCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcbmltcG9ydCB7IGdldERldmljZUlkIH0gZnJvbSBcIn4vdXRpbGl0aWVzL2NvbW1vbi1oZWxwZXJzXCI7XHJcbmltcG9ydCBSZXBvc2l0b3J5LCB7IGJhc2VVcmwsIHNlcmlhbGl6ZVF1ZXJ5LCBhcGliYXNldXJsIH0gZnJvbSBcIn4vcmVwb3NpdG9yaWVzL1JlcG9zaXRvcnlcIjtcclxuY29uc3QgTWluaUNhcnQgPSBSZWFjdC5tZW1vKCh7IGNhcnQgfSkgPT4ge1xyXG4gIGxldCBjYXJ0SXRlbXNWaWV3O1xyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuICBjb25zdCBhdXRoID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5hdXRoKTtcclxuXHJcbiAgY29uc3QgcHJvZHVjdEl0ZW1XaXRoU2VsbGVyID0gY2FydD8ucHJvZHVjdD8ubWFwKChwcm9kdWN0SXRlbSkgPT4gKFxyXG4gICAgPGRpdiBrZXk9e3Byb2R1Y3RJdGVtPy5zZWxsZXI/LnNlbGxlcl9pZH0+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInN0b3ItdGl0XCI+e3Byb2R1Y3RJdGVtPy5zZWxsZXI/LnNlbGxlcn08L3A+XHJcbiAgICAgIHtwcm9kdWN0SXRlbT8uc2VsbGVyPy5wcm9kdWN0cz8ubWFwKChjYXJ0UHJvZHVjdCkgPT4gKFxyXG4gICAgICAgIDxQcm9kdWN0T25DYXJ0IHByb2R1Y3Q9e2NhcnRQcm9kdWN0fSBrZXk9e2NhcnRQcm9kdWN0Py5jYXJ0X2lkfSAvPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICkpO1xyXG4gIGNvbnN0IFtjYXJ0ZGF0YSwgc2V0Q2FydGRhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RvdGFsSXRlbXMsIHNldFRvdGFsSXRlbXNdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi5wcm9kdWN0SXRlbU5leHQuLi4uLi5jYXJ0Li4uLi5cIiwgY2FydClcclxuICAgLy8gY29uc29sZS5sb2coXCIucHJvZHVjdEl0ZW1OZXh0Li4uLi4uLi4uLi5cIiwgcHJvZHVjdEl0ZW1OZXh0KVxyXG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XHJcblxyXG4gICAgaWYgKGlzTW91bnRlZCkge1xyXG4gICAgICAvL2FsZXJ0KFwiYmhiaGhiaGhoXCIpXHJcbiAgICAgIGNvbnN0IGNhcnRUb3RhbFByb2R1Y3RzRnJvbUFsbFNlbGxlciA9IGNhcnQ/LnByb2R1Y3Q/LnJlZHVjZShcclxuICAgICAgICAocHJvZHVjdEl0ZW1QcmV2LCBwcm9kdWN0SXRlbU5leHQpID0+IHtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIE51bWJlcihwcm9kdWN0SXRlbVByZXYpIFxyXG4gICAgICAgICAgICAgK1xyXG4gICAgICAgICAgICAgTnVtYmVyKHByb2R1Y3RJdGVtTmV4dC5zZWxsZXIucHJvZHVjdHMubGVuZ3RoKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldFRvdGFsSXRlbXMoY2FydFRvdGFsUHJvZHVjdHNGcm9tQWxsU2VsbGVyKTtcclxuICAgICAgc2V0Q2FydGRhdGEoY2FydCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBpc01vdW50ZWQgPSBmYWxzZTtcclxuICAgIH07XHJcbiAgfSwgW2NhcnQ/LnByb2R1Y3RdKTtcclxuICBcclxuICAvLyBhc3luYyBnZXRDYXJ0SXRlbShwYXlsb2FkKSB7XHJcblxyXG4gICAgY29uc3QgZ2V0Q2FydEl0ZW0gPSAocGF5bG9hZCkgPT4ge1xyXG4gICAgICBhbGVydChcIjc3Nzc3NjdcIilcclxuICAgIC8vYWxlcnQoXCJkXCIpXHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZW1haWwuLi5sb2dpbi4uLi4gJHthcGliYXNldXJsfS4uLlwiLHthcGliYXNldXJsfSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmFhYWFhYWFhYWFhYWFhYWEuLi5cIix1c2VyX3Rva2VuKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmJiYmJiYmJiYmJiYi4uLlwiLGdldERldmljZUlkKVxyXG5cclxuICAgIGNvbnN0IGRhdGEgPSBBeGlvcy5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsXHJcbiAgICAgIHtcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IHVzZXJfdG9rZW4sXHJcbiAgICAgICAgbGFuZ19pZDogMSxcclxuICAgICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9wcm9kdWN0LzJcIixcclxuICAgICAgICBvc190eXBlOiBcIldFQlwiLFxyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi5paWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWkuXCIsZGF0YSlcclxuICAgIC8vICAgIGNvbnNvbGUubG9nKFwiLi4uLmVtYWlsLi4ubG9naW4uLi4uIHJlc3BvbnNlLi4uXCIscmVzcG9uc2UpXHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gNDAwICYmIGRhdGEuc3RhdHVzID09IFwiZXJyb3JcIikge1xyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgLy8gICBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAvLyB9KTtcclxuICAgICAgICAgIC8vIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGRhdGEuaHR0cGNvZGUgPT0gMjAwICYmIGRhdGEuc3RhdHVzID09IFwic3VjY2Vzc1wiKSB7XHJcbiAgICAgICAgICBzZXRDYXJ0ZGF0YShkYXRhLmRhdGEpXHJcbiAgICAgICAgICBzZXRUb3RhbEl0ZW1zKGRhdGEuZGF0YS5jYXJ0X2NvdW50KVxyXG4gICAgICAgLy8gICBhbGVydChcInllc1wiKVxyXG4gICAgICAgIC8vICBzZXRPZmZlckRhdGEoZGF0YS5kYXRhKVxyXG4gICAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wic3VjY2Vzc1wiXSh7XHJcbiAgICAgICAgICAvLyAgIG1lc3NhZ2U6IGRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAvLyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJcIiwgSlNPTi5zdHJpbmdpZnkoZGF0YS5kYXRhKSk7XHJcbiAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgLy8gbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgIC8vICAgbWVzc2FnZTogZXJyb3IsXHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuY2NjY2MuLlwiLGdldERldmljZUlkKVxyXG4gICAvLyBjb25zb2xlLmxvZyhcIi4uLi5iYmJiYi4uLmJiYi4uLlwiLHBheWxvYWQpXHJcbiAgICAvLyBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAvLyBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICAvLyBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAvLyBjb25zdCB1c2VyX3Rva2VuID0gYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIC8vIGNvbnN0IHJlc3BvbnNlID0gIFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsIHtcclxuICAgIC8vICAgYWNjZXNzX3Rva2VuOiB1c2VyX3Rva2VuLFxyXG4gICAgLy8gICBsYW5nX2lkOiAxLFxyXG4gICAgLy8gICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgLy8gICBwYWdlX3VybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvcHJvZHVjdC8yXCIsXHJcbiAgICAvLyAgIG9zX3R5cGU6IFwiV0VCXCIsXHJcbiAgICAvLyB9KVxyXG4gICAgLy8gY29uc29sZS5sb2coXCIuLi4uYmJiYmIuLi5iYmIuLjQ0NDQ0NDQ0NDQ0NC5cIixyZXNwb25zZSlcclxuICAgIC8vICAgLy8gLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAvLyAgICAgaWYgKHJlc3BvbnNlLmRhdGEuaHR0cGNvZGUgPT0gXCIyMDBcIikge1xyXG4gICAgLy8gICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAvLyAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgLy8gICAvLyB9KVxyXG4gICAgLy8gICAvLyAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIC8vIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi41NTcuLlwiLGNhcnQpXHJcbiAgICBnZXRDYXJ0SXRlbSgpXHJcbiAgICBpZiAoY2FydCA9PSB1bmRlZmluZWQpIHtcclxuICAgICAvLyBhbGVydChcImRkZmZmZFwiKVxyXG4gICAgICBhdXRoPy5hY2Nlc3NfdG9rZW4gJiYgZGlzcGF0Y2goZ2V0Q2FydCgpKTtcclxuICAgIH1cclxuICB9LCBbYXV0aC5hY2Nlc3NfdG9rZW4sIGNhcnQ/LnByb2R1Y3RdKTtcclxuXHJcbiAgaWYgKFxyXG4gICAgY2FydGRhdGEgIT09IG51bGwgJiZcclxuICAgIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggJiZcclxuICAgIGNhcnRkYXRhPy5wcm9kdWN0Py5sZW5ndGggIT09IDBcclxuICApIHtcclxuICAgIGNhcnRJdGVtc1ZpZXcgPSAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9faXRlbXNcIj57cHJvZHVjdEl0ZW1XaXRoU2VsbGVyfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydF9fZm9vdGVyXCI+XHJcbiAgICAgICAgICA8aDM+XHJcbiAgICAgICAgICAgIFN1YiBUb3RhbDpcclxuICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICB7Y2FydGRhdGEgJiYgY2FydGRhdGEgIT09IG51bGwgJiYgY2FydGRhdGE/LnByb2R1Y3Q/Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgID8gY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0KGNhcnRkYXRhLmdyYW5kX3RvdGFsKVxyXG4gICAgICAgICAgICAgICAgOiAwfVxyXG4gICAgICAgICAgICA8L3N0cm9uZz5cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvc2hvcHBpbmctY2FydFwiPlxyXG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInBzLWJ0blwiPlZpZXcgQ2FydDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TGluayBocmVmPVwiL2FjY291bnQvY2hlY2tvdXRcIj5cclxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJwcy1idG5cIj5DaGVja291dDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2FydEl0ZW1zVmlldyA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1jYXJ0X19pdGVtc1wiPlxyXG4gICAgICAgICAgPHNwYW4+Tm8gcHJvZHVjdHMgaW4gY2FydDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtY2FydC0tbWluaVwiPlxyXG4gICAgICA8YSBjbGFzc05hbWU9XCJoZWFkZXJfX2V4dHJhXCIgaHJlZj1cIiNcIj5cclxuICAgICAgICA8aSBjbGFzc05hbWU9XCJpY29uLWJhZzJcIj48L2k+XHJcbiAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICA8aT5cclxuICAgICAgICAgICAge2NhcnRkYXRhICE9PSBudWxsICYmIGNhcnRkYXRhICE9PSB1bmRlZmluZWQgJiYgdG90YWxJdGVtcyA+IDBcclxuICAgICAgICAgICAgICA/IHRvdGFsSXRlbXNcclxuICAgICAgICAgICAgICA6IDB9XHJcbiAgICAgICAgICA8L2k+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2E+XHJcbiAgICAgIHtjYXJ0SXRlbXNWaWV3fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KChzdGF0ZSkgPT4gc3RhdGUuY2FydCkoTWluaUNhcnQpO1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IFByb2R1Y3RTZWFyY2hSZXN1bHQgZnJvbSBcIn4vY29tcG9uZW50cy9lbGVtZW50cy9wcm9kdWN0cy9Qcm9kdWN0U2VhcmNoUmVzdWx0XCI7XHJcblxyXG5jb25zdCBleGFtcGxlQ2F0ZWdvcmllcyA9IFtcclxuICB7XHJcbiAgICBpZDogXCJcIixcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiQWxsXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNCxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiR3JvY2VyeVwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDUsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkVsZWN0cm9uaWNzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNixcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiQmFrZXJ5XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNyxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiRmFzaGlvblwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDgsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcInNob2VzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTAsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcImtpZHMgZmFzaGlvblwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDExLFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJEYWlyeSBQcm9kdWN0c1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDEyLFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJIb21lXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTMsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkFwcGxpYW5jZXNcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAxNCxcclxuICAgIGNhdGVnb3J5X25hbWU6IFwiTW9iaWxlc1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDE1LFxyXG4gICAgY2F0ZWdvcnlfbmFtZTogXCJUb3lzXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMTgsXHJcbiAgICBjYXRlZ29yeV9uYW1lOiBcIkpld2VsbGVyeXlcIixcclxuICB9LFxyXG5dO1xyXG5cclxuZnVuY3Rpb24gdXNlRGVib3VuY2UodmFsdWUsIGRlbGF5KSB7XHJcbiAgY29uc3QgW2RlYm91bmNlZFZhbHVlLCBzZXREZWJvdW5jZWRWYWx1ZV0gPSB1c2VTdGF0ZSh2YWx1ZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIFVwZGF0ZSBkZWJvdW5jZWQgdmFsdWUgYWZ0ZXIgZGVsYXlcclxuICAgIGNvbnN0IGhhbmRsZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0RGVib3VuY2VkVmFsdWUodmFsdWUpO1xyXG4gICAgfSwgZGVsYXkpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICAgIH07XHJcbiAgfSwgW3ZhbHVlLCBkZWxheV0pO1xyXG5cclxuICByZXR1cm4gZGVib3VuY2VkVmFsdWU7XHJcbn1cclxuXHJcbmNvbnN0IFNlYXJjaEhlYWRlciA9ICgpID0+IHtcclxuICBjb25zdCBpbnB1dEVsID0gdXNlUmVmKG51bGwpO1xyXG4gIGNvbnN0IFtpc1NlYXJjaCwgc2V0SXNTZWFyY2hdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtrZXl3b3JkLCBzZXRLZXl3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Jlc3VsdEl0ZW1zLCBzZXRSZXN1bHRJdGVtc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgZGVib3VuY2VkU2VhcmNoVGVybSA9IHVzZURlYm91bmNlKGtleXdvcmQsIDE1MDApO1xyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVDbGVhcktleXdvcmQoKSB7XHJcbiAgICBzZXRLZXl3b3JkKFwiXCIpO1xyXG4gICAgc2V0SXNTZWFyY2goZmFsc2UpO1xyXG4gICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgUm91dGVyLnB1c2goYC9zZWFyY2g/a2V5d29yZD0ke2tleXdvcmR9YCk7XHJcbiAgfVxyXG4gIGNvbnN0IFttZW51RGF0YUZyb21TZXJ2ZXIsIHNldE1lbnVEYXRhRnJvbVNlcnZlcl0gPSB1c2VTdGF0ZShbXHJcbiAgICB7XHJcbiAgICAgIGNhdGVnb3J5X2lkOiBcIlwiLFxyXG4gICAgICBjYXRlZ29yeV9uYW1lOiBcIkFsbFwiLFxyXG4gICAgfSxcclxuICBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBpc1N1YnNjcmliZWQgPSB0cnVlO1xyXG4gICAgY29uc3QgZmV0Y2hNZW51RGF0YUZyb21TZXJ2ZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBQcm9kdWN0UmVwb3NpdG9yeS5nZXRQcm9kdWN0Q2F0ZWdvcmllcygpO1xyXG4gICAgICAgIGlzU3Vic2NyaWJlZFxyXG4gICAgICAgICAgPyBzZXRNZW51RGF0YUZyb21TZXJ2ZXIoW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGNhdGVnb3J5X2lkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgY2F0ZWdvcnlfbmFtZTogXCJBbGxcIixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIC4uLnJlc3BvbnNlLmRhdGEuY2F0X3N1YmNhdCxcclxuICAgICAgICAgICAgXSlcclxuICAgICAgICAgIDogbnVsbDtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlcigpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiAoaXNTdWJzY3JpYmVkID0gZmFsc2UpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChkZWJvdW5jZWRTZWFyY2hUZXJtKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGlmIChrZXl3b3JkKSB7XHJcbiAgICAgICAgY29uc3QgcXVlcmllcyA9IHtcclxuICAgICAgICAgIF9saW1pdDogNSxcclxuICAgICAgICAgIHRpdGxlX2NvbnRhaW5zOiBrZXl3b3JkLFxyXG4gICAgICAgICAgY2F0ZWdvcnlfaWQ6IGNhdGVnb3J5LFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy8gY29uc3QgcHJvZHVjdHMgPSBQcm9kdWN0UmVwb3NpdG9yeS5nZXRSZWNvcmRzKHF1ZXJpZXMpO1xyXG4gICAgICAgIGNvbnN0IHByb2R1Y3RzID0gUHJvZHVjdFJlcG9zaXRvcnkuZ2V0U2VhcmNoZWRQcm9kdWN0cyhxdWVyaWVzKTtcclxuXHJcbiAgICAgICAgcHJvZHVjdHMudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgIHNldFJlc3VsdEl0ZW1zKHJlc3VsdC5pdGVtcyk7XHJcbiAgICAgICAgICBzZXRJc1NlYXJjaCh0cnVlKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRJc1NlYXJjaChmYWxzZSk7XHJcbiAgICAgICAgc2V0S2V5d29yZChcIlwiKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAobG9hZGluZykge1xyXG4gICAgICAgIHNldElzU2VhcmNoKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldElzU2VhcmNoKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbZGVib3VuY2VkU2VhcmNoVGVybV0pO1xyXG5cclxuICAvLyBWaWV3c1xyXG4gIGxldCBwcm9kdWN0SXRlbXNWaWV3LFxyXG4gICAgY2xlYXJUZXh0VmlldyxcclxuICAgIHNlbGVjdE9wdGlvblZpZXcsXHJcbiAgICBsb2FkaW5nVmlldyxcclxuICAgIGxvYWRNb3JlVmlldztcclxuICBpZiAoIWxvYWRpbmcpIHtcclxuICAgIGlmIChyZXN1bHRJdGVtcyAmJiByZXN1bHRJdGVtcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGlmIChyZXN1bHRJdGVtcy5sZW5ndGggPiA1KSB7XHJcbiAgICAgICAgbG9hZE1vcmVWaWV3ID0gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wYW5lbF9fZm9vdGVyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvc2VhcmNoXCI+XHJcbiAgICAgICAgICAgICAgPGE+U2VlIGFsbCByZXN1bHRzPC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICAgIHByb2R1Y3RJdGVtc1ZpZXcgPSByZXN1bHRJdGVtcy5tYXAoKHByb2R1Y3QpID0+IChcclxuICAgICAgICA8UHJvZHVjdFNlYXJjaFJlc3VsdCBwcm9kdWN0PXtwcm9kdWN0fSBrZXk9e3Byb2R1Y3QuaWR9IC8+XHJcbiAgICAgICkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcHJvZHVjdEl0ZW1zVmlldyA9IDxwPk5vIHByb2R1Y3QgZm91bmQuPC9wPjtcclxuICAgIH1cclxuICAgIGlmIChrZXl3b3JkICE9PSBcIlwiKSB7XHJcbiAgICAgIGNsZWFyVGV4dFZpZXcgPSAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHMtZm9ybV9fYWN0aW9uXCIgb25DbGljaz17aGFuZGxlQ2xlYXJLZXl3b3JkfT5cclxuICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24gaWNvbi1jcm9zczJcIj48L2k+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICBsb2FkaW5nVmlldyA9IChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHMtZm9ybV9fYWN0aW9uXCI+XHJcbiAgICAgICAgPFNwaW4gc2l6ZT1cInNtYWxsXCIgLz5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChtZW51RGF0YUZyb21TZXJ2ZXI/Lmxlbmd0aCA+IDApIHtcclxuICAgIHNlbGVjdE9wdGlvblZpZXcgPSBtZW51RGF0YUZyb21TZXJ2ZXI/Lm1hcCgob3B0aW9uLCBpbmRleCkgPT4ge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxvcHRpb24gdmFsdWU9e29wdGlvbi5jYXRlZ29yeV9pZH0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICB7b3B0aW9uLmNhdGVnb3J5X25hbWV9XHJcbiAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtXHJcbiAgICAgIGNsYXNzTmFtZT1cInBzLWZvcm0tLXF1aWNrLXNlYXJjaFwiXHJcbiAgICAgIG1ldGhvZD1cImdldFwiXHJcbiAgICAgIGFjdGlvbj1cIi9cIlxyXG4gICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxyXG4gICAgPlxyXG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJwcy1mb3JtX19jYXRlZ29yaWVzXCI+XHJcbiAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzZWxlY3RPcHRpb25WaWV3fVxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICA8L2Rpdj4gKi99XHJcbiAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG5cclxuICAgICAgPC9kaXY+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLWZvcm1fX2lucHV0XCI+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICByZWY9e2lucHV0RWx9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2xcIlxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgdmFsdWU9e2tleXdvcmR9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkknbSBzaG9wcGluZyBmb3IuLi5cIlxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRLZXl3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHtjbGVhclRleHRWaWV3fVxyXG4gICAgICAgIHtsb2FkaW5nVmlld31cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHsvKiA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0+U2VhcmNoPC9idXR0b24+ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YHBzLXBhbmVsLS1zZWFyY2gtcmVzdWx0JHtpc1NlYXJjaCA/IFwiIGFjdGl2ZSBcIiA6IFwiXCJ9YH0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wYW5lbF9fY29udGVudFwiPntwcm9kdWN0SXRlbXNWaWV3fTwvZGl2PlxyXG4gICAgICAgIHtsb2FkTW9yZVZpZXd9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hIZWFkZXI7XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBtZW51RGF0YSBmcm9tIFwifi9wdWJsaWMvc3RhdGljL2RhdGEvbWVudS5qc29uXCI7XHJcbmltcG9ydCBNZW51U2hvcEJ5IGZyb20gXCJ+L2NvbXBvbmVudHMvZWxlbWVudHMvbWVudS9NZW51U2hvcEJ5XCI7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgYXBpYmFzZXVybCB9IGZyb20gXCIuLi8uLi8uLi9yZXBvc2l0b3JpZXMvUmVwb3NpdG9yeVwiO1xyXG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5cclxuY29uc3QgTWVudUNhdGVnb3JpZXNEcm9wZG93biA9ICgpID0+IHtcclxuICBjb25zdCBbbWVudURhdGFGcm9tU2VydmVyLCBzZXRNZW51RGF0YUZyb21TZXJ2ZXJdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlciA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQXhpb3MucG9zdChcclxuICAgICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2F0LXN1YmNhdGBcclxuICAgICAgKTtcclxuICAgICAgc2V0TWVudURhdGFGcm9tU2VydmVyKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgeyBob21lZGF0YSB9ID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5ob21lKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBoYW5kbGVyO1xyXG4gICAgaGFuZGxlciA9IHNldFRpbWVvdXQoYXN5bmMgKCkgPT4ge1xyXG4gICAgICBhd2FpdCBmZXRjaE1lbnVEYXRhRnJvbVNlcnZlcigpO1xyXG4gICAgfSwgMTAwKTtcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICAgIH07XHJcbiAgfSwgW2hvbWVkYXRhXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lbnUtLXByb2R1Y3QtY2F0ZWdvcmllc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lbnVfX3RvZ2dsZVwiPlxyXG4gICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24tbWVudVwiPjwvaT5cclxuICAgICAgICA8c3Bhbj5TaG9wIGJ5IENhdGVnb3J5PC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZW51X19jb250ZW50XCI+XHJcbiAgICAgICAgPE1lbnVTaG9wQnlcclxuICAgICAgICAgIHNvdXJjZT17bWVudURhdGFGcm9tU2VydmVyPy5kYXRhPy5jYXRfc3ViY2F0fVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWVudS0tZHJvcGRvd25cIlxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lbnVDYXRlZ29yaWVzRHJvcGRvd247XHJcbiIsImltcG9ydCB7IHJlc3BvbnNpdmVGb250U2l6ZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IFJlcG9zaXRvcnksIHsgYmFzZVVybCwgc2VyaWFsaXplUXVlcnksIGFwaWJhc2V1cmwgfSBmcm9tIFwiLi9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBBeGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmNvbnN0IG1vZGFsT3BlbiA9ICh0eXBlLCBtZXNzYWdlLCBkZXNjcmlwdGlvbikgPT4ge1xyXG4gIG5vdGlmaWNhdGlvblt0eXBlXSh7XHJcbiAgICBtZXNzYWdlLFxyXG4gICAgZGVzY3JpcHRpb24sXHJcbiAgfSk7XHJcbn07XHJcblxyXG5jbGFzcyBBY2NvdW50UmVwb3NpdG9yeSB7XHJcbiAgYXN5bmMgZ2V0VXNlclB1cmNoYXNlWWVhcnMocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9vcmRlci95ZWFyYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBtb2RhbE9wZW4oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRXJyb3IgRmV0Y2hpbmcgWWVhcnMgZnJvbSBTZXJ2ZXJcIik7XHJcbiAgICAgIH0pO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcblxyXG4gIGFzeW5jIGNoYW5nZVBhc3N3b3JkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcGFzc3dvcmQvY2hhbmdlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcmVnaXN0ZXJOZXdVc2VyKHBheWxvYWQpIHtcclxuICAgIGFsZXJ0KFwiZFwiKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uNTU1Li4uXCIscGF5bG9hZClcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcmVnaXN0ZXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBlZGl0Q3VzdG9tZXJQcm9maWxlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZWRpdC9wcm9maWxlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGZ1bmN0aW9uIChyZXNwb25zZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDb3VudHJ5KCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NvdW50cnlgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSAyMDApIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRDaGF0TGlzdChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEF4aW9zKHtcclxuICAgICAgbWV0aG9kOiBcInBvc3RcIixcclxuICAgICAgdXJsOiBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2hhdC9saXN0YCxcclxuICAgICAgZGF0YTogcGF5bG9hZCxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG5cclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldENoYXRNZXNzYWdlKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9jaGF0L21lc3NhZ2VgLFxyXG4gICAgICBkYXRhOiBwYXlsb2FkLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcblxyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgc2VuZE1lc3NhZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NoYXQvc2VuZGAsXHJcbiAgICAgIGRhdGE6IHBheWxvYWQsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuXHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdGF0ZShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3N0YXRlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2l0eShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NpdHlgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmh0dHBjb2RlID09IFwiMjAwXCIpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRNeU9yZGVycyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvbXlwdXJjaGFzZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjYW5jZWxPcmRlclJlcXVlc3QocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Jlc3BvbnNlL2NhbmNlbC9yZXF1ZXN0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE9yZGVyRGV0YWlscyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIvZGV0YWlsYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIC8vIGFzeW5jIGdldEN1c3RvbWVyUHJvZmlsZURldGFpbCh7IGFjY2Vzc190b2tlbiB9KSB7XHJcbiAgYXN5bmMgZ2V0Q3VzdG9tZXJQcm9maWxlRGV0YWlsKCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9maWxlYCxcclxuICAgICAgeyBhY2Nlc3NfdG9rZW4sIGxhbmdfaWQ6IDEgfVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZUN1c3RvbWVyUHJvZmlsZURldGFpbChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvZWRpdC9wcm9maWxlYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEN1c3RvbWVyUmVjZW50Vmlld3MocGF5bG9hZCkge1xyXG4gICAgbGV0IHVzZXJkYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgbGV0IGFjY2Vzc190b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZWNlbnQvdmlld3NgLFxyXG4gICAgICB7IGFjY2Vzc190b2tlbiwgbGFuZ19pZDogMSB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q3VzdG9tZXJBZGRyZXNzZXMoKSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2FkZHJlc3NgLFxyXG4gICAgICB7IGFjY2Vzc190b2tlbiB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuICBhc3luYyBtYWtlRGVmYXVsdEFkZHJlc3NlcyhwYXlsb2FkKSB7XHJcbiAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBsZXQgcGFyc2VkYXRhID0gSlNPTi5wYXJzZSh1c2VyZGF0YSk7XHJcbiAgICBsZXQgYWNjZXNzX3Rva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcblxyXG4gICAgdmFyIHVzZXJVcGRhdGVGb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgIHVzZXJVcGRhdGVGb3JtRGF0YS5hcHBlbmQoXCJhY2Nlc3NfdG9rZW5cIiwgYWNjZXNzX3Rva2VuKTtcclxuICAgIHVzZXJVcGRhdGVGb3JtRGF0YS5hcHBlbmQoXCJhZGRyZXNzX2lkXCIsIHBheWxvYWQuYWRkcmVzc19pZCk7XHJcbiAgICB1c2VyVXBkYXRlRm9ybURhdGEuYXBwZW5kKFwiaXNfZGVmYXVsdFwiLCBwYXlsb2FkLmRlZmF1bHQpO1xyXG5cclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2RlZmF1bHQvYWRkcmVzc2AsXHJcbiAgICAgIGRhdGE6IHVzZXJVcGRhdGVGb3JtRGF0YSxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBkZWxldGVBZGRyZXNzKHBheWxvYWQpIHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuXHJcbiAgICB2YXIgdXNlclVwZGF0ZUZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgdXNlclVwZGF0ZUZvcm1EYXRhLmFwcGVuZChcImFjY2Vzc190b2tlblwiLCBhY2Nlc3NfdG9rZW4pO1xyXG4gICAgdXNlclVwZGF0ZUZvcm1EYXRhLmFwcGVuZChcImFkZHJlc3NfaWRcIiwgcGF5bG9hZC5hZGRyZXNzX2lkKTtcclxuXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgQXhpb3Moe1xyXG4gICAgICBtZXRob2Q6IFwicG9zdFwiLFxyXG4gICAgICB1cmw6IGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZW1vdmUvYWRkcmVzc2AsXHJcbiAgICAgIGRhdGE6IHVzZXJVcGRhdGVGb3JtRGF0YSxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBhZGRBZGRyZXNzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2FkZC9hZGRyZXNzYCxcclxuICAgICAgZGF0YTogcGF5bG9hZCxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcIm11bHRpcGFydC9mb3JtLWRhdGFcIiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVBZGRyZXNzKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBBeGlvcyh7XHJcbiAgICAgIG1ldGhvZDogXCJwb3N0XCIsXHJcbiAgICAgIHVybDogYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2VkaXQvYWRkcmVzc2AsXHJcbiAgICAgIGRhdGE6IHBheWxvYWQsXHJcbiAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcmV0dXJuT3JkZXJSZXF1ZXN0KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZXR1cm4vcmVxdWVzdGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXR1cm5TaGlwbWVudERldGFpbChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvb3JkZXIvcmV0dXJuL3NoaXBtZW50YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNyZWF0ZVN1cHBvcnRUb2tlbihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NyZWF0ZS10aWNrZXRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiByZXNwb25zZS5lcnJvcik7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBsaXN0U3VwcG9ydFRva2VuKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvbGlzdC10aWNrZXRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1cHBvcnRNZXNzYWdlQnlJRChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3N1cHBvcnQtbWVzc2FnZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgYWRkVGlja2V0TWVzc2FnZShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2FkZC10aWNrZXQtbWVzc2FnZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0V2FsbGV0RGV0YWlscyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3dhbGxldC9hbW91bnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEF1Y3Rpb25DYXJ0RGF0YShwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2F1Y3Rpb24vZGV0YWlsYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRVc2VyTm90aWZpY2F0aW9uKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvdmlldy9ub3RpZmljYXRpb25zYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRBdWN0aW9uT3JkZXJMaXN0KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYXVjdGlvbi9vcmRlci9saXN0YCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzZW5kUmVnaXN0ZXJNb2JpbGVPVFAocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZWdpc3Rlci9zZW5kL290cGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdmVyaWZ5UmVnaXN0ZXJNb2JpbGVPVFAocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9yZWdpc3Rlci92ZXJpZnkvb3RwYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyB2ZXJpZnlGb3Jnb3RPVFAocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9sb2dpbi9mb3Jnb3QvdmVyaWZ5LW90cGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxufVxyXG5cclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgQWNjb3VudFJlcG9zaXRvcnkoKTtcclxuIiwiaW1wb3J0IFJlcG9zaXRvcnksIHsgYXBpYmFzZXVybCB9IGZyb20gXCIuL1JlcG9zaXRvcnlcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyBnZXREZXZpY2VJZCwgbWFrZVBhZ2VVcmwsIG9zVHlwZSB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5cclxuY2xhc3MgSG9tZWFwaSB7XHJcbiAgYXN5bmMgZ2V0SG9tZWRhdGEocGF0aE5hbWUpIHtcclxuICAgIGxldCBwYXlsb2FkID0ge1xyXG4gICAgICBhY2Nlc3NfdG9rZW46IFwiXCIsXHJcbiAgICAgIGxhbmdfaWQ6IDEsXHJcbiAgICAgIGRldmljZV9pZDogZ2V0RGV2aWNlSWQsXHJcbiAgICAgIHBhZ2VfdXJsOiBtYWtlUGFnZVVybChcIi9cIiksXHJcbiAgICAgIG9zX3R5cGU6IG9zVHlwZSgpLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBDYW5jZWxUb2tlbiA9IGF4aW9zLkNhbmNlbFRva2VuO1xyXG4gICAgbGV0IHNvdXJjZSA9IENhbmNlbFRva2VuLnNvdXJjZSgpO1xyXG5cclxuICAgIHNvdXJjZSAmJiBzb3VyY2UuY2FuY2VsKFwiT3BlcmF0aW9uIGNhbmNlbGVkIGR1ZSB0byBuZXcgcmVxdWVzdC5cIik7XHJcbiAgICAvLyBzYXZlIHRoZSBuZXcgcmVxdWVzdCBmb3IgY2FuY2VsbGF0aW9uXHJcbiAgICBzb3VyY2UgPSBheGlvcy5DYW5jZWxUb2tlbi5zb3VyY2UoKTtcclxuXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvaG9tZWAsXHJcbiAgICAgIHBheWxvYWQsXHJcbiAgICAgIHtcclxuICAgICAgICBjYW5jZWxUb2tlbjogc291cmNlLnRva2VuLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIC8vIGNhbmNlbCB0aGUgcmVxdWVzdCAodGhlIG1lc3NhZ2UgcGFyYW1ldGVyIGlzIG9wdGlvbmFsKVxyXG4gICAgc291cmNlLmNhbmNlbChcIk9wZXJhdGlvbiBjYW5jZWxlZCBieSB0aGUgdXNlci5cIik7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdFJldmlldyhwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcG9zdC1wcm9kdWN0LXJldmlld2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdWJtaXRTZWxsZXJSZXZpZXcocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Bvc3Qtc2VsbGVyLXJldmlld2AsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG4gIC8vIGFzeW5jIGdldEhvbWVkYXRhKCkge1xyXG4gIC8vICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvc1xyXG4gIC8vICAgICAuZ2V0KGBodHRwczovL2VzdHJyYWRvd2ViLmNvbS9rYW5ndGFvL2FwaS9jdXN0b21lci9ob21lYCwge1xyXG4gIC8vICAgICAgIGhlYWRlcnM6IHtcclxuICAvLyAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gIC8vICAgICAgIH0sXHJcbiAgLy8gICAgIH0pXHJcbiAgLy8gICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuZGF0YSlcclxuICAvLyAgICAgLmNhdGNoKChlcnJvcikgPT4gZXJyb3IpO1xyXG4gIC8vICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIC8vIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IEhvbWVhcGkoKTtcclxuIiwiaW1wb3J0IHsgZ2V0RGV2aWNlSWQsIG9zVHlwZSB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5pbXBvcnQgUmVwb3NpdG9yeSwge1xyXG4gIGJhc2VVcmwsXHJcbiAgc2VyaWFsaXplUXVlcnksXHJcbiAgYXBpYmFzZXVybCxcclxuICBiYXNlUGF0aFVybCxcclxufSBmcm9tIFwiLi9SZXBvc2l0b3J5XCI7XHJcblxyXG5jbGFzcyBQcm9kdWN0UmVwb3NpdG9yeSB7XHJcbiAgYXN5bmMgZ2V0UmVjb3JkcyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChcclxuICAgICAgYCR7YmFzZVVybH0vcHJvZHVjdHM/JHtzZXJpYWxpemVRdWVyeShwYXJhbXMpfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTZWFyY2hlZFByb2R1Y3RzKHBhcmFtcykge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL3Byb2R1Y3Qtc2VhcmNoYCxcclxuICAgICAge1xyXG4gICAgICAgIGxhbmdfaWQ6IFwiXCIsXHJcbiAgICAgICAgY2F0ZWdvcnlfaWQ6IHBhcmFtcy5jYXRlZ29yeV9pZCxcclxuICAgICAgICBrZXl3b3JkOiBwYXJhbXMudGl0bGVfY29udGFpbnMsXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEubm9fb2ZfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0cyhwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWxpc3Q/cGFnZT1gICsgcGFyYW1zLnBhZ2UsXHJcbiAgICAgIHtcclxuICAgICAgICBsYW5nX2lkOiAxLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjogXCJcIixcclxuICAgICAgICBkZXZpY2VfaWQ6IGdldERldmljZUlkLFxyXG4gICAgICAgIHBhZ2VfdXJsOiBcImh0dHBzOi8vYWJjLmNvbS9wcm9kdWN0cy91cy9pbWdcIixcclxuICAgICAgICBvc190eXBlOiBcIldFQlwiLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0TmV3RGVhbHNQcm9kdWN0cyhwYXlsb2FkLCBwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWRlYWxzP3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U2hvY2tpbmdTYWxlUHJvZHVjdHMocGF5bG9hZCwgcGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZS1wcm9kdWN0cz9wYWdlPWAgKyBwYXJhbXMucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0RmVhdHVyZWRQcm9kdWN0cyhwYXlsb2FkLCBwYXJhbXMpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWZlYXR1cmVkP3BhZ2U9YCArIHBhcmFtcy5wYWdlLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnByb2R1Y3RzLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1saXN0LWZpbHRlcj9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIjIyMjIyMjIyMjIyNcIixyZXNwb25zZSlcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldE5ld0RlYWxzUHJvZHVjdHNieUZpbHRlcihwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1kZWFscz9wYWdlPWAgKyBwYXlsb2FkLnBhZ2UsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEucHJvZHVjdHMsXHJcbiAgICAgICAgICB0b3RhbEl0ZW1zOiByZXNwb25zZS5kYXRhLmRhdGEudG90YWxfcHJvZHVjdHMsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSlcclxuXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja2luZ1NhbGVQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9zaG9jay1zYWxlLXByb2R1Y3RzP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0RmVhdHVyZWRQcm9kdWN0c2J5RmlsdGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9wcm9kdWN0LWZlYXR1cmVkP3BhZ2U9YCArIHBheWxvYWQucGFnZSxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5wcm9kdWN0cyxcclxuICAgICAgICAgIHRvdGFsSXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS50b3RhbF9wcm9kdWN0cyxcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG5cclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFNob2NraW5nUHJvZHVjdHMocGFyYW1zKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZS1wcm9kdWN0cz9wYWdlPWAgKyBwYXJhbXMucGFnZVxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgaXRlbXM6IHJlc3BvbnNlLmRhdGEuZGF0YS5zaG9ja19zYWxlLFxyXG4gICAgICAgICAgdG90YWxJdGVtczogcmVzcG9uc2UuZGF0YS5kYXRhLnRvdGFsX3Byb2R1Y3RzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0QnJhbmRzKCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYnJhbmRgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RDYXRlZ29yaWVzKCkge1xyXG4gICAgLy8gY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L3Byb2R1Y3QtY2F0ZWdvcmllc2ApXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2F0LXN1YmNhdGBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRUb3RhbFJlY29yZHMoKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vcHJvZHVjdHMvY291bnRgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlJZChpZCkge1xyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLi5cIixpZClcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCBhY2Nlc3NfdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS51c2VyZGF0YS5cIix1c2VyZGF0YSlcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uMS4ucGFyc2VkYXRhXCIscGFyc2VkYXRhKVxyXG4gICAgY29uc29sZS5sb2coXCIuLi4uZGRkZGRkLi4xLmFjY2Vzc190b2tlbi5cIixhY2Nlc3NfdG9rZW4pXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuZ2V0RGV2aWNlSWQuXCIsZ2V0RGV2aWNlSWQpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5kZGRkZGQuLjEuYWNjZXNzX3Rva2VuLlwiLGFjY2Vzc190b2tlbilcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvcHJvZHVjdC1kZXRhaWxgLFxyXG4gICAgICB7XHJcbiAgICAgICAgYWNjZXNzX3Rva2VuLFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIGxhbmdfaWQ6IDEsXHJcbiAgICAgICAgZGV2aWNlX2lkOiBnZXREZXZpY2VJZCxcclxuICAgICAgICBwYWdlX3VybDogYCR7YmFzZVBhdGhVcmx9L3Byb2R1Y3QvJHtpZH1gLFxyXG4gICAgICAgIG9zX3R5cGU6IG9zVHlwZSgpLFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLi4uLmRkZGRkZC4uLi5cIixyZXNwb25zZSlcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9ja1NhbGVCeWlkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvY2stc2FsZWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUNhdGVnb3J5KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChcclxuICAgICAgYCR7YmFzZVVybH0vcHJvZHVjdC1jYXRlZ29yaWVzP3NsdWc9JHtwYXlsb2FkfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGFbMF07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeUJyYW5kKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LmdldChgJHtiYXNlVXJsfS9icmFuZHM/c2x1Zz0ke3BheWxvYWR9YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGFbMF07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFByb2R1Y3RzQnlCcmFuZHMocGF5bG9hZCkge1xyXG4gICAgbGV0IHF1ZXJ5ID0gXCJcIjtcclxuICAgIHBheWxvYWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICBpZiAocXVlcnkgPT09IFwiXCIpIHtcclxuICAgICAgICBxdWVyeSA9IGBpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBxdWVyeSA9IHF1ZXJ5ICsgYCZpZF9pbj0ke2l0ZW19YDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5nZXQoYCR7YmFzZVVybH0vYnJhbmRzPyR7cXVlcnl9YClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRQcm9kdWN0c0J5QnJhbmRzKHBheWxvYWQpIHtcclxuICAgIGxldCBxdWVyeSA9IFwiXCI7XHJcbiAgICBwYXlsb2FkLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKHF1ZXJ5ID09PSBcIlwiKSB7XHJcbiAgICAgICAgcXVlcnkgPSBgaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcXVlcnkgPSBxdWVyeSArIGAmaWRfaW49JHtpdGVtfWA7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KGAke2Jhc2VVcmx9L2JyYW5kcz8ke3F1ZXJ5fWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0UHJvZHVjdHNCeVByaWNlUmFuZ2UocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkuZ2V0KFxyXG4gICAgICBgJHtiYXNlVXJsfS9wcm9kdWN0cz8ke3NlcmlhbGl6ZVF1ZXJ5KHBheWxvYWQpfWBcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBhZGRQcm9kdWN0VG9DYXJ0KHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLi41NjU2NTY1NjU2NTY1Ni4uLlwiLHBheWxvYWQpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvYWRkLWNhcnRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuICBhc3luYyBjaGFuZ2VRdHkocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2NhcnQvY2hhbmdlLXF0eWAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBwbGFjZU9yZGVyKHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uLi4uMzMzMzMzMzMzMy4uLi4uLi5cIixwYXlsb2FkKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL3BsYWNlb3JkZXJgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2FydChwYXlsb2FkKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLi5hYWFhLi4uLlwiLHBheWxvYWQpXHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY2FydGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBkZWxldGVDYXJ0KHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9kZWxldGUtY2FydGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRBdWN0aW9uUHJvZHVjdEJ5QXVjdGlvbklkKHBheWxvYWQpIHtcclxuICAgIGNvbnN0IHJlcG9uc2UgPSBhd2FpdCBSZXBvc2l0b3J5LnBvc3QoXHJcbiAgICAgIGAke2FwaWJhc2V1cmx9L2FwaS9jdXN0b21lci9hdWN0aW9uYCxcclxuICAgICAgcGF5bG9hZFxyXG4gICAgKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnJvcikgPT4gKHsgZXJyb3I6IEpTT04uc3RyaW5naWZ5KGVycm9yKSB9KSk7XHJcbiAgICByZXR1cm4gcmVwb25zZTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNyZWF0ZUJpZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvY3JlYXRlLWJpZGAsXHJcbiAgICAgIHBheWxvYWRcclxuICAgIClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+ICh7IGVycm9yOiBKU09OLnN0cmluZ2lmeShlcnJvcikgfSkpO1xyXG4gICAgcmV0dXJuIHJlcG9uc2U7XHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTaG9wRGV0YWlsQnlJZChwYXlsb2FkKSB7XHJcbiAgICBjb25zdCByZXBvbnNlID0gYXdhaXQgUmVwb3NpdG9yeS5wb3N0KFxyXG4gICAgICBgJHthcGliYXNldXJsfS9hcGkvY3VzdG9tZXIvc2hvcC1kZXRhaWxgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0Q2hlY2tvdXRJbmZvKHBheWxvYWQpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiLi4uZ2V0Q2hlY2tvdXRJbmZvLi4uIGFweWxvYWQuLlwiLHBheWxvYWQpXHJcbiAgICBjb25zb2xlLmxvZyhcIi4uLmdldENoZWNrb3V0SW5mby4uLiBhcGliYXNldXJsLi5cIixhcGliYXNldXJsKVxyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL29yZGVyL2NoZWNrb3V0LWluZm9gLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGxhY2VBdWN0aW9uT3JkZXIocGF5bG9hZCkge1xyXG4gICAgY29uc3QgcmVwb25zZSA9IGF3YWl0IFJlcG9zaXRvcnkucG9zdChcclxuICAgICAgYCR7YXBpYmFzZXVybH0vYXBpL2N1c3RvbWVyL2F1Y3Rpb24vY2hlY2tvdXRgLFxyXG4gICAgICBwYXlsb2FkXHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiAoeyBlcnJvcjogSlNPTi5zdHJpbmdpZnkoZXJyb3IpIH0pKTtcclxuICAgIHJldHVybiByZXBvbnNlO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IFByb2R1Y3RSZXBvc2l0b3J5KCk7XHJcbiIsImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuY29uc3QgYmFzZURvbWFpbiA9IFwiaHR0cHM6Ly9iZXRhLmFwaW5vdXRoZW1lcy5jb21cIjsgLy8gQVBJIGZvciBwcm9kdWN0c1xyXG5leHBvcnQgY29uc3QgYmFzZVBvc3RVcmwgPSBcImh0dHBzOi8vYmV0YS5hcGlub3V0aGVtZXMuY29tXCI7IC8vIEFQSSBmb3IgcG9zdFxyXG5leHBvcnQgY29uc3QgYmFzZVN0b3JlVVJMID0gXCJodHRwczovL2JldGEuYXBpbm91dGhlbWVzLmNvbVwiOyAvLyBBUEkgZm9yIHZlbmRvcihzdG9yZSlcclxuXHJcbmxldCBhcGliYXNldXJsQ3VzdG9tID0gXCJodHRwczovL2Rldi1iaWdiYXNrZXQuZXN0cnJhZG93ZWIuY29tXCI7XHJcbmxldCBiYXNlUGF0aCA9IFwiaHR0cHM6Ly9kZXYta2FuZ3Rhby52ZXJjZWwuYXBwXCI7XHJcbmlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSA9PSBcInVhdC1rYW5ndGFvLnZlcmNlbC5hcHBcIikge1xyXG4gICAgYXBpYmFzZXVybEN1c3RvbSA9IFwiaHR0cHM6Ly91YXQta3QuZXN0cnJhZG93ZWIuY29tXCI7XHJcbiAgICBiYXNlUGF0aCA9IFwiaHR0cHM6Ly91YXQta2FuZ3Rhby52ZXJjZWwuYXBwXCI7XHJcbiAgfVxyXG4gIGlmICh3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUgPT0gXCJxYS1rYW5ndGFvLnZlcmNlbC5hcHBcIikge1xyXG4gICAgYXBpYmFzZXVybEN1c3RvbSA9IFwiaHR0cHM6Ly9xYS1rdC5lc3RycmFkb3dlYi5jb21cIjtcclxuICAgIGJhc2VQYXRoID0gXCJodHRwczovL3FhLWthbmd0YW8udmVyY2VsLmFwcFwiO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGFwaWJhc2V1cmwgPSBhcGliYXNldXJsQ3VzdG9tO1xyXG5leHBvcnQgY29uc3QgYmFzZVBhdGhVcmwgPSBiYXNlUGF0aDtcclxuXHJcbmV4cG9ydCBjb25zdCBjdXN0b21IZWFkZXJzID0ge1xyXG4gIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgYmFzZVVybCA9IGAke2Jhc2VEb21haW59YDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGF4aW9zLmNyZWF0ZSh7XHJcbiAgYmFzZVVybCxcclxuICBoZWFkZXJzOiBjdXN0b21IZWFkZXJzLFxyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCBzZXJpYWxpemVRdWVyeSA9IChxdWVyeSkgPT4ge1xyXG4gIHJldHVybiBPYmplY3Qua2V5cyhxdWVyeSlcclxuICAgIC5tYXAoXHJcbiAgICAgIChrZXkpID0+IGAke2VuY29kZVVSSUNvbXBvbmVudChrZXkpfT0ke2VuY29kZVVSSUNvbXBvbmVudChxdWVyeVtrZXldKX1gXHJcbiAgICApXHJcbiAgICAuam9pbihcIiZcIik7XHJcbn07XHJcbiIsImV4cG9ydCBjb25zdCBhY3Rpb25UeXBlcyA9IHtcclxuICBHRVRfQ0FSVDogXCJHRVRfQ0FSVFwiLFxyXG4gIEdFVF9DQVJUX1NVQ0NFU1M6IFwiR0VUX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIEdFVF9DQVJUX0VSUk9SOiBcIkdFVF9DQVJUX0VSUk9SXCIsXHJcblxyXG4gIEdFVF9DQVJUX1RPVEFMX1FVQU5USVRZOiBcIkdFVF9DQVJUX1RPVEFMX1FVQU5USVRZXCIsXHJcbiAgR0VUX0NBUlRfVE9UQUxfUVVBTlRJVFlfU1VDQ0VTUzogXCJHRVRfQ0FSVF9UT1RBTF9RVUFOVElUWV9TVUNDRVNTXCIsXHJcblxyXG4gIEFERF9JVEVNOiBcIkFERF9JVEVNXCIsXHJcbiAgUkVNT1ZFX0lURU06IFwiUkVNT1ZFX0lURU1cIixcclxuICBSRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXOiBcIlJFTU9WRV9QUk9EVUNUX0ZST01fQ0FSVF9ORVdcIixcclxuXHJcbiAgQ0xFQVJfQ0FSVDogXCJDTEVBUl9DQVJUXCIsXHJcbiAgQ0xFQVJfQ0FSVF9TVUNDRVNTOiBcIkNMRUFSX0NBUlRfU1VDQ0VTU1wiLFxyXG4gIENMRUFSX0NBUlRfRVJST1I6IFwiQ0xFQVJfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBJTkNSRUFTRV9RVFk6IFwiSU5DUkVBU0VfUVRZXCIsXHJcbiAgSU5DUkVBU0VfUVRZX1NVQ0NFU1M6IFwiSU5DUkVBU0VfUVRZX1NVQ0NFU1NcIixcclxuICBJTkNSRUFTRV9RVFlfRVJST1I6IFwiSU5DUkVBU0VfUVRZX0VSUk9SXCIsXHJcblxyXG4gIERFQ1JFQVNFX1FUWTogXCJERUNSRUFTRV9RVFlcIixcclxuICBVUERBVEVfQ0FSVDogXCJVUERBVEVfQ0FSVFwiLFxyXG5cclxuICBVUERBVEVfQ0FSVF9TVUNDRVNTOiBcIlVQREFURV9DQVJUX1NVQ0NFU1NcIixcclxuICBVUERBVEVfQ0FSVF9FUlJPUjogXCJVUERBVEVfQ0FSVF9FUlJPUlwiLFxyXG5cclxuICBVUERBVEVfU0VMRUNURURfQUREUkVTUzogXCJVUERBVEVfU0VMRUNURURfQUREUkVTU1wiLFxyXG5cclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSOiBcIkZFVENIX1BMQVRGT1JNX1ZPVUNIRVJcIixcclxuICBGRVRDSF9QTEFURk9STV9WT1VDSEVSX1NVQ0NFU1M6IFwiRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTXCIsXHJcblxyXG4gIFRPVEFMX0RJU0NPVU5UOiBcIlRPVEFMX0RJU0NPVU5UXCIsXHJcblxyXG4gIEFQUExJRURfU0VMTEVSX1ZPVUNIRVI6IFwiQVBQTElFRF9TRUxMRVJfVk9VQ0hFUlwiLFxyXG5cclxuICBBUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVI6IFwiQVBQTElFRF9QTEFURk9STV9WT1VDSEVSXCIsXHJcblxyXG4gIEdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUU6IFwiR1JBTkRfVE9UQUxfV0lUSF9ESVNDT1VOVF9WQUxVRVwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9ESVNDT1VOVDogXCJTRUxMRVJfV0lTRV9ESVNDT1VOVFwiLFxyXG5cclxuICBTRUxMRVJfV0lTRV9NRVNTQUdFUzogXCJTRUxMRVJfV0lTRU1FU1NBR0VTXCIsXHJcblxyXG4gIFVTRURfV0FMTEVUX0FNT1VOVDogXCJVU0VEX1dBTExFVF9BTU9VTlRcIixcclxuXHJcbiAgU0VMRUNURURfUEFZTUVOVF9PUFRJT05fQllfVVNFUjogXCJTRUxFQ1RFRF9QQVlNRU5UX09QVElPTl9CWV9VU0VSXCIsXHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlUHJvZHVjdEZyb21DYXJ0TmV3KHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5SRU1PVkVfUFJPRFVDVF9GUk9NX0NBUlRfTkVXLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxlY3RlZFBheW1lbnRPcHRpb24ocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTEVDVEVEX1BBWU1FTlRfT1BUSU9OX0JZX1VTRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNlbGxlcldpc2VNZXNzYWdlKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5TRUxMRVJfV0lTRV9NRVNTQUdFUywgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlZFdhbGxldEFtb3VudChwYXlsb2FkKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuVVNFRF9XQUxMRVRfQU1PVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZWxsZXJXaXNlRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlNFTExFUl9XSVNFX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBncmFuZFRvdGFsV2l0aERpc2NvdW50VmFsdWUocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkdSQU5EX1RPVEFMX1dJVEhfRElTQ09VTlRfVkFMVUUsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGFwcGxpZWRTZWxsZXJWb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1NFTExFUl9WT1VDSEVSLCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhcHBsaWVkUGxhdGZvcm1Wb3VjaGVyKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BUFBMSUVEX1BMQVRGT1JNX1ZPVUNIRVIsIHBheWxvYWQgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvdGFsRGlzY291bnQocGF5bG9hZCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLlRPVEFMX0RJU0NPVU5ULCBwYXlsb2FkIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmZXRjaFBsYXRmb3JtVm91Y2hlckFjdGlvbigpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUixcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hQbGF0Zm9ybVZvdWNoZXJBY3Rpb25TdWNjZXNzKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuRkVUQ0hfUExBVEZPUk1fVk9VQ0hFUl9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydCgpIHtcclxuICBhbGVydChcImdldENhcnRcIilcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5HRVRfQ0FSVCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydFN1Y2Nlc3MocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5HRVRfQ0FSVF9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2FydEVycm9yKGVycm9yKSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIHR5cGU6IGFjdGlvblR5cGVzLkdFVF9DQVJUX0VSUk9SLFxyXG4gICAgZXJyb3IsXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVNlbGVjdGVkQWRkcmVzcyhwYXlsb2FkKSB7XHJcbiAgYWxlcnQoXCJjYWxsXCIpXHJcbiAgY29uc29sZS5sb2coXCIuLjU1NTU1NS4uLi5cIixwYXlsb2FkKVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX1NFTEVDVEVEX0FERFJFU1MsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhZGRJdGVtKHBheWxvYWQpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5BRERfSVRFTSwgcGF5bG9hZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlSXRlbShwcm9kdWN0KSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuUkVNT1ZFX0lURU0sIHByb2R1Y3QgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluY3JlYXNlSXRlbVF0eShwcm9kdWN0KSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuSU5DUkVBU0VfUVRZLCBwcm9kdWN0IH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZWNyZWFzZUl0ZW1RdHkocHJvZHVjdCkge1xyXG4gIHJldHVybiB7IHR5cGU6IGFjdGlvblR5cGVzLkRFQ1JFQVNFX1FUWSwgcHJvZHVjdCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2FydFN1Y2Nlc3MocGF5bG9hZCkge1xyXG4gIHJldHVybiB7XHJcbiAgICB0eXBlOiBhY3Rpb25UeXBlcy5VUERBVEVfQ0FSVF9TVUNDRVNTLFxyXG4gICAgcGF5bG9hZCxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2FydEVycm9yKHBheWxvYWQpIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHlwZTogYWN0aW9uVHlwZXMuVVBEQVRFX0NBUlRfRVJST1IsXHJcbiAgICBwYXlsb2FkLFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjbGVhckNhcnQoKSB7XHJcbiAgcmV0dXJuIHsgdHlwZTogYWN0aW9uVHlwZXMuQ0xFQVJfQ0FSVCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJDYXJ0U3VjY2VzcygpIHtcclxuICByZXR1cm4geyB0eXBlOiBhY3Rpb25UeXBlcy5DTEVBUl9DQVJUX1NVQ0NFU1MgfTtcclxufVxyXG4iLCIvKlxyXG4gKiBSZWFjdCB0ZW1wbGF0ZSBoZWxwZXJzXHJcbiAqIEF1dGhvcjogTm91dGhlbWVzXHJcbiAqIERldmVsb3BlZDogZGlhcnlmb3JsaWZlXHJcbiAqICovXHJcblxyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMYXp5TG9hZCBmcm9tIFwicmVhY3QtbGF6eWxvYWRcIjtcclxuaW1wb3J0IHsgYmFzZVVybCB9IGZyb20gXCJ+L3JlcG9zaXRvcmllcy9SZXBvc2l0b3J5XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuXHJcbmNvbnN0IGV4YWN0TWF0aCA9IHJlcXVpcmUoXCJleGFjdC1tYXRoXCIpO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJvdXRlV2l0aG91dFJlZnJlc2gocm91dGVMaW5rKSB7XHJcbiAgUm91dGVyLnJlcGxhY2Uocm91dGVMaW5rLCB1bmRlZmluZWQsIHtcclxuICAgIHNoYWxsb3c6IHRydWUsXHJcbiAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBob21lUGFnZVByb2R1Y3RQcmljZUhlbHBlcihwcm9kdWN0KSB7XHJcbiAgaWYgKHByb2R1Y3Qub2ZmZXJfcHJpY2UgIT09IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBvZmZlclwiPlxyXG4gICAgICAgIFJNIHtwcm9kdWN0Lm9mZmVyX3ByaWNlID8gcHJvZHVjdC5vZmZlcl9wcmljZSA6IDB9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICBSTSB7cHJvZHVjdC5hY3R1YWxfcHJpY2UgPyBwcm9kdWN0LmFjdHVhbF9wcmljZSA6IDB9XHJcbiAgICAgICAgPC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIGlmIChwcm9kdWN0LnNob2NrX3NhbGVfcHJpY2UgIT09IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBvZmZlclwiPlxyXG4gICAgICAgIFJNIHtwcm9kdWN0LnNob2NrX3NhbGVfcHJpY2V9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICBSTSB7cHJvZHVjdC5hY3R1YWxfcHJpY2UgPyBwcm9kdWN0LmFjdHVhbF9wcmljZSA6IDB9XHJcbiAgICAgICAgPC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIGlmIChwcm9kdWN0LnNhbGVfcHJpY2UgIT09IGZhbHNlKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZSBvZmZlclwiPlxyXG4gICAgICAgIFJNIHtwcm9kdWN0LnNhbGVfcHJpY2V9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+XHJcbiAgICAgICAgICBSTSB7cHJvZHVjdC5hY3R1YWxfcHJpY2UgPyBwcm9kdWN0LmFjdHVhbF9wcmljZSA6IDB9XHJcbiAgICAgICAgPC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICBSTSB7cHJvZHVjdC5hY3R1YWxfcHJpY2UgPyBwcm9kdWN0LmFjdHVhbF9wcmljZSA6IDB9XHJcbiAgICA8L3A+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJldHVyblRvdGFsT2ZDYXJ0VmFsdWUocHJvZHVjdHMpIHtcclxuICBsZXQgY2FydF90b3RhbF9wcmljZSA9IHByb2R1Y3RzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgTnVtYmVyKHByaWNlSGVscGVyKHByZXYpKSArXHJcbiAgICAgIE51bWJlcihcclxuICAgICAgICBwcmljZUhlbHBlcihcclxuICAgICAgICAgIG5leHQudG90YWxfZGlzY291bnRfcHJpY2UgPT0gMFxyXG4gICAgICAgICAgICA/IG5leHQudG90YWxfYWN0dWFsX3ByaWNlXHJcbiAgICAgICAgICAgIDogbmV4dC50b3RhbF9kaXNjb3VudF9wcmljZVxyXG4gICAgICAgIClcclxuICAgICAgKVxyXG4gICAgKTtcclxuICB9LCAwKTtcclxuXHJcbiAgcmV0dXJuIGNhcnRfdG90YWxfcHJpY2U7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZXR1cm5Ub3RhbENvbW1pc3Npb24ocHJvZHVjdHMpIHtcclxuICBsZXQgY2FydF90b3RhbF9jb21taXNzaW9uID0gcHJvZHVjdHMucmVkdWNlKChwcmV2LCBuZXh0KSA9PiB7XHJcbiAgICByZXR1cm4gTnVtYmVyKHByaWNlSGVscGVyKHByZXYpKSArIE51bWJlcihwcmljZUhlbHBlcihuZXh0LmNvbW1pc3Npb24pKTtcclxuICB9LCAwKTtcclxuXHJcbiAgcmV0dXJuIGNhcnRfdG90YWxfY29tbWlzc2lvbjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJldHVyblRvdGFsT2ZDYXJ0VGF4VmFsdWUocHJvZHVjdHMpIHtcclxuICBsZXQgY2FydF90b3RhbF90YXggPSBwcm9kdWN0cy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIE51bWJlcihwcmljZUhlbHBlcihwcmV2KSkgKyBOdW1iZXIocHJpY2VIZWxwZXIobmV4dC50b3RhbF90YXhfdmFsdWUpKVxyXG4gICAgKTtcclxuICB9LCAwKTtcclxuXHJcbiAgcmV0dXJuIGNhcnRfdG90YWxfdGF4O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcHJpY2VIZWxwZXIobnVtKSB7XHJcbiAgbGV0IG51bWJlckFycmF5ID0gbnVtPy50b1N0cmluZygpLnNwbGl0KFwiLFwiKTtcclxuICBpZiAobnVtYmVyQXJyYXkgJiYgbnVtYmVyQXJyYXk/Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiBudW1iZXJBcnJheS5yZWR1Y2UoKHByZXYsIG5leHQpID0+IHByZXYgKyBuZXh0KTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIDA7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0KGN1cnJlbmN5VmFsKSB7XHJcbiAgcmV0dXJuIG5ldyBJbnRsLk51bWJlckZvcm1hdChcIm1zLU1ZXCIsIHtcclxuICAgIHN0eWxlOiBcImN1cnJlbmN5XCIsXHJcbiAgICBjdXJyZW5jeTogXCJNWVJcIixcclxuICB9KS5mb3JtYXQocHJpY2VIZWxwZXIoY3VycmVuY3lWYWwpKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG1hdGhGb3JtdWxhKGZvcm11bGFUZXh0KSB7XHJcbiAgbGV0IHJlc3VsdCA9IGV4YWN0TWF0aC5mb3JtdWxhKGZvcm11bGFUZXh0KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRpdkN1cnJlbmN5KGZpcnN0VmFsLCBzZWNvbmRWYWwpIHtcclxuICBsZXQgZGl2RGF0YSA9IGV4YWN0TWF0aC5kaXYoXHJcbiAgICBwcmljZUhlbHBlcihmaXJzdFZhbCB8fCAwKSxcclxuICAgIHByaWNlSGVscGVyKHNlY29uZFZhbCB8fCAxKVxyXG4gICk7XHJcbiAgcmV0dXJuIGRpdkRhdGE7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBtdWxDdXJyZW5jeShmaXJzdFZhbCwgc2Vjb25kVmFsKSB7XHJcbiAgbGV0IG11bERhdGEgPSBleGFjdE1hdGgubXVsKFxyXG4gICAgcHJpY2VIZWxwZXIoZmlyc3RWYWwgfHwgMSksXHJcbiAgICBwcmljZUhlbHBlcihzZWNvbmRWYWwgfHwgMSlcclxuICApO1xyXG4gIHJldHVybiBtdWxEYXRhO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gYWRkQ3VycmVuY3koY3VycmVuY3lWYWxGaXJzdCwgY3VycmVuY3lWYWxTZWNvbmQpIHtcclxuICBsZXQgYWRkRGF0YSA9IGV4YWN0TWF0aC5hZGQoXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbEZpcnN0IHx8IDApLFxyXG4gICAgcHJpY2VIZWxwZXIoY3VycmVuY3lWYWxTZWNvbmQgfHwgMClcclxuICApO1xyXG5cclxuICByZXR1cm4gYWRkRGF0YTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc3ViQ3VycmVuY3koY3VycmVuY3lWYWxGaXJzdCwgY3VycmVuY3lWYWxTZWNvbmQpIHtcclxuICBsZXQgc3ViRGF0YSA9IGV4YWN0TWF0aC5zdWIoXHJcbiAgICBwcmljZUhlbHBlcihjdXJyZW5jeVZhbEZpcnN0IHx8IDApLFxyXG4gICAgcHJpY2VIZWxwZXIoY3VycmVuY3lWYWxTZWNvbmQgfHwgMClcclxuICApO1xyXG5cclxuICByZXR1cm4gc3ViRGF0YTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdEN1cnJlbmN5KG51bSkge1xyXG4gIGlmIChudW0gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIHBhcnNlRmxvYXQobnVtKVxyXG4gICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAucmVwbGFjZSgvKFxcZCkoPz0oXFxkezN9KSsoPyFcXGQpKS9nLCBcIiQxLFwiKTtcclxuICB9IGVsc2Uge1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbGxldGlvbkJ5U2x1Zyhjb2xsZWN0aW9ucywgc2x1Zykge1xyXG4gIGlmIChjb2xsZWN0aW9ucy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBjb2xsZWN0aW9ucy5maW5kKChpdGVtKSA9PiBpdGVtLnNsdWcgPT09IHNsdWcudG9TdHJpbmcoKSk7XHJcbiAgICBpZiAocmVzdWx0ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgcmV0dXJuIHJlc3VsdC5wcm9kdWN0cztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIFtdO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldEl0ZW1CeVNsdWcoYmFubmVycywgc2x1Zykge1xyXG4gIGlmIChiYW5uZXJzLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IGJhbm5lciA9IGJhbm5lcnMuZmluZCgoaXRlbSkgPT4gaXRlbS5zbHVnID09PSBzbHVnLnRvU3RyaW5nKCkpO1xyXG4gICAgaWYgKGJhbm5lciAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHJldHVybiBiYW5uZXI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gY29udmVydFNsdWdzUXVlcnlTdHJpbmcocGF5bG9hZCkge1xyXG4gIGxldCBxdWVyeSA9IFwiXCI7XHJcbiAgaWYgKHBheWxvYWQubGVuZ3RoID4gMCkge1xyXG4gICAgcGF5bG9hZC5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICAgIGlmIChxdWVyeSA9PT0gXCJcIikge1xyXG4gICAgICAgIHF1ZXJ5ID0gYHNsdWdfaW49JHtpdGVtfWA7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcXVlcnkgPSBxdWVyeSArIGAmc2x1Z19pbj0ke2l0ZW19YDtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJldHVybiBxdWVyeTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RCYWRnZShwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuYmFkZ2UgJiYgcHJvZHVjdC5iYWRnZSAhPT0gbnVsbCkge1xyXG4gICAgdmlldyA9IHByb2R1Y3QuYmFkZ2UubWFwKChiYWRnZSkgPT4ge1xyXG4gICAgICBpZiAoYmFkZ2UudHlwZSA9PT0gXCJzYWxlXCIpIHtcclxuICAgICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19iYWRnZVwiPntiYWRnZS52YWx1ZX08L2Rpdj47XHJcbiAgICAgIH0gZWxzZSBpZiAoYmFkZ2UudHlwZSA9PT0gXCJvdXRTdG9ja1wiKSB7XHJcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fYmFkZ2Ugb3V0LXN0b2NrXCI+e2JhZGdlLnZhbHVlfTwvZGl2PjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19iYWRnZSBob3RcIj57YmFkZ2UudmFsdWV9PC9kaXY+O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2UocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG4gIGlmIChwcm9kdWN0LmlzX3NhbGUgPT09IHRydWUpIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIHNhbGVcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+Uk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Quc2FsZV9wcmljZSl9PC9kZWw+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+Uk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QucHJpY2UpfTwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlX05ldyhwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3Quc2FsZV9wcmljZSAhPT0gZmFsc2UpIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIHNhbGVcIj5cclxuICAgICAgICBSTSB7cHJvZHVjdC5zYWxlX3ByaWNlfVxyXG4gICAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlJNIHtwcm9kdWN0LmFjdHVhbF9wcmljZX08L2RlbD5cclxuICAgICAgPC9wPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlXCI+Uk0ge3Byb2R1Y3QuYWN0dWFsX3ByaWNlfTwvcD47XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZmVhdHVyZXByb2R1Y3RwcmljZShwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcbiAgaWYgKHByb2R1Y3QuaXNfc2FsZSA9PT0gdHJ1ZSkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlKX17XCIgXCJ9XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGluLXByZHRcIj5cclxuICAgICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LmFjdHVhbF9wcmljZSl9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnNhbGVfcHJpY2UpfXtcIiBcIn1cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsaW4tcHJkdFwiPlxyXG4gICAgICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3QuYWN0dWFsX3ByaWNlKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvcD5cclxuICAgICk7XHJcbiAgfVxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU3RyYXBpUHJvZHVjdFByaWNlRXhwYW5kZWQocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG4gIGlmIChwcm9kdWN0LmlzX3NhbGUgPT09IHRydWUpIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX3ByaWNlIHNhbGVcIj5cclxuICAgICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5wcmljZSl9XHJcbiAgICAgICAgPGRlbCBjbGFzc05hbWU9XCJtbC0yXCI+Uk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Quc2FsZV9wcmljZSl9PC9kZWw+XHJcbiAgICAgICAgPHNtYWxsPjE4JSBvZmY8L3NtYWxsPlxyXG4gICAgICA8L3A+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlKX08L3A+XHJcbiAgICApO1xyXG4gIH1cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RQcmljZUV4cGFuZGVkT3RoZXIocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICB2aWV3ID0gKFxyXG4gICAgPHAgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fcHJpY2VcIj5cclxuICAgICAgUk0ge2Zvcm1hdEN1cnJlbmN5KHByb2R1Y3Qub2ZmZXJfcHJpY2UgPyBwcm9kdWN0Lm9mZmVyX3ByaWNlIDogMCl9XHJcbiAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LmFjdHVhbF9wcmljZSA/IHByb2R1Y3QuYWN0dWFsX3ByaWNlIDogMCl9XHJcbiAgICAgIDwvZGVsPlxyXG4gICAgICA8c21hbGw+e3Byb2R1Y3Qub2ZmZXIgPyBwcm9kdWN0Lm9mZmVyIDogMH08L3NtYWxsPlxyXG4gICAgPC9wPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiB2aWV3O1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0UHJpY2VFeHBhbmRlZE90aGVyMShwcm9kdWN0KSB7XHJcbiAgbGV0IHZpZXc7XHJcblxyXG4gIHZpZXcgPSAoXHJcbiAgICA8cCBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19wcmljZVwiPlxyXG4gICAgICBSTSB7Zm9ybWF0Q3VycmVuY3kocHJvZHVjdC5zYWxlX3ByaWNlID8gcHJvZHVjdC5zYWxlX3ByaWNlIDogMCl9XHJcbiAgICAgIDxkZWwgY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgIFJNIHtmb3JtYXRDdXJyZW5jeShwcm9kdWN0LnByaWNlID8gcHJvZHVjdC5wcmljZSA6IDApfVxyXG4gICAgICA8L2RlbD5cclxuICAgICAgPHNtYWxsPntwcm9kdWN0Lm9mZmVyID8gcHJvZHVjdC5vZmZlciA6IDB9PC9zbWFsbD5cclxuICAgIDwvcD5cclxuICApO1xyXG5cclxuICByZXR1cm4gdmlldztcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0cmFwaVByb2R1Y3RUaHVtYm5haWwocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICBpZiAocHJvZHVjdC50aHVtYm5haWwpIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtgJHtiYXNlVXJsfSR7cHJvZHVjdC50aHVtYm5haWwudXJsfWB9XHJcbiAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0LnRpdGxlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9MYXp5TG9hZD5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvTGluaz5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHZpZXcgPSAoXHJcbiAgICAgIDxMaW5rIGhyZWY9XCIvcHJvZHVjdC9bcGlkXVwiIGFzPXtgL3Byb2R1Y3QvJHtwcm9kdWN0LmlkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIiBhbHQ9XCJLYW5ndGFvXCIgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0VGh1bWJuYWlsT3RoZXIocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICBpZiAocHJvZHVjdC5pbWFnZS5sZW5ndGggPiAwKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9XHJcbiAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0LnByb2R1Y3RfbmFtZX1cclxuICAgICAgICAgICAgICB3aWR0aD1cIjMwMHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCIyMDBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIlxyXG4gICAgICAgICAgICAgIGFsdD1cIkthbmd0YW9cIlxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTdHJhcGlQcm9kdWN0VGh1bWJuYWlsRGV0YWlsKHByb2R1Y3QpIHtcclxuICBsZXQgdmlldztcclxuXHJcbiAgaWYgKHByb2R1Y3QuaW1hZ2UubGVuZ3RoID4gMCkge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17cHJvZHVjdD8uaW1hZ2VbMF0/LmltYWdlfVxyXG4gICAgICAgICAgICAgIGFsdD17cHJvZHVjdC5wcm9kdWN0X25hbWV9XHJcbiAgICAgICAgICAgICAgd2lkdGg9XCI1MHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCI1MHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiL3N0YXRpYy9pbWcvbm90LWZvdW5kLmpwZ1wiXHJcbiAgICAgICAgICAgICAgYWx0PVwiS2FuZ3Rhb1wiXHJcbiAgICAgICAgICAgICAgd2lkdGg9XCI1MHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCI1MHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTaG9ja2luZ3Byb2R1Y3R0aHVtYm5haWwocHJvZHVjdCkge1xyXG4gIGxldCB2aWV3O1xyXG5cclxuICBpZiAocHJvZHVjdC5pbWFnZS5sZW5ndGggPiAwKSB7XHJcbiAgICB2aWV3ID0gKFxyXG4gICAgICA8TGluayBocmVmPVwiL3Byb2R1Y3QvW3BpZF1cIiBhcz17YC9wcm9kdWN0LyR7cHJvZHVjdC5wcm9kdWN0X2lkfWB9PlxyXG4gICAgICAgIDxhPlxyXG4gICAgICAgICAgPExhenlMb2FkPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtwcm9kdWN0Py5pbWFnZVswXT8uaW1hZ2V9XHJcbiAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0LnByb2R1Y3RfbmFtZX1cclxuICAgICAgICAgICAgICB3aWR0aD1cIjMwMHB4XCJcclxuICAgICAgICAgICAgICBoZWlnaHQ9XCIyMDBweFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0xhenlMb2FkPlxyXG4gICAgICAgIDwvYT5cclxuICAgICAgPC9MaW5rPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgdmlldyA9IChcclxuICAgICAgPExpbmsgaHJlZj1cIi9wcm9kdWN0L1twaWRdXCIgYXM9e2AvcHJvZHVjdC8ke3Byb2R1Y3QucHJvZHVjdF9pZH1gfT5cclxuICAgICAgICA8YT5cclxuICAgICAgICAgIDxMYXp5TG9hZD5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz1cIi9zdGF0aWMvaW1nL25vdC1mb3VuZC5qcGdcIlxyXG4gICAgICAgICAgICAgIGFsdD1cIkthbmd0YW9cIlxyXG4gICAgICAgICAgICAgIHdpZHRoPVwiMzAwcHhcIlxyXG4gICAgICAgICAgICAgIGhlaWdodD1cIjIwMHB4XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvTGF6eUxvYWQ+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICA8L0xpbms+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHZpZXc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjb2xvckhlbHBlcigpIHtcclxuICBjb25zb2xlLmxvZyhcImhlbGxvXCIpO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=