webpackHotUpdate_N_E("pages/index",{

/***/ "./components/elements/detail/modules/ModuleDetailActionsMobile.jsx":
/*!**************************************************************************!*\
  !*** ./components/elements/detail/modules/ModuleDetailActionsMobile.jsx ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/utilities/common-helpers */ "./utilities/common-helpers.js");



var _jsxFileName = "E:\\bigBasket\\components\\elements\\detail\\modules\\ModuleDetailActionsMobile.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }









const ModuleDetailActionsMobile = ({
  product
}) => {
  _s();

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"])();
  const Router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();
  const {
    0: loading1,
    1: setLoading1
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading2,
    1: setLoading2
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading3,
    1: setLoading3
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"])(state => state.auth);
  const {
    productQuantity,
    productIdOfConfig,
    out_of_stock_selling,
    stock
  } = Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"])(state => state.product);

  const handleAddItemToCart = async e => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please login first");
      return false;
    } else if (product.product.product_type == "config" && (productIdOfConfig == 0 || productIdOfConfig == null || productIdOfConfig == undefined)) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please Select Varient");
      return false;
    } else {
      var _payload;

      setLoading1(true);
      let payload = {
        user_id: 1,
        quantity: productQuantity || 1,
        cart_type: "web",
        access_token: token
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: productIdOfConfig
        });

        if (out_of_stock_selling === false && stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      }

      const responseData = ((_payload = payload) === null || _payload === void 0 ? void 0 : _payload.access_token) && (await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToCart(payload));

      if (responseData && responseData.httpcode == "200") {
        dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_3__["getCart"])());
        setLoading1(false);
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])(responseData.status, responseData.status, responseData.response);
      } else if (responseData && responseData.httpcode == 400) {
        let error = responseData.errors;

        for (const [key, value] of Object.entries(error)) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "", value, 2);
        }
      } else {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", responseData.message);
        setLoading1(false);
      }
    }

    return false;
  };

  const handleBuynow = async e => {
    if (auth.isLoggedIn !== true) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please login first");
      return false;
    } else if (product.product.product_type == "config" && (productIdOfConfig == 0 || productIdOfConfig == null || productIdOfConfig == undefined)) {
      Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Please Select Varient");
      return false;
    } else {
      setLoading2(true);
      let payload = {
        user_id: 1,
        quantity: productQuantity || 1,
        access_token: auth.access_token,
        cart_type: "web"
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: productIdOfConfig
        });

        if (out_of_stock_selling === false && stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", "Product Out of Stock!");
          setLoading2(false);
          return false;
        }
      }

      const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_6__["default"].addProductToCart(payload);

      if (responseData.httpcode == 200) {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])(responseData.status, responseData.status, responseData.response);
        setTimeout(function () {
          Router.push("/account/checkout");
        }, 1000);
        setLoading2(false);
        return false;
      } else {
        Object(_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_7__["displayNotification"])("error", "Error", responseData.message);
        setLoading2(false);
        return false;
      }
    }

    return false;
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ps-product__actions-mobile",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "ps-btn ps-btn--black",
      onClick: e => handleAddItemToCart(e),
      children: "Add to cart"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 175,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
      className: "ps-btn",
      onClick: e => handleBuynow(e),
      children: "Buy Now"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 181,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 174,
    columnNumber: 5
  }, undefined);
};

_s(ModuleDetailActionsMobile, "JBJhYokuiu19kou1mDKh33i5BTM=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_4__["useDispatch"], next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_4__["useSelector"]];
});

_c = ModuleDetailActionsMobile;
/* harmony default export */ __webpack_exports__["default"] = (ModuleDetailActionsMobile);

var _c;

$RefreshReg$(_c, "ModuleDetailActionsMobile");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/elements/detail/modules/ModuleDetailShoppingActions.jsx":
/*!****************************************************************************!*\
  !*** ./components/elements/detail/modules/ModuleDetailShoppingActions.jsx ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons */ "./node_modules/@material-ui/icons/esm/index.js");
/* harmony import */ var _store_product_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/store/product/action */ "./store/product/action.js");
/* harmony import */ var _store_cart_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/store/cart/action */ "./store/cart/action.js");
/* harmony import */ var _store_compare_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/store/compare/action */ "./store/compare/action.js");
/* harmony import */ var _store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/store/wishlist/action */ "./store/wishlist/action.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/repositories/ProductRepository */ "./repositories/ProductRepository.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _ModuleDetailProductGroup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ModuleDetailProductGroup */ "./components/elements/detail/modules/ModuleDetailProductGroup.jsx");
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/utilities/product-helper */ "./utilities/product-helper.js");




var _jsxFileName = "E:\\bigBasket\\components\\elements\\detail\\modules\\ModuleDetailShoppingActions.jsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_bigBasket_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }
















const ModuleDetailShoppingActions = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.memo(_c = _s(({
  product,
  extended = false,
  shockingsale = false
}) => {
  _s();

  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["useDispatch"])();
  const {
    0: quantity,
    1: setQuantity
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(1);
  const {
    0: wishlistFromServer,
    1: setWishlistFromServer
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const Router = Object(next_router__WEBPACK_IMPORTED_MODULE_9__["useRouter"])();
  const {
    0: loading1,
    1: setLoading1
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading2,
    1: setLoading2
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: loading3,
    1: setLoading3
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const auth = Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["useSelector"])(state => state.auth);

  const handleAddItemToCart = async e => {
    var _product$product;

    console.log("...111.....");
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;
    console.log("...111..userdata...", userdata);
    console.log("...111...parsedata..", parsedata);
    console.log("...111..token...", token);

    if (userdata === undefined || userdata === null) {
      console.log("...111...222..");
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else if ((product === null || product === void 0 ? void 0 : (_product$product = product.product) === null || _product$product === void 0 ? void 0 : _product$product.product_type) == "config" && (filterAssocProd.assocValSel == "" || filterAssocProd.assocValSizeSel == "")) {
      console.log("...111...555..");
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please Select Varient",
        duration: 1
      });
      return false;
    } else {
      var _product$product2, _payload;

      console.log("...111..666...");
      setLoading1(true);
      let payload = {
        // user_id: 1,
        prd_assign_id: "",
        quantity: quantity,
        cart_type: "web",
        access_token: token
      };
      console.log("...111..777...");

      if ((product === null || product === void 0 ? void 0 : (_product$product2 = product.product) === null || _product$product2 === void 0 ? void 0 : _product$product2.product_type) == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: getProductId(filterAssocProd.assocValSizeSel)
        });
        const {
          out_of_stock_selling,
          stock
        } = getOutOfstockValueConfigProd(filterAssocProd.assocValSizeSel);

        if (out_of_stock_selling === false && stock <= 0) {
          console.log("...111..8888...");
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading1(false);
          return false;
        } //condition for config end

      } else {
        console.log("...111...999..");
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          console.log("...111..1111222...");
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading1(false);
          return false;
        }
      }

      const responseData = ((_payload = payload) === null || _payload === void 0 ? void 0 : _payload.access_token) && (await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__["default"].addProductToCart(payload));

      if (responseData && responseData.httpcode == "200") {
        let tmp = product;
        tmp.quantity = quantity; // dispatch(addItem(tmp));

        dispatch(Object(_store_cart_action__WEBPACK_IMPORTED_MODULE_5__["getCart"])());
        setLoading1(false);
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"][responseData.status]({
          message: responseData.message,
          description: responseData.response,
          duration: 1
        });
        setTimeout(function () {
          Router.push("/account/shopping-cart");
        }, 200);
      } else {
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
          message: "Error",
          description: responseData.message,
          duration: 1
        });
        setLoading1(false);
      }
    }
  };

  const handleBuynow = async e => {
    if (auth.isLoggedIn !== true) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else if (product.product.product_type == "config" && (filterAssocProd.assocValSel == "" || filterAssocProd.assocValSizeSel == "")) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please Select Varient",
        duration: 1
      });
      return false;
    } else {
      setLoading2(true);
      let payload = {
        // user_id: 1,
        prd_assign_id: "",
        quantity: quantity,
        access_token: auth.access_token,
        cart_type: "web"
      };

      if (product.product.product_type == "config") {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: getProductId(filterAssocProd.assocValSizeSel)
        });
        const {
          out_of_stock_selling,
          stock
        } = getOutOfstockValueConfigProd(filterAssocProd.assocValSizeSel);

        if (out_of_stock_selling === false && stock <= 0) {
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading2(false);
          return false;
        }
      } else {
        payload = _objectSpread(_objectSpread({}, payload), {}, {
          product_id: product.product.product_id
        });

        if (product.product.out_of_stock_selling === false && product.product.stock <= 0) {
          antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
            message: "Error",
            description: "Product Out of Stock!",
            duration: 2
          });
          setLoading2(false);
          return false;
        }
      }

      const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_10__["default"].addProductToCart(payload);

      if (responseData.httpcode == 200) {
        let tmp = product;
        tmp.quantity = quantity;
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"][responseData.status]({
          description: responseData.response,
          duration: 1
        }); // dispatch(addItem(tmp));

        setTimeout(function () {
          Router.push("/account/checkout");
        }, 1000);
        setLoading2(false);
      } else {
        antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
          message: "Error",
          description: responseData.message,
          duration: 1
        });
        setLoading2(false);
      }
    }
  };

  const handleAddItemToCompare = e => {
    dispatch(Object(_store_compare_action__WEBPACK_IMPORTED_MODULE_6__["addItemToCompare"])(product));
  };

  const handleAddItemToWishlist = async e => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      if (shockingsale == true) {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["addShockingSaleItemToWishlist"])(product.product.product_id));
      } else {
        console.log("lllll..........ll....", product.product.product_id);
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["addItemToWishlist"])(product.product.product_id));
      }
    }
  };

  const handleRemoveWishListItem = () => {
    let userdata = localStorage.getItem("user");
    let parsedata = JSON.parse(userdata);
    let token = parsedata === null || parsedata === void 0 ? void 0 : parsedata.access_token;

    if (userdata === undefined || userdata === null) {
      antd__WEBPACK_IMPORTED_MODULE_11__["notification"]["error"]({
        message: "Error",
        description: "Please login first",
        duration: 1
      });
      return false;
    } else {
      if (shockingsale == true) {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["removeShockingSaleItemFromWishlist"])(product.product.product_id));
      } else {
        dispatch(Object(_store_wishlist_action__WEBPACK_IMPORTED_MODULE_7__["removeWishlistItem"])(product.product.product_id));
      }
    }
  };

  const handleIncreaseItemQty = e => {
    setQuantity(quantity + 1);
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setProductQuantityAction"])(quantity + 1));
  };

  const handleDecreaseItemQty = e => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
      dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setProductQuantityAction"])(quantity - 1));
    }
  };

  const {
    0: associativeProd,
    1: setAssociativeProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const {
    0: uniqueAssociativeProd,
    1: setUniqueAssociativeProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
  const {
    0: filterAssocProd,
    1: setFilterAssocProd
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    assocVal: "",
    assocValSel: "",
    assocValSize: "",
    assocValSizeSel: "",
    assocProdId: ""
  });
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    var _product$associative_;

    setAssociativeProd(product === null || product === void 0 ? void 0 : product.associative_products);
    let arrayVals = [...new Map(product === null || product === void 0 ? void 0 : (_product$associative_ = product.associative_products) === null || _product$associative_ === void 0 ? void 0 : _product$associative_.map(item => [item["attr_value"], item])).values()];
    setUniqueAssociativeProd(arrayVals);
  }, [product]);

  const handleChangeAttr = e => {
    setFilterAssocProd(_objectSpread(_objectSpread({}, filterAssocProd), {}, {
      assocValSel: e.target.value
    }));
    setTimeout(() => {
      getProductId(filterAssocProd.assocValSizeSel);
    }, 1000);
  };

  const handleChangeAttrSize = e => {
    setFilterAssocProd(_objectSpread(_objectSpread({}, filterAssocProd), {}, {
      assocValSizeSel: e.target.value
    }));
    setTimeout(() => {
      getProductId(e.target.value);
    }, 1000);
  };

  const renderAssociativeProduct = () => {
    var _associativeProd$, _associativeProd$2, _associativeProd$2$su, _associativeProd$filt, _associativeProd$filt2;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__groupped",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("table", {
        className: "table table-borderless",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tbody", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: (_associativeProd$ = associativeProd[0]) === null || _associativeProd$ === void 0 ? void 0 : _associativeProd$.attr_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 360,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Group, {
                size: "large",
                className: "ml-4",
                onChange: handleChangeAttr,
                defaultValue: filterAssocProd === null || filterAssocProd === void 0 ? void 0 : filterAssocProd.assocVal,
                children: uniqueAssociativeProd === null || uniqueAssociativeProd === void 0 ? void 0 : uniqueAssociativeProd.map((attr, index) => {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Button, {
                    value: attr.attr_value,
                    className: "mr-2",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Avatar"], {
                      src: attr.image
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 383,
                      columnNumber: 27
                    }, undefined)
                  }, index, false, {
                    fileName: _jsxFileName,
                    lineNumber: 378,
                    columnNumber: 25
                  }, undefined);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 370,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 369,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 359,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 391,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 390,
            columnNumber: 15
          }, undefined), filterAssocProd.assocValSel ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: (_associativeProd$2 = associativeProd[0]) === null || _associativeProd$2 === void 0 ? void 0 : (_associativeProd$2$su = _associativeProd$2.sub_attributes[0]) === null || _associativeProd$2$su === void 0 ? void 0 : _associativeProd$2$su.attr_name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 395,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Group, {
                size: "large",
                className: "ml-4",
                onChange: handleChangeAttrSize,
                children: associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt = associativeProd.filter(prod => prod.attr_value.toLowerCase() === filterAssocProd.assocValSel.toLowerCase())) === null || _associativeProd$filt === void 0 ? void 0 : (_associativeProd$filt2 = _associativeProd$filt.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt2 === void 0 ? void 0 : _associativeProd$filt2.map((values, index) => {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_11__["Radio"].Button, {
                    value: values.attr_value,
                    children: values.attr_value
                  }, index, false, {
                    fileName: _jsxFileName,
                    lineNumber: 419,
                    columnNumber: 29
                  }, undefined);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 405,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 404,
              columnNumber: 19
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 394,
            columnNumber: 17
          }, undefined) : null, filterAssocProd.assocValSizeSel ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            className: renderPrice() !== undefined ? `` : `d-none`,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 500,
                fontSize: "large",
                width: "20%"
              },
              children: "Price:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 431,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                fontWeight: 400,
                fontSize: "large"
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "ml-4",
                children: Object(_utilities_product_helper__WEBPACK_IMPORTED_MODULE_14__["currencyHelperConvertToRinggit"])(renderPrice())
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 446,
                columnNumber: 21
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 440,
              columnNumber: 19
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 430,
            columnNumber: 17
          }, undefined) : null]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 358,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 357,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 356,
      columnNumber: 9
    }, undefined);
  };

  const renderPrice = () => {
    var _associativeProd$filt3, _associativeProd$filt4, _associativeProd$filt5, _associativeProd$filt6, _associativeProd$filt7, _associativeProd$filt8;

    // const price = associativeProd
    //   ?.filter((prod) => prod.attr_value == filterAssocProd.assocValSel)[0]
    //   ?.sub_attributes?.filter(
    //     (attr) => attr.attr_value == filterAssocProd.assocValSizeSel
    //   )[0]?.actual_price;
    const price = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt3 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt3 === void 0 ? void 0 : (_associativeProd$filt4 = _associativeProd$filt3.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt4 === void 0 ? void 0 : (_associativeProd$filt5 = _associativeProd$filt4.filter(attr => attr.attr_value == filterAssocProd.assocValSizeSel)[0]) === null || _associativeProd$filt5 === void 0 ? void 0 : _associativeProd$filt5.actual_price;
    const prod_sale_price = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt6 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt6 === void 0 ? void 0 : (_associativeProd$filt7 = _associativeProd$filt6.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt7 === void 0 ? void 0 : (_associativeProd$filt8 = _associativeProd$filt7.filter(attr => attr.attr_value == filterAssocProd.assocValSizeSel)[0]) === null || _associativeProd$filt8 === void 0 ? void 0 : _associativeProd$filt8.sale_price;

    if (prod_sale_price !== false) {
      return prod_sale_price;
    } else {
      return price;
    }
  };

  const getOutOfstockValueConfigProd = sizeValue => {
    var _associativeProd$filt9, _associativeProd$filt10, _associativeProd$filt11, _associativeProd$filt12, _associativeProd$filt13, _associativeProd$filt14;

    const out_of_stock_selling = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt9 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt9 === void 0 ? void 0 : (_associativeProd$filt10 = _associativeProd$filt9.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt10 === void 0 ? void 0 : (_associativeProd$filt11 = _associativeProd$filt10.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt11 === void 0 ? void 0 : _associativeProd$filt11.out_of_stock_selling;
    const stock = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt12 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt12 === void 0 ? void 0 : (_associativeProd$filt13 = _associativeProd$filt12.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt13 === void 0 ? void 0 : (_associativeProd$filt14 = _associativeProd$filt13.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt14 === void 0 ? void 0 : _associativeProd$filt14.stock;
    return {
      stock,
      out_of_stock_selling
    };
  };

  const getProductId = sizeValue => {
    var _associativeProd$filt15, _associativeProd$filt16, _associativeProd$filt17;

    const selectedProductID = associativeProd === null || associativeProd === void 0 ? void 0 : (_associativeProd$filt15 = associativeProd.filter(prod => prod.attr_value == filterAssocProd.assocValSel)) === null || _associativeProd$filt15 === void 0 ? void 0 : (_associativeProd$filt16 = _associativeProd$filt15.map(attr => attr.sub_attributes[0])) === null || _associativeProd$filt16 === void 0 ? void 0 : (_associativeProd$filt17 = _associativeProd$filt16.filter(attr => attr.attr_value == sizeValue)[0]) === null || _associativeProd$filt17 === void 0 ? void 0 : _associativeProd$filt17.product_id;
    const {
      stock,
      out_of_stock_selling
    } = getOutOfstockValueConfigProd(sizeValue);
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductID"])(selectedProductID));
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductStock"])(stock));
    dispatch(Object(_store_product_action__WEBPACK_IMPORTED_MODULE_4__["setConfigProductOutOfStockSelling"])(out_of_stock_selling));
    return selectedProductID;
  };

  if (!extended && product.product) {
    var _product$product3;

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [(product === null || product === void 0 ? void 0 : (_product$product3 = product.product) === null || _product$product3 === void 0 ? void 0 : _product$product3.product_type) == "config" ? renderAssociativeProduct() : null, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__shopping",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "Quantity"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 526,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group--number",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "up",
              onClick: e => handleIncreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-plus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 532,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 528,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "down",
              onClick: e => handleDecreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-minus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 538,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 534,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              className: "form-control",
              type: "text",
              placeholder: quantity,
              disabled: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 540,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 527,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 525,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--yellow",
          onClick: e => handleAddItemToCart(e),
          children: loading1 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 552,
            columnNumber: 27
          }, undefined) : "Add to cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 548,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--blu",
          onClick: e => handleBuynow(e),
          children: loading2 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 555,
            columnNumber: 27
          }, undefined) : "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 554,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__actions",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: [loading3 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
              size: 20
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 560,
              columnNumber: 19
            }, undefined) : product.product.in_wishlist == 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__["FavoriteBorder"], {
              color: "inherit",
              fontSize: "large",
              onClick: e => handleAddItemToWishlist(e),
              style: {
                cursor: "pointer"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 563,
              columnNumber: 21
            }, undefined), loading3 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_12__["CircularProgress"], {
              size: 20
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 572,
              columnNumber: 19
            }, undefined) : product.product.in_wishlist == 1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__["Favorite"], {
              color: "secondary",
              fontSize: "large",
              onClick: e => handleRemoveWishListItem(e),
              style: {
                cursor: "pointer"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 575,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 558,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 557,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 524,
        columnNumber: 11
      }, undefined)]
    }, void 0, true);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "ps-product__shopping extend",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "ps-product__btn-group",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figure", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("figcaption", {
            children: "Quantity"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 599,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "form-group--number",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "up",
              onClick: e => handleIncreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-plus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 605,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 601,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              className: "down",
              onClick: e => handleDecreaseItemQty(e),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                className: "fa fa-minus"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 611,
                columnNumber: 19
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 607,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              className: "form-control",
              type: "text",
              placeholder: quantity,
              disabled: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 613,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 600,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 598,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          className: "ps-btn ps-btn--black",
          href: "#",
          onClick: e => handleAddItemToCart(e),
          children: "Add to cart"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 621,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "ps-product__actions",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            href: "#",
            onClick: e => handleAddItemToWishlist(e),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
              className: "icon-heart"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 630,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 629,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 628,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 597,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        className: "ps-btn text-white",
        href: "#",
        onClick: e => handleBuynow(e),
        children: "Buy Now"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 637,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 596,
      columnNumber: 9
    }, undefined);
  }
}, "3eckObuHGK8RoUO3o2ueFhzm+Lk=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_8__["useDispatch"], next_router__WEBPACK_IMPORTED_MODULE_9__["useRouter"], react_redux__WEBPACK_IMPORTED_MODULE_8__["useSelector"]];
})); // export default connect((state) => state)(ModuleDetailShoppingActions);

_c2 = ModuleDetailShoppingActions;
/* harmony default export */ __webpack_exports__["default"] = (ModuleDetailShoppingActions);

var _c, _c2;

$RefreshReg$(_c, "ModuleDetailShoppingActions$React.memo");
$RefreshReg$(_c2, "ModuleDetailShoppingActions");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9kZXRhaWwvbW9kdWxlcy9Nb2R1bGVEZXRhaWxBY3Rpb25zTW9iaWxlLmpzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9lbGVtZW50cy9kZXRhaWwvbW9kdWxlcy9Nb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMuanN4Il0sIm5hbWVzIjpbIk1vZHVsZURldGFpbEFjdGlvbnNNb2JpbGUiLCJwcm9kdWN0IiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsIlJvdXRlciIsInVzZVJvdXRlciIsImxvYWRpbmcxIiwic2V0TG9hZGluZzEiLCJ1c2VTdGF0ZSIsImxvYWRpbmcyIiwic2V0TG9hZGluZzIiLCJsb2FkaW5nMyIsInNldExvYWRpbmczIiwiYXV0aCIsInVzZVNlbGVjdG9yIiwic3RhdGUiLCJwcm9kdWN0UXVhbnRpdHkiLCJwcm9kdWN0SWRPZkNvbmZpZyIsIm91dF9vZl9zdG9ja19zZWxsaW5nIiwic3RvY2siLCJoYW5kbGVBZGRJdGVtVG9DYXJ0IiwiZSIsInVzZXJkYXRhIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBhcnNlZGF0YSIsIkpTT04iLCJwYXJzZSIsInRva2VuIiwiYWNjZXNzX3Rva2VuIiwidW5kZWZpbmVkIiwiZGlzcGxheU5vdGlmaWNhdGlvbiIsInByb2R1Y3RfdHlwZSIsInBheWxvYWQiLCJ1c2VyX2lkIiwicXVhbnRpdHkiLCJjYXJ0X3R5cGUiLCJwcm9kdWN0X2lkIiwicmVzcG9uc2VEYXRhIiwiUHJvZHVjdFJlcG9zaXRvcnkiLCJhZGRQcm9kdWN0VG9DYXJ0IiwiaHR0cGNvZGUiLCJnZXRDYXJ0Iiwic3RhdHVzIiwicmVzcG9uc2UiLCJlcnJvciIsImVycm9ycyIsImtleSIsInZhbHVlIiwiT2JqZWN0IiwiZW50cmllcyIsIm1lc3NhZ2UiLCJoYW5kbGVCdXlub3ciLCJpc0xvZ2dlZEluIiwic2V0VGltZW91dCIsInB1c2giLCJNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMiLCJSZWFjdCIsIm1lbW8iLCJleHRlbmRlZCIsInNob2NraW5nc2FsZSIsInNldFF1YW50aXR5Iiwid2lzaGxpc3RGcm9tU2VydmVyIiwic2V0V2lzaGxpc3RGcm9tU2VydmVyIiwiY29uc29sZSIsImxvZyIsIm5vdGlmaWNhdGlvbiIsImRlc2NyaXB0aW9uIiwiZHVyYXRpb24iLCJmaWx0ZXJBc3NvY1Byb2QiLCJhc3NvY1ZhbFNlbCIsImFzc29jVmFsU2l6ZVNlbCIsInByZF9hc3NpZ25faWQiLCJnZXRQcm9kdWN0SWQiLCJnZXRPdXRPZnN0b2NrVmFsdWVDb25maWdQcm9kIiwidG1wIiwiaGFuZGxlQWRkSXRlbVRvQ29tcGFyZSIsImFkZEl0ZW1Ub0NvbXBhcmUiLCJoYW5kbGVBZGRJdGVtVG9XaXNobGlzdCIsImFkZFNob2NraW5nU2FsZUl0ZW1Ub1dpc2hsaXN0IiwiYWRkSXRlbVRvV2lzaGxpc3QiLCJoYW5kbGVSZW1vdmVXaXNoTGlzdEl0ZW0iLCJyZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0IiwicmVtb3ZlV2lzaGxpc3RJdGVtIiwiaGFuZGxlSW5jcmVhc2VJdGVtUXR5Iiwic2V0UHJvZHVjdFF1YW50aXR5QWN0aW9uIiwiaGFuZGxlRGVjcmVhc2VJdGVtUXR5IiwiYXNzb2NpYXRpdmVQcm9kIiwic2V0QXNzb2NpYXRpdmVQcm9kIiwidW5pcXVlQXNzb2NpYXRpdmVQcm9kIiwic2V0VW5pcXVlQXNzb2NpYXRpdmVQcm9kIiwic2V0RmlsdGVyQXNzb2NQcm9kIiwiYXNzb2NWYWwiLCJhc3NvY1ZhbFNpemUiLCJhc3NvY1Byb2RJZCIsInVzZUVmZmVjdCIsImFzc29jaWF0aXZlX3Byb2R1Y3RzIiwiYXJyYXlWYWxzIiwiTWFwIiwibWFwIiwiaXRlbSIsInZhbHVlcyIsImhhbmRsZUNoYW5nZUF0dHIiLCJ0YXJnZXQiLCJoYW5kbGVDaGFuZ2VBdHRyU2l6ZSIsInJlbmRlckFzc29jaWF0aXZlUHJvZHVjdCIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsIndpZHRoIiwiYXR0cl9uYW1lIiwiYXR0ciIsImluZGV4IiwiYXR0cl92YWx1ZSIsImltYWdlIiwic3ViX2F0dHJpYnV0ZXMiLCJmaWx0ZXIiLCJwcm9kIiwidG9Mb3dlckNhc2UiLCJyZW5kZXJQcmljZSIsImN1cnJlbmN5SGVscGVyQ29udmVydFRvUmluZ2dpdCIsInByaWNlIiwiYWN0dWFsX3ByaWNlIiwicHJvZF9zYWxlX3ByaWNlIiwic2FsZV9wcmljZSIsInNpemVWYWx1ZSIsInNlbGVjdGVkUHJvZHVjdElEIiwic2V0Q29uZmlnUHJvZHVjdElEIiwic2V0Q29uZmlnUHJvZHVjdFN0b2NrIiwic2V0Q29uZmlnUHJvZHVjdE91dE9mU3RvY2tTZWxsaW5nIiwiaW5fd2lzaGxpc3QiLCJjdXJzb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUEseUJBQXlCLEdBQUcsQ0FBQztBQUFFQztBQUFGLENBQUQsS0FBaUI7QUFBQTs7QUFDakQsUUFBTUMsUUFBUSxHQUFHQywrREFBVyxFQUE1QjtBQUNBLFFBQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJDLHNEQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQkYsc0RBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNHLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCSixzREFBUSxDQUFDLEtBQUQsQ0FBeEM7QUFFQSxRQUFNSyxJQUFJLEdBQUdDLCtEQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDRixJQUFsQixDQUF4QjtBQUNBLFFBQU07QUFBRUcsbUJBQUY7QUFBbUJDLHFCQUFuQjtBQUFzQ0Msd0JBQXRDO0FBQTREQztBQUE1RCxNQUNKTCwrREFBVyxDQUFFQyxLQUFELElBQVdBLEtBQUssQ0FBQ2QsT0FBbEIsQ0FEYjs7QUFHQSxRQUFNbUIsbUJBQW1CLEdBQUcsTUFBT0MsQ0FBUCxJQUFhO0FBQ3ZDLFFBQUlDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxRQUFYLENBQWhCO0FBQ0EsUUFBSU0sS0FBSyxHQUFHSCxTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUksWUFBdkI7O0FBRUEsUUFBSVAsUUFBUSxLQUFLUSxTQUFiLElBQTBCUixRQUFRLEtBQUssSUFBM0MsRUFBaUQ7QUFDL0NTLDJGQUFtQixDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLG9CQUFuQixDQUFuQjtBQUNBLGFBQU8sS0FBUDtBQUNELEtBSEQsTUFHTyxJQUNMOUIsT0FBTyxDQUFDQSxPQUFSLENBQWdCK0IsWUFBaEIsSUFBZ0MsUUFBaEMsS0FDQ2YsaUJBQWlCLElBQUksQ0FBckIsSUFDQ0EsaUJBQWlCLElBQUksSUFEdEIsSUFFQ0EsaUJBQWlCLElBQUlhLFNBSHZCLENBREssRUFLTDtBQUNBQywyRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix1QkFBbkIsQ0FBbkI7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQVJNLE1BUUE7QUFBQTs7QUFDTHhCLGlCQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0EsVUFBSTBCLE9BQU8sR0FBRztBQUNaQyxlQUFPLEVBQUUsQ0FERztBQUVaQyxnQkFBUSxFQUFFbkIsZUFBZSxJQUFJLENBRmpCO0FBR1pvQixpQkFBUyxFQUFFLEtBSEM7QUFJWlAsb0JBQVksRUFBRUQ7QUFKRixPQUFkOztBQU9BLFVBQUkzQixPQUFPLENBQUNBLE9BQVIsQ0FBZ0IrQixZQUFoQixJQUFnQyxRQUFwQyxFQUE4QztBQUM1Q0MsZUFBTyxtQ0FDRkEsT0FERTtBQUVMSSxvQkFBVSxFQUFFcEI7QUFGUCxVQUFQOztBQUlBLFlBQUlDLG9CQUFvQixLQUFLLEtBQXpCLElBQWtDQyxLQUFLLElBQUksQ0FBL0MsRUFBa0Q7QUFDaERZLCtGQUFtQixDQUFDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLHVCQUFuQixDQUFuQjtBQUVBckIscUJBQVcsQ0FBQyxLQUFELENBQVg7QUFFQSxpQkFBTyxLQUFQO0FBQ0Q7QUFDRixPQVpELE1BWU87QUFDTHVCLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEksb0JBQVUsRUFBRXBDLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQm9DO0FBRnZCLFVBQVA7O0FBSUEsWUFDRXBDLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmlCLG9CQUFoQixLQUF5QyxLQUF6QyxJQUNBakIsT0FBTyxDQUFDQSxPQUFSLENBQWdCa0IsS0FBaEIsSUFBeUIsQ0FGM0IsRUFHRTtBQUNBWSwrRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix1QkFBbkIsQ0FBbkI7QUFFQXJCLHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBRUEsaUJBQU8sS0FBUDtBQUNEO0FBQ0Y7O0FBRUQsWUFBTTRCLFlBQVksR0FDaEIsYUFBQUwsT0FBTyxVQUFQLDRDQUFTSixZQUFULE1BQ0MsTUFBTVUsdUVBQWlCLENBQUNDLGdCQUFsQixDQUFtQ1AsT0FBbkMsQ0FEUCxDQURGOztBQUlBLFVBQUlLLFlBQVksSUFBSUEsWUFBWSxDQUFDRyxRQUFiLElBQXlCLEtBQTdDLEVBQW9EO0FBQ2xEdkMsZ0JBQVEsQ0FBQ3dDLGtFQUFPLEVBQVIsQ0FBUjtBQUVBbkMsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDQXdCLDZGQUFtQixDQUNqQk8sWUFBWSxDQUFDSyxNQURJLEVBRWpCTCxZQUFZLENBQUNLLE1BRkksRUFHakJMLFlBQVksQ0FBQ00sUUFISSxDQUFuQjtBQUtELE9BVEQsTUFTTyxJQUFJTixZQUFZLElBQUlBLFlBQVksQ0FBQ0csUUFBYixJQUF5QixHQUE3QyxFQUFrRDtBQUN2RCxZQUFJSSxLQUFLLEdBQUdQLFlBQVksQ0FBQ1EsTUFBekI7O0FBQ0EsYUFBSyxNQUFNLENBQUNDLEdBQUQsRUFBTUMsS0FBTixDQUFYLElBQTJCQyxNQUFNLENBQUNDLE9BQVAsQ0FBZUwsS0FBZixDQUEzQixFQUFrRDtBQUNoRGQsK0ZBQW1CLENBQUMsT0FBRCxFQUFVLEVBQVYsRUFBY2lCLEtBQWQsRUFBcUIsQ0FBckIsQ0FBbkI7QUFDRDtBQUNGLE9BTE0sTUFLQTtBQUNMakIsNkZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUJPLFlBQVksQ0FBQ2EsT0FBaEMsQ0FBbkI7QUFDQTVDLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPLEtBQVA7QUFDRCxHQTlFRDs7QUFnRkEsUUFBTTZDLFlBQVksR0FBRyxNQUFPL0IsQ0FBUCxJQUFhO0FBQ2hDLFFBQUlSLElBQUksQ0FBQ3dDLFVBQUwsS0FBb0IsSUFBeEIsRUFBOEI7QUFDNUJ0QiwyRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQixvQkFBbkIsQ0FBbkI7QUFDQSxhQUFPLEtBQVA7QUFDRCxLQUhELE1BR08sSUFDTDlCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQitCLFlBQWhCLElBQWdDLFFBQWhDLEtBQ0NmLGlCQUFpQixJQUFJLENBQXJCLElBQ0NBLGlCQUFpQixJQUFJLElBRHRCLElBRUNBLGlCQUFpQixJQUFJYSxTQUh2QixDQURLLEVBS0w7QUFDQUMsMkZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsdUJBQW5CLENBQW5CO0FBQ0EsYUFBTyxLQUFQO0FBQ0QsS0FSTSxNQVFBO0FBQ0xyQixpQkFBVyxDQUFDLElBQUQsQ0FBWDtBQUNBLFVBQUl1QixPQUFPLEdBQUc7QUFDWkMsZUFBTyxFQUFFLENBREc7QUFFWkMsZ0JBQVEsRUFBRW5CLGVBQWUsSUFBSSxDQUZqQjtBQUdaYSxvQkFBWSxFQUFFaEIsSUFBSSxDQUFDZ0IsWUFIUDtBQUlaTyxpQkFBUyxFQUFFO0FBSkMsT0FBZDs7QUFPQSxVQUFJbkMsT0FBTyxDQUFDQSxPQUFSLENBQWdCK0IsWUFBaEIsSUFBZ0MsUUFBcEMsRUFBOEM7QUFDNUNDLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEksb0JBQVUsRUFBRXBCO0FBRlAsVUFBUDs7QUFJQSxZQUFJQyxvQkFBb0IsS0FBSyxLQUF6QixJQUFrQ0MsS0FBSyxJQUFJLENBQS9DLEVBQWtEO0FBQ2hEWSwrRkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQix1QkFBbkIsQ0FBbkI7QUFFQXJCLHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBRUEsaUJBQU8sS0FBUDtBQUNEO0FBQ0YsT0FaRCxNQVlPO0FBQ0x1QixlQUFPLG1DQUNGQSxPQURFO0FBRUxJLG9CQUFVLEVBQUVwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQztBQUZ2QixVQUFQOztBQUtBLFlBQ0VwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JpQixvQkFBaEIsS0FBeUMsS0FBekMsSUFDQWpCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmtCLEtBQWhCLElBQXlCLENBRjNCLEVBR0U7QUFDQVksK0ZBQW1CLENBQUMsT0FBRCxFQUFVLE9BQVYsRUFBbUIsdUJBQW5CLENBQW5CO0FBRUFyQixxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFlBQU00QixZQUFZLEdBQUcsTUFBTUMsdUVBQWlCLENBQUNDLGdCQUFsQixDQUFtQ1AsT0FBbkMsQ0FBM0I7O0FBRUEsVUFBSUssWUFBWSxDQUFDRyxRQUFiLElBQXlCLEdBQTdCLEVBQWtDO0FBQ2hDViw2RkFBbUIsQ0FDakJPLFlBQVksQ0FBQ0ssTUFESSxFQUVqQkwsWUFBWSxDQUFDSyxNQUZJLEVBR2pCTCxZQUFZLENBQUNNLFFBSEksQ0FBbkI7QUFLQVUsa0JBQVUsQ0FBQyxZQUFZO0FBQ3JCbEQsZ0JBQU0sQ0FBQ21ELElBQVAsQ0FBWSxtQkFBWjtBQUNELFNBRlMsRUFFUCxJQUZPLENBQVY7QUFHQTdDLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0EsZUFBTyxLQUFQO0FBQ0QsT0FYRCxNQVdPO0FBQ0xxQiw2RkFBbUIsQ0FBQyxPQUFELEVBQVUsT0FBVixFQUFtQk8sWUFBWSxDQUFDYSxPQUFoQyxDQUFuQjtBQUNBekMsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDQSxlQUFPLEtBQVA7QUFDRDtBQUNGOztBQUNELFdBQU8sS0FBUDtBQUNELEdBdkVEOztBQXlFQSxzQkFDRTtBQUFLLGFBQVMsRUFBQyw0QkFBZjtBQUFBLDRCQUNFO0FBQ0UsZUFBUyxFQUFDLHNCQURaO0FBRUUsYUFBTyxFQUFHVyxDQUFELElBQU9ELG1CQUFtQixDQUFDQyxDQUFELENBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBT0U7QUFBRyxlQUFTLEVBQUMsUUFBYjtBQUFzQixhQUFPLEVBQUdBLENBQUQsSUFBTytCLFlBQVksQ0FBQy9CLENBQUQsQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFhRCxDQWpMRDs7R0FBTXJCLHlCO1VBQ2FHLHVELEVBQ0ZFLHFELEVBS0ZTLHVELEVBRVhBLHVEOzs7S0FURWQseUI7QUFtTFNBLHdGQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0xBO0FBQ0E7QUFLQTtBQVFBO0FBQ0E7QUFDQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU13RCwyQkFBMkIsZ0JBQUdDLDRDQUFLLENBQUNDLElBQU4sU0FDbEMsQ0FBQztBQUFFekQsU0FBRjtBQUFXMEQsVUFBUSxHQUFHLEtBQXRCO0FBQTZCQyxjQUFZLEdBQUc7QUFBNUMsQ0FBRCxLQUF5RDtBQUFBOztBQUN2RCxRQUFNMUQsUUFBUSxHQUFHQywrREFBVyxFQUE1QjtBQUNBLFFBQU07QUFBQSxPQUFDZ0MsUUFBRDtBQUFBLE9BQVcwQjtBQUFYLE1BQTBCckQsc0RBQVEsQ0FBQyxDQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNzRCxrQkFBRDtBQUFBLE9BQXFCQztBQUFyQixNQUE4Q3ZELHNEQUFRLENBQUMsRUFBRCxDQUE1RDtBQUNBLFFBQU1KLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJDLHNEQUFRLENBQUMsS0FBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQkYsc0RBQVEsQ0FBQyxLQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNHLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCSixzREFBUSxDQUFDLEtBQUQsQ0FBeEM7QUFDQSxRQUFNSyxJQUFJLEdBQUdDLCtEQUFXLENBQUVDLEtBQUQsSUFBV0EsS0FBSyxDQUFDRixJQUFsQixDQUF4Qjs7QUFFQSxRQUFNTyxtQkFBbUIsR0FBRyxNQUFPQyxDQUFQLElBQWE7QUFBQTs7QUFDdkMyQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsUUFBSTNDLFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxRQUFYLENBQWhCO0FBQ0EsUUFBSU0sS0FBSyxHQUFHSCxTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUksWUFBdkI7QUFDQW1DLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaLEVBQWtDM0MsUUFBbEM7QUFDQTBDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFaLEVBQW1DeEMsU0FBbkM7QUFDQXVDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQStCckMsS0FBL0I7O0FBQ0EsUUFBSU4sUUFBUSxLQUFLUSxTQUFiLElBQTBCUixRQUFRLEtBQUssSUFBM0MsRUFBaUQ7QUFDL0MwQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWjtBQUNBQyx3REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQmYsZUFBTyxFQUFFLE9BRFc7QUFFcEJnQixtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVJELE1BUU8sSUFDTCxDQUFBbkUsT0FBTyxTQUFQLElBQUFBLE9BQU8sV0FBUCxnQ0FBQUEsT0FBTyxDQUFFQSxPQUFULHNFQUFrQitCLFlBQWxCLEtBQWtDLFFBQWxDLEtBQ0NxQyxlQUFlLENBQUNDLFdBQWhCLElBQStCLEVBQS9CLElBQ0NELGVBQWUsQ0FBQ0UsZUFBaEIsSUFBbUMsRUFGckMsQ0FESyxFQUlMO0FBQ0FQLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FDLHdEQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCZixlQUFPLEVBQUUsT0FEVztBQUVwQmdCLG1CQUFXLEVBQUUsdUJBRk87QUFHcEJDLGdCQUFRLEVBQUU7QUFIVSxPQUF0QjtBQUtBLGFBQU8sS0FBUDtBQUNELEtBWk0sTUFZQTtBQUFBOztBQUNMSixhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWjtBQUNBMUQsaUJBQVcsQ0FBQyxJQUFELENBQVg7QUFDQSxVQUFJMEIsT0FBTyxHQUFHO0FBQ1o7QUFDQXVDLHFCQUFhLEVBQUMsRUFGRjtBQUdackMsZ0JBQVEsRUFBRUEsUUFIRTtBQUlaQyxpQkFBUyxFQUFFLEtBSkM7QUFLWlAsb0JBQVksRUFBRUQ7QUFMRixPQUFkO0FBT0FvQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBWjs7QUFDQSxVQUFJLENBQUFoRSxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLGlDQUFBQSxPQUFPLENBQUVBLE9BQVQsd0VBQWtCK0IsWUFBbEIsS0FBa0MsUUFBdEMsRUFBZ0Q7QUFHOUNDLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEksb0JBQVUsRUFBRW9DLFlBQVksQ0FBQ0osZUFBZSxDQUFDRSxlQUFqQjtBQUZuQixVQUFQO0FBSUEsY0FBTTtBQUFFckQsOEJBQUY7QUFBd0JDO0FBQXhCLFlBQWtDdUQsNEJBQTRCLENBQ2xFTCxlQUFlLENBQUNFLGVBRGtELENBQXBFOztBQUlBLFlBQUlyRCxvQkFBb0IsS0FBSyxLQUF6QixJQUFrQ0MsS0FBSyxJQUFJLENBQS9DLEVBQWtEO0FBQ2hENkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0FDLDREQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCZixtQkFBTyxFQUFFLE9BRFc7QUFFcEJnQix1QkFBVyxFQUFFLHVCQUZPO0FBR3BCQyxvQkFBUSxFQUFFO0FBSFUsV0FBdEI7QUFLQTdELHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0EsaUJBQU8sS0FBUDtBQUNELFNBcEI2QyxDQXFCOUM7O0FBQ0QsT0F0QkQsTUFzQk87QUFDTHlELGVBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaO0FBQ0FoQyxlQUFPLG1DQUNGQSxPQURFO0FBRUxJLG9CQUFVLEVBQUVwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQztBQUZ2QixVQUFQOztBQUlBLFlBQ0VwQyxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JpQixvQkFBaEIsS0FBeUMsS0FBekMsSUFDQWpCLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmtCLEtBQWhCLElBQXlCLENBRjNCLEVBR0U7QUFDQTZDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWSxvQkFBWjtBQUNBQyw0REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQmYsbUJBQU8sRUFBRSxPQURXO0FBRXBCZ0IsdUJBQVcsRUFBRSx1QkFGTztBQUdwQkMsb0JBQVEsRUFBRTtBQUhVLFdBQXRCO0FBS0E3RCxxQkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUVBLGlCQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFlBQU0rQixZQUFZLEdBQ2hCLGFBQUFMLE9BQU8sVUFBUCw0Q0FBU0osWUFBVCxNQUVDLE1BQU1VLHdFQUFpQixDQUFDQyxnQkFBbEIsQ0FBbUNQLE9BQW5DLENBRlAsQ0FERjs7QUFLQSxVQUFJSyxZQUFZLElBQUlBLFlBQVksQ0FBQ0csUUFBYixJQUF5QixLQUE3QyxFQUFvRDtBQUNsRCxZQUFJa0MsR0FBRyxHQUFHMUUsT0FBVjtBQUNBMEUsV0FBRyxDQUFDeEMsUUFBSixHQUFlQSxRQUFmLENBRmtELENBR2xEOztBQUNBakMsZ0JBQVEsQ0FBQ3dDLGtFQUFPLEVBQVIsQ0FBUjtBQUVBbkMsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDQTJELDBEQUFZLENBQUM1QixZQUFZLENBQUNLLE1BQWQsQ0FBWixDQUFrQztBQUNoQ1EsaUJBQU8sRUFBRWIsWUFBWSxDQUFDYSxPQURVO0FBRWhDZ0IscUJBQVcsRUFBRTdCLFlBQVksQ0FBQ00sUUFGTTtBQUdoQ3dCLGtCQUFRLEVBQUU7QUFIc0IsU0FBbEM7QUFLQWQsa0JBQVUsQ0FBQyxZQUFZO0FBQ3JCbEQsZ0JBQU0sQ0FBQ21ELElBQVAsQ0FBWSx3QkFBWjtBQUNELFNBRlMsRUFFUCxHQUZPLENBQVY7QUFHRCxPQWZELE1BZU87QUFDTFcsMERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJmLGlCQUFPLEVBQUUsT0FEVztBQUVwQmdCLHFCQUFXLEVBQUU3QixZQUFZLENBQUNhLE9BRk47QUFHcEJpQixrQkFBUSxFQUFFO0FBSFUsU0FBdEI7QUFLQTdELG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0Q7QUFDRjtBQUNGLEdBaEhEOztBQWtIQSxRQUFNNkMsWUFBWSxHQUFHLE1BQU8vQixDQUFQLElBQWE7QUFDaEMsUUFBSVIsSUFBSSxDQUFDd0MsVUFBTCxLQUFvQixJQUF4QixFQUE4QjtBQUM1QmEsd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJmLGVBQU8sRUFBRSxPQURXO0FBRXBCZ0IsbUJBQVcsRUFBRSxvQkFGTztBQUdwQkMsZ0JBQVEsRUFBRTtBQUhVLE9BQXRCO0FBS0EsYUFBTyxLQUFQO0FBQ0QsS0FQRCxNQU9PLElBQ0xuRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0IrQixZQUFoQixJQUFnQyxRQUFoQyxLQUNDcUMsZUFBZSxDQUFDQyxXQUFoQixJQUErQixFQUEvQixJQUNDRCxlQUFlLENBQUNFLGVBQWhCLElBQW1DLEVBRnJDLENBREssRUFJTDtBQUNBTCx3REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQmYsZUFBTyxFQUFFLE9BRFc7QUFFcEJnQixtQkFBVyxFQUFFLHVCQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVhNLE1BV0E7QUFDTDFELGlCQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0EsVUFBSXVCLE9BQU8sR0FBRztBQUNaO0FBQ0F1QyxxQkFBYSxFQUFDLEVBRkY7QUFHWnJDLGdCQUFRLEVBQUVBLFFBSEU7QUFJWk4sb0JBQVksRUFBRWhCLElBQUksQ0FBQ2dCLFlBSlA7QUFLWk8saUJBQVMsRUFBRTtBQUxDLE9BQWQ7O0FBUUEsVUFBSW5DLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQitCLFlBQWhCLElBQWdDLFFBQXBDLEVBQThDO0FBQzVDQyxlQUFPLG1DQUNGQSxPQURFO0FBRUxJLG9CQUFVLEVBQUVvQyxZQUFZLENBQUNKLGVBQWUsQ0FBQ0UsZUFBakI7QUFGbkIsVUFBUDtBQUtBLGNBQU07QUFBRXJELDhCQUFGO0FBQXdCQztBQUF4QixZQUFrQ3VELDRCQUE0QixDQUNsRUwsZUFBZSxDQUFDRSxlQURrRCxDQUFwRTs7QUFJQSxZQUFJckQsb0JBQW9CLEtBQUssS0FBekIsSUFBa0NDLEtBQUssSUFBSSxDQUEvQyxFQUFrRDtBQUNoRCtDLDREQUFZLENBQUMsT0FBRCxDQUFaLENBQXNCO0FBQ3BCZixtQkFBTyxFQUFFLE9BRFc7QUFFcEJnQix1QkFBVyxFQUFFLHVCQUZPO0FBR3BCQyxvQkFBUSxFQUFFO0FBSFUsV0FBdEI7QUFLQTFELHFCQUFXLENBQUMsS0FBRCxDQUFYO0FBRUEsaUJBQU8sS0FBUDtBQUNEO0FBQ0YsT0FwQkQsTUFvQk87QUFDTHVCLGVBQU8sbUNBQ0ZBLE9BREU7QUFFTEksb0JBQVUsRUFBRXBDLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQm9DO0FBRnZCLFVBQVA7O0FBSUEsWUFDRXBDLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmlCLG9CQUFoQixLQUF5QyxLQUF6QyxJQUNBakIsT0FBTyxDQUFDQSxPQUFSLENBQWdCa0IsS0FBaEIsSUFBeUIsQ0FGM0IsRUFHRTtBQUNBK0MsNERBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJmLG1CQUFPLEVBQUUsT0FEVztBQUVwQmdCLHVCQUFXLEVBQUUsdUJBRk87QUFHcEJDLG9CQUFRLEVBQUU7QUFIVSxXQUF0QjtBQUtBMUQscUJBQVcsQ0FBQyxLQUFELENBQVg7QUFFQSxpQkFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFDRCxZQUFNNEIsWUFBWSxHQUFHLE1BQU1DLHdFQUFpQixDQUFDQyxnQkFBbEIsQ0FBbUNQLE9BQW5DLENBQTNCOztBQUVBLFVBQUlLLFlBQVksQ0FBQ0csUUFBYixJQUF5QixHQUE3QixFQUFrQztBQUNoQyxZQUFJa0MsR0FBRyxHQUFHMUUsT0FBVjtBQUNBMEUsV0FBRyxDQUFDeEMsUUFBSixHQUFlQSxRQUFmO0FBQ0ErQiwwREFBWSxDQUFDNUIsWUFBWSxDQUFDSyxNQUFkLENBQVosQ0FBa0M7QUFDaEN3QixxQkFBVyxFQUFFN0IsWUFBWSxDQUFDTSxRQURNO0FBRWhDd0Isa0JBQVEsRUFBRTtBQUZzQixTQUFsQyxFQUhnQyxDQU9oQzs7QUFDQWQsa0JBQVUsQ0FBQyxZQUFZO0FBQ3JCbEQsZ0JBQU0sQ0FBQ21ELElBQVAsQ0FBWSxtQkFBWjtBQUNELFNBRlMsRUFFUCxJQUZPLENBQVY7QUFHQTdDLG1CQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0QsT0FaRCxNQVlPO0FBQ0x3RCwwREFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQmYsaUJBQU8sRUFBRSxPQURXO0FBRXBCZ0IscUJBQVcsRUFBRTdCLFlBQVksQ0FBQ2EsT0FGTjtBQUdwQmlCLGtCQUFRLEVBQUU7QUFIVSxTQUF0QjtBQUtBMUQsbUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDRDtBQUNGO0FBQ0YsR0EzRkQ7O0FBNkZBLFFBQU1rRSxzQkFBc0IsR0FBSXZELENBQUQsSUFBTztBQUNwQ25CLFlBQVEsQ0FBQzJFLDhFQUFnQixDQUFDNUUsT0FBRCxDQUFqQixDQUFSO0FBQ0QsR0FGRDs7QUFJQSxRQUFNNkUsdUJBQXVCLEdBQUcsTUFBT3pELENBQVAsSUFBYTtBQUUzQyxRQUFJQyxRQUFRLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixNQUFyQixDQUFmO0FBQ0EsUUFBSUMsU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0wsUUFBWCxDQUFoQjtBQUNBLFFBQUlNLEtBQUssR0FBR0gsU0FBSCxhQUFHQSxTQUFILHVCQUFHQSxTQUFTLENBQUVJLFlBQXZCOztBQUNBLFFBQUlQLFFBQVEsS0FBS1EsU0FBYixJQUEwQlIsUUFBUSxLQUFLLElBQTNDLEVBQWlEO0FBQy9DNEMsd0RBQVksQ0FBQyxPQUFELENBQVosQ0FBc0I7QUFDcEJmLGVBQU8sRUFBRSxPQURXO0FBRXBCZ0IsbUJBQVcsRUFBRSxvQkFGTztBQUdwQkMsZ0JBQVEsRUFBRTtBQUhVLE9BQXRCO0FBS0EsYUFBTyxLQUFQO0FBQ0QsS0FQRCxNQU9PO0FBQ0wsVUFBSVIsWUFBWSxJQUFJLElBQXBCLEVBQTBCO0FBQ3hCMUQsZ0JBQVEsQ0FBQzZFLDRGQUE2QixDQUFDOUUsT0FBTyxDQUFDQSxPQUFSLENBQWdCb0MsVUFBakIsQ0FBOUIsQ0FBUjtBQUNELE9BRkQsTUFFTztBQUNMMkIsZUFBTyxDQUFDQyxHQUFSLENBQVksdUJBQVosRUFBb0NoRSxPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQyxVQUFwRDtBQUNBbkMsZ0JBQVEsQ0FBQzhFLGdGQUFpQixDQUFDL0UsT0FBTyxDQUFDQSxPQUFSLENBQWdCb0MsVUFBakIsQ0FBbEIsQ0FBUjtBQUNEO0FBQ0Y7QUFDRixHQXBCRDs7QUFzQkEsUUFBTTRDLHdCQUF3QixHQUFHLE1BQU07QUFDckMsUUFBSTNELFFBQVEsR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLENBQWY7QUFDQSxRQUFJQyxTQUFTLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxRQUFYLENBQWhCO0FBQ0EsUUFBSU0sS0FBSyxHQUFHSCxTQUFILGFBQUdBLFNBQUgsdUJBQUdBLFNBQVMsQ0FBRUksWUFBdkI7O0FBQ0EsUUFBSVAsUUFBUSxLQUFLUSxTQUFiLElBQTBCUixRQUFRLEtBQUssSUFBM0MsRUFBaUQ7QUFDL0M0Qyx3REFBWSxDQUFDLE9BQUQsQ0FBWixDQUFzQjtBQUNwQmYsZUFBTyxFQUFFLE9BRFc7QUFFcEJnQixtQkFBVyxFQUFFLG9CQUZPO0FBR3BCQyxnQkFBUSxFQUFFO0FBSFUsT0FBdEI7QUFLQSxhQUFPLEtBQVA7QUFDRCxLQVBELE1BT087QUFDTCxVQUFJUixZQUFZLElBQUksSUFBcEIsRUFBMEI7QUFDeEIxRCxnQkFBUSxDQUNOZ0YsaUdBQWtDLENBQUNqRixPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQyxVQUFqQixDQUQ1QixDQUFSO0FBR0QsT0FKRCxNQUlPO0FBQ0xuQyxnQkFBUSxDQUFDaUYsaUZBQWtCLENBQUNsRixPQUFPLENBQUNBLE9BQVIsQ0FBZ0JvQyxVQUFqQixDQUFuQixDQUFSO0FBQ0Q7QUFDRjtBQUNGLEdBcEJEOztBQXNCQSxRQUFNK0MscUJBQXFCLEdBQUkvRCxDQUFELElBQU87QUFDbkN3QyxlQUFXLENBQUMxQixRQUFRLEdBQUcsQ0FBWixDQUFYO0FBQ0FqQyxZQUFRLENBQUNtRixzRkFBd0IsQ0FBQ2xELFFBQVEsR0FBRyxDQUFaLENBQXpCLENBQVI7QUFDRCxHQUhEOztBQUtBLFFBQU1tRCxxQkFBcUIsR0FBSWpFLENBQUQsSUFBTztBQUNuQyxRQUFJYyxRQUFRLEdBQUcsQ0FBZixFQUFrQjtBQUNoQjBCLGlCQUFXLENBQUMxQixRQUFRLEdBQUcsQ0FBWixDQUFYO0FBQ0FqQyxjQUFRLENBQUNtRixzRkFBd0IsQ0FBQ2xELFFBQVEsR0FBRyxDQUFaLENBQXpCLENBQVI7QUFDRDtBQUNGLEdBTEQ7O0FBT0EsUUFBTTtBQUFBLE9BQUNvRCxlQUFEO0FBQUEsT0FBa0JDO0FBQWxCLE1BQXdDaEYsc0RBQVEsQ0FBQyxFQUFELENBQXREO0FBQ0EsUUFBTTtBQUFBLE9BQUNpRixxQkFBRDtBQUFBLE9BQXdCQztBQUF4QixNQUFvRGxGLHNEQUFRLENBQUMsRUFBRCxDQUFsRTtBQUVBLFFBQU07QUFBQSxPQUFDNkQsZUFBRDtBQUFBLE9BQWtCc0I7QUFBbEIsTUFBd0NuRixzREFBUSxDQUFDO0FBQ3JEb0YsWUFBUSxFQUFFLEVBRDJDO0FBRXJEdEIsZUFBVyxFQUFFLEVBRndDO0FBR3JEdUIsZ0JBQVksRUFBRSxFQUh1QztBQUlyRHRCLG1CQUFlLEVBQUUsRUFKb0M7QUFLckR1QixlQUFXLEVBQUU7QUFMd0MsR0FBRCxDQUF0RDtBQVFBQyx5REFBUyxDQUFDLE1BQU07QUFBQTs7QUFDZFAsc0JBQWtCLENBQUN2RixPQUFELGFBQUNBLE9BQUQsdUJBQUNBLE9BQU8sQ0FBRStGLG9CQUFWLENBQWxCO0FBQ0EsUUFBSUMsU0FBUyxHQUFHLENBQ2QsR0FBRyxJQUFJQyxHQUFKLENBQ0RqRyxPQURDLGFBQ0RBLE9BREMsZ0RBQ0RBLE9BQU8sQ0FBRStGLG9CQURSLDBEQUNELHNCQUErQkcsR0FBL0IsQ0FBb0NDLElBQUQsSUFBVSxDQUMzQ0EsSUFBSSxDQUFDLFlBQUQsQ0FEdUMsRUFFM0NBLElBRjJDLENBQTdDLENBREMsRUFLREMsTUFMQyxFQURXLENBQWhCO0FBUUFYLDRCQUF3QixDQUFDTyxTQUFELENBQXhCO0FBQ0QsR0FYUSxFQVdOLENBQUNoRyxPQUFELENBWE0sQ0FBVDs7QUFhQSxRQUFNcUcsZ0JBQWdCLEdBQUlqRixDQUFELElBQU87QUFDOUJzRSxzQkFBa0IsaUNBQU10QixlQUFOO0FBQXVCQyxpQkFBVyxFQUFFakQsQ0FBQyxDQUFDa0YsTUFBRixDQUFTdkQ7QUFBN0MsT0FBbEI7QUFDQU0sY0FBVSxDQUFDLE1BQU07QUFDZm1CLGtCQUFZLENBQUNKLGVBQWUsQ0FBQ0UsZUFBakIsQ0FBWjtBQUNELEtBRlMsRUFFUCxJQUZPLENBQVY7QUFHRCxHQUxEOztBQU9BLFFBQU1pQyxvQkFBb0IsR0FBSW5GLENBQUQsSUFBTztBQUNsQ3NFLHNCQUFrQixpQ0FDYnRCLGVBRGE7QUFFaEJFLHFCQUFlLEVBQUVsRCxDQUFDLENBQUNrRixNQUFGLENBQVN2RDtBQUZWLE9BQWxCO0FBSUFNLGNBQVUsQ0FBQyxNQUFNO0FBQ2ZtQixrQkFBWSxDQUFDcEQsQ0FBQyxDQUFDa0YsTUFBRixDQUFTdkQsS0FBVixDQUFaO0FBQ0QsS0FGUyxFQUVQLElBRk8sQ0FBVjtBQUdELEdBUkQ7O0FBVUEsUUFBTXlELHdCQUF3QixHQUFHLE1BQU07QUFBQTs7QUFDckMsd0JBQ0U7QUFBSyxlQUFTLEVBQUMsc0JBQWY7QUFBQSw2QkFDRTtBQUFPLGlCQUFTLEVBQUMsd0JBQWpCO0FBQUEsK0JBQ0U7QUFBQSxrQ0FDRTtBQUFBLG9DQUNFO0FBQ0UsbUJBQUssRUFBRTtBQUNMQywwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRSxPQUZMO0FBR0xDLHFCQUFLLEVBQUU7QUFIRixlQURUO0FBQUEsNkNBT0dyQixlQUFlLENBQUMsQ0FBRCxDQVBsQixzREFPRyxrQkFBb0JzQjtBQVB2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBVUU7QUFBQSxxQ0FDRSxxRUFBQywyQ0FBRCxDQUFPLEtBQVA7QUFDRSxvQkFBSSxFQUFDLE9BRFA7QUFFRSx5QkFBUyxFQUFDLE1BRlo7QUFHRSx3QkFBUSxFQUFFUCxnQkFIWjtBQUlFLDRCQUFZLEVBQUVqQyxlQUFGLGFBQUVBLGVBQUYsdUJBQUVBLGVBQWUsQ0FBRXVCLFFBSmpDO0FBQUEsMEJBTUdILHFCQU5ILGFBTUdBLHFCQU5ILHVCQU1HQSxxQkFBcUIsQ0FBRVUsR0FBdkIsQ0FBMkIsQ0FBQ1csSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQzNDLHNDQUNFLHFFQUFDLDJDQUFELENBQU8sTUFBUDtBQUNFLHlCQUFLLEVBQUVELElBQUksQ0FBQ0UsVUFEZDtBQUdFLDZCQUFTLEVBQUMsTUFIWjtBQUFBLDJDQUtFLHFFQUFDLDRDQUFEO0FBQVEseUJBQUcsRUFBRUYsSUFBSSxDQUFDRztBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEYscUJBRU9GLEtBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQVNELGlCQVZBO0FBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBZ0NFO0FBQUEsbUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaENGLEVBbUNHMUMsZUFBZSxDQUFDQyxXQUFoQixnQkFDQztBQUFBLG9DQUNFO0FBQ0UsbUJBQUssRUFBRTtBQUNMb0MsMEJBQVUsRUFBRSxHQURQO0FBRUxDLHdCQUFRLEVBQUUsT0FGTDtBQUdMQyxxQkFBSyxFQUFFO0FBSEYsZUFEVDtBQUFBLDhDQU9HckIsZUFBZSxDQUFDLENBQUQsQ0FQbEIsZ0ZBT0csbUJBQW9CMkIsY0FBcEIsQ0FBbUMsQ0FBbkMsQ0FQSCwwREFPRyxzQkFBdUNMO0FBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFVRTtBQUFBLHFDQUNFLHFFQUFDLDJDQUFELENBQU8sS0FBUDtBQUNFLG9CQUFJLEVBQUMsT0FEUDtBQUVFLHlCQUFTLEVBQUMsTUFGWjtBQUdFLHdCQUFRLEVBQUVMLG9CQUhaO0FBQUEsMEJBS0dqQixlQUxILGFBS0dBLGVBTEgsZ0RBS0dBLGVBQWUsQ0FDWjRCLE1BREgsQ0FFSUMsSUFBRCxJQUNFQSxJQUFJLENBQUNKLFVBQUwsQ0FBZ0JLLFdBQWhCLE9BQ0FoRCxlQUFlLENBQUNDLFdBQWhCLENBQTRCK0MsV0FBNUIsRUFKTCxDQUxILG9GQUtHLHNCQU1HbEIsR0FOSCxDQU1RVyxJQUFELElBQVVBLElBQUksQ0FBQ0ksY0FBTCxDQUFvQixDQUFwQixDQU5qQixDQUxILDJEQUtHLHVCQU9HZixHQVBILENBT08sQ0FBQ0UsTUFBRCxFQUFTVSxLQUFULEtBQW1CO0FBQ3ZCLHNDQUNFLHFFQUFDLDJDQUFELENBQU8sTUFBUDtBQUFjLHlCQUFLLEVBQUVWLE1BQU0sQ0FBQ1csVUFBNUI7QUFBQSw4QkFDR1gsTUFBTSxDQUFDVztBQURWLHFCQUE2Q0QsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERjtBQUtELGlCQWJGO0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURELEdBa0NHLElBckVOLEVBdUVHMUMsZUFBZSxDQUFDRSxlQUFoQixnQkFDQztBQUFJLHFCQUFTLEVBQUUrQyxXQUFXLE9BQU94RixTQUFsQixHQUErQixFQUEvQixHQUFvQyxRQUFuRDtBQUFBLG9DQUNFO0FBQ0UsbUJBQUssRUFBRTtBQUNMNEUsMEJBQVUsRUFBRSxHQURQO0FBRUxDLHdCQUFRLEVBQUUsT0FGTDtBQUdMQyxxQkFBSyxFQUFFO0FBSEYsZUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQVVFO0FBQ0UsbUJBQUssRUFBRTtBQUNMRiwwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRTtBQUZMLGVBRFQ7QUFBQSxxQ0FNRTtBQUFNLHlCQUFTLEVBQUMsTUFBaEI7QUFBQSwwQkFDR1ksaUdBQThCLENBQUNELFdBQVcsRUFBWjtBQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREQsR0FzQkcsSUE3Rk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFxR0QsR0F0R0Q7O0FBd0dBLFFBQU1BLFdBQVcsR0FBRyxNQUFNO0FBQUE7O0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxVQUFNRSxLQUFLLEdBQUdqQyxlQUFILGFBQUdBLGVBQUgsaURBQUdBLGVBQWUsQ0FDekI0QixNQURVLENBQ0ZDLElBQUQsSUFBVUEsSUFBSSxDQUFDSixVQUFMLElBQW1CM0MsZUFBZSxDQUFDQyxXQUQxQyxDQUFILHFGQUFHLHVCQUVWNkIsR0FGVSxDQUVMVyxJQUFELElBQVVBLElBQUksQ0FBQ0ksY0FBTCxDQUFvQixDQUFwQixDQUZKLENBQUgscUZBQUcsdUJBR1ZDLE1BSFUsQ0FJVEwsSUFBRCxJQUFVQSxJQUFJLENBQUNFLFVBQUwsSUFBbUIzQyxlQUFlLENBQUNFLGVBSm5DLEVBS1YsQ0FMVSxDQUFILDJEQUFHLHVCQUtOa0QsWUFMUjtBQU9BLFVBQU1DLGVBQWUsR0FBR25DLGVBQUgsYUFBR0EsZUFBSCxpREFBR0EsZUFBZSxDQUNuQzRCLE1BRG9CLENBQ1pDLElBQUQsSUFBVUEsSUFBSSxDQUFDSixVQUFMLElBQW1CM0MsZUFBZSxDQUFDQyxXQURoQyxDQUFILHFGQUFHLHVCQUVwQjZCLEdBRm9CLENBRWZXLElBQUQsSUFBVUEsSUFBSSxDQUFDSSxjQUFMLENBQW9CLENBQXBCLENBRk0sQ0FBSCxxRkFBRyx1QkFHcEJDLE1BSG9CLENBSW5CTCxJQUFELElBQVVBLElBQUksQ0FBQ0UsVUFBTCxJQUFtQjNDLGVBQWUsQ0FBQ0UsZUFKekIsRUFLcEIsQ0FMb0IsQ0FBSCwyREFBRyx1QkFLaEJvRCxVQUxSOztBQU9BLFFBQUlELGVBQWUsS0FBSyxLQUF4QixFQUErQjtBQUM3QixhQUFPQSxlQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsYUFBT0YsS0FBUDtBQUNEO0FBQ0YsR0ExQkQ7O0FBNEJBLFFBQU05Qyw0QkFBNEIsR0FBSWtELFNBQUQsSUFBZTtBQUFBOztBQUNsRCxVQUFNMUcsb0JBQW9CLEdBQUdxRSxlQUFILGFBQUdBLGVBQUgsaURBQUdBLGVBQWUsQ0FDeEM0QixNQUR5QixDQUNqQkMsSUFBRCxJQUFVQSxJQUFJLENBQUNKLFVBQUwsSUFBbUIzQyxlQUFlLENBQUNDLFdBRDNCLENBQUgsc0ZBQUcsdUJBRXpCNkIsR0FGeUIsQ0FFcEJXLElBQUQsSUFBVUEsSUFBSSxDQUFDSSxjQUFMLENBQW9CLENBQXBCLENBRlcsQ0FBSCx1RkFBRyx3QkFHekJDLE1BSHlCLENBSXhCTCxJQUFELElBQVVBLElBQUksQ0FBQ0UsVUFBTCxJQUFtQlksU0FKSixFQUt6QixDQUx5QixDQUFILDREQUFHLHdCQUtyQjFHLG9CQUxSO0FBT0EsVUFBTUMsS0FBSyxHQUFHb0UsZUFBSCxhQUFHQSxlQUFILGtEQUFHQSxlQUFlLENBQ3pCNEIsTUFEVSxDQUNGQyxJQUFELElBQVVBLElBQUksQ0FBQ0osVUFBTCxJQUFtQjNDLGVBQWUsQ0FBQ0MsV0FEMUMsQ0FBSCx1RkFBRyx3QkFFVjZCLEdBRlUsQ0FFTFcsSUFBRCxJQUFVQSxJQUFJLENBQUNJLGNBQUwsQ0FBb0IsQ0FBcEIsQ0FGSixDQUFILHVGQUFHLHdCQUdWQyxNQUhVLENBR0ZMLElBQUQsSUFBVUEsSUFBSSxDQUFDRSxVQUFMLElBQW1CWSxTQUgxQixFQUdxQyxDQUhyQyxDQUFILDREQUFHLHdCQUd5Q3pHLEtBSHZEO0FBS0EsV0FBTztBQUFFQSxXQUFGO0FBQVNEO0FBQVQsS0FBUDtBQUNELEdBZEQ7O0FBZ0JBLFFBQU11RCxZQUFZLEdBQUltRCxTQUFELElBQWU7QUFBQTs7QUFDbEMsVUFBTUMsaUJBQWlCLEdBQUd0QyxlQUFILGFBQUdBLGVBQUgsa0RBQUdBLGVBQWUsQ0FDckM0QixNQURzQixDQUNkQyxJQUFELElBQVVBLElBQUksQ0FBQ0osVUFBTCxJQUFtQjNDLGVBQWUsQ0FBQ0MsV0FEOUIsQ0FBSCx1RkFBRyx3QkFFdEI2QixHQUZzQixDQUVqQlcsSUFBRCxJQUFVQSxJQUFJLENBQUNJLGNBQUwsQ0FBb0IsQ0FBcEIsQ0FGUSxDQUFILHVGQUFHLHdCQUd0QkMsTUFIc0IsQ0FHZEwsSUFBRCxJQUFVQSxJQUFJLENBQUNFLFVBQUwsSUFBbUJZLFNBSGQsRUFHeUIsQ0FIekIsQ0FBSCw0REFBRyx3QkFHNkJ2RixVQUh2RDtBQUlBLFVBQU07QUFBRWxCLFdBQUY7QUFBU0Q7QUFBVCxRQUNKd0QsNEJBQTRCLENBQUNrRCxTQUFELENBRDlCO0FBR0ExSCxZQUFRLENBQUM0SCxnRkFBa0IsQ0FBQ0QsaUJBQUQsQ0FBbkIsQ0FBUjtBQUNBM0gsWUFBUSxDQUFDNkgsbUZBQXFCLENBQUM1RyxLQUFELENBQXRCLENBQVI7QUFDQWpCLFlBQVEsQ0FBQzhILCtGQUFpQyxDQUFDOUcsb0JBQUQsQ0FBbEMsQ0FBUjtBQUVBLFdBQU8yRyxpQkFBUDtBQUNELEdBYkQ7O0FBZUEsTUFBSSxDQUFDbEUsUUFBRCxJQUFhMUQsT0FBTyxDQUFDQSxPQUF6QixFQUFrQztBQUFBOztBQUNoQyx3QkFDRTtBQUFBLGlCQUNHLENBQUFBLE9BQU8sU0FBUCxJQUFBQSxPQUFPLFdBQVAsaUNBQUFBLE9BQU8sQ0FBRUEsT0FBVCx3RUFBa0IrQixZQUFsQixLQUFrQyxRQUFsQyxHQUNHeUUsd0JBQXdCLEVBRDNCLEdBRUcsSUFITixlQUtFO0FBQUssaUJBQVMsRUFBQyxzQkFBZjtBQUFBLGdDQUNFO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsb0JBQWY7QUFBQSxvQ0FDRTtBQUNFLHVCQUFTLEVBQUMsSUFEWjtBQUVFLHFCQUFPLEVBQUdwRixDQUFELElBQU8rRCxxQkFBcUIsQ0FBQy9ELENBQUQsQ0FGdkM7QUFBQSxxQ0FJRTtBQUFHLHlCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU9FO0FBQ0UsdUJBQVMsRUFBQyxNQURaO0FBRUUscUJBQU8sRUFBR0EsQ0FBRCxJQUFPaUUscUJBQXFCLENBQUNqRSxDQUFELENBRnZDO0FBQUEscUNBSUU7QUFBRyx5QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEYsZUFhRTtBQUNFLHVCQUFTLEVBQUMsY0FEWjtBQUVFLGtCQUFJLEVBQUMsTUFGUDtBQUdFLHlCQUFXLEVBQUVjLFFBSGY7QUFJRSxzQkFBUTtBQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQXdCRTtBQUNFLG1CQUFTLEVBQUMsdUJBRFo7QUFFRSxpQkFBTyxFQUFHZCxDQUFELElBQU9ELG1CQUFtQixDQUFDQyxDQUFELENBRnJDO0FBQUEsb0JBSUdmLFFBQVEsZ0JBQUcscUVBQUMsbUVBQUQ7QUFBa0IsZ0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFILEdBQW9DO0FBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeEJGLGVBOEJFO0FBQUcsbUJBQVMsRUFBQyxvQkFBYjtBQUFrQyxpQkFBTyxFQUFHZSxDQUFELElBQU8rQixZQUFZLENBQUMvQixDQUFELENBQTlEO0FBQUEsb0JBQ0daLFFBQVEsZ0JBQUcscUVBQUMsbUVBQUQ7QUFBa0IsZ0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFILEdBQW9DO0FBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOUJGLGVBaUNFO0FBQUssbUJBQVMsRUFBQyxxQkFBZjtBQUFBLGlDQUNFO0FBQUEsdUJBQ0dFLFFBQVEsZ0JBQ1AscUVBQUMsbUVBQUQ7QUFBa0Isa0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURPLEdBR1BWLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmdJLFdBQWhCLElBQStCLENBQS9CLGlCQUNFLHFFQUFDLGlFQUFEO0FBQ0UsbUJBQUssRUFBRSxTQURUO0FBRUUsc0JBQVEsRUFBQyxPQUZYO0FBR0UscUJBQU8sRUFBRzVHLENBQUQsSUFBT3lELHVCQUF1QixDQUFDekQsQ0FBRCxDQUh6QztBQUlFLG1CQUFLLEVBQUU7QUFBRTZHLHNCQUFNLEVBQUU7QUFBVjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTE4sRUFhR3ZILFFBQVEsZ0JBQ1AscUVBQUMsbUVBQUQ7QUFBa0Isa0JBQUksRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURPLEdBR1BWLE9BQU8sQ0FBQ0EsT0FBUixDQUFnQmdJLFdBQWhCLElBQStCLENBQS9CLGlCQUNFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssRUFBRSxXQURUO0FBRUUsc0JBQVEsRUFBQyxPQUZYO0FBR0UscUJBQU8sRUFBRzVHLENBQUQsSUFBTzRELHdCQUF3QixDQUFDNUQsQ0FBRCxDQUgxQztBQUlFLG1CQUFLLEVBQUU7QUFBRTZHLHNCQUFNLEVBQUU7QUFBVjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBakJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRjtBQUFBLG9CQURGO0FBNEVELEdBN0VELE1BNkVPO0FBQ0wsd0JBQ0U7QUFBSyxlQUFTLEVBQUMsNkJBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsdUJBQWY7QUFBQSxnQ0FDRTtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBSyxxQkFBUyxFQUFDLG9CQUFmO0FBQUEsb0NBQ0U7QUFDRSx1QkFBUyxFQUFDLElBRFo7QUFFRSxxQkFBTyxFQUFHN0csQ0FBRCxJQUFPK0QscUJBQXFCLENBQUMvRCxDQUFELENBRnZDO0FBQUEscUNBSUU7QUFBRyx5QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFPRTtBQUNFLHVCQUFTLEVBQUMsTUFEWjtBQUVFLHFCQUFPLEVBQUdBLENBQUQsSUFBT2lFLHFCQUFxQixDQUFDakUsQ0FBRCxDQUZ2QztBQUFBLHFDQUlFO0FBQUcseUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGLGVBYUU7QUFDRSx1QkFBUyxFQUFDLGNBRFo7QUFFRSxrQkFBSSxFQUFDLE1BRlA7QUFHRSx5QkFBVyxFQUFFYyxRQUhmO0FBSUUsc0JBQVE7QUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUF3QkU7QUFDRSxtQkFBUyxFQUFDLHNCQURaO0FBRUUsY0FBSSxFQUFDLEdBRlA7QUFHRSxpQkFBTyxFQUFHZCxDQUFELElBQU9ELG1CQUFtQixDQUFDQyxDQUFELENBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXhCRixlQStCRTtBQUFLLG1CQUFTLEVBQUMscUJBQWY7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsR0FBUjtBQUFZLG1CQUFPLEVBQUdBLENBQUQsSUFBT3lELHVCQUF1QixDQUFDekQsQ0FBRCxDQUFuRDtBQUFBLG1DQUNFO0FBQUcsdUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBeUNFO0FBQ0UsaUJBQVMsRUFBQyxtQkFEWjtBQUVFLFlBQUksRUFBQyxHQUZQO0FBR0UsZUFBTyxFQUFHQSxDQUFELElBQU8rQixZQUFZLENBQUMvQixDQUFELENBSDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFtREQ7QUFDRixDQXBtQmlDO0FBQUEsVUFFZmxCLHVEQUZlLEVBS2pCRSxxREFMaUIsRUFTbkJTLHVEQVRtQjtBQUFBLEdBQXBDLEMsQ0F1bUJBOztNQXZtQk0wQywyQjtBQXdtQlNBLDBGQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmUwNjY0NDkwZDEzODYwYmNjZTFiLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBhZGRJdGVtLCBnZXRDYXJ0IH0gZnJvbSBcIn4vc3RvcmUvY2FydC9hY3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgZGlzcGxheU5vdGlmaWNhdGlvbiB9IGZyb20gXCJ+L3V0aWxpdGllcy9jb21tb24taGVscGVyc1wiO1xyXG5cclxuY29uc3QgTW9kdWxlRGV0YWlsQWN0aW9uc01vYmlsZSA9ICh7IHByb2R1Y3QgfSkgPT4ge1xyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuICBjb25zdCBSb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBbbG9hZGluZzEsIHNldExvYWRpbmcxXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9hZGluZzIsIHNldExvYWRpbmcyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbG9hZGluZzMsIHNldExvYWRpbmczXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgYXV0aCA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuYXV0aCk7XHJcbiAgY29uc3QgeyBwcm9kdWN0UXVhbnRpdHksIHByb2R1Y3RJZE9mQ29uZmlnLCBvdXRfb2Zfc3RvY2tfc2VsbGluZywgc3RvY2sgfSA9XHJcbiAgICB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLnByb2R1Y3QpO1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRJdGVtVG9DYXJ0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgIGxldCB0b2tlbiA9IHBhcnNlZGF0YT8uYWNjZXNzX3Rva2VuO1xyXG5cclxuICAgIGlmICh1c2VyZGF0YSA9PT0gdW5kZWZpbmVkIHx8IHVzZXJkYXRhID09PSBudWxsKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIgJiZcclxuICAgICAgKHByb2R1Y3RJZE9mQ29uZmlnID09IDAgfHxcclxuICAgICAgICBwcm9kdWN0SWRPZkNvbmZpZyA9PSBudWxsIHx8XHJcbiAgICAgICAgcHJvZHVjdElkT2ZDb25maWcgPT0gdW5kZWZpbmVkKVxyXG4gICAgKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUGxlYXNlIFNlbGVjdCBWYXJpZW50XCIpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMb2FkaW5nMSh0cnVlKTtcclxuICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgdXNlcl9pZDogMSxcclxuICAgICAgICBxdWFudGl0eTogcHJvZHVjdFF1YW50aXR5IHx8IDEsXHJcbiAgICAgICAgY2FydF90eXBlOiBcIndlYlwiLFxyXG4gICAgICAgIGFjY2Vzc190b2tlbjogdG9rZW4sXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBpZiAocHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiKSB7XHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWRPZkNvbmZpZyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmIChvdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiYgc3RvY2sgPD0gMCkge1xyXG4gICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIik7XHJcblxyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5vdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiZcclxuICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5zdG9jayA8PSAwXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBkaXNwbGF5Tm90aWZpY2F0aW9uKFwiZXJyb3JcIiwgXCJFcnJvclwiLCBcIlByb2R1Y3QgT3V0IG9mIFN0b2NrIVwiKTtcclxuXHJcbiAgICAgICAgICBzZXRMb2FkaW5nMihmYWxzZSk7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID1cclxuICAgICAgICBwYXlsb2FkPy5hY2Nlc3NfdG9rZW4gJiZcclxuICAgICAgICAoYXdhaXQgUHJvZHVjdFJlcG9zaXRvcnkuYWRkUHJvZHVjdFRvQ2FydChwYXlsb2FkKSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2VEYXRhICYmIHJlc3BvbnNlRGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgZGlzcGF0Y2goZ2V0Q2FydCgpKTtcclxuXHJcbiAgICAgICAgc2V0TG9hZGluZzEoZmFsc2UpO1xyXG4gICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXHJcbiAgICAgICAgICByZXNwb25zZURhdGEuc3RhdHVzLFxyXG4gICAgICAgICAgcmVzcG9uc2VEYXRhLnN0YXR1cyxcclxuICAgICAgICAgIHJlc3BvbnNlRGF0YS5yZXNwb25zZVxyXG4gICAgICAgICk7XHJcbiAgICAgIH0gZWxzZSBpZiAocmVzcG9uc2VEYXRhICYmIHJlc3BvbnNlRGF0YS5odHRwY29kZSA9PSA0MDApIHtcclxuICAgICAgICBsZXQgZXJyb3IgPSByZXNwb25zZURhdGEuZXJyb3JzO1xyXG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGVycm9yKSkge1xyXG4gICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiXCIsIHZhbHVlLCAyKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgcmVzcG9uc2VEYXRhLm1lc3NhZ2UpO1xyXG4gICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUJ1eW5vdyA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBpZiAoYXV0aC5pc0xvZ2dlZEluICE9PSB0cnVlKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIgJiZcclxuICAgICAgKHByb2R1Y3RJZE9mQ29uZmlnID09IDAgfHxcclxuICAgICAgICBwcm9kdWN0SWRPZkNvbmZpZyA9PSBudWxsIHx8XHJcbiAgICAgICAgcHJvZHVjdElkT2ZDb25maWcgPT0gdW5kZWZpbmVkKVxyXG4gICAgKSB7XHJcbiAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiUGxlYXNlIFNlbGVjdCBWYXJpZW50XCIpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMb2FkaW5nMih0cnVlKTtcclxuICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgdXNlcl9pZDogMSxcclxuICAgICAgICBxdWFudGl0eTogcHJvZHVjdFF1YW50aXR5IHx8IDEsXHJcbiAgICAgICAgYWNjZXNzX3Rva2VuOiBhdXRoLmFjY2Vzc190b2tlbixcclxuICAgICAgICBjYXJ0X3R5cGU6IFwid2ViXCIsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBpZiAocHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfdHlwZSA9PSBcImNvbmZpZ1wiKSB7XHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWRPZkNvbmZpZyxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmIChvdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiYgc3RvY2sgPD0gMCkge1xyXG4gICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIik7XHJcblxyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Qub3V0X29mX3N0b2NrX3NlbGxpbmcgPT09IGZhbHNlICYmXHJcbiAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Quc3RvY2sgPD0gMFxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJQcm9kdWN0IE91dCBvZiBTdG9jayFcIik7XHJcblxyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG5cclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IFByb2R1Y3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb0NhcnQocGF5bG9hZCk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2VEYXRhLmh0dHBjb2RlID09IDIwMCkge1xyXG4gICAgICAgIGRpc3BsYXlOb3RpZmljYXRpb24oXHJcbiAgICAgICAgICByZXNwb25zZURhdGEuc3RhdHVzLFxyXG4gICAgICAgICAgcmVzcG9uc2VEYXRhLnN0YXR1cyxcclxuICAgICAgICAgIHJlc3BvbnNlRGF0YS5yZXNwb25zZVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICBSb3V0ZXIucHVzaChcIi9hY2NvdW50L2NoZWNrb3V0XCIpO1xyXG4gICAgICAgIH0sIDEwMDApO1xyXG4gICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGlzcGxheU5vdGlmaWNhdGlvbihcImVycm9yXCIsIFwiRXJyb3JcIiwgcmVzcG9uc2VEYXRhLm1lc3NhZ2UpO1xyXG4gICAgICAgIHNldExvYWRpbmcyKGZhbHNlKTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19hY3Rpb25zLW1vYmlsZVwiPlxyXG4gICAgICA8YVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInBzLWJ0biBwcy1idG4tLWJsYWNrXCJcclxuICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvQ2FydChlKX1cclxuICAgICAgPlxyXG4gICAgICAgIEFkZCB0byBjYXJ0XHJcbiAgICAgIDwvYT5cclxuICAgICAgPGEgY2xhc3NOYW1lPVwicHMtYnRuXCIgb25DbGljaz17KGUpID0+IGhhbmRsZUJ1eW5vdyhlKX0+XHJcbiAgICAgICAgQnV5IE5vd1xyXG4gICAgICA8L2E+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTW9kdWxlRGV0YWlsQWN0aW9uc01vYmlsZTtcclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBGYXZvcml0ZSxcclxuICBGYXZvcml0ZUJvcmRlcixcclxuICBBc3Nlc3NtZW50T3V0bGluZWQsXHJcbn0gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29uc1wiO1xyXG5pbXBvcnQge1xyXG4gIGdldFByb2R1Y3RzQnlJZCxcclxuICBzZXRDb25maWdQcm9kdWN0SUQsXHJcbiAgc2V0Q29uZmlnUHJvZHVjdE91dE9mU3RvY2tTZWxsaW5nLFxyXG4gIHNldENvbmZpZ1Byb2R1Y3RTdG9jayxcclxuICBzZXRQcm9kdWN0UXVhbnRpdHlBY3Rpb24sXHJcbiAgdXBkYXRlU2hvY2tpbmdzYWxlV2lzaGxpc3QsXHJcbn0gZnJvbSBcIn4vc3RvcmUvcHJvZHVjdC9hY3Rpb25cIjtcclxuaW1wb3J0IHsgYWRkSXRlbSB9IGZyb20gXCJ+L3N0b3JlL2NhcnQvYWN0aW9uXCI7XHJcbmltcG9ydCB7IGFkZEl0ZW1Ub0NvbXBhcmUgfSBmcm9tIFwifi9zdG9yZS9jb21wYXJlL2FjdGlvblwiO1xyXG5pbXBvcnQge1xyXG4gIGFkZEl0ZW1Ub1dpc2hsaXN0LFxyXG4gIGFkZFNob2NraW5nU2FsZUl0ZW1Ub1dpc2hsaXN0LFxyXG4gIGdldFdpc2hsaXN0TGlzdCxcclxuICByZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0LFxyXG4gIHJlbW92ZVdpc2hsaXN0SXRlbSxcclxufSBmcm9tIFwifi9zdG9yZS93aXNobGlzdC9hY3Rpb25cIjtcclxuXHJcbmltcG9ydCB7IGdldENhcnQgfSBmcm9tIFwifi9zdG9yZS9jYXJ0L2FjdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VEaXNwYXRjaCwgdXNlU2VsZWN0b3IgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBQcm9kdWN0UmVwb3NpdG9yeSBmcm9tIFwifi9yZXBvc2l0b3JpZXMvUHJvZHVjdFJlcG9zaXRvcnlcIjtcclxuaW1wb3J0IHsgQXZhdGFyLCBJbWFnZSwgbm90aWZpY2F0aW9uLCBSYWRpbyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IENpcmN1bGFyUHJvZ3Jlc3MgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgQ29udGFjdHNPdXRsaW5lZCB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnNcIjtcclxuaW1wb3J0IE1vZHVsZURldGFpbFByb2R1Y3RHcm91cCBmcm9tIFwiLi9Nb2R1bGVEZXRhaWxQcm9kdWN0R3JvdXBcIjtcclxuaW1wb3J0IHsgY3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0IH0gZnJvbSBcIn4vdXRpbGl0aWVzL3Byb2R1Y3QtaGVscGVyXCI7XHJcblxyXG5jb25zdCBNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMgPSBSZWFjdC5tZW1vKFxyXG4gICh7IHByb2R1Y3QsIGV4dGVuZGVkID0gZmFsc2UsIHNob2NraW5nc2FsZSA9IGZhbHNlIH0pID0+IHtcclxuICAgIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuICAgIGNvbnN0IFtxdWFudGl0eSwgc2V0UXVhbnRpdHldID0gdXNlU3RhdGUoMSk7XHJcbiAgICBjb25zdCBbd2lzaGxpc3RGcm9tU2VydmVyLCBzZXRXaXNobGlzdEZyb21TZXJ2ZXJdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgUm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBjb25zdCBbbG9hZGluZzEsIHNldExvYWRpbmcxXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nMiwgc2V0TG9hZGluZzJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2xvYWRpbmczLCBzZXRMb2FkaW5nM10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBhdXRoID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5hdXRoKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBZGRJdGVtVG9DYXJ0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLi4uLlwiKVxyXG4gICAgICBsZXQgdXNlcmRhdGEgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGxldCBwYXJzZWRhdGEgPSBKU09OLnBhcnNlKHVzZXJkYXRhKTtcclxuICAgICAgbGV0IHRva2VuID0gcGFyc2VkYXRhPy5hY2Nlc3NfdG9rZW47XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiLi4uMTExLi51c2VyZGF0YS4uLlwiLHVzZXJkYXRhKVxyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uLnBhcnNlZGF0YS4uXCIscGFyc2VkYXRhKVxyXG4gICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4udG9rZW4uLi5cIix0b2tlbilcclxuICAgICAgaWYgKHVzZXJkYXRhID09PSB1bmRlZmluZWQgfHwgdXNlcmRhdGEgPT09IG51bGwpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uLjIyMi4uXCIpXHJcbiAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiUGxlYXNlIGxvZ2luIGZpcnN0XCIsXHJcbiAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgcHJvZHVjdD8ucHJvZHVjdD8ucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIgJiZcclxuICAgICAgICAoZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsID09IFwiXCIgfHxcclxuICAgICAgICAgIGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWwgPT0gXCJcIilcclxuICAgICAgKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLi41NTUuLlwiKVxyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBsZWFzZSBTZWxlY3QgVmFyaWVudFwiLFxyXG4gICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLi4uMTExLi42NjYuLi5cIilcclxuICAgICAgICBzZXRMb2FkaW5nMSh0cnVlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC8vIHVzZXJfaWQ6IDEsXHJcbiAgICAgICAgICBwcmRfYXNzaWduX2lkOlwiXCIsXHJcbiAgICAgICAgICBxdWFudGl0eTogcXVhbnRpdHksXHJcbiAgICAgICAgICBjYXJ0X3R5cGU6IFwid2ViXCIsXHJcbiAgICAgICAgICBhY2Nlc3NfdG9rZW46IHRva2VuLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuLi4xMTEuLjc3Ny4uLlwiKVxyXG4gICAgICAgIGlmIChwcm9kdWN0Py5wcm9kdWN0Py5wcm9kdWN0X3R5cGUgPT0gXCJjb25maWdcIikge1xyXG4gICAgICAgICAgXHJcblxyXG4gICAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgICAgLi4ucGF5bG9hZCxcclxuICAgICAgICAgICAgcHJvZHVjdF9pZDogZ2V0UHJvZHVjdElkKGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWwpLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIGNvbnN0IHsgb3V0X29mX3N0b2NrX3NlbGxpbmcsIHN0b2NrIH0gPSBnZXRPdXRPZnN0b2NrVmFsdWVDb25maWdQcm9kKFxyXG4gICAgICAgICAgICBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGlmIChvdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiYgc3RvY2sgPD0gMCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uODg4OC4uLlwiKVxyXG4gICAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2R1Y3QgT3V0IG9mIFN0b2NrIVwiLFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0TG9hZGluZzEoZmFsc2UpO1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAvL2NvbmRpdGlvbiBmb3IgY29uZmlnIGVuZFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uLjk5OS4uXCIpXHJcbiAgICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIHByb2R1Y3QucHJvZHVjdC5vdXRfb2Zfc3RvY2tfc2VsbGluZyA9PT0gZmFsc2UgJiZcclxuICAgICAgICAgICAgcHJvZHVjdC5wcm9kdWN0LnN0b2NrIDw9IDBcclxuICAgICAgICAgICkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIi4uLjExMS4uMTExMTIyMi4uLlwiKVxyXG4gICAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2R1Y3QgT3V0IG9mIFN0b2NrIVwiLFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0TG9hZGluZzEoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID1cclxuICAgICAgICAgIHBheWxvYWQ/LmFjY2Vzc190b2tlbiAmJlxyXG4gICAgICAgIFxyXG4gICAgICAgICAgKGF3YWl0IFByb2R1Y3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb0NhcnQocGF5bG9hZCkpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2VEYXRhICYmIHJlc3BvbnNlRGF0YS5odHRwY29kZSA9PSBcIjIwMFwiKSB7XHJcbiAgICAgICAgICBsZXQgdG1wID0gcHJvZHVjdDtcclxuICAgICAgICAgIHRtcC5xdWFudGl0eSA9IHF1YW50aXR5O1xyXG4gICAgICAgICAgLy8gZGlzcGF0Y2goYWRkSXRlbSh0bXApKTtcclxuICAgICAgICAgIGRpc3BhdGNoKGdldENhcnQoKSk7XHJcblxyXG4gICAgICAgICAgc2V0TG9hZGluZzEoZmFsc2UpO1xyXG4gICAgICAgICAgbm90aWZpY2F0aW9uW3Jlc3BvbnNlRGF0YS5zdGF0dXNdKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogcmVzcG9uc2VEYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZURhdGEucmVzcG9uc2UsXHJcbiAgICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgUm91dGVyLnB1c2goXCIvYWNjb3VudC9zaG9wcGluZy1jYXJ0XCIpO1xyXG4gICAgICAgICAgfSwgMjAwKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbm90aWZpY2F0aW9uW1wiZXJyb3JcIl0oe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZURhdGEubWVzc2FnZSxcclxuICAgICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldExvYWRpbmcxKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQnV5bm93ID0gYXN5bmMgKGUpID0+IHtcclxuICAgICAgaWYgKGF1dGguaXNMb2dnZWRJbiAhPT0gdHJ1ZSkge1xyXG4gICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBsZWFzZSBsb2dpbiBmaXJzdFwiLFxyXG4gICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAgIHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X3R5cGUgPT0gXCJjb25maWdcIiAmJlxyXG4gICAgICAgIChmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTZWwgPT0gXCJcIiB8fFxyXG4gICAgICAgICAgZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2l6ZVNlbCA9PSBcIlwiKVxyXG4gICAgICApIHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgU2VsZWN0IFZhcmllbnRcIixcclxuICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRMb2FkaW5nMih0cnVlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC8vIHVzZXJfaWQ6IDEsXHJcbiAgICAgICAgICBwcmRfYXNzaWduX2lkOlwiXCIsXHJcbiAgICAgICAgICBxdWFudGl0eTogcXVhbnRpdHksXHJcbiAgICAgICAgICBhY2Nlc3NfdG9rZW46IGF1dGguYWNjZXNzX3Rva2VuLFxyXG4gICAgICAgICAgY2FydF90eXBlOiBcIndlYlwiLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCIpIHtcclxuICAgICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGdldFByb2R1Y3RJZChmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsKSxcclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgY29uc3QgeyBvdXRfb2Zfc3RvY2tfc2VsbGluZywgc3RvY2sgfSA9IGdldE91dE9mc3RvY2tWYWx1ZUNvbmZpZ1Byb2QoXHJcbiAgICAgICAgICAgIGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWxcclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgaWYgKG91dF9vZl9zdG9ja19zZWxsaW5nID09PSBmYWxzZSAmJiBzdG9jayA8PSAwKSB7XHJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvZHVjdCBPdXQgb2YgU3RvY2shXCIsXHJcbiAgICAgICAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nMihmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgcHJvZHVjdC5wcm9kdWN0Lm91dF9vZl9zdG9ja19zZWxsaW5nID09PSBmYWxzZSAmJlxyXG4gICAgICAgICAgICBwcm9kdWN0LnByb2R1Y3Quc3RvY2sgPD0gMFxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbltcImVycm9yXCJdKHtcclxuICAgICAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvZHVjdCBPdXQgb2YgU3RvY2shXCIsXHJcbiAgICAgICAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nMihmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IFByb2R1Y3RSZXBvc2l0b3J5LmFkZFByb2R1Y3RUb0NhcnQocGF5bG9hZCk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZURhdGEuaHR0cGNvZGUgPT0gMjAwKSB7XHJcbiAgICAgICAgICBsZXQgdG1wID0gcHJvZHVjdDtcclxuICAgICAgICAgIHRtcC5xdWFudGl0eSA9IHF1YW50aXR5O1xyXG4gICAgICAgICAgbm90aWZpY2F0aW9uW3Jlc3BvbnNlRGF0YS5zdGF0dXNdKHtcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IHJlc3BvbnNlRGF0YS5yZXNwb25zZSxcclxuICAgICAgICAgICAgZHVyYXRpb246IDEsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIC8vIGRpc3BhdGNoKGFkZEl0ZW0odG1wKSk7XHJcbiAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgUm91dGVyLnB1c2goXCIvYWNjb3VudC9jaGVja291dFwiKTtcclxuICAgICAgICAgIH0sIDEwMDApO1xyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IHJlc3BvbnNlRGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICBkdXJhdGlvbjogMSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0TG9hZGluZzIoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBZGRJdGVtVG9Db21wYXJlID0gKGUpID0+IHtcclxuICAgICAgZGlzcGF0Y2goYWRkSXRlbVRvQ29tcGFyZShwcm9kdWN0KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUFkZEl0ZW1Ub1dpc2hsaXN0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgXHJcbiAgICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgICBsZXQgdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgICAgaWYgKHVzZXJkYXRhID09PSB1bmRlZmluZWQgfHwgdXNlcmRhdGEgPT09IG51bGwpIHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgbG9naW4gZmlyc3RcIixcclxuICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoc2hvY2tpbmdzYWxlID09IHRydWUpIHtcclxuICAgICAgICAgIGRpc3BhdGNoKGFkZFNob2NraW5nU2FsZUl0ZW1Ub1dpc2hsaXN0KHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X2lkKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwibGxsbGwuLi4uLi4uLi4ubGwuLi4uXCIscHJvZHVjdC5wcm9kdWN0LnByb2R1Y3RfaWQpXHJcbiAgICAgICAgICBkaXNwYXRjaChhZGRJdGVtVG9XaXNobGlzdChwcm9kdWN0LnByb2R1Y3QucHJvZHVjdF9pZCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZW1vdmVXaXNoTGlzdEl0ZW0gPSAoKSA9PiB7XHJcbiAgICAgIGxldCB1c2VyZGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgICAgbGV0IHBhcnNlZGF0YSA9IEpTT04ucGFyc2UodXNlcmRhdGEpO1xyXG4gICAgICBsZXQgdG9rZW4gPSBwYXJzZWRhdGE/LmFjY2Vzc190b2tlbjtcclxuICAgICAgaWYgKHVzZXJkYXRhID09PSB1bmRlZmluZWQgfHwgdXNlcmRhdGEgPT09IG51bGwpIHtcclxuICAgICAgICBub3RpZmljYXRpb25bXCJlcnJvclwiXSh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQbGVhc2UgbG9naW4gZmlyc3RcIixcclxuICAgICAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoc2hvY2tpbmdzYWxlID09IHRydWUpIHtcclxuICAgICAgICAgIGRpc3BhdGNoKFxyXG4gICAgICAgICAgICByZW1vdmVTaG9ja2luZ1NhbGVJdGVtRnJvbVdpc2hsaXN0KHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X2lkKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZGlzcGF0Y2gocmVtb3ZlV2lzaGxpc3RJdGVtKHByb2R1Y3QucHJvZHVjdC5wcm9kdWN0X2lkKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUluY3JlYXNlSXRlbVF0eSA9IChlKSA9PiB7XHJcbiAgICAgIHNldFF1YW50aXR5KHF1YW50aXR5ICsgMSk7XHJcbiAgICAgIGRpc3BhdGNoKHNldFByb2R1Y3RRdWFudGl0eUFjdGlvbihxdWFudGl0eSArIDEpKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRGVjcmVhc2VJdGVtUXR5ID0gKGUpID0+IHtcclxuICAgICAgaWYgKHF1YW50aXR5ID4gMSkge1xyXG4gICAgICAgIHNldFF1YW50aXR5KHF1YW50aXR5IC0gMSk7XHJcbiAgICAgICAgZGlzcGF0Y2goc2V0UHJvZHVjdFF1YW50aXR5QWN0aW9uKHF1YW50aXR5IC0gMSkpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IFthc3NvY2lhdGl2ZVByb2QsIHNldEFzc29jaWF0aXZlUHJvZF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbdW5pcXVlQXNzb2NpYXRpdmVQcm9kLCBzZXRVbmlxdWVBc3NvY2lhdGl2ZVByb2RdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAgIGNvbnN0IFtmaWx0ZXJBc3NvY1Byb2QsIHNldEZpbHRlckFzc29jUHJvZF0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgIGFzc29jVmFsOiBcIlwiLFxyXG4gICAgICBhc3NvY1ZhbFNlbDogXCJcIixcclxuICAgICAgYXNzb2NWYWxTaXplOiBcIlwiLFxyXG4gICAgICBhc3NvY1ZhbFNpemVTZWw6IFwiXCIsXHJcbiAgICAgIGFzc29jUHJvZElkOiBcIlwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgc2V0QXNzb2NpYXRpdmVQcm9kKHByb2R1Y3Q/LmFzc29jaWF0aXZlX3Byb2R1Y3RzKTtcclxuICAgICAgbGV0IGFycmF5VmFscyA9IFtcclxuICAgICAgICAuLi5uZXcgTWFwKFxyXG4gICAgICAgICAgcHJvZHVjdD8uYXNzb2NpYXRpdmVfcHJvZHVjdHM/Lm1hcCgoaXRlbSkgPT4gW1xyXG4gICAgICAgICAgICBpdGVtW1wiYXR0cl92YWx1ZVwiXSxcclxuICAgICAgICAgICAgaXRlbSxcclxuICAgICAgICAgIF0pXHJcbiAgICAgICAgKS52YWx1ZXMoKSxcclxuICAgICAgXTtcclxuICAgICAgc2V0VW5pcXVlQXNzb2NpYXRpdmVQcm9kKGFycmF5VmFscyk7XHJcbiAgICB9LCBbcHJvZHVjdF0pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZUF0dHIgPSAoZSkgPT4ge1xyXG4gICAgICBzZXRGaWx0ZXJBc3NvY1Byb2QoeyAuLi5maWx0ZXJBc3NvY1Byb2QsIGFzc29jVmFsU2VsOiBlLnRhcmdldC52YWx1ZSB9KTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZ2V0UHJvZHVjdElkKGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWwpO1xyXG4gICAgICB9LCAxMDAwKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2hhbmdlQXR0clNpemUgPSAoZSkgPT4ge1xyXG4gICAgICBzZXRGaWx0ZXJBc3NvY1Byb2Qoe1xyXG4gICAgICAgIC4uLmZpbHRlckFzc29jUHJvZCxcclxuICAgICAgICBhc3NvY1ZhbFNpemVTZWw6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgZ2V0UHJvZHVjdElkKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgfSwgMTAwMCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHJlbmRlckFzc29jaWF0aXZlUHJvZHVjdCA9ICgpID0+IHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBzLXByb2R1Y3RfX2dyb3VwcGVkXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidGFibGUgdGFibGUtYm9yZGVybGVzc1wiPlxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNTAwLFxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMjAlXCIsXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHthc3NvY2lhdGl2ZVByb2RbMF0/LmF0dHJfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgIDxSYWRpby5Hcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZUF0dHJ9XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtmaWx0ZXJBc3NvY1Byb2Q/LmFzc29jVmFsfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3VuaXF1ZUFzc29jaWF0aXZlUHJvZD8ubWFwKChhdHRyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthdHRyLmF0dHJfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxBdmF0YXIgc3JjPXthdHRyLmltYWdlfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1JhZGlvLkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvUmFkaW8uR3JvdXA+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPjwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsID8gKFxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNTAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwibGFyZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjIwJVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7YXNzb2NpYXRpdmVQcm9kWzBdPy5zdWJfYXR0cmlidXRlc1swXT8uYXR0cl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhZGlvLkdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlQXR0clNpemV9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Fzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAocHJvZCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2QuYXR0cl92YWx1ZS50b0xvd2VyQ2FzZSgpID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/Lm1hcCgoYXR0cikgPT4gYXR0ci5zdWJfYXR0cmlidXRlc1swXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPy5tYXAoKHZhbHVlcywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvLkJ1dHRvbiB2YWx1ZT17dmFsdWVzLmF0dHJfdmFsdWV9IGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWVzLmF0dHJfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1JhZGlvLkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApIDogbnVsbH1cclxuXHJcbiAgICAgICAgICAgICAge2ZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWwgPyAoXHJcbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPXtyZW5kZXJQcmljZSgpICE9PSB1bmRlZmluZWQgPyBgYCA6IGBkLW5vbmVgfT5cclxuICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDUwMCxcclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIyMCVcIixcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUHJpY2U6XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA0MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCJsYXJnZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVuY3lIZWxwZXJDb252ZXJ0VG9SaW5nZ2l0KHJlbmRlclByaWNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZW5kZXJQcmljZSA9ICgpID0+IHtcclxuICAgICAgLy8gY29uc3QgcHJpY2UgPSBhc3NvY2lhdGl2ZVByb2RcclxuICAgICAgLy8gICA/LmZpbHRlcigocHJvZCkgPT4gcHJvZC5hdHRyX3ZhbHVlID09IGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNlbClbMF1cclxuICAgICAgLy8gICA/LnN1Yl9hdHRyaWJ1dGVzPy5maWx0ZXIoXHJcbiAgICAgIC8vICAgICAoYXR0cikgPT4gYXR0ci5hdHRyX3ZhbHVlID09IGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWxcclxuICAgICAgLy8gICApWzBdPy5hY3R1YWxfcHJpY2U7XHJcblxyXG4gICAgICBjb25zdCBwcmljZSA9IGFzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgID8uZmlsdGVyKChwcm9kKSA9PiBwcm9kLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsKVxyXG4gICAgICAgID8ubWFwKChhdHRyKSA9PiBhdHRyLnN1Yl9hdHRyaWJ1dGVzWzBdKVxyXG4gICAgICAgID8uZmlsdGVyKFxyXG4gICAgICAgICAgKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTaXplU2VsXHJcbiAgICAgICAgKVswXT8uYWN0dWFsX3ByaWNlO1xyXG5cclxuICAgICAgY29uc3QgcHJvZF9zYWxlX3ByaWNlID0gYXNzb2NpYXRpdmVQcm9kXHJcbiAgICAgICAgPy5maWx0ZXIoKHByb2QpID0+IHByb2QuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTZWwpXHJcbiAgICAgICAgPy5tYXAoKGF0dHIpID0+IGF0dHIuc3ViX2F0dHJpYnV0ZXNbMF0pXHJcbiAgICAgICAgPy5maWx0ZXIoXHJcbiAgICAgICAgICAoYXR0cikgPT4gYXR0ci5hdHRyX3ZhbHVlID09IGZpbHRlckFzc29jUHJvZC5hc3NvY1ZhbFNpemVTZWxcclxuICAgICAgICApWzBdPy5zYWxlX3ByaWNlO1xyXG5cclxuICAgICAgaWYgKHByb2Rfc2FsZV9wcmljZSAhPT0gZmFsc2UpIHtcclxuICAgICAgICByZXR1cm4gcHJvZF9zYWxlX3ByaWNlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJldHVybiBwcmljZTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBnZXRPdXRPZnN0b2NrVmFsdWVDb25maWdQcm9kID0gKHNpemVWYWx1ZSkgPT4ge1xyXG4gICAgICBjb25zdCBvdXRfb2Zfc3RvY2tfc2VsbGluZyA9IGFzc29jaWF0aXZlUHJvZFxyXG4gICAgICAgID8uZmlsdGVyKChwcm9kKSA9PiBwcm9kLmF0dHJfdmFsdWUgPT0gZmlsdGVyQXNzb2NQcm9kLmFzc29jVmFsU2VsKVxyXG4gICAgICAgID8ubWFwKChhdHRyKSA9PiBhdHRyLnN1Yl9hdHRyaWJ1dGVzWzBdKVxyXG4gICAgICAgID8uZmlsdGVyKFxyXG4gICAgICAgICAgKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBzaXplVmFsdWVcclxuICAgICAgICApWzBdPy5vdXRfb2Zfc3RvY2tfc2VsbGluZztcclxuXHJcbiAgICAgIGNvbnN0IHN0b2NrID0gYXNzb2NpYXRpdmVQcm9kXHJcbiAgICAgICAgPy5maWx0ZXIoKHByb2QpID0+IHByb2QuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTZWwpXHJcbiAgICAgICAgPy5tYXAoKGF0dHIpID0+IGF0dHIuc3ViX2F0dHJpYnV0ZXNbMF0pXHJcbiAgICAgICAgPy5maWx0ZXIoKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBzaXplVmFsdWUpWzBdPy5zdG9jaztcclxuXHJcbiAgICAgIHJldHVybiB7IHN0b2NrLCBvdXRfb2Zfc3RvY2tfc2VsbGluZyB9O1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBnZXRQcm9kdWN0SWQgPSAoc2l6ZVZhbHVlKSA9PiB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkUHJvZHVjdElEID0gYXNzb2NpYXRpdmVQcm9kXHJcbiAgICAgICAgPy5maWx0ZXIoKHByb2QpID0+IHByb2QuYXR0cl92YWx1ZSA9PSBmaWx0ZXJBc3NvY1Byb2QuYXNzb2NWYWxTZWwpXHJcbiAgICAgICAgPy5tYXAoKGF0dHIpID0+IGF0dHIuc3ViX2F0dHJpYnV0ZXNbMF0pXHJcbiAgICAgICAgPy5maWx0ZXIoKGF0dHIpID0+IGF0dHIuYXR0cl92YWx1ZSA9PSBzaXplVmFsdWUpWzBdPy5wcm9kdWN0X2lkO1xyXG4gICAgICBjb25zdCB7IHN0b2NrLCBvdXRfb2Zfc3RvY2tfc2VsbGluZyB9ID1cclxuICAgICAgICBnZXRPdXRPZnN0b2NrVmFsdWVDb25maWdQcm9kKHNpemVWYWx1ZSk7XHJcblxyXG4gICAgICBkaXNwYXRjaChzZXRDb25maWdQcm9kdWN0SUQoc2VsZWN0ZWRQcm9kdWN0SUQpKTtcclxuICAgICAgZGlzcGF0Y2goc2V0Q29uZmlnUHJvZHVjdFN0b2NrKHN0b2NrKSk7XHJcbiAgICAgIGRpc3BhdGNoKHNldENvbmZpZ1Byb2R1Y3RPdXRPZlN0b2NrU2VsbGluZyhvdXRfb2Zfc3RvY2tfc2VsbGluZykpO1xyXG5cclxuICAgICAgcmV0dXJuIHNlbGVjdGVkUHJvZHVjdElEO1xyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWV4dGVuZGVkICYmIHByb2R1Y3QucHJvZHVjdCkge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7cHJvZHVjdD8ucHJvZHVjdD8ucHJvZHVjdF90eXBlID09IFwiY29uZmlnXCJcclxuICAgICAgICAgICAgPyByZW5kZXJBc3NvY2lhdGl2ZVByb2R1Y3QoKVxyXG4gICAgICAgICAgICA6IG51bGx9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19zaG9wcGluZ1wiPlxyXG4gICAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICAgIDxmaWdjYXB0aW9uPlF1YW50aXR5PC9maWdjYXB0aW9uPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC0tbnVtYmVyXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVwXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZUluY3JlYXNlSXRlbVF0eShlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtcGx1c1wiPjwvaT5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkb3duXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZURlY3JlYXNlSXRlbVF0eShlKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtbWludXNcIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2xcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtxdWFudGl0eX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZmlndXJlPlxyXG4gICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLWJ0biBwcy1idG4tLXllbGxvd1wiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZUFkZEl0ZW1Ub0NhcnQoZSl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7bG9hZGluZzEgPyA8Q2lyY3VsYXJQcm9ncmVzcyBzaXplPXsyMH0gLz4gOiBcIkFkZCB0byBjYXJ0XCJ9XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHMtYnRuIHBzLWJ0bi0tYmx1XCIgb25DbGljaz17KGUpID0+IGhhbmRsZUJ1eW5vdyhlKX0+XHJcbiAgICAgICAgICAgICAge2xvYWRpbmcyID8gPENpcmN1bGFyUHJvZ3Jlc3Mgc2l6ZT17MjB9IC8+IDogXCJCdXkgTm93XCJ9XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPGE+XHJcbiAgICAgICAgICAgICAgICB7bG9hZGluZzMgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhclByb2dyZXNzIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgcHJvZHVjdC5wcm9kdWN0LmluX3dpc2hsaXN0ID09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxGYXZvcml0ZUJvcmRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1wiaW5oZXJpdFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvV2lzaGxpc3QoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjdXJzb3I6IFwicG9pbnRlclwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtsb2FkaW5nMyA/IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyUHJvZ3Jlc3Mgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICBwcm9kdWN0LnByb2R1Y3QuaW5fd2lzaGxpc3QgPT0gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEZhdm9yaXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17XCJzZWNvbmRhcnlcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVJlbW92ZVdpc2hMaXN0SXRlbShlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGN1cnNvcjogXCJwb2ludGVyXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICB7LyogPGEgb25DbGljaz17KGUpID0+IGhhbmRsZUFkZEl0ZW1Ub0NvbXBhcmUoZSl9PlxyXG4gICAgICAgICAgICA8QXNzZXNzbWVudE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgZm9udFNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgY3Vyc29yOiBcInBvaW50ZXJcIiB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9hPiAqL31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICAgKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19zaG9wcGluZyBleHRlbmRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHMtcHJvZHVjdF9fYnRuLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxmaWd1cmU+XHJcbiAgICAgICAgICAgICAgPGZpZ2NhcHRpb24+UXVhbnRpdHk8L2ZpZ2NhcHRpb24+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLS1udW1iZXJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidXBcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlSW5jcmVhc2VJdGVtUXR5KGUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1wbHVzXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRvd25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlRGVjcmVhc2VJdGVtUXR5KGUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1taW51c1wiPjwvaT5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbFwiXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3F1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHMtYnRuIHBzLWJ0bi0tYmxhY2tcIlxyXG4gICAgICAgICAgICAgIGhyZWY9XCIjXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvQ2FydChlKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEFkZCB0byBjYXJ0XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcy1wcm9kdWN0X19hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQWRkSXRlbVRvV2lzaGxpc3QoZSl9PlxyXG4gICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiaWNvbi1oZWFydFwiPjwvaT5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgey8qIDxhIGhyZWY9XCIjXCIgb25DbGljaz17KGUpID0+IGhhbmRsZUFkZEl0ZW1Ub0NvbXBhcmUoZSl9PlxyXG4gICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImljb24tY2hhcnQtYmFyc1wiPjwvaT5cclxuICAgICAgICAgICAgPC9hPiAqL31cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBzLWJ0biB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgaHJlZj1cIiNcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gaGFuZGxlQnV5bm93KGUpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBCdXkgTm93XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG4pO1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgY29ubmVjdCgoc3RhdGUpID0+IHN0YXRlKShNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnMpO1xyXG5leHBvcnQgZGVmYXVsdCBNb2R1bGVEZXRhaWxTaG9wcGluZ0FjdGlvbnM7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=